@echo off
chcp 65001 >nul
title Kaelo Local Deploy — Step 1: Install Dependencies
echo ============================================================
echo   Kaelo Local Deploy Package — Dependency Installer
echo ============================================================
echo.
echo This script will:
echo   1. Check Python installation
echo   2. Create a virtual environment
echo   3. Install all required packages
echo   4. Verify the installation
echo.
echo Estimated time: 1-3 minutes (depending on network)
echo ============================================================
echo.

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

:: Step 1: Check Python
echo [1/4] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo   [ERROR] Python not found!
    echo.
    echo   Please install Python 3.11 or later:
    echo   1. Visit https://www.python.org/downloads/
    echo   2. Download Python 3.11.x Windows installer (64-bit)
    echo   3. Run installer and CHECK "Add Python to PATH"
    echo   4. Re-run this script after installation
    echo.
    pause
    exit /b 1
)

for /f "tokens=2" %%a in ('python --version') do echo   Found Python %%a
echo.

:: Step 2: Create virtual environment
echo [2/4] Creating virtual environment...
if exist "venv" (
    echo   venv already exists, skipping creation.
) else (
    python -m venv venv
    echo   venv created successfully.
)
echo.

:: Step 3: Install dependencies
echo [3/4] Installing dependencies (this may take 1-3 minutes)...
set "PIP=%SCRIPT_DIR%venv\Scripts\pip.exe"
set "PYTHON=%SCRIPT_DIR%venv\Scripts\python.exe"

"%PIP%" install --upgrade pip -q
"%PIP%" install -r requirements.txt

if errorlevel 1 (
    echo.
    echo   [ERROR] Installation failed!
    echo   Possible causes:
    echo   - Network issue (try again or use mobile hotspot)
    echo   - Python version incompatible (need 3.11+)
    echo.
    pause
    exit /b 1
)

echo   All dependencies installed successfully.
echo.

:: Step 4: Verify
echo [4/4] Verifying installation...
"%PYTHON%" -c "import fastapi, uvicorn, requests, numpy; print('Core packages OK')"
if errorlevel 1 (
    echo   [WARNING] Some packages may not be installed correctly.
    echo   You can try running this script again.
    pause
    exit /b 1
)

echo   Verification passed!
echo.
echo ============================================================
echo   Installation complete! Next step:
echo   Double-click [2-start.bat] to launch services.
echo ============================================================
timeout /t 3 /nobreak >nul
