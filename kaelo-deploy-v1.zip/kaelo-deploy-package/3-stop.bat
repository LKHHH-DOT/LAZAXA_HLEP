@echo off
chcp 65001 >nul
title Kaelo Local Deploy — Stop Services
echo ============================================================
echo   Kaelo Local Deploy Package — Service Stopper
echo ============================================================
echo.

:: Kill backend (uvicorn on port 8000)
echo [1/2] Stopping Kaelo backend (port 8000)...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8000" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
    echo   Process %%a stopped.
)

:: Kill MCP Server (port 8765)
echo [2/2] Stopping MCP Server (port 8765)...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8765" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
    echo   Process %%a stopped.
)

echo.
echo ============================================================
echo   All services stopped.
echo ============================================================
timeout /t 2 /nobreak >nul
