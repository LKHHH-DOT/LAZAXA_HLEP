@echo off
chcp 65001 >nul
title Kaelo Local Deploy — Step 2: Start Services
echo ============================================================
echo   Kaelo Local Deploy Package — Service Launcher
echo ============================================================
echo.

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

:: Check virtual environment
if not exist "venv\Scripts\python.exe" (
    echo   [ERROR] Virtual environment not found!
    echo   Please run [1-install.bat] first.
    pause
    exit /b 1
)

set "PYTHON=%SCRIPT_DIR%venv\Scripts\python.exe"

:: Check if already running
echo [1/3] Checking existing services...
curl -s -o nul -w "%%{http_code}" http://127.0.0.1:8000/health > %temp%\kaelo_check.txt 2>nul
set /p KAELO_CODE=<%temp%\kaelo_check.txt
del %temp%\kaelo_check.txt >nul 2>&1

if "%KAELO_CODE%"=="200" (
    echo   Kaelo backend already running on port 8000.
) else (
    echo   Starting Kaelo backend...
    start "Kaelo Backend" cmd /k "cd /d %SCRIPT_DIR% && %PYTHON% -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --log-level info"
    timeout /t 3 /nobreak >nul
)

curl -s -o nul -w "%%{http_code}" http://127.0.0.1:8765/health > %temp%\mcp_check.txt 2>nul
set /p MCP_CODE=<%temp%\mcp_check.txt
del %temp%\mcp_check.txt >nul 2>&1

if "%MCP_CODE%"=="200" (
    echo   MCP Server already running on port 8765.
) else (
    echo   Starting MCP Server...
    start "Kaelo MCP" cmd /k "cd /d %SCRIPT_DIR% && %PYTHON% mcp_server.py --http --port 8765"
    timeout /t 3 /nobreak >nul
)

echo.
echo [2/3] Waiting for services to be ready...
timeout /t 5 /nobreak >nul

:: Verify
echo [3/3] Verifying services...
curl -s http://127.0.0.1:8000/health >nul 2>&1
if errorlevel 1 (
    echo   [WARNING] Backend may not be fully ready yet.
    echo   Wait a few more seconds and check http://127.0.0.1:8000/docs
) else (
    echo   Backend: READY  ^(http://127.0.0.1:8000/docs^)
)

curl -s http://127.0.0.1:8765/health >nul 2>&1
if errorlevel 1 (
    echo   [WARNING] MCP Server may not be fully ready yet.
) else (
    echo   MCP Server: READY  ^(http://127.0.0.1:8765/health^)
)

echo.
echo ============================================================
echo   Services launched!
echo.
echo   Keep these command windows open while using Kaelo.
echo   Close this window will NOT stop the services.
echo   Run [3-stop.bat] when you want to shut down.
echo ============================================================
pause
