# -*- coding: utf-8 -*-
"""Lazaxa 手机事件反连（C批1 · 设备通知/电量 → 桌面提醒）。

概念：借 adb 反向通道的思路——手机/设备上的事件"主动流向桌面"，而不是等用户
开口问。实现 = 桌面侧后台轮询 adb（同一台电脑管设备，见 tools/adb.py 定位），
从设备读两块信息：
  1. 电量：`adb shell dumpsys battery`（level/status/plugged）
  2. 通知：`adb shell dumpsys notification --noredact`（活跃通知 pkg/title/text）

产物：新增事件写入 phone_events 表（ev_key 去重幂等），由 kb_gui 轮询
/api/v1/phone/events 弹窗提醒用户。安静契约（B批3）：无新增静默，不刷日志。

架构：解析/判定是纯函数（可单测）；PhoneMonitor 只持有"上一轮状态"用于去重与
"低电量每放电会话只提醒一次"；真实 adb 执行可注入 runner（默认 subprocess），
测试传 fake runner 即可。DB 写在顶层 scan_and_store()，与判定解耦。
"""
import logging
import re
import time

logger = logging.getLogger("phone")

# ---- 事件常量 ----
KIND_NOTICE = "notice"      # 手机通知
KIND_BATTERY = "battery"    # 低电量等告警
KIND_CHARGE = "charging"    # 充电状态变化（开始充电/充满）

# 通知块分界：dumpsys notification 中每条记录以 "NotificationRecord(" 开头
_RE_RECORD = re.compile(r"NotificationRecord\([^\n]*\n", re.MULTILINE)
# 通知头里的 pkg / id / tag（tag 可能为 null）
_RE_PKG = re.compile(r"\bpkg=(\S+)")
_RE_RID = re.compile(r"\bid=(\d+)")
_RE_TAG = re.compile(r"\btag=(\S+)")
# 记录内明细属性（--noredact 下以单独一行 "属性=值" 输出，值可含空格）
_RE_KEY = re.compile(r"^\s*key=(\S+)\s*$", re.MULTILINE)
_RE_TITLE = re.compile(r"^\s*android\.title=(.*)$", re.MULTILINE)
_RE_TEXT = re.compile(r"^\s*android\.text=(.*)$", re.MULTILINE)
_RE_TICKER = re.compile(r"^\s*tickerText=(.*)$", re.MULTILINE)

# dumpsys battery 属性（顶格属性名，冒号后跟值）
_RE_BAT_ATTR = re.compile(r"^\s*([A-Za-z ]+):\s*(.*)$", re.MULTILINE)

# 电量状态码（Android BatteryManager.BATTERY_STATUS_*）
_STATUS_CHARGING = 2
_STATUS_DISCHARGING = 3
_STATUS_NOT_CHARGING = 4
_STATUS_FULL = 5


def _clean_text(raw: str) -> str:
    """清洗 dumpsys 单条字段值，剥厂商壳/空字面量（真机 vivo PD2121C 实测坑）。

    vivo/OriginOS 把 CharSequence 序列化成 `String (实际内容)`；`android.title=null`
    或 `android.text=null` 是字面字符串而非空。统一处理：
    `String (...)` 剥最外层括号取内容（嵌套括号安全），`null`（大小写不敏感）
    与纯空白归一为空串——保证"没内容"的通知不会被当成有内容弹窗。
    """
    s = (raw or "").strip()
    if not s or s.lower() == "null":
        return ""
    m = re.fullmatch(r"String\s*\((.*)\)", s)
    if m:
        s = m.group(1).strip()
        if not s or s.lower() == "null":
            return ""
    return s


# ============ 纯解析：dumpsys 文本 → 结构 ============

def parse_battery(text: str) -> dict:
    """解析 `adb shell dumpsys battery` 输出 → {level, status, plugged}。

    status 保留数字（2=充电 3=放电 4=未充电 5=充满，可用 phone 常量对照）；
    plugged 汇总 bool（AC/USB/Wireless 任一为 true 即插着电）。
    解析不到关键字段返回 {}（调用方按"不可用"处理，不误报）。
    """
    attrs = {}
    for m in _RE_BAT_ATTR.finditer(text or ""):
        key = m.group(1).strip().lower().replace(" ", "_")
        attrs[key] = m.group(2).strip()
    if "level" not in attrs:
        return {}
    try:
        level = int(float(attrs["level"]))
    except (TypeError, ValueError):
        return {}
    plugged = any(attrs.get(k) == "true"
                  for k in ("ac_powered", "usb_powered", "wireless_powered"))
    try:
        status = int(float(attrs.get("status", 0)))
    except (TypeError, ValueError):
        status = 0
    return {"level": level, "status": status, "plugged": plugged}


def parse_notifications(text: str) -> list:
    """解析 `adb shell dumpsys notification --noredact` 的活跃通知列表。

    只取 "Notification List" 主节（下一个顶格小节的文本之前），逐条
    NotificationRecord 提取 pkg/id/tag/title/text；key 优先取明细 key= 行，
    缺省用 pkg|id|tag 拼（同一通知不同轮输出 key 稳定才可去重）。
    返回 [{key,pkg,title,text}]，正文/标题缺失或整段不可解析时自然跳过。
    """
    raw = text or ""
    # 裁出 Notification List 主节：从该标题行起到下一个顶格小节标题为止
    m = re.search(r"^Notification List[^\n]*$", raw, re.MULTILINE)
    if m:
        head_end = m.end()
        rest = raw[head_end:]
        tail = re.search(r"^[^ \t\n]", rest, re.MULTILINE)
        raw = rest[: tail.start()] if tail else rest
    out = []
    starts = [mm.start() for mm in _RE_RECORD.finditer(raw)]
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(raw)
        chunk = raw[s:e]
        pm = _RE_PKG.search(chunk)
        if not pm:
            continue
        pkg = pm.group(1)
        rid = _RE_RID.search(chunk).group(1) if _RE_RID.search(chunk) else "0"
        tm = _RE_TAG.search(chunk)
        tag = tm.group(1) if tm else "null"
        km = _RE_KEY.search(chunk)
        key = km.group(1) if km else f"{pkg}|{rid}|{tag}"
        def _val(pat):
            mm = pat.search(chunk)
            return mm.group(1).strip() if mm else ""
        title = _clean_text(_val(_RE_TITLE) or _val(_RE_TICKER))
        out.append({"key": key, "pkg": pkg, "title": title[:200],
                    "text": _clean_text(_val(_RE_TEXT))[:500]})
    return out


def has_device(text: str) -> bool:
    """`adb devices -l` 输出是否有可用设备（state=device）。

    行格式：<serial> <state> [product=.. model=.. device=..]（state 是第二列），
    只看 device 态（offline/unauthorized 不算）。
    """
    for line in (text or "").splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            return True
    return False


# ============ 监控器：跨轮状态 + 事件判定 ============

class PhoneMonitor:
    """轮询一次设备状态 → 与上轮比较，产出"需要提醒用户"的新事件。

    状态字段：
      seen    已入库通知的 key 集合（防同一条通知每轮重复弹）
      low_warned  本轮放电会话是否已提醒过低电量（低于阈值只提醒一次，
                  充到阈值以上或开始充电后重置）
      charge_phase 充电会话标识：''=无  'charging'=充电中  'full'=已充满
    tick() 是纯判定（不碰 DB / 网络），新增事件由调用方负责落库。
    """
    def __init__(self, low_pct: int = 20, max_seen: int = 200):
        self.low_pct = low_pct
        self.seen: set[str] = set()
        self._seen_max = max_seen
        self.low_warned = False
        self.charge_phase = ""
        self.battery_last = ""

    # ---- 内部工具 ----
    def _mark_seen(self, key: str) -> None:
        self.seen.add(key)
        if len(self.seen) > self._seen_max:   # 防无限膨胀：只留最近
            self.seen = set(list(self.seen)[-self._seen_max:])

    def _charging_state(self, bat: dict) -> str:
        """由 battery dict 推导充电相位：''=未充电 'charging'=充电中 'full'=已充满。"""
        st = bat.get("status")
        if st == _STATUS_FULL:
            return "full"
        if st in (_STATUS_CHARGING,) and bat.get("plugged"):
            return "charging"
        return ""

    # ---- 主判定 ----
    def tick_battery(self, bat: dict) -> list:
        """电池状态变化 → 事件列表。每次扫描调用，内部自己跨轮去重。"""
        events = []
        if not bat:
            # 电量信息不可用（dumpsys 失败）：重置会话状态，不误报也不刷屏
            self.low_warned = False
            self.charge_phase = ""
            self.battery_last = ""
            return events
        level = bat.get("level", 0)
        phase = self._charging_state(bat)
        snap = f"{level}:{phase}"
        # 电量/相位未变 → 无新事件（安静契约）
        if snap == self.battery_last:
            return events
        self.battery_last = snap

        # --- 充电相位事件 ---
        if phase == "charging" and self.charge_phase != "charging":
            events.append({
                "key": f"battery:charge:{int(time.time())}",
                "kind": KIND_CHARGE, "pkg": "", "level": "info",
                "title": "手机开始充电", "content": f"当前电量 {level}%",
            })
        elif phase == "full" and self.charge_phase != "full":
            events.append({
                "key": f"battery:full:{int(time.time())}",
                "kind": KIND_CHARGE, "pkg": "", "level": "info",
                "title": "手机已充满", "content": f"电量 {level}%，可以拔掉充电器了",
            })
        self.charge_phase = phase

        # --- 低电量：每段"放电会话"只提醒一次 ---
        low = level <= self.low_pct
        if low and not phase and not self.low_warned:
            events.append({
                "key": f"battery:low:{int(time.time())}",
                "kind": KIND_BATTERY, "pkg": "", "level": "warn",
                "title": f"手机电量低（{level}%）",
                "content": f"电量已低于 {self.low_pct}%，记得找充电器。",
            })
            self.low_warned = True
        elif (not low) or phase:
            # 充上电或电量回升 → 解除低电量告警状态
            self.low_warned = False
        return events

    def tick_notifications(self, notifs: list) -> list:
        """活跃通知 → 事件列表（与上轮已见 key 去重）。"""
        events = []
        for n in notifs:
            if not n.get("title") and not n.get("text"):
                continue   # 只有包名没有内容，不打扰用户
            key = n["key"]
            if key in self.seen:
                continue
            self._mark_seen(key)
            events.append({
                "key": key,
                "kind": KIND_NOTICE, "pkg": n.get("pkg", ""), "level": "info",
                "title": n.get("title") or n.get("pkg", "手机通知"),
                "content": n.get("text") or "",
            })
        return events

    def tick(self, device: bool, bat: dict, notifs: list) -> list:
        """整轮判定：设备不可用 → 静默（无事件）；否则电池+通知合并返回。"""
        if not device:
            # 设备断开：重置会话状态，重新连上后低电量/充电事件可再次触发
            self.low_warned = False
            self.charge_phase = ""
            self.battery_last = ""
            return []
        return self.tick_battery(bat) + self.tick_notifications(notifs)


# ============ 顶层执行：真实 adb + 落库 ============

def _real_runner(args: list[str], timeout: int = 20):
    """默认 adb 执行器：subprocess 跑一条 adb 命令 → (ok, text)。"""
    import shutil
    import subprocess
    cmd = shutil.which("adb") or "adb"
    try:
        proc = subprocess.run(
            [cmd] + args, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace")
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False, ""
    return proc.returncode == 0, (proc.stdout or "") + ("\n" + proc.stderr or "")


def fetch_device_state(runner=_real_runner) -> tuple:
    """跑一轮 adb，返回 (device_ok, battery_dict, notifications_list)。

    device_ok=False 表示当前没有可用设备/adb 不可用——调用方整体静默跳过。
    """
    try:
        ok, dev_text = runner(["devices", "-l"])
        if not ok or not has_device(dev_text):
            return False, {}, []
    except Exception:  # noqa: BLE001  adb 进程异常按"无设备"处理
        return False, {}, []
    _, bat_text = runner(["shell", "dumpsys", "battery"])
    _, noti_text = runner(["shell", "dumpsys", "notification", "--noredact"])
    return True, parse_battery(bat_text), parse_notifications(noti_text)


def scan_and_store(low_pct: int = 20, monitor: PhoneMonitor | None = None) -> int:
    """执行一轮"读取设备 → 判定 → 落库"，返回本轮新增入库条数。

    DB 不可用/写入失败只记 warning，不中断轮询（fail-open，同记忆检索口径）。
    """
    from . import db
    mon = monitor or PhoneMonitor(low_pct=low_pct)
    try:
        device, bat, notifs = fetch_device_state()
        events = mon.tick(device, bat, notifs)
    except Exception as e:  # noqa: BLE001
        logger.warning("[phone] 读取设备状态失败（本轮跳过）: %s", e)
        return 0
    added = 0
    for ev in events:
        try:
            if db.add_phone_event(
                    ev_key=ev["key"], kind=ev["kind"], pkg=ev.get("pkg", ""),
                    title=ev.get("title", ""), content=ev.get("content", ""),
                    level=ev.get("level", "info")):
                added += 1
        except Exception as e:  # noqa: BLE001
            logger.warning("[phone] 事件落库失败（key=%s）: %s", ev.get("key"), e)
    if added:
        # 只有真有新事件才 info 一行（B批3 安静契约）
        logger.info("[phone] 新增 %d 条设备事件", added)
    return added


def run_loop(seconds: int = 60, low_pct: int = 20):
    """main.py 后台线程入口：每 seconds 秒轮询一次，异常不影响主流程。"""
    mon = PhoneMonitor(low_pct=low_pct)
    while True:
        try:
            scan_and_store(low_pct=low_pct, monitor=mon)
        except Exception as e:  # noqa: BLE001
            logger.warning("[phone] 轮询失败（不影响主流程）: %s", e)
        time.sleep(seconds)
