# -*- coding: utf-8 -*-
"""对外接口限流（阶段 3 专业化：防 API Key 泄露后刷爆 DeepSeek 账单）。

内存滑动窗口（单进程内生效；将来多 worker 部署时换 Redis 实现）。
按维度独立计数：每个 API Key、每个来源 IP 各维护一个窗口。
"""
import threading
import time
from collections import deque


class _Window:
    """单个维度的滑动窗口计数器（线程安全）。"""

    __slots__ = ("limit", "window_sec", "hits", "lock")

    def __init__(self, limit: int, window_sec: int):
        self.limit = limit
        self.window_sec = window_sec
        self.hits: deque[float] = deque()
        self.lock = threading.Lock()

    def allow(self) -> bool:
        """窗口内尝试放行一次；已超限返回 False。"""
        now = time.monotonic()
        with self.lock:
            while self.hits and self.hits[0] <= now - self.window_sec:
                self.hits.popleft()
            if len(self.hits) >= self.limit:
                return False
            self.hits.append(now)
            return True


class RateLimiter:
    """Key + IP 双维度限流。"""

    def __init__(self, key_limit: int = 30, key_window: int = 60,
                 ip_limit: int = 60, ip_window: int = 60):
        self._windows: dict[str, _Window] = {}
        self._lock = threading.Lock()
        self.key_limit = key_limit
        self.key_window = key_window
        self.ip_limit = ip_limit
        self.ip_window = ip_window

    def _window(self, scope: str, limit: int, window: int) -> _Window:
        with self._lock:
            w = self._windows.get(scope)
            if w is None:
                w = _Window(limit, window)
                self._windows[scope] = w
            return w

    def check(self, key: str | None, ip: str) -> tuple[bool, str]:
        """按 Key 与 IP 各限一次。返回 (是否放行, 拒绝原因)。"""
        if key:
            if not self._window(f"k:{key}", self.key_limit, self.key_window).allow():
                return False, f"API Key 限流：{self.key_limit} 次/{self.key_window}s"
        if not self._window(f"i:{ip}", self.ip_limit, self.ip_window).allow():
            return False, f"IP 限流：{self.ip_limit} 次/{self.ip_window}s"
        return True, ""


# 模块级单例（供路由直接使用）
limiter = RateLimiter()
