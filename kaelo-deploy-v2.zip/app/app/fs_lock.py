# -*- coding: utf-8 -*-
r"""可移植跨进程文件锁（fs_lock · B批3，借 DeerFlow deermem `_process_file_lock`）。

为什么需要：Lazaxa 的"诊断/配置修复/文件型持久化"类操作可能被多个进程同时
触达同一文件——典型是 config doctor 在两个终端里并发跑 `--fix` 补 .env，
若不加锁会互相交错写入。本模块提供纯 stdlib 的 advisory 文件锁，保证同一
路径同一时刻只有一个持有者：

- Windows：msvcrt.locking（锁文件 1 字节区域，LK_NBLCK 非阻塞尝试）
- POSIX：fcntl.flock（LOCK_EX | LOCK_NB）
- 拿不到锁时按 poll_interval 轮询直至 timeout → 抛 TimeoutError；
- 支持 with 语法，退出（含异常）自动释放。

用法：
    from app import fs_lock
    with fs_lock.acquire_lock(r"D:\...\\.env.lock", timeout=5):
        修复/追加写文件...   # 临界区被跨进程串行化

锁文件由调用方自选位置（建议系统临时目录，避免污染工作区/被版本库追踪）。
"""
import os
import time

# 默认：获取锁的超时与轮询间隔（秒）
_DEFAULT_TIMEOUT = 5.0
_POLL_INTERVAL = 0.05


def _os_lock_acquire(handle):
    """对已打开的文件句柄做一次非阻塞排它锁（失败抛 OSError）。"""
    if os.name == "nt":  # Windows：锁 1 字节区域（空文件先垫一个字节）
        import msvcrt

        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
    else:  # POSIX
        import fcntl

        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def _os_lock_release(handle):
    """释放文件锁（文件已关/锁已失效等异常静默忽略）。"""
    try:
        if os.name == "nt":
            import msvcrt

            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass


class FileLock:
    """跨进程 advisory 文件锁（上下文管理器）。

    同一路径只允许一个持有者：第二个 FileLock（无论同进程不同句柄，
    还是跨进程）会在 timeout 秒内轮询等待，超时抛 TimeoutError。
    """

    def __init__(self, path, timeout: float = _DEFAULT_TIMEOUT,
                 poll_interval: float = _POLL_INTERVAL):
        self.path = os.fspath(path)
        self.timeout = float(timeout)
        self._poll = max(0.001, float(poll_interval))
        self._handle = None

    def acquire(self) -> "FileLock":
        """获取锁（阻塞轮询至超时）。已持有则直接返回自身。"""
        if self._handle is not None:
            return self
        parent = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(parent, exist_ok=True)
        handle = open(self.path, "a+b")
        deadline = time.monotonic() + self.timeout
        try:
            while True:
                try:
                    _os_lock_acquire(handle)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError(
                            f"获取文件锁超时（>{self.timeout}s）: {self.path}")
                    time.sleep(self._poll)
            self._handle = handle
        except Exception:
            handle.close()
            raise
        return self

    def release(self):
        """释放锁并关闭文件（未持有则无操作）。"""
        if self._handle is None:
            return
        handle, self._handle = self._handle, None
        try:
            _os_lock_release(handle)
        finally:
            handle.close()

    def __enter__(self) -> "FileLock":
        return self.acquire()

    def __exit__(self, *exc) -> bool:
        self.release()
        return False  # 不吞调用方异常


def acquire_lock(path, timeout: float = _DEFAULT_TIMEOUT) -> FileLock:
    """便捷入口：`with acquire_lock(path): ...` 进入临界区，块结束自动释放。"""
    return FileLock(path, timeout=timeout)
