# -*- coding: utf-8 -*-
"""长期记忆接入层：为对话提供记忆注入与规则式自动沉淀（M3 阶段 3）。

对应 Sanctum/Sanctum定位与技术方案.md 阶段 3（自动记忆管道）：
  - get_memory_context：每轮对话检索相关记忆（排除画像，画像走稳定段），注入系统提示
    （延迟敏感路径：模型已由 main.py 后台预热 + LRU 缓存命中，常规耗时 <100ms）
  - get_profile_block  ：画像稳定段（type=profile 少而稳，每轮常驻注入，L3 层）
  - auto_sink_message ：规则式自动沉淀，识别"记住/别忘了"等记忆意图后写入记忆库
    （P1 借 Agent-Memory：只在最终答复轮由路由调用，存"干净原文"，防记忆反馈环污染）
  - warm_up           ：后台预热嵌入模型，避免首个对话请求冷启动 1-2s

设计约束：
  - 嵌入/检索全程本地（fastembed 离线 + 本机 Qdrant），向量不出网
  - 注入/沉淀路径任何异常都静默降级，绝不影响主对话流程
"""
from functools import lru_cache
import time

from .agent.tools.memory import retrieve, retrieve_recent

# ---- 记忆注入的标准节头（单一来源） ----
# 路由/系统提示按这些头组装注入文本；沉淀剥离时按相同前缀识别注入段，防污染回写。
# 记忆检索段（L1/L2：事件/经验/偏好，随问题动态检索）
MEM_CTX_HEADER = "【长期记忆】（主人之前记住的相关内容，可作参考；与【资料】冲突时以【资料】为准）"
# 画像稳定段（L3：长期画像/稳定身份事实，每轮常驻注入）
MEM_PROFILE_HEADER = "【画像档案】（主人长期稳定的画像/偏好/身份信息，每轮常驻、可作参考）"
# 剥离识别的节头前缀（含 agent 循环里 loop.py 自带的记忆节头）
_STRIP_HEADER_PREFIXES = ("【画像档案】", "【画像】",
                          "【长期记忆】", "【相关长期记忆】")

# 记忆意图关键词（保守集合：宁缺毋滥，避免误记）
_SINK_KEYWORDS = ("记住", "别忘了", "记一下", "给我记住", "牢记",
                  "以后都要", "以后就", "以后用", "以后都")
_MIN_SINK_LEN = 12  # 过短消息易误记，设长度门槛

# 正反馈关键词（用户认可任务完成 → 触发经验沉淀）
_PRAISE_KEYWORDS = ("不错", "很好", "做得好", "做得漂亮", "干得漂亮", "太棒了",
                    "好棒", "棒极了", "厉害", "满意", "完美", "给力",
                    "优秀", "靠谱", "赞", "漂亮")
# 任务完成后多久内的正反馈才有效（秒）：超过视为闲聊，不沉淀
_PRAISE_WINDOW_S = 600
# 同一任务摘要的沉淀防抖窗口（秒）：30 分钟内不重复沉淀
_PRAISE_DEBOUNCE_S = 1800
# 任务摘要过短不沉淀（防把琐碎对话当经验）
_PRAISE_MIN_SUMMARY_LEN = 8
# ---- M4c 失败教训沉淀：只沉淀"行为可改进"的失败终态 ----
# loop_capped=反复同参空转、max_steps=不会拆解/低效不收敛，提炼后供未来同类任务召回；
# error（外部 API/网络故障）与 empty_response（无轨迹无内容）不沉淀，避免噪声。
_LESSON_SINK_STOPS = ("loop_capped", "max_steps")
_LESSON_DEBOUNCE_S = 1800        # 同任务同停因 30 分钟内只沉淀一次
_LESSON_MIN_DESC_LEN = 6         # 任务描述过短不沉淀
_LESSON_PATH_MAX = 12            # 教训里携带的工具序列长度（保留重复以体现空转）
_recent_lesson = {"fp": None, "ts": 0.0}  # 失败沉淀防抖状态

# 最近一次完成的任务（供正反馈沉淀取上下文；线程安全由 GIL + 简单赋值保证）
_recent_task = {"summary": None, "ts": 0.0, "hash": None, "last_sink_ts": 0.0,
                "round_id": ""}


def _fallback_round_id() -> str:
    """chat 路径（无 agent 轮概念）自动沉淀用的溯源 id：chat-<毫秒时间戳>。"""
    return f"chat-{int(time.time() * 1000)}"


@lru_cache(maxsize=256)
def _cached_retrieve(query: str, top_k: int) -> tuple:
    """LRU 缓存检索结果（同 query 不重复计算；返回 tuple 以支持 lru_cache）。"""
    return tuple(retrieve(query, top_k=top_k))


def _fmt_items(items) -> str:
    """把检索条目格式化为注入行（- 文本 [type]）。"""
    lines = []
    for it in items:
        tag = f" [{it['type']}]" if it.get("type") else ""
        lines.append(f"- {it['text']}{tag}")
    return "\n".join(lines)


def _strip_injected_memory(text: str) -> str:
    """剔除文本中夹带的记忆注入段（防止把被注入的旧记忆原样写回记忆库）。

    识别逻辑：行首命中任一记忆节头（【长期记忆】/【画像档案】/【相关长期记忆】…）
    即进入"注入块"；块内以 "- " 开头的记忆条目行一并剔除；遇到空行或普通正文行
    视为块结束。返回剩余文本。
    """
    lines = (text or "").splitlines()
    out = []
    in_block = False
    for ln in lines:
        stripped = ln.strip()
        if not stripped:
            if in_block:
                in_block = False
            out.append(ln)
            continue
        if not in_block and any(stripped.startswith(h)
                                for h in _STRIP_HEADER_PREFIXES):
            in_block = True
            continue
        if in_block and stripped.startswith("- "):
            continue
        in_block = False
        out.append(ln)
    return "\n".join(out).strip()


def get_memory_context(query: str, top_k: int = 3) -> str:
    """检索相关长期记忆（L1/L2：事件/经验/偏好），格式化为注入行。

    画像（type=profile）从本段排除，改由 get_profile_block 稳定段注入，
    避免同一画像在两段重复出现。无命中/失败返回空串。
    """
    if not query or not query.strip():
        return ""
    items = _cached_retrieve(query.strip(), top_k)
    items = [it for it in items if it.get("type") != "profile"]
    if not items:
        return ""
    # M4c：经验/教训（experience）稳定置前（列表前部注意力更强）；
    # sorted 稳定排序，组内保持语义相关度原序，不打乱检索相关度。
    items = sorted(items, key=lambda it: 0 if it.get("type") == "experience" else 1)
    return _fmt_items(items)


def get_profile_block(top_k: int = 2) -> str:
    """画像稳定段：最近 top_k 条 type=profile 常驻注入（画像少、每轮都用）。

    返回裸注入行（节头由调用方按 MEM_PROFILE_HEADER 拼接）；
    画像库为空/不可用返回空串。
    """
    if top_k <= 0:
        return ""
    items = retrieve_recent(type="profile", limit=top_k)
    items = [it for it in items if it.get("type") == "profile"]
    if not items:
        return ""
    return _fmt_items(items)


def auto_sink_message(user_msg: str, source_msg: str | None = None,
                      round_id: str = "") -> bool:
    """规则式自动沉淀：识别"记住/别忘了"等记忆意图后写入记忆库。

    只应在**最终答复轮**（assistant 完成回复后）由路由调用：
    - user_msg：本轮用户消息（关键词/长度判定源）
    - source_msg：落库的干净原文快照；缺省 = 对 user_msg 剥离注入段后的文本
    - round_id：本轮任务聚合键（r-<ms>-<seq>，必填）；为空时按 chat 消息时间
      现造一个溯源 id（chat 路径无轮概念），保证每条自动沉淀都可按轮追溯清理。

    防自增强反馈环（P1，借 Agent-Memory）：若消息夹带系统注入过的记忆段
    （用户复述/前端回显等），剥离该段后才写入，绝不把被污染文本写回记忆库。
    异步调用（后台线程），失败静默。返回是否成功写入。
    """
    msg = (user_msg or "").strip()
    raw = source_msg if source_msg is not None else msg
    clean = _strip_injected_memory(raw)
    if len(clean) < _MIN_SINK_LEN:
        return False
    if not any(kw in clean for kw in _SINK_KEYWORDS):
        return False
    try:
        from .agent.registry import registry

        r = registry.execute("memory_add", {
            "text": clean,
            "type": "memory",
            "tags": ["自动沉淀"],
            "source": "[自动记忆] 对话",
            "round_id": round_id or _fallback_round_id(),
        })
        return r.ok
    except Exception:
        return False


def note_task_done(task_desc: str, reply: str, round_id: str = "") -> None:
    """任务完成时记录摘要（agent done 事件调用），供后续正反馈沉淀取上下文。

    只保留最近一次任务；时间戳用于 10 分钟正反馈窗口判定。
    round_id：本轮任务聚合键，随摘要暂存，正反馈沉淀时一并溯源落库。
    """
    summary = (task_desc or "").strip()
    if summary and len(summary) > 200:
        summary = summary[:200]
    reply_part = (reply or "").strip()
    if reply_part and len(reply_part) > 400:
        reply_part = reply_part[:400]
    text = f"任务：{summary}\n执行结果：{reply_part}".strip()
    _recent_task["summary"] = text or None
    _recent_task["ts"] = time.time()
    _recent_task["hash"] = summary[:50] or None
    _recent_task["round_id"] = round_id or ""


def _build_experience_via_llm(task_desc: str, reply: str, feedback: str) -> str:
    """用 LLM 把任务上下文 + 用户反馈提炼成一条可复用经验。

    失败/超时/无输出时返回空串（由调用方决定规则兜底）。
    """
    from .llm import _llm_complete

    sys_prompt = (
        "你是经验提炼器。根据「用户任务 / AI 执行结果 / 用户反馈」提炼一条"
        "可复用的经验条目，供以后做类似任务时参考。"
        "要求：1-3 句话中文，包含「目标-成功方法-复用提示」，直接输出经验内容，"
        "不要标题、不要解释、不要编号。"
    )
    usr = (
        f"用户任务：{task_desc}\n"
        f"AI 执行结果摘要：{reply}\n"
        f"用户反馈：{feedback}\n"
        f"经验条目："
    )
    out = _llm_complete(sys_prompt, usr, timeout=20)
    out = (out or "").strip().strip("\"'`")
    if 4 <= len(out) <= 400:
        return out
    return ""


def _build_lesson_via_llm(task_desc: str, stop_reason: str, error: str,
                          reply: str, tool_path) -> str:
    """用 LLM 把一次失败任务提炼成一条可复用教训（面向未来执行类似任务的自己）。

    失败/超时/输出不合规返回空串（由调用方走规则兜底）。
    """
    from .llm import _llm_complete

    stop_label = {
        "loop_capped": "反复调用同一工具/同一组参数空转，被循环熔断强制终止",
        "max_steps": "步数耗尽仍未收敛完成（不会拆解或低效兜圈）",
    }.get(stop_reason, stop_reason)
    path = " → ".join((tool_path or [])[-_LESSON_PATH_MAX:]) or "（无工具记录）"
    sys_prompt = (
        "你是失败教训提炼器。一次智能体任务没有成功，请根据「用户任务/失败类型/"
        "执行工具序列/报错与片段」提炼一条可复用教训，供以后执行类似任务时参考。"
        "要求：1-3 句中文，包含「失败情形—根因—下次具体怎么做」，建议要可执行"
        "（换什么工具、如何拆解、何时该停下换路或向用户澄清）；不抱怨、不复述报错"
        "堆栈、不写标题编号，直接输出教训内容。"
    )
    usr = (
        f"用户任务：{task_desc}\n"
        f"失败类型：{stop_label}\n"
        f"执行工具序列：{path}\n"
        f"报错/收尾片段：{(error or '')[:300]}\n"
        f"部分输出：{(reply or '')[:300]}\n"
        f"教训条目："
    )
    out = _llm_complete(sys_prompt, usr, timeout=20)
    out = (out or "").strip().strip("\"'`")
    if 6 <= len(out) <= 400:
        return out
    return ""


def auto_sink_praise(feedback: str, round_id: str = "") -> bool:
    """正反馈沉淀：用户在任务完成后表达认可 → 把该任务提炼为经验入库。

    三重防线防误触：
      1. 消息含正反馈关键词；
      2. 10 分钟内刚完成过任务（避免"天气不错"这类闲聊触发）；
      3. 同一任务 30 分钟内不重复沉淀（防抖）。
    round_id：若传空，优先沿用最近一次完成任务暂存的 round_id，再退回现造 id。
    提炼走 LLM；LLM 不可用时退化为规则拼装。任何异常静默返回 False。
    """
    msg = (feedback or "").strip()
    if not any(kw in msg for kw in _PRAISE_KEYWORDS):
        return False
    rt = _recent_task
    if not rt["summary"]:
        return False
    if time.time() - rt["ts"] > _PRAISE_WINDOW_S:
        return False
    if len(rt["summary"]) < _PRAISE_MIN_SUMMARY_LEN:
        return False
    if time.time() - rt["last_sink_ts"] < _PRAISE_DEBOUNCE_S:
        return False
    try:
        task_part = rt["summary"]
        desc, _, reply = task_part.partition("\n执行结果：")
        # LLM 提炼，失败退化为规则拼装
        text = _build_experience_via_llm(desc, reply or "", msg)
        if not text:
            text = (
                f"用户认可任务「{desc[:80]}」的完成（反馈：{msg[:30]}）。"
                f"成功经验：{reply[:200]}"
            ).strip()
        from .agent.registry import registry

        rid = round_id or rt.get("round_id") or ""
        r = registry.execute("memory_add", {
            "text": text,
            "type": "experience",
            "tags": ["正反馈沉淀"],
            "source": "[经验] 用户正反馈",
            "round_id": rid or _fallback_round_id(),
        })
        if r.ok:
            rt["last_sink_ts"] = time.time()
            return True
        return False
    except Exception:
        return False


def sink_failure_lesson(task_desc: str, stop_reason: str, error: str = "",
                        reply: str = "", tool_path=None, round_id: str = "") -> bool:
    """失败教训沉淀：行为类失败终态（loop_capped/max_steps）提炼教训入记忆库。

    防线：
      1. 只沉淀白名单停因（外部故障 error / 空回复 empty_response 直接跳过）；
      2. 任务描述达长度门槛；
      3. 同任务同停因 30 分钟防抖；
      4. LLM 提炼失败退化为规则拼装；复用 type=experience（其定义本含"踩过的坑"），
         tags 标 ["失败教训", stop_reason] 与正反馈经验区分。
    任何异常静默返回 False，绝不影响主流程。
    """
    desc = (task_desc or "").strip()
    if stop_reason not in _LESSON_SINK_STOPS:
        return False
    if len(desc) < _LESSON_MIN_DESC_LEN:
        return False
    fp = f"{stop_reason}|{desc[:50]}"
    now = time.time()
    rl = _recent_lesson
    if rl["fp"] == fp and now - rl["ts"] < _LESSON_DEBOUNCE_S:
        return False
    try:
        text = _build_lesson_via_llm(desc, stop_reason, error, reply, tool_path)
        if not text:
            stop_hint = ("反复同一工具/参数空转" if stop_reason == "loop_capped"
                         else "步骤超限仍未收敛")
            uniq_path = "、".join(dict.fromkeys(tool_path or []))[:120] or "未知"
            text = (
                f"任务「{desc[:80]}」因{stop_hint}中断（涉及工具：{uniq_path}）。"
                f"教训：先停下判断当前做法为何无效，换工具/换参数或把任务拆成更小步骤，"
                f"不要重复同样的调用；确实走不通时如实告知用户并请求澄清。"
            ).strip()
        from .agent.registry import registry

        r = registry.execute("memory_add", {
            "text": text,
            "type": "experience",
            "tags": ["失败教训", stop_reason],
            "source": "[教训] 失败终态",
            "round_id": round_id or _fallback_round_id(),
        })
        if getattr(r, "ok", False):
            rl["fp"] = fp
            rl["ts"] = now
            return True
        return False
    except Exception:
        return False


def warm_up():
    """后台预热：触发嵌入模型单例初始化 + 集合确保（首次调用加载模型，约 1-2s）。"""
    try:
        retrieve("预热", top_k=1)
    except Exception:
        pass
