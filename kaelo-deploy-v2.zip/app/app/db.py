# -*- coding: utf-8 -*-
"""MySQL 持久化层：对话历史 / 文档台账 / 高亮条目。

使用 pymysql 直连本机 MySQL（PHPStudy 托管，root 空密码）。
设计原则：
  - 所有数据库操作失败不影响主流程（RAG 对话照常跑），只打印警告日志
  - 连接按需创建，短连接为主；封装成函数供 main.py 调用
"""
import json
import logging
import threading
import os

import pymysql

from . import config

logger = logging.getLogger("db")

# 短暂连接超时，避免 MySQL 挂掉时页面卡死
_CONNECT_TIMEOUT = 3


def _conn():
    """创建一条新连接（pymysql 短连接）。"""
    return pymysql.connect(
        host=config.MYSQL_HOST,
        port=config.MYSQL_PORT,
        user=config.MYSQL_USER,
        password=config.MYSQL_PASSWORD,
        database=config.MYSQL_DB,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=_CONNECT_TIMEOUT,
        read_timeout=10,
        write_timeout=10,
    )


def _execute(sql, args=None, fetch_one=False):
    """执行 SQL。成功返回结果（list/dict/None），失败返回 None 并打印告警。"""
    try:
        conn = _conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, args or ())
                if cur.description is None:  # 非查询语句
                    conn.commit()
                    return cur
                rows = cur.fetchone() if fetch_one else cur.fetchall()
                return rows
        finally:
            conn.close()
    except Exception as e:
        logger.warning("[db] 操作失败: %s", e)
        return None


# ---------------- 运行指标（阶段 3 /api/metrics 用） ----------------

def count_sessions() -> int:
    rows = _execute("SELECT COUNT(*) AS c FROM chat_sessions", fetch_one=True)
    return int(rows["c"]) if rows else 0


def count_messages() -> int:
    rows = _execute("SELECT COUNT(*) AS c FROM chat_messages", fetch_one=True)
    return int(rows["c"]) if rows else 0


# ---------------- 建表（幂等，启动时调用一次） ----------------
# Schema 单一来源（阶段 2）：本文件 _INIT_SQL 是唯一权威，服务启动自动幂等建表；
# sql/migrations/0001_init.sql 是其版本化镜像（人工初始化用），变更流程见该文件头部注释。

_INIT_SQL = """
CREATE TABLE IF NOT EXISTS chat_sessions (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key      VARCHAR(50)  NOT NULL DEFAULT '',
  kb_name     VARCHAR(50)  NOT NULL DEFAULT '',
  model       VARCHAR(100) DEFAULT '',
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_kb_time (kb_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS chat_messages (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id    BIGINT UNSIGNED NOT NULL,
  role          ENUM('user','assistant') NOT NULL,
  content       MEDIUMTEXT      NOT NULL,
  kb_key        VARCHAR(50)  DEFAULT '',
  retrieved     JSON          NULL,
  query_used    VARCHAR(1000) DEFAULT '',
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_session (session_id, created_at),
  KEY idx_kb_time (kb_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kb_docs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key      VARCHAR(50)   NOT NULL,
  kb_name     VARCHAR(50)   NOT NULL DEFAULT '',
  filename    VARCHAR(200)  NOT NULL,
  chunk_count INT UNSIGNED  DEFAULT 0,
  status      VARCHAR(20)   NOT NULL DEFAULT 'active',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_kb_file (kb_key, filename, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS highlights (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200)  NOT NULL,
  content     TEXT          NOT NULL,
  category    VARCHAR(50)   NOT NULL DEFAULT '通用',
  tags        VARCHAR(255)  DEFAULT '',
  level       TINYINT       NOT NULL DEFAULT 3,
  source      VARCHAR(200)  DEFAULT '',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_category (category),
  KEY idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_settings (
  `key`  VARCHAR(50)   NOT NULL PRIMARY KEY,
  value  VARCHAR(1000) DEFAULT '',
  updated_at DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='应用设置（API Key/模型等，网页可改）';

CREATE TABLE IF NOT EXISTS personal_profile (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  field       VARCHAR(50)   NOT NULL COMMENT '档案项（如 性格/背景/目标）',
  field_key   VARCHAR(50)   DEFAULT '' COMMENT '英文标志（可选）',
  content     TEXT          NOT NULL COMMENT '档案内容',
  visibility  VARCHAR(20)   NOT NULL DEFAULT 'private' COMMENT 'private/sensitive（默认私有）',
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_field (field)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='个人敏感档案（性格/背景/想法）';

CREATE TABLE IF NOT EXISTS api_keys (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL COMMENT '用途/说明（如 好友-聊天）',
  key_hash     CHAR(64)      NOT NULL COMMENT 'API Key 的 SHA-256 哈希（不存明文）',
  key_prefix   VARCHAR(16)   NOT NULL COMMENT 'Key 前 8 位，用于界面展示',
  scopes       VARCHAR(255)  NOT NULL DEFAULT '["chat"]' COMMENT '权限 JSON 数组',
  status       VARCHAR(20)   NOT NULL DEFAULT 'active' COMMENT 'active/disabled',
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_used_at DATETIME      NULL COMMENT '最近调用时间',
  UNIQUE KEY uk_hash (key_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对外 API 密钥（鉴权用，仅存哈希）';

CREATE TABLE IF NOT EXISTS agent_tasks (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  task_id      VARCHAR(64)    NOT NULL COMMENT '审批/任务唯一标识（t-时间戳-工具名）',
  parent_task_id VARCHAR(64)  NOT NULL DEFAULT '' COMMENT '父任务 task_id（子代理审计谱系，空=根任务）',
  round_id     VARCHAR(64)    NOT NULL DEFAULT '' COMMENT '对话轮次 id（一次 agent 请求=一轮，任务聚合键）',
  session_id   VARCHAR(64)    DEFAULT '' COMMENT '来源会话标识（可空）',
  user_message VARCHAR(2000)  DEFAULT '' COMMENT '用户指令（该次任务）',
  tool_name    VARCHAR(50)    NOT NULL COMMENT '工具名',
  tool_args    JSON           NULL COMMENT '工具参数（JSON）',
  tool_result  TEXT           NULL COMMENT '工具执行结果（截断）',
  risk         VARCHAR(20)    NOT NULL DEFAULT 'safe' COMMENT 'safe/sensitive/dangerous',
  mode         VARCHAR(16)    NOT NULL DEFAULT 'standard' COMMENT '权限模式 locked/standard/relaxed',
  decision     VARCHAR(16)    NOT NULL DEFAULT 'ask' COMMENT '权限决策 allow/ask/deny',
  approved     TINYINT        NULL COMMENT 'NULL=未决策 1=允许 0=拒绝/超时',
  ok           TINYINT        NULL COMMENT '工具执行是否成功 1/0',
  element_id   VARCHAR(190)   NULL COMMENT '本步定向操作的控件稳定引用（P2-2 回溯"为什么点了这里"）',
  retries      INT UNSIGNED   NULL COMMENT '本步自动重试次数（P2-2 里程碑断言失败重试）',
  token_in     INT UNSIGNED   NULL COMMENT '本步模型请求输入 token（S1-2）',
  token_out    INT UNSIGNED   NULL COMMENT '本步模型请求输出 token（S1-2）',
  created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_task (task_id),
  KEY idx_time (created_at),
  KEY idx_tool (tool_name),
  KEY idx_round (round_id),
  KEY idx_parent (parent_task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lazaxa agent 任务/审批审计';

CREATE TABLE IF NOT EXISTS reminders (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  content    VARCHAR(500) NOT NULL COMMENT '提醒内容',
  note_path  VARCHAR(200) NOT NULL DEFAULT '' COMMENT '来源笔记相对路径',
  remind_at  DATE         NOT NULL COMMENT '提醒日期（当天到期）',
  status     VARCHAR(20)  NOT NULL DEFAULT 'pending' COMMENT 'pending/read/done',
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_note_content (note_path, content(200), remind_at),
  KEY idx_date (remind_at, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lazaxa 笔记到期提醒（定时扫描 Obsidian 生成）';

CREATE TABLE IF NOT EXISTS phone_events (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ev_key     VARCHAR(190) NOT NULL COMMENT '去重键（pkg|id|tag 或 battery:<会话>）',
  kind       VARCHAR(24)  NOT NULL DEFAULT 'notice' COMMENT 'notice/battery/charging',
  pkg        VARCHAR(100) NOT NULL DEFAULT '' COMMENT '来源应用包名',
  title      VARCHAR(200) NOT NULL DEFAULT '' COMMENT '标题（通知应用名/事件名）',
  content    VARCHAR(500) NOT NULL DEFAULT '' COMMENT '内容（通知正文/电量说明）',
  level      VARCHAR(10)  NOT NULL DEFAULT 'info' COMMENT 'info/warn/critical',
  status     VARCHAR(20)  NOT NULL DEFAULT 'pending' COMMENT 'pending/read',
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_ev_key (ev_key),
  KEY idx_status (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lazaxa 手机事件反连（adb 轮询设备通知/电量 → 桌面提醒）';

CREATE TABLE IF NOT EXISTS agent_jobs (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_id       VARCHAR(64)    NOT NULL COMMENT 'job-毫秒-序号',
  fingerprint  VARCHAR(64)    NOT NULL DEFAULT '' COMMENT '调度幂等键 sha256(task+mode+round_id)',
  task         TEXT           NOT NULL COMMENT '原始指令',
  mode         VARCHAR(16)    NOT NULL DEFAULT 'standard' COMMENT '权限模式 locked/standard/relaxed',
  round_id     VARCHAR(64)    NOT NULL DEFAULT '' COMMENT '发起该 job 的主对话轮 id（可空）',
  status       VARCHAR(20)    NOT NULL DEFAULT 'queued' COMMENT 'queued/running/awaiting_approval/done/failed/cancelled/interrupted',
  reply        MEDIUMTEXT     NULL COMMENT '最终回复',
  error        TEXT           NULL COMMENT '失败原因',
  stop_reason  VARCHAR(32)    NOT NULL DEFAULT '' COMMENT '停因（StopReason / interrupted）',
  steps        INT            NOT NULL DEFAULT 0 COMMENT '工具步数',
  ms           INT            NOT NULL DEFAULT 0 COMMENT '耗时毫秒',
  started_at   DATETIME       NULL COMMENT '开始时间',
  ended_at     DATETIME       NULL COMMENT '结束时间',
  created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_job_id (job_id),
  KEY idx_status (status),
  KEY idx_fingerprint (fingerprint, status),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lazaxa 后台任务（worker）落盘 journal：进程重启恢复与调度幂等';

CREATE TABLE IF NOT EXISTS agent_events (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  round_id     VARCHAR(64)    NOT NULL DEFAULT '' COMMENT '对话轮次 id（r-*/job-*；子代理并入父轮，一次 agent 请求=一轮）',
  task_id      VARCHAR(64)    NOT NULL DEFAULT '' COMMENT '相关工具/审批 task_id（如 t-*/sub-*/par-*；可空）',
  parent_task_id VARCHAR(64)  NOT NULL DEFAULT '' COMMENT '父任务 task_id（子代理谱系；空=根任务）',
  event_type   VARCHAR(40)    NOT NULL COMMENT 'turn_start/request/assistant/thinking/tool_call/tool_result/approval_request/approval_resolved/compaction/subagent_*/done',
  step         INT            NOT NULL DEFAULT 0 COMMENT '主循环步号（request/assistant/tool 事件归属；非步事件为 0）',
  payload      JSON           NULL COMMENT '事件负载（完整快照；模型可见输入/输出/决策）',
  created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_round_id (round_id, id),
  KEY idx_type (event_type),
  KEY idx_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Lazaxa agent 全生命周期事件日志（仅追加不更新；模型可见即已记录，M3）';
"""


def init_db():
    """启动时调用：确保四张表存在（幂等）。失败只告警不影响主流程。"""
    try:
        conn = _conn()
        try:
            with conn.cursor() as cur:
                for stmt in _INIT_SQL.split(";"):
                    s = stmt.strip()
                    if s:
                        cur.execute(s)
        finally:
            conn.close()
        logger.info("[db] personal_kb 表结构就绪")
        # 老库表已存在时补齐新增列（三级权限：mode/decision）
        _ensure_agent_task_columns()
    except Exception as e:
        logger.warning("[db] 初始化失败（对话历史不会落库，其余功能不受影响）: %s", e)


def _ensure_agent_task_columns():
    """agent_tasks 表已存在时补齐 mode/decision 列（幂等，三级权限升级迁移）。"""
    try:
        cols = _execute("SHOW COLUMNS FROM agent_tasks") or []
        names = {c["Field"] for c in cols} if cols else set()
        for col, ddl in (
            ("mode", "VARCHAR(16) NOT NULL DEFAULT 'standard' COMMENT '权限模式 locked/standard/relaxed'"),
            ("decision", "VARCHAR(16) NOT NULL DEFAULT 'ask' COMMENT '权限决策 allow/ask/deny'"),
            ("round_id", "VARCHAR(64) NOT NULL DEFAULT '' COMMENT '对话轮次 id（一次 agent 请求=一轮，任务聚合键）'"),
        ):
            if col not in names:
                _execute(f"ALTER TABLE agent_tasks ADD COLUMN {col} {ddl}")
    except Exception:
        pass


def ping() -> bool:
    """MySQL 连通性检查（供 MySQL 向量同步判断是否可用）。"""
    return _execute("SELECT 1", fetch_one=True) is not None


# ---------------- 会话与消息 ----------------

def create_session(kb_key: str = "", kb_name: str = "", model: str = "") -> int | None:
    """创建一个新会话，返回 session id。"""
    r = _execute(
        "INSERT INTO chat_sessions (kb_key, kb_name, model) VALUES (%s,%s,%s)",
        (kb_key, kb_name, model),
    )
    return r.lastrowid if r else None


def get_session(session_id) -> dict | None:
    """按 id 查单个会话（会话模型修正：前端持 session_id 复用同一会话）。"""
    return _execute(
        "SELECT id, kb_key, kb_name, model, created_at FROM chat_sessions WHERE id=%s",
        (session_id,),
        fetch_one=True,
    )


def add_message(session_id, role, content, kb_key="", retrieved=None, query_used=""):
    """写入一条消息。retrieved 传 list/dict，自动 JSON 序列化。"""
    if not session_id:
        return None
    if retrieved is not None:
        retrieved = json.dumps(retrieved, ensure_ascii=False, default=str)
    return _execute(
        "INSERT INTO chat_messages (session_id, role, content, kb_key, retrieved, query_used) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (session_id, role, content, kb_key, retrieved, query_used),
    )


def get_sessions(kb_key: str | None = None, limit: int = 20) -> list:
    """最近会话列表（可过滤知识库）。"""
    if kb_key:
        return _execute(
            "SELECT id, kb_key, kb_name, model, created_at FROM chat_sessions "
            "WHERE kb_key=%s ORDER BY updated_at DESC LIMIT %s",
            (kb_key, int(limit)),
        ) or []
    return _execute(
        "SELECT id, kb_key, kb_name, model, created_at FROM chat_sessions "
        "ORDER BY updated_at DESC LIMIT %s",
        (int(limit),),
    ) or []


def get_messages(session_id: int, limit: int = 100) -> list:
    """某会话的全部消息（升序返回对应轮次）。"""
    rows = _execute(
        "SELECT id, role, content, kb_key, retrieved, query_used, created_at "
        "FROM chat_messages WHERE session_id=%s ORDER BY id ASC LIMIT %s",
        (int(session_id), int(limit)),
    ) or []
    for r in rows:
        if r.get("retrieved"):
            try:
                r["retrieved"] = json.loads(r["retrieved"])
            except (TypeError, json.JSONDecodeError):
                r["retrieved"] = None
    return rows


def get_recent_messages(limit: int = 200) -> list:
    """最近 N 条消息（全库，倒序取最新，供 MySQL 向量同步用）。"""
    return _execute(
        "SELECT id, session_id, role, content, kb_key, created_at "
        "FROM chat_messages ORDER BY id DESC LIMIT %s",
        (int(limit),),
    ) or []


# ---------------- 文档台账 ----------------

def upsert_kb_doc(kb_key: str, kb_name: str, filename: str, chunk_count: int):
    """登记/更新文档台账：同名文件先逻辑删除旧记录，再写入新记录。"""
    _execute(
        "UPDATE kb_docs SET status='removed' WHERE kb_key=%s AND filename=%s AND status='active'",
        (kb_key, filename),
    )
    _execute(
        "INSERT INTO kb_docs (kb_key, kb_name, filename, chunk_count) VALUES (%s,%s,%s,%s)",
        (kb_key, kb_name, filename, int(chunk_count)),
    )


def mark_kb_doc_removed(kb_key: str, filename: str):
    """文档被删除：把台账状态改为 removed。"""
    _execute(
        "UPDATE kb_docs SET status='removed' WHERE kb_key=%s AND filename=%s AND status='active'",
        (kb_key, filename),
    )


def list_kb_docs(kb_key: str | None = None) -> list:
    """台账列表：active 在前，按更新时间排序。"""
    if kb_key:
        return _execute(
            "SELECT id, kb_key, kb_name, filename, chunk_count, status, created_at, updated_at "
            "FROM kb_docs WHERE kb_key=%s ORDER BY (status='removed'), updated_at DESC",
            (kb_key,),
        ) or []
    return _execute(
        "SELECT id, kb_key, kb_name, filename, chunk_count, status, created_at, updated_at "
        "FROM kb_docs ORDER BY (status='removed'), updated_at DESC LIMIT 500",
    ) or []


# ---------------- 高亮条目 ----------------

def list_highlights(category: str | None = None, q: str | None = None) -> list:
    """高亮列表，可按分类/关键词过滤。"""
    sql = "SELECT * FROM highlights WHERE 1=1"
    args = []
    if category and category not in ("", "全部"):
        sql += " AND category=%s"
        args.append(category)
    if q:
        sql += " AND (title LIKE %s OR content LIKE %s OR tags LIKE %s)"
        like = f"%{q}%"
        args += [like, like, like]
    sql += " ORDER BY level DESC, updated_at DESC"
    return _execute(sql, tuple(args)) or []


def get_highlight(hid: int):
    return _execute("SELECT * FROM highlights WHERE id=%s", (int(hid),), fetch_one=True)


def create_highlight(title, content, category="通用", tags="", level=3, source="") -> int | None:
    r = _execute(
        "INSERT INTO highlights (title, content, category, tags, level, source) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (title, content, category, tags, int(level), source),
    )
    return r.lastrowid if r else None


def update_highlight(hid, title=None, content=None, category=None, tags=None, level=None, source=None) -> bool:
    fields, args = [], []
    for col, val in (("title", title), ("content", content), ("category", category),
                     ("tags", tags), ("level", level), ("source", source)):
        if val is not None:
            fields.append(f"{col}=%s")
            args.append(val)
    if not fields:
        return False
    args.append(int(hid))
    r = _execute(f"UPDATE highlights SET {','.join(fields)} WHERE id=%s", tuple(args))
    return bool(r)


def delete_highlight(hid) -> bool:
    r = _execute("DELETE FROM highlights WHERE id=%s", (int(hid),))
    return bool(r)


def highlight_categories() -> list[str]:
    rows = _execute("SELECT DISTINCT category FROM highlights ORDER BY category") or []
    return [r["category"] for r in rows if r.get("category")]


# ---------------- 应用设置（API Key / 模型 / 接口地址） ----------------

def get_setting(key: str, default: str = "") -> str:
    """读取单个设置；不存在返回 default。"""
    row = _execute("SELECT value FROM app_settings WHERE `key`=%s", (key,), fetch_one=True)
    return (row or {}).get("value", default) if row else default


def set_setting(key: str, value: str) -> bool:
    """写入/更新单个设置（空值则删除）。"""
    value = (value or "").strip()
    if value == "":
        _execute("DELETE FROM app_settings WHERE `key`=%s", (key,))
    else:
        _execute(
            "INSERT INTO app_settings (`key`, value) VALUES (%s,%s) "
            "ON DUPLICATE KEY UPDATE value=VALUES(value)",
            (key, value),
        )
    return True


def all_settings() -> dict:
    """读取全部设置。"""
    rows = _execute("SELECT `key`, value FROM app_settings") or []
    return {r["key"]: r["value"] for r in rows}


# ---------------- 个人敏感档案（personal_profile） ----------------

def list_profile() -> list:
    """列出全部个人档案项。"""
    return _execute(
        "SELECT id, field, field_key, content, visibility, updated_at "
        "FROM personal_profile ORDER BY id ASC"
    ) or []


def get_profile_field(field: str) -> dict | None:
    """按档案项名取单条。"""
    return _execute(
        "SELECT id, field, field_key, content, visibility, updated_at "
        "FROM personal_profile WHERE field=%s", (field,), fetch_one=True
    )


def save_profile(field: str, content: str, field_key: str = "", visibility: str = "private") -> bool:
    """新增/更新档案项（field 唯一，存在则覆盖）。"""
    if not field or not content:
        return False
    _execute(
        "INSERT INTO personal_profile (field, field_key, content, visibility) "
        "VALUES (%s,%s,%s,%s) "
        "ON DUPLICATE KEY UPDATE content=VALUES(content), field_key=VALUES(field_key), visibility=VALUES(visibility)",
        (field.strip(), field_key.strip(), content.strip(), visibility),
    )
    return True


def delete_profile_field(field: str) -> bool:
    """删除一个档案项。"""
    r = _execute("DELETE FROM personal_profile WHERE field=%s", (field,))
    return bool(r)


# ---------------- 对外 API 密钥（api_keys） ----------------
# 设计要点（参考业界最佳实践）：
#   - 只存 SHA-256 哈希，不存明文——即使数据库泄露也无法反推真实 Key
#   - key_prefix 存前 8 位，仅用于界面展示（sk-xxxx****）
#   - 每次调用鉴权时比对哈希，更新 last_used_at

def generate_api_key() -> str:
    """生成密码学安全的 API Key：sk- + 32 字节 urlsafe 随机串（≈43 字符）。"""
    import secrets
    return "sk-" + secrets.token_urlsafe(32)


def create_api_key(name: str, scopes: list | None = None) -> dict | None:
    """创建 API Key。返回 {id, name, key(明文，仅此一次), key_prefix, scopes}。
    key 明文只在创建时返回一次，之后无法再次查看。
    """
    import hashlib
    raw = generate_api_key()
    scopes = scopes or ["chat"]
    row = _execute(
        "INSERT INTO api_keys (name, key_hash, key_prefix, scopes) VALUES (%s,%s,%s,%s)",
        (name.strip() or "未命名", hashlib.sha256(raw.encode()).hexdigest(), raw[:8], json.dumps(scopes, ensure_ascii=False)),
    )
    if not row:
        return None
    return {"id": row.lastrowid, "name": name.strip() or "未命名", "key": raw,
            "key_prefix": raw[:8], "scopes": scopes}


def list_api_keys() -> list:
    """列出全部 API Key（不含明文，只含前缀与状态）。"""
    rows = _execute(
        "SELECT id, name, key_prefix, scopes, status, created_at, last_used_at "
        "FROM api_keys ORDER BY id DESC"
    ) or []
    for r in rows:
        try:
            r["scopes"] = json.loads(r.get("scopes") or "[]")
        except Exception:
            r["scopes"] = []
    return rows


def delete_api_key(kid: int) -> bool:
    """删除一个 API Key。"""
    return bool(_execute("DELETE FROM api_keys WHERE id=%s", (int(kid),)))


def set_api_key_status(kid: int, status: str) -> bool:
    """启用/禁用 API Key（status: active/disabled）。"""
    return bool(_execute("UPDATE api_keys SET status=%s WHERE id=%s", (status, int(kid))))


def find_api_key(raw_key: str) -> dict | None:
    """按明文 Key 查找（比对哈希）；找到且 active 时更新 last_used_at。
    返回该条记录（含 scopes 解析后的列表）；无效/禁用返回 None。
    """
    import hashlib
    if not raw_key:
        return None
    h = hashlib.sha256(raw_key.encode()).hexdigest()
    row = _execute("SELECT * FROM api_keys WHERE key_hash=%s", (h,), fetch_one=True)
    if not row:
        return None
    if row.get("status") != "active":
        return None
    try:
        row["scopes"] = json.loads(row.get("scopes") or "[]")
    except Exception:
        row["scopes"] = []
    # 更新最近使用时间（失败不影响鉴权）
    _execute("UPDATE api_keys SET last_used_at=NOW() WHERE id=%s", (row["id"],))
    return row


# ---------------- Lazaxa agent 任务/审批审计（agent_tasks） ----------------

_MIGRATED_PARENT_COL = False


def _ensure_agent_tasks_parent_col():
    """惰性迁移：给 agent_tasks 补 parent_task_id 列（幂等，已存在则跳过）。

    建表 SQL（_INIT_SQL）已含该列与 idx_parent 索引，这里只服务旧库升级：
    1) 老表无 parent_task_id 列 → 补列；
    2) 无论补列与否，确保 idx_parent 索引存在（老库可能列在而索引缺，防谱系查询全表扫）。
    """
    global _MIGRATED_PARENT_COL
    if _MIGRATED_PARENT_COL:
        return
    try:
        cols = _execute("SHOW COLUMNS FROM agent_tasks") or []
        names = {c["Field"] for c in cols} if cols else set()
        if "parent_task_id" not in names:
            _execute(
                "ALTER TABLE agent_tasks ADD COLUMN parent_task_id VARCHAR(64) "
                "NOT NULL DEFAULT '' COMMENT '父任务 task_id（子代理审计谱系，空=根任务）' "
                "AFTER task_id")
        idxs = _execute("SHOW INDEX FROM agent_tasks") or []
        has_parent_idx = any(i.get("Key_name") == "idx_parent" for i in idxs) if idxs else False
        if not has_parent_idx:
            _execute("ALTER TABLE agent_tasks ADD KEY idx_parent (parent_task_id)")
    except Exception:
        pass  # 列/索引已存在或数据库不可用：下次再试
    _MIGRATED_PARENT_COL = True


# ---------------- S1-2 / S1-4：token 列惰性迁移 + 审计失败可见化 ----------------

_MIGRATED_TASK_TOKEN_COL = False


def _ensure_agent_tasks_token_col():
    """惰性迁移：给 agent_tasks 补 token_in/token_out 列（幂等，已存在则跳过）。

    建表 SQL（_INIT_SQL）已含这两列，这里只服务旧库升级。
    """
    global _MIGRATED_TASK_TOKEN_COL
    if _MIGRATED_TASK_TOKEN_COL:
        return
    try:
        cols = _execute("SHOW COLUMNS FROM agent_tasks") or []
        names = {c["Field"] for c in cols} if cols else set()
        if "token_in" not in names:
            _execute("ALTER TABLE agent_tasks ADD COLUMN token_in INT UNSIGNED "
                     "NULL COMMENT '本步模型请求输入 token（S1-2）' AFTER ok")
        if "token_out" not in names:
            _execute("ALTER TABLE agent_tasks ADD COLUMN token_out INT UNSIGNED "
                     "NULL COMMENT '本步模型请求输出 token（S1-2）' AFTER token_in")
    except Exception:
        pass  # 列已存在或数据库不可用：下次再试
    _MIGRATED_TASK_TOKEN_COL = True


# ---------------- P2-2：控件引用/重试次数列惰性迁移（审计回溯） ----------------

_MIGRATED_TASK_TRACE_COL = False


def _ensure_agent_tasks_trace_col():
    """惰性迁移：给 agent_tasks 补 element_id/retries 列（幂等，P2-2 审计增强）。

    建表 SQL（_INIT_SQL）已含这两列，这里只服务旧库升级。
    element_id：本步定向操作的控件稳定引用（回溯"为什么点了这里"）；
    retries：本步自动重试次数（里程碑断言失败重试）。
    """
    global _MIGRATED_TASK_TRACE_COL
    if _MIGRATED_TASK_TRACE_COL:
        return
    try:
        cols = _execute("SHOW COLUMNS FROM agent_tasks") or []
        names = {c["Field"] for c in cols} if cols else set()
        if "element_id" not in names:
            _execute("ALTER TABLE agent_tasks ADD COLUMN element_id VARCHAR(190) "
                     "NULL COMMENT '本步定向操作的控件稳定引用（P2-2）' AFTER ok")
        if "retries" not in names:
            _execute("ALTER TABLE agent_tasks ADD COLUMN retries INT UNSIGNED "
                     "NULL COMMENT '本步自动重试次数（P2-2）' AFTER element_id")
    except Exception:
        pass  # 列已存在或数据库不可用：下次再试
    _MIGRATED_TASK_TRACE_COL = True


# S1-4：审计写库失败计数器（_audit 长期"异常静默"→ 至少可见可数）
_AUDIT_FAILURES = {"count": 0, "last": ""}


def bump_audit_failure(msg: str = ""):
    """审计写库失败时计数（health/metrics 暴露，不再全静默）。"""
    _AUDIT_FAILURES["count"] += 1
    _AUDIT_FAILURES["last"] = (msg or "")[:200]


def audit_failure_count() -> int:
    """累计审计写库失败次数（进程内）。"""
    return _AUDIT_FAILURES.get("count", 0)


def audit_failure_last() -> str:
    """最近一次审计失败摘要（便于排查）。"""
    return _AUDIT_FAILURES.get("last", "")


def log_agent_task(task_id: str, tool_name: str, tool_args: dict | None = None,
                   risk: str = "safe", approved: bool | None = None,
                   result_text: str = "", ok: bool | None = None,
                   user_message: str = "", session_id: str = "",
                   mode: str = "standard", decision: str = "ask",
                   parent_task_id: str = "", round_id: str = "",
                   token_in: int | None = None,
                   token_out: int | None = None,
                   element_id: str = "", retries: int | None = None) -> bool:
    """写入一条 agent 任务/审批审计记录。

    - task_id: 审批/任务唯一标识
    - parent_task_id: 父任务 task_id（子代理审计谱系；空=根任务）
    - round_id: 对话轮次 id（一次 agent 请求=一轮；任务记录中心按此聚合主任务）
    - token_in / token_out: 本步模型请求的输入/输出 token 数（S1-2 usage 落库）
    - element_id / retries: P2-2 审计增强——本步定向操作的控件稳定引用、本步自动重试
      次数（回溯"为什么点了这里"）
    - approved: None=自动执行(safe/allow) 1=用户允许 0=拒绝/超时
    - result_text: 工具结果（截断 2000 字符，防撑爆表）
    - mode: 执行时权限模式 locked/standard/relaxed
    - decision: 权限决策 allow/ask/deny
    幂等原子（B批3）：唯一索引就绪时用单语句 INSERT IGNORE——同 task_id 冲突
    即整行静默忽略（=审计去重），没有"先查后插"两步的竞态窗口；唯一索引
    不可用（老库脏数据）才退化为应用层先查后插兜底。
    任何异常静默返回 False（审计失败绝不阻断 agent 主流程）；同时 bump_audit_failure
    计数（S1-4），让"审计在静默漏记"这件事至少可被 health 看到。
    """
    try:
        _ensure_agent_tasks_parent_col()
        _ensure_agent_task_unique_idx()
        _ensure_agent_tasks_token_col()
        _ensure_agent_tasks_trace_col()
        params = (
            str(task_id)[:64],
            str(parent_task_id or "")[:64],
            str(round_id or "")[:64],
            str(session_id or "")[:64],
            str(user_message or "")[:2000],
            str(tool_name)[:50],
            json.dumps(tool_args or {}, ensure_ascii=False, default=str)[:4000],
            str(result_text or "")[:2000],
            str(risk)[:20],
            str(mode)[:16],
            str(decision)[:16],
            None if approved is None else (1 if approved else 0),
            None if ok is None else (1 if ok else 0),
            (str(element_id)[:190] or None) if element_id else None,
            None if retries is None else int(retries),
            None if token_in is None else int(token_in),
            None if token_out is None else int(token_out),
        )
        if _TASK_UQ_READY:
            # 原子幂等路径（B批3）：唯一索引兜底，同 task_id 重复插入整行静默忽略
            _execute(
                "INSERT IGNORE INTO agent_tasks "
                "(task_id, parent_task_id, round_id, session_id, user_message, tool_name, "
                " tool_args, tool_result, risk, mode, decision, approved, ok, "
                " element_id, retries, token_in, token_out) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                params,
            )
        else:
            # 唯一索引不可用（库异常/老库有重复 task_id）→ 先查后插兜底防重复
            if _execute("SELECT id FROM agent_tasks WHERE task_id=%s LIMIT 1",
                        (str(task_id)[:64],), fetch_one=True):
                return True
            _execute(
                "INSERT INTO agent_tasks "
                "(task_id, parent_task_id, round_id, session_id, user_message, tool_name, "
                " tool_args, tool_result, risk, mode, decision, approved, ok, "
                " element_id, retries, token_in, token_out) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                params,
            )
        return True
    except Exception as e:
        bump_audit_failure(f"log_agent_task: {type(e).__name__}: {e}")
        return False


def query_agent_tasks(q: str = "", tool: str = "", minutes: int = 1440,
                      limit: int = 300, round_id: str = "") -> list:
    """按条件查询 agent 工具审计行（供"任务记录中心"）。

    - q: 模糊关键词（匹配 user_message / tool_name / tool_args / tool_result）
    - tool: 工具名精确过滤
    - minutes: 只看最近 N 分钟（<=0 表示不限时间）
    - round_id: 限定某个对话轮次（任务展开用；空=不限）
    - 返回按 id 升序的原始行（路由层负责按 round_id/消息+时间连续聚合成"任务"）。
    """
    where, params = [], []
    if minutes and int(minutes) > 0:
        where.append("created_at >= NOW() - INTERVAL %s MINUTE")
        params.append(int(minutes))
    if round_id:
        where.append("round_id = %s")
        params.append(str(round_id)[:64])
    if tool:
        where.append("tool_name = %s")
        params.append(str(tool)[:50])
    if q:
        kw = str(q).strip()
        if kw:
            like = f"%{kw}%"
            where.append("(user_message LIKE %s OR tool_name LIKE %s "
                         "OR tool_args LIKE %s OR tool_result LIKE %s)")
            params += [like, like, like, like]
    sql = ("SELECT id, task_id, parent_task_id, round_id, session_id, user_message, "
           "tool_name, tool_args, tool_result, risk, mode, decision, approved, ok, "
           "element_id, retries, token_in, token_out, created_at FROM agent_tasks")
    if where:
        sql += " WHERE " + " AND ".join(where)
    # 先取最新的 N 行（id 倒序），再按 id 正序返回（组内执行顺序不变）
    sql += " ORDER BY id DESC LIMIT %s"
    params.append(max(1, min(int(limit), 2000)))
    sql = "SELECT * FROM (" + sql + ") _recent ORDER BY id ASC"
    return _execute(sql, tuple(params)) or []


def list_agent_tasks(limit: int = 50) -> list:
    """最近 agent 任务审计（按时间倒序，供管理页备用）。"""
    return _execute(
        "SELECT id, task_id, session_id, tool_name, risk, mode, decision, "
        "approved, ok, SUBSTRING(user_message,1,120) AS user_message, created_at "
        "FROM agent_tasks ORDER BY id DESC LIMIT %s",
        (int(limit),),
    ) or []


# ---------------- M3：agent 全生命周期事件账本（agent_events，2026-09-06） ----------------
# 设计见 智能体升级方案/M3-事件日志-细化方案.md。仅追加不更新；任何异常静默返回，
# 并 bump_audit_failure 让"账本漏记"可见（S1-4 同款口径）。id = 全局单调 seq，
# 补发/回放游标用 after=<id>。

_MIGRATED_EVENTS_TABLE = False


def _ensure_agent_events_table():
    """惰性确保 agent_events 表存在（幂等；服务启动 init_db 也会建，这里兜早调用）。"""
    global _MIGRATED_EVENTS_TABLE
    if _MIGRATED_EVENTS_TABLE:
        return
    _MIGRATED_EVENTS_TABLE = True
    try:
        _execute(
            "CREATE TABLE IF NOT EXISTS agent_events (\n"
            "  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,\n"
            "  round_id VARCHAR(64) NOT NULL DEFAULT '',\n"
            "  task_id VARCHAR(64) NOT NULL DEFAULT '',\n"
            "  parent_task_id VARCHAR(64) NOT NULL DEFAULT '',\n"
            "  event_type VARCHAR(40) NOT NULL,\n"
            "  step INT NOT NULL DEFAULT 0,\n"
            "  payload JSON NULL,\n"
            "  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n"
            "  KEY idx_round_id (round_id, id),\n"
            "  KEY idx_type (event_type),\n"
            "  KEY idx_time (created_at)\n"
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
    except Exception:
        pass  # 库不可用：下次再试（不阻塞 agent 主流程）


def log_agent_event(event_type: str, payload: dict | None = None, *,
                    round_id: str = "", task_id: str = "",
                    parent_task_id: str = "", step: int = 0) -> int:
    """写一条 agent 事件日志（仅追加）。返回事件 id；失败/无轮次返回 0。
    - round_id 为空则直接跳过（无轮次的调用/测试不产生噪音行）。
    - payload 任意可 JSON 序列化对象；序列化兜底 default=str（防 Date 等坏值炸表）。
    """
    if not round_id or not event_type:
        return 0
    try:
        _ensure_agent_events_table()
        cur = _execute(
            "INSERT INTO agent_events "
            "(round_id, task_id, parent_task_id, event_type, step, payload) "
            "VALUES (%s,%s,%s,%s,%s,%s)",
            (str(round_id)[:64], str(task_id or "")[:64],
             str(parent_task_id or "")[:64], str(event_type)[:40],
             int(step or 0),
             json.dumps(payload or {}, ensure_ascii=False, default=str)),
        )
        if cur is not None and getattr(cur, "lastrowid", None):
            return int(cur.lastrowid)
        return 0
    except Exception as e:
        bump_audit_failure(f"log_agent_event: {type(e).__name__}: {e}")
        return 0


def last_agent_event_id(round_id: str) -> int:
    """该轮最近一条事件 id（SSE done 携带用；无事件返回 0）。"""
    if not round_id:
        return 0
    rows = _execute(
        "SELECT id FROM agent_events WHERE round_id=%s ORDER BY id DESC LIMIT 1",
        (str(round_id)[:64],)) or []
    return int(rows[0]["id"]) if rows else 0


def query_agent_events(round_id: str, after: int = 0,
                       limit: int = 500) -> list[dict]:
    """按轮次取事件时间线（id 升序；after 为增量游标，只返回 id > after）。
    返回 [{id, type, step, payload, ts}]；失败/无轮次返回 []。"""
    if not round_id:
        return []
    limit = max(1, min(int(limit or 500), 1000))
    rows = _execute(
        "SELECT id, event_type, step, payload, created_at AS ts "
        "FROM agent_events WHERE round_id=%s AND id > %s "
        "ORDER BY id ASC LIMIT %s",
        (str(round_id)[:64], int(after or 0), limit)) or []
    out = []
    for r in rows:
        try:
            pl = json.loads(r["payload"]) if r.get("payload") else {}
        except Exception:
            pl = {}
        out.append({"id": int(r["id"]), "type": r["event_type"],
                    "step": int(r.get("step") or 0), "payload": pl,
                    "ts": r.get("ts")})
    return out


# ---------------- 后台任务落盘 journal（agent_jobs，P4 · 借 LoopX 务实版） ----------------
# 全部静默降级：MySQL 不可用时返回空/False，job 仍能纯内存跑（服务不因落盘挂掉）。

_MIGRATED_TASK_UNIQUE = False
# agent_tasks 是否确有 task_id 唯一索引（log_agent_task 原子幂等路径依赖：
# 索引就绪用单语句 INSERT IGNORE；建索引失败/老库脏数据置 False，走先查后插兜底）
_TASK_UQ_READY = False


def _ensure_agent_task_unique_idx():
    """给 agent_tasks 建 task_id 唯一索引（幂等；老库已有重复行时放弃建索引，
    由 log_agent_task 的应用层去重兜底，不因脏数据阻塞升级）。
    结束时把"唯一索引是否真正可用"写进 _TASK_UQ_READY（供原子幂等路径选择）。"""
    global _MIGRATED_TASK_UNIQUE, _TASK_UQ_READY
    if _MIGRATED_TASK_UNIQUE:
        return
    _MIGRATED_TASK_UNIQUE = True
    try:
        idxs = _execute("SHOW INDEX FROM agent_tasks") or []
        has = any(i.get("Key_name") in ("idx_task_uq", "idx_task")
                  and not i.get("Non_unique") for i in idxs) if idxs else False
        if not has:
            _execute("ALTER TABLE agent_tasks ADD UNIQUE KEY idx_task_uq (task_id)")
            has = True  # 建索引成功 → 原子幂等路径可用
        _TASK_UQ_READY = has
    except Exception:
        # 表里有重复 task_id（或库不可用）→ 应用层去重兜底
        _TASK_UQ_READY = False


def _ts(v) -> str | None:
    """float 时间戳 → MySQL DATETIME 字符串；None 保持 None。"""
    if not v:
        return None
    import datetime
    try:
        return datetime.datetime.fromtimestamp(float(v)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def save_agent_job(job_id: str, fingerprint: str = "", task: str = "",
                   mode: str = "standard", round_id: str = "",
                   status: str = "queued", reply: str = "", error: str = "",
                   stop_reason: str = "", steps: int = 0, ms: int = 0,
                   started_at=None, ended_at=None) -> bool:
    """upsert 一行 agent_jobs（按 job_id 幂等）。任何异常返回 False 不抛。"""
    try:
        _execute(
            "INSERT INTO agent_jobs (job_id, fingerprint, task, mode, round_id, status, "
            " reply, error, stop_reason, steps, ms, started_at, ended_at) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
            "ON DUPLICATE KEY UPDATE fingerprint=VALUES(fingerprint), task=VALUES(task), "
            " mode=VALUES(mode), round_id=VALUES(round_id), status=VALUES(status), "
            " reply=VALUES(reply), error=VALUES(error), stop_reason=VALUES(stop_reason), "
            " steps=VALUES(steps), ms=VALUES(ms), started_at=VALUES(started_at), "
            " ended_at=VALUES(ended_at)",
            (str(job_id)[:64], str(fingerprint or "")[:64], str(task or ""),
             str(mode or "standard")[:16], str(round_id or "")[:64],
             str(status)[:20], str(reply or ""), str(error or ""),
             str(stop_reason or "")[:32], int(steps or 0), int(ms or 0),
             _ts(started_at), _ts(ended_at)),
        )
        return True
    except Exception:
        return False


def agent_job_find_active(fingerprint: str) -> str:
    """调度幂等：同 fingerprint 且状态非终态 → 返回已有 job_id；否则空串。"""
    if not fingerprint:
        return ""
    try:
        r = _execute(
            "SELECT job_id FROM agent_jobs WHERE fingerprint=%s "
            "AND status IN ('queued','running','awaiting_approval') "
            "ORDER BY id DESC LIMIT 1",
            (str(fingerprint)[:64],),
            fetch_one=True,
        )
        return (r or {}).get("job_id", "")
    except Exception:
        return ""


def list_agent_job_pending() -> list[dict]:
    """启动恢复扫描：返回未进入终态的 job 行（queued/running/awaiting_approval）。"""
    try:
        rows = _execute(
            "SELECT job_id, fingerprint, task, mode, round_id, status "
            "FROM agent_jobs WHERE status IN "
            "('queued','running','awaiting_approval') ORDER BY id ASC") or []
        return [dict(r) for r in rows]
    except Exception:
        return []


def close_agent_job_interrupted(job_id: str, ended_at=None) -> bool:
    """把重启前仍在执行/等审批的 job 标记为 interrupted（不自动重跑）。

    只 UPDATE 状态/错误/停因/结束时间，绝不覆盖 task/reply 等原文
    （upsert 式全字段更新会清空日志，journal 就失去意义）。
    """
    try:
        _execute(
            "UPDATE agent_jobs SET status='interrupted', "
            " error=%s, stop_reason='interrupted', ended_at=%s "
            " WHERE job_id=%s",
            ("上次进程退出时该任务正在执行，已中断（副作用不可重放，需手动重跑）",
             _ts(ended_at), str(job_id)[:64]),
        )
        return True
    except Exception:
        return False


# ---------------- Lazaxa 笔记到期提醒（reminders，定时扫描 Obsidian 生成） ----------------

def add_reminder(content: str, note_path: str = "", remind_at=None) -> bool:
    """写入一条提醒（按 笔记+内容+日期 去重，重复返回 False）。"""
    from datetime import date

    remind_at = remind_at or date.today()
    try:
        cur = _execute(
            "INSERT IGNORE INTO reminders (content, note_path, remind_at) "
            "VALUES (%s,%s,%s)",
            (str(content)[:500], str(note_path or "")[:200], str(remind_at)),
        )
        return bool(cur and cur.rowcount)
    except Exception:
        return False


def list_reminders_by_date(remind_at) -> list:
    """某天到期且未处理的提醒（pending + 已读一并返回，前端区分）。"""
    return _execute(
        "SELECT id, content, note_path, status, created_at "
        "FROM reminders WHERE remind_at=%s AND status IN ('pending','read') "
        "ORDER BY id",
        (str(remind_at),),
    ) or []


def mark_reminder_read(rid: int) -> bool:
    """把提醒标记为已读。"""
    try:
        _execute("UPDATE reminders SET status='read' WHERE id=%s", (int(rid),))
        return True
    except Exception:
        return False


# ---------------- Lazaxa 手机事件反连（phone_events，adb 轮询设备通知/电量入库） ----------------

def add_phone_event(ev_key: str, kind: str = "notice", pkg: str = "",
                    title: str = "", content: str = "", level: str = "info") -> bool:
    """写入一条手机事件（按 ev_key 去重，重复返回 False）。"""
    try:
        cur = _execute(
            "INSERT IGNORE INTO phone_events (ev_key, kind, pkg, title, content, level) "
            "VALUES (%s,%s,%s,%s,%s,%s)",
            (str(ev_key)[:190], str(kind)[:24], str(pkg or "")[:100],
             str(title or "")[:200], str(content or "")[:500], str(level or "info")[:10]),
        )
        return bool(cur and cur.rowcount)
    except Exception:
        return False


def list_phone_events(limit: int = 20) -> list:
    """最近未处理完的手机事件（pending 优先，再按新→旧）。"""
    limit = max(1, min(int(limit), 100))
    return _execute(
        "SELECT id, ev_key, kind, pkg, title, content, level, status, created_at "
        "FROM phone_events WHERE status IN ('pending','read') "
        "ORDER BY (status='pending') DESC, id DESC LIMIT %s",
        (limit,),
    ) or []


def mark_phone_event_read(rid: int) -> bool:
    """把一条手机事件标记为已读。"""
    try:
        _execute("UPDATE phone_events SET status='read' WHERE id=%s", (int(rid),))
        return True
    except Exception:
        return False