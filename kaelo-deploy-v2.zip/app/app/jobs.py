# -*- coding: utf-8 -*-
"""后台任务管理器（"边聊边做"通话督导模式 · 2026-08-18）。

形态：用户开着"边聊边做"开关时，Lazaxa 是监工、你是老板：
- 复杂指令由主对话调 delegate_job → 派一个后台 worker（独立
  run_agent_task 协程，role="worker"）执行，主对话立刻回复，不被阻塞；
- 老板随时可继续说话（新指令/问进度/传话），每轮对话自动注入活跃
  job 摘要，主模型据此汇报；call_worker 把老板的话传进 worker 的
  inbox，worker 每轮循环开头读取并照办（真·现场指挥）；
- 最多 config.AGENT_JOB_PARALLEL 个 worker 并行执行（期3 多任务并行）：
  文件/检索等不碰界面的任务互不干扰、同时跑；会操作同一屏幕/键鼠的
  工具（screen_lock=True）执行前申请全局屏幕互斥锁（loop._screen_sem），
  谁先申请到谁用、用完让出，天然防键鼠打架；超出并行上限的新委派进入
  queued 排队，有 worker 结束自动补位启动；
- worker 的进度与审批事件写入 Job 内部状态，由前端轮询
  GET /api/v1/agent/jobs 读取（Tkinter 轮询最稳，不做常驻 SSE）；
- 审批复用全局 ApprovalManager 单例（asyncio.Event 跨协程可唤醒），
  前端照旧 POST /approve 应答，resolve 后 worker 自动恢复运行。
"""
import asyncio
import collections
import hashlib
import itertools
import threading
import time

from . import config
from .agent.stop_reason import StopReason

# job_id 生成：毫秒时间戳 + 进程内自增序号（同毫秒批量派发不冲突）
_ID_COUNTER = itertools.count(1)

# worker 可见工具 = 全量工具 - 管理/委派类（防 worker 再开 worker / 误用管理工具）
_MANAGEMENT_TOOLS = {
    "delegate_job",       # 后台开工
    "check_jobs",         # 查任务
    "call_worker",        # 向任务传话
    "cancel_job",         # 取消任务
    "subagent_spawn",     # 子代理委派（worker 不应再委派）
    "subagent_parallel",  # 并行委派
}

# job 状态机
STATE_QUEUED = "queued"               # 排队等待（前面有 worker 在执行）
STATE_RUNNING = "running"             # 执行中
STATE_AWAITING = "awaiting_approval"  # 执行中，等你审批
STATE_DONE = "done"                   # 完成
STATE_FAILED = "failed"               # 失败（出错/超时）
STATE_CANCELLED = "cancelled"         # 被老板取消

_ACTIVE_STATES = (STATE_RUNNING, STATE_AWAITING)
# 可接收老板传话的状态（排队中先把话收进 inbox，等 worker 启动后再消费）
_CAN_RECEIVE = (STATE_QUEUED, STATE_RUNNING, STATE_AWAITING)
# 终态（不会再有状态变化，只等收尾展示）
_TERMINAL_STATES = (STATE_DONE, STATE_FAILED, STATE_CANCELLED)
# 安静契约（B批3 · 借 LoopX quiet_noop 哲学）：终态任务只在结束后该秒数内
# 进入主对话摘要（刚结束时老板可能追问结果），窗口一过即静默——自动化不制造
# 多余 review 噪音。老板想查历史随时可用 check_jobs 工具主动问。
_TERMINAL_QUIET_SECONDS = 300

# worker 实际执行器（懒加载，避免与 agent 包循环 import；测试可替换为假执行器）
_TASK_RUNNER = None


def _get_runner():
    global _TASK_RUNNER
    if _TASK_RUNNER is None:
        from .agent.loop import run_agent_task  # 懒加载
        _TASK_RUNNER = run_agent_task
    return _TASK_RUNNER


# ============ 落盘 journal（P4 · 借 LoopX 务实版：job 级不静默丢失 + 不重复启动） ============
# 默认写 MySQL（db.py agent_jobs 表）；测试/库不可用时静默降级纯内存。
# 可整体替换这四个钩子做单元测试（monkeypatch）。

def _db_save_job(job) -> None:
    """把一个 Job 快照 upsert 进 agent_jobs（任意状态变化后调用）。"""
    try:
        from . import db
        db.save_agent_job(
            job_id=job.id, fingerprint=job.fingerprint, task=job.task,
            mode=job.mode, round_id=job.round_id, status=job.state,
            reply=job.reply, error=job.error, stop_reason=job.stop_reason,
            steps=job.steps, ms=job.ms, started_at=job.started_at,
            ended_at=job.ended_at)
    except Exception:
        pass


def _db_find_active(fingerprint: str) -> str:
    try:
        from . import db
        return db.agent_job_find_active(fingerprint)
    except Exception:
        return ""


def _db_load_pending() -> list[dict]:
    try:
        from . import db
        return db.list_agent_job_pending()
    except Exception:
        return []


def _db_close_interrupted(job_id: str, ended_at=None) -> None:
    try:
        from . import db
        db.close_agent_job_interrupted(job_id, ended_at)
    except Exception:
        pass


def _fingerprint(task: str, mode: str, round_id: str = "") -> str:
    """调度幂等键：同一 指令+模式+轮次 → 同一指纹，防消息重发产生双份副作用。"""
    return hashlib.sha256(
        f"{mode}|{round_id}|{task}".encode("utf-8")).hexdigest()[:64]


class Job:
    """一个后台任务（worker）的记录与运行状态。"""

    def __init__(self, job_id: str, task: str, mode: str):
        self.id = job_id
        self.task = task                # 原始指令
        self.mode = mode                # 权限模式（与委派它的主对话一致）
        self.fingerprint = ""           # 调度幂等键（P4）
        self.round_id = ""              # 发起该 job 的主对话轮 id（P4）
        self.state = STATE_QUEUED
        self.created_at = time.time()
        self.started_at: float | None = None
        self.ended_at: float | None = None
        self.reply = ""                 # 最终输出
        self.error = ""                 # 失败原因（state=failed 时）
        self.stop_reason = ""           # 停因（取值见 agent.stop_reason.StopReason）
        self.steps = 0
        self.ms = 0
        self.activity: list[dict] = []  # 进度事件环形缓冲（前端面板"当前在干什么"）
        self.pending_approval: dict | None = None  # state=awaiting_approval 时的审批详情
        self.cancel_event: asyncio.Event = asyncio.Event()  # 老板取消信号（协作式中断）
        self.inbox: asyncio.Queue = asyncio.Queue()  # 老板传话（worker 每轮循环开头消费）
        self.future: asyncio.Task | None = None      # worker 协程的 Task 句柄（取消用）

    def to_dict(self, detail: bool = True) -> dict:
        d = {
            "id": self.id,
            "task": self.task,
            "mode": self.mode,
            "state": self.state,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "reply": self.reply,
            "error": self.error,
            "stop_reason": self.stop_reason,
            "steps": self.steps,
            "ms": self.ms,
            "pending_approval": self.pending_approval,
        }
        if detail:
            d["activity"] = self.activity[-config.AGENT_JOB_ACTIVITY_LIMIT:]
        return d

    def _append_activity(self, kind: str, text: str):
        self.activity.append({"kind": kind, "text": text, "ts": time.time()})
        if len(self.activity) > config.AGENT_JOB_ACTIVITY_LIMIT:
            self.activity = self.activity[-config.AGENT_JOB_ACTIVITY_LIMIT:]


class JobManager:
    """后台任务管理器（进程级单例）：调度 / 排队 / 取消 / 状态查询。"""

    def __init__(self):
        self._jobs: dict[str, Job] = {}
        self._order: list[str] = []           # 创建顺序（展示用）
        self._queued: collections.deque = collections.deque()  # 等待执行的 job_id FIFO
        self._running: set[str] = set()       # 正在执行的 job_id（最多 AGENT_JOB_PARALLEL 个）
        self._lock = threading.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None  # 主事件循环（工具线程投递用）
        self._context_mode: str | None = None  # 最近一次主对话的权限模式（worker 继承）
        self._recovered = False  # 进程启动后是否已做落盘恢复扫描（P4）

    # ---------- 事件循环绑定 ----------

    def bind_loop(self, loop: asyncio.AbstractEventLoop):
        """绑定主事件循环（routers/agent.py 每轮任务开始时调用）。

        工具在 ThreadPoolExecutor 线程里执行，启动/取消协程需投递到
        这个已绑定的事件循环（run_coroutine_threadsafe）。
        首次绑定时顺带触发落盘恢复扫描（recover_pending 内部有幂等闸，
        重复绑定/重复调度只会真正执行一次）。
        """
        self._loop = loop
        try:
            loop.create_task(self.recover_pending())
        except Exception:
            pass  # 事件循环未就绪等：恢复留到下次绑定

    def set_context_mode(self, mode: str | None):
        """记录最近一次主对话的权限模式，新 worker 继承同一模式。"""
        if mode:
            self._context_mode = mode

    def _run_async(self, coro):
        """在绑定的事件循环里同步等待一个协程（供工具线程调用）。"""
        loop = self._loop or asyncio.get_event_loop()
        fut = asyncio.run_coroutine_threadsafe(coro, loop)
        return fut.result(timeout=30)

    # ---------- 对外操作（工具/路由调用） ----------

    def launch(self, task: str, mode: str | None = None,
               round_id: str = "") -> str:
        """派一个后台任务。返回 job_id；并行槽已满时进入排队。

        幂等（P4）：同一 指令+模式+轮次 已有非终态任务 → 返回既有 job_id，
        不重复创建（防"消息重发/双击发送"产生双份副作用）。
        """
        mode = mode or self._context_mode or config.PERMISSION_DEFAULT_MODE
        return self._run_async(self._launch_async(task, mode, round_id))

    def cancel(self, job_id: str) -> bool:
        """取消任务（执行中立即中断；排队中直接移除）。

        先同步快速失败（任务不存在/已终态无需动事件循环），
        只有真需要中断/移除时才投递到绑定的事件循环。
        """
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.state not in _CAN_RECEIVE:
                return False
            if job.state == STATE_QUEUED:  # 排队中：同步直接取消，无需事件循环
                return self._cancel_queued_locked(job)
        return self._run_async(self._cancel_async(job_id))

    def send_instruction(self, job_id: str, text: str) -> bool:
        """向执行中（含排队中）的 worker 传话（入 inbox，worker 每轮循环读取）。"""
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.state not in _CAN_RECEIVE:
                return False
            job.inbox.put_nowait(text)
            return True

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            return self._jobs.get(job_id)

    def list_jobs(self) -> list[dict]:
        with self._lock:
            jobs = [self._jobs[i] for i in self._order if i in self._jobs]
        return [j.to_dict() for j in reversed(jobs)]

    def list_active(self) -> list[Job]:
        with self._lock:
            return [self._jobs[i] for i in self._order
                    if i in self._jobs and self._jobs[i].state in _ACTIVE_STATES]

    def context_block(self) -> str:
        """活跃/最近任务摘要（注入主对话系统提示，供监工汇报）。无任务返回空串。

        安静契约（B批3 · 借 LoopX quiet_noop 哲学）：活跃/排队任务始终注入
        （督导模式核心）；终态任务只在结束 _TERMINAL_QUIET_SECONDS 内注入
        （刚结束时老板可能追问结果），超窗即静默，不为早已完成的旧任务反复
        制造汇报噪音。老板想查随时可问 check_jobs。
        """
        with self._lock:
            jobs = [self._jobs[i] for i in self._order if i in self._jobs]
        quiet_before = time.time() - _TERMINAL_QUIET_SECONDS
        lines = []
        for j in reversed(jobs[-6:]):
            if j.state in _TERMINAL_STATES and (j.ended_at or 0) < quiet_before:
                continue  # 终态且早已结束 → 安静，不进主对话
            st = {"queued": "排队", "running": "工作中", "awaiting_approval": "等你审批",
                  "done": "已完成", "failed": "失败", "cancelled": "已取消"}.get(j.state, j.state)
            task = j.task if len(j.task) <= 60 else j.task[:60] + "…"
            line = f"- [{j.id}] {st}：{task}"
            if j.state == STATE_RUNNING and j.activity:
                last = j.activity[-1]
                line += f"（当前：{last['text'][:50]}）"
            elif j.state in (STATE_DONE, STATE_FAILED, STATE_CANCELLED):
                tail = (j.reply or j.error or "").strip()
                line += f" → {tail[:50]}" if tail else ""
            lines.append(line)
        if not lines:
            return ""
        return ("【后台任务状态】（用户委托你监督这些后台任务，随时向用户汇报进度："
                "用户问进度就用它回答，别夸大也别漏报）：\n" + "\n".join(lines))

    # ---------- 内部调度（事件循环线程内调用） ----------

    async def recover_pending(self) -> int:
        """进程启动落盘恢复（幂等：全进程只真正执行一次）。

        借 LoopX 的 journal 思想，务实处理重启后的孤儿 job：
        - queued（从未开跑，无副作用）→ 自动续跑：无 worker 在执行则立即
          启动，否则照常进队等待（等价于重启前只是排队没动过手）；
        - running / awaiting_approval（进程退出时正在执行）→ 副作用不可
          重放，绝不自动重跑：落盘标记 interrupted，内存记成失败态展示给
          用户（任务记录中心可查原因），需用户手动重新下达。
        返回本次收口的 job 数（重复调用返回 0）。
        """
        if self._recovered:
            return 0
        self._recovered = True
        rows = _db_load_pending()
        if not rows:
            return 0
        n = 0
        for row in rows:
            jid = str(row.get("job_id") or "")
            status = str(row.get("status") or "")
            if not jid:
                continue
            with self._lock:
                if jid in self._jobs:
                    continue  # 防御：本次进程内已存在同 id 的 job
                job = Job(jid, str(row.get("task") or ""),
                          str(row.get("mode") or "") or config.PERMISSION_DEFAULT_MODE)
                job.fingerprint = str(row.get("fingerprint") or "")
                job.round_id = str(row.get("round_id") or "")
                self._jobs[jid] = job
                self._order.append(jid)
            if status == STATE_QUEUED:
                # 没开跑过 → 续跑（_drive 与正常调度完全同构）
                with self._lock:
                    if len(self._running) < config.AGENT_JOB_PARALLEL:
                        self._running.add(jid)
                        job.started_at = time.time()
                        job.state = STATE_RUNNING
                        try:
                            job.future = asyncio.create_task(self._drive(job))
                        except RuntimeError:
                            # 事件循环已关闭（进程退出边缘）→ 放弃本次续跑
                            self._running.discard(jid)
                            job.state = STATE_FAILED
                            job.error = "进程退出，恢复的任务未执行"
                            job.ended_at = time.time()
                    else:
                        self._queued.append(jid)
                _db_save_job(job)  # 续跑状态落盘（running/queued）
                n += 1
            else:
                # running / awaiting_approval → 中断不重跑
                _db_close_interrupted(jid, ended_at=time.time())
                job.state = STATE_FAILED
                job.stop_reason = "interrupted"
                job.error = ("上次进程退出时该任务正在执行，已中断"
                             "（副作用不可重放，需手动重跑）")
                job.ended_at = time.time()
                n += 1
        return n

    async def _launch_async(self, task: str, mode: str, round_id: str = "") -> str:
        task = (task or "").strip()
        if not task:
            raise ValueError("任务指令不能为空")
        fp = _fingerprint(task, mode, round_id)
        # 幂等（P4）：内存 + 落盘双查同指纹非终态任务
        with self._lock:
            for jid in list(self._jobs):
                j = self._jobs.get(jid)
                if (j is not None and j.fingerprint == fp
                        and j.state in _CAN_RECEIVE):
                    return jid
        dup = _db_find_active(fp)
        if dup:
            return dup
        job_id = f"job-{int(time.time() * 1000)}-{next(_ID_COUNTER)}"
        job = Job(job_id, task, mode)
        job.fingerprint = fp
        job.round_id = round_id
        with self._lock:
            self._jobs[job_id] = job
            self._order.append(job_id)
            if len(self._running) < config.AGENT_JOB_PARALLEL:
                self._running.add(job_id)
                job.started_at = time.time()
                job.state = STATE_RUNNING
                job.future = asyncio.create_task(self._drive(job))
            else:
                self._queued.append(job_id)  # 并行槽已满 → 排队
        _db_save_job(job)   # 落盘：queued 或 running 首行（库不可用自动降级）
        return job_id

    async def _drive(self, job: Job):
        """执行 worker：run_agent_task 独立上下文，取消/超时协作处理。

        取消不依赖 Task.cancel()（Python 3.11 中 cancel + wait_for 组合的
        CancelledError 会直接终结 task 而不被 except 捕获，状态机收不了尾），
        改为：_drive 同时等待 worker 与 cancel_event，任一先完成即返回；
        老板取消 → 发信号中断 worker 并置 cancelled；整体超时同理置 failed。
        """
        from .agent.registry import registry

        allowed = [n for n in registry.names() if n not in _MANAGEMENT_TOOLS]
        t0 = time.time()
        worker = asyncio.create_task(_get_runner()(
            user_message=job.task, history=[],
            emit=_make_job_emitter(job),
            mode=job.mode,
            depth=1,
            tool_filter=allowed,
            role="worker",
            parent_task_id=job.id,
            inbox=job.inbox,
            round_id=job.id,
        ))
        job.future = worker  # 记录 worker 任务（后续若需强制取消的直接目标）
        cancel_waiter = asyncio.create_task(job.cancel_event.wait())
        try:
            try:
                done, _pending = await asyncio.wait(
                    {worker, cancel_waiter},
                    return_when=asyncio.FIRST_COMPLETED,
                    timeout=config.AGENT_JOB_TIMEOUT)
                job.ms = int((time.time() - t0) * 1000)
                if worker in done:
                    # worker 自行结束 → 取汇总（正常/错误/异常一律转成终态）
                    if worker.cancelled():
                        job.state = STATE_CANCELLED
                        job.stop_reason = StopReason.CANCELLED.value
                        job.reply = "（任务已被老板取消）"
                    else:
                        try:
                            summary = worker.result()
                        except Exception as e:
                            job.state = STATE_FAILED
                            job.error = f"{type(e).__name__}: {e}"
                            job.stop_reason = StopReason.ERROR.value
                        else:
                            job.steps = summary.get("steps", 0)
                            sr = summary.get("stop_reason") or ""
                            # 停因统一引用 StopReason；mock/旧调用未带 stop_reason 时
                            # 按 error 字段兼容（无 error 视为完成）
                            if summary.get("error"):
                                job.state = STATE_FAILED
                                job.error = summary.get("error", "")
                                job.stop_reason = (sr or StopReason.ERROR.value)
                            elif sr in (StopReason.ERROR.value,
                                        StopReason.EMPTY_RESPONSE.value,
                                        StopReason.MAX_STEPS.value,
                                        StopReason.LOOP_CAPPED.value,
                                        StopReason.CANCELLED.value,
                                        StopReason.TIMEOUT.value):
                                job.state = STATE_FAILED
                                job.error = sr
                                job.stop_reason = sr
                            else:
                                job.state = STATE_DONE
                                job.reply = summary.get("reply", "")
                                job.stop_reason = (sr or StopReason.COMPLETED.value)
                else:
                    # cancel 事件触发 或 超时 → 中断 worker，收尾成终态
                    if not worker.done():
                        worker.cancel()
                    await asyncio.gather(worker, return_exceptions=True)
                    if job.cancel_event.is_set():
                        job.state = STATE_CANCELLED
                        job.stop_reason = StopReason.CANCELLED.value
                        job.reply = "（任务已被老板取消）"
                    else:
                        job.state = STATE_FAILED
                        job.error = f"任务超时（>{config.AGENT_JOB_TIMEOUT}s）"
                        job.stop_reason = StopReason.TIMEOUT.value
            finally:
                try:
                    if not cancel_waiter.done():
                        cancel_waiter.cancel()
                except RuntimeError:
                    pass  # 事件循环已关闭（进程退出边缘）→ 忽略
                job.ended_at = time.time()
                job.pending_approval = None
                _db_save_job(job)   # 落盘终态（P4）
                self._finish(job)
        except asyncio.CancelledError:
            # _drive 自身被取消（进程关闭等）→ 中断 worker 并把任务收成已取消
            if not worker.done():
                worker.cancel()
                await asyncio.gather(worker, return_exceptions=True)
            job.state = STATE_CANCELLED
            job.stop_reason = StopReason.CANCELLED.value
            job.reply = "（任务在进程退出时被中断）"
            job.ended_at = time.time()
            _db_save_job(job)  # 尽力落盘终态（库已不可用则静默跳过）
            raise

    def _finish(self, job: Job):
        """当前 worker 结束：腾出执行槽，自动启动排队任务补位。"""
        with self._lock:
            self._running.discard(job.id)
            self._start_next_locked()

    async def _cancel_async(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return False
            if job.state in _ACTIVE_STATES:
                # 协作式取消：发信号 → _drive 的 asyncio.wait 立即返回，
                # 中断 worker 并把状态收成 cancelled（不必 Task.cancel，规避
                # Python 3.11 cancel+wait_for 组合的收尾陷阱）
                job.pending_approval = None
                job.cancel_event.set()
                return True
            if job.state == STATE_QUEUED:
                return self._cancel_queued_locked(job)
            return False  # 已完成/已失败/已取消 → 无需再取消

    def _mark_cancelled_locked(self, job: Job, note: str):
        """把 job 置为已取消（须持有 _lock）。"""
        job.state = STATE_CANCELLED
        job.stop_reason = StopReason.CANCELLED.value
        job.reply = note
        job.pending_approval = None
        job.ended_at = time.time()

    def _cancel_queued_locked(self, job: Job) -> bool:
        """移除并取消一个排队中的任务（须持有 _lock）。"""
        try:
            self._queued.remove(job.id)
        except ValueError:
            pass
        self._mark_cancelled_locked(job, "（任务在排队时被老板取消）")
        # 落盘终态（P4）：排队任务从未跑过、没有 _drive 收尾，必须在这里把状态
        # 写死 cancelled；否则 DB 会留陈旧 queued 行，重启被恢复扫描重跑，或让
        # 同指纹新任务被误判已存在而吞掉。
        _db_save_job(job)
        return True

    def _start_next_locked(self):
        """执行槽释放后启动排队任务补位（须持有 _lock）。

        有多少空槽就尽量填满多少（直到排空或触到并行上限），与 _finish /
        取消 queued 任务的回收路径同构；排队中的任务若已被取消/不存在则
        跳过，继续取下一个。
        """
        while len(self._running) < config.AGENT_JOB_PARALLEL and self._queued:
            job_id = self._queued.popleft()
            job = self._jobs.get(job_id)
            if job is None or job.state != STATE_QUEUED:
                continue  # 已被取消或不存在 → 跳过
            self._running.add(job_id)
            job.started_at = time.time()
            job.state = STATE_RUNNING
            try:
                job.future = asyncio.create_task(self._drive(job))
            except RuntimeError:
                # 事件循环已关闭（进程退出中）→ 腾出槽位，放弃本次启动
                self._running.discard(job_id)
                job.state = STATE_FAILED
                job.error = "进程退出，任务未执行"
                job.ended_at = time.time()


def _make_job_emitter(job: Job):
    """worker 事件适配器：把 run_agent_task 的事件写入 Job 状态。

    - approval_request → state=awaiting_approval + 存审批详情（前端轮询到后弹窗）
    - 其他事件（thinking/tool_call/tool_result）→ 写入 activity 环形缓冲；
      若正处于 awaiting_approval（说明审批已通过、worker 恢复），切回 running
    """
    async def emit(event_type: str, payload: dict):
        if event_type == "approval_request":
            job.state = STATE_AWAITING
            job.pending_approval = {
                "task_id": payload.get("task_id", ""),
                "tool": payload.get("tool", ""),
                "args": payload.get("args", {}),
                "risk": payload.get("risk", ""),
                "ts": time.time(),
            }
            return
        if event_type in ("done", "error"):
            return  # 终态由 _drive 依据 run_agent_task 返回值处理
        # 非审批事件到达 → 若刚从等待审批恢复，切回运行态并清空审批缓存
        if job.state == STATE_AWAITING:
            job.state = STATE_RUNNING
            job.pending_approval = None
        if event_type == "tool_call":
            name = payload.get("display_name") or payload.get("name", "")
            job._append_activity("tool_call", f"调用 {name}")
        elif event_type == "tool_result":
            if payload.get("ok"):
                job._append_activity("tool_result", "✔ " + (payload.get("brief") or "成功"))
            else:
                job._append_activity("tool_result", "✘ " + (payload.get("error") or payload.get("brief") or "失败"))
        elif event_type == "thinking":
            step = payload.get("step", 0)
            note = payload.get("note", "")
            job._append_activity("thinking", note or f"思考第 {step} 步")
    return emit


# 进程级单例
manager = JobManager()
