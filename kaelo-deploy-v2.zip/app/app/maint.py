# -*- coding: utf-8 -*-
"""知识库维护算法模块（独立可部署，适合放到更强服务器上运行）。

解决的问题：知识库文件一多，"脏数据"就会拖垮检索——
  1. 重复内容：同一信息被多次上传 → 检索时重复块挤占候选位
  2. 低价值内容：广告、口水话、空话 → 浪费向量空间与检索精度
  3. 过度相似：两份文档讲同一件事 → 知识冗余

本模块提供四类算法（全部可独立运行，也可通过 /api/maint 接口调用）：
  A. 精确去重          —— 完全相同的文本块，只保留一份
  B. 语义去重合并      —— 语义高度相似(>0.9)的块合并，保留信息更全者
  C. 低价值提炼/降权   —— 过短、空话、低信息块移入"冷库"(不参与检索)
  D. 维护报告          —— 每次维护输出统计，供人工确认

设计原则：
  · 绝不自动删除 —— 所有"淘汰"都是降权/归档，可恢复，人工确认才删
  · 合并可追溯   —— 合并后保留来源引用，出问题能回滚
  · 批量矩阵计算 —— 不逐对循环，用 numpy 向量矩阵，适合较大库
"""
import json
import os
import re
from datetime import datetime
from typing import List

import numpy as np

from . import config, rag

# ============ A. 精确去重 ============

def dedup_exact(store: rag.VecStore) -> dict:
    """精确去重：完全相同的文本块只保留第一份。返回统计。"""
    seen: dict[str, int] = {}   # text -> 首次出现 index
    keep_idx: List[int] = []
    removed = 0
    for i, m in enumerate(store.meta):
        t = m["text"]
        if t in seen:
            removed += 1
            continue
        seen[t] = i
        keep_idx.append(i)
    if removed:
        _rebuild_by_index(store, keep_idx)
    return {"removed": removed, "kept": len(keep_idx), "total_before": len(seen) + removed}


# ============ B. 语义去重合并 ============

def _semantic_similar_pairs(store: rag.VecStore, threshold: float = 0.90,
                            block: int = 256) -> List[tuple]:
    """分块计算全库所有相似度 > threshold 的 (sim, i, j) 对，按相似度降序。

    阶段 2 可靠性：原实现构建 n×n 全库相似度矩阵，块数上万后内存爆炸
    （1 万块约 400MB，5 万块约 10GB）。改为分块批处理——每次只算
    block×n 的局部矩阵，内存峰值 O(block×n)（block=256 时约 2MB/万块量级）。
    只保留上三角（j>i）且超过阈值的高相似对，结果与全矩阵版完全一致。
    """
    v = store.vectors
    if v is None or len(v) == 0:
        return []
    n = len(v)
    norms = np.linalg.norm(v, axis=1)
    pairs: List[tuple] = []
    for start in range(0, n, block):
        end = min(start + block, n)
        block_v = v[start:end]
        # (block × n) 相似度矩阵（只保留该批次内每行 j>i 的部分）
        sim = (block_v @ v.T) / (norms[start:end, None] * norms[None, :] + 1e-9)
        for k in range(end - start):
            i = start + k
            row = sim[k]
            js = np.nonzero(row[i + 1:] > threshold)[0] + (i + 1)
            for j in js:
                pairs.append((float(row[j]), i, int(j)))
    pairs.sort(key=lambda x: -x[0])
    return pairs


def dedup_semantic(store: rag.VecStore, threshold: float = 0.90) -> dict:
    """语义去重合并：相似度 > threshold 的块合并，保留更长、信息更全者。

    返回合并统计。因为会改 meta/vectors，先算好再一次性重建。
    """
    n = store.size
    if n < 2:
        return {"merged": 0, "kept": n, "pairs": []}
    pairs = _semantic_similar_pairs(store, threshold)
    # 贪心合并：从相似度最高的对开始
    merged_pairs = []
    keep = [True] * n
    for sim_val, i, j in pairs:
        if not keep[i] or not keep[j]:
            continue  # 已并入其他块
        # 保留信息更全（更长）者，另一个标记删除
        if len(store.meta[i]["text"]) >= len(store.meta[j]["text"]):
            survivor, victim = i, j
        else:
            survivor, victim = j, i
        keep[victim] = False
        merged_pairs.append({
            "kept_source": store.meta[survivor].get("source", ""),
            "removed_source": store.meta[victim].get("source", ""),
            "similarity": round(float(sim_val), 3),
        })
    removed = n - sum(keep)
    if removed:
        keep_idx = [i for i in range(n) if keep[i]]
        _rebuild_by_index(store, keep_idx)
    return {"merged": removed, "kept": sum(keep), "pairs": merged_pairs}


# ============ C. 低价值提炼 / 降权 ============

# 低价值特征：长度过短 / 纯符号 / 无实义词
_LOWVALUE_PATTERNS = [
    re.compile(r"^[\s\u3000]{0,5}$"),           # 纯空白
    re.compile(r"^[\W_]{1,20}$"),               # 纯符号(含下划线)
    re.compile(r"^(你好|谢谢|好的|收到|嗯|嗯嗯|ok|OK|谢谢您)[\s。！!]*$"),  # 口水话
]


def _is_low_value(text: str, min_len: int = 12) -> tuple[bool, str]:
    """判断文本块是否低价值，返回 (是否低价值, 原因)。"""
    t = text.strip()
    if len(t) < min_len:
        return True, f"过短({len(t)}字<{min_len})"
    for pat in _LOWVALUE_PATTERNS:
        if pat.match(t):
            return True, "纯符号/口水话"
    # 有效汉字/字母数量占比过低
    valid = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", t))
    if valid / max(len(t), 1) < 0.5:
        return True, "有效字符占比过低"
    return False, ""


def prune_low_value(store: rag.VecStore, min_len: int = 12) -> dict:
    """低价值块移入冷库（从活跃集移除，归档到 cold_meta.json，可恢复）。"""
    cold = []
    keep_idx: List[int] = []
    for i, m in enumerate(store.meta):
        low, reason = _is_low_value(m["text"], min_len)
        if low:
            cold.append({**m, "cold_reason": reason, "cold_at": datetime.now().isoformat()})
        else:
            keep_idx.append(i)
    if cold:
        # 归档冷库
        cold_path = os.path.join(store.path, "cold_meta.json")
        existing = []
        if os.path.exists(cold_path):
            with open(cold_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        existing.extend(cold)
        with open(cold_path, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=1)
        _rebuild_by_index(store, keep_idx)
    return {"pruned": len(cold), "kept": len(keep_idx), "cold_items": [c["text"][:40] for c in cold]}


# ============ 内部工具 ============

def _rebuild_by_index(store: rag.VecStore, keep_idx: List[int]):
    """按保留索引重建 store 的 vectors/meta/bm25 并保存（复用 VecStore 实现）。"""
    store._rebuild_by_index(keep_idx)


# ============ D. 维护报告 ============

def run_maintenance(store: rag.VecStore, semantic_threshold: float = 0.90,
                    min_len: int = 12) -> dict:
    """一键维护：精确去重 → 语义合并 → 低价值提炼。返回完整报告。"""
    report = {
        "run_at": datetime.now().isoformat(),
        "kb_size_before": store.size,
        "steps": {},
    }
    # A. 精确去重
    r1 = dedup_exact(store)
    report["steps"]["exact_dedup"] = r1
    # B. 语义合并
    r2 = dedup_semantic(store, threshold=semantic_threshold)
    report["steps"]["semantic_merge"] = r2
    # C. 低价值提炼
    r3 = prune_low_value(store, min_len=min_len)
    report["steps"]["low_value_prune"] = r3
    report["kb_size_after"] = store.size
    report["total_removed"] = store.size - report["kb_size_before"] + (r1["removed"] + r2["merged"] + r3["pruned"])
    report["total_removed"] = report["kb_size_before"] - store.size
    return report


# ============ 独立运行入口（可部署到更强服务器） ============

if __name__ == "__main__":
    from .log_util import setup_logging, get_logger
    setup_logging()
    _log = get_logger("maint")
    _log.info("=" * 50)
    _log.info("知识库维护算法 · 独立运行")
    _log.info("=" * 50)
    store = rag.get_store()
    _log.info("维护前知识库规模: %d 块", store.size)
    rep = run_maintenance(store)
    _log.info(json.dumps(rep, ensure_ascii=False, indent=2))
    _log.info("维护后知识库规模: %d 块", store.size)
    _log.info("提示：冷库文件在 %s", os.path.join(store.path, "cold_meta.json"))