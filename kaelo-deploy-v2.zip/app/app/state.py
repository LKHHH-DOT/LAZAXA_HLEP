# -*- coding: utf-8 -*-
"""全局共享状态与知识库辅助函数（main.py 拆分后的公共层，阶段 1）。

拆分前这些状态/函数都定义在 main.py 模块级，多个路由模块各自 import 会
导致循环依赖，故集中在此作为唯一共享源。路由层通过 `from ..state import ...`
引用，main.py 只负责组合路由与启动初始化。
"""
import os

from . import config, rag
from .llm import _llm_complete

# 项目根目录（基于当前文件定位，避免相对路径在 Windows 上出错）
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_DIR = os.path.join(BASE_DIR, "web")

# 多库 store 缓存：kb_key -> VecStore
_stores: dict[str, rag.VecStore] = {}
# MySQL 内容向量库（懒加载）
_mysql_store: rag.VecStore | None = None
_mysql_store_loaded = False

# ---------- 智能体权限开关（前端"权限按钮"控制，默认全关=最安全） ----------
# 目前只有一个开关：workspace_strict（工作区沙箱）。默认 True=限死仓库内；
# 用户在前端点按钮关闭后，文件类工具可访问工作区外（受保护目录/敏感文件
# 黑名单/硬断路器/删除确认仍生效）。内存态，重启恢复默认（安全兜底）。
_permission_flags = {"workspace_strict": True}


def get_permission_flags() -> dict:
    """读取智能体权限开关当前状态（只读副本）。"""
    return dict(_permission_flags)


def set_permission_flag(key: str, value: bool) -> bool:
    """更新智能体权限开关；非法键返回 False。"""
    if key not in _permission_flags:
        return False
    _permission_flags[key] = bool(value)
    return True


# ---------- 智能体运行参数（前端"设置"界面自定义，用户可调） ----------
# max_steps = 单次任务最大工具调用步数。默认取 config.AGENT_MAX_STEPS（20），
# 复杂任务 20 步可能不够，用户可在前端设置里调大（1~100）。
# 内存态 + 前端 config.json 持久化：前端启动时把本地配置推送到后端，
# 后端重启后自动恢复用户设置；单看后端时恢复默认（安全兜底）。
_agent_settings = {"max_steps": int(getattr(config, "AGENT_MAX_STEPS", 20))}


def get_agent_settings() -> dict:
    """读取智能体运行参数（只读副本）。"""
    return dict(_agent_settings)


def set_agent_setting(key: str, value) -> bool:
    """更新智能体运行参数；非法键/非法值返回 False。

    max_steps 必须是 1~100 的整数（下限防死循环，上限留足够余量）。
    """
    if key != "max_steps":
        return False
    try:
        v = int(value)
    except (TypeError, ValueError):
        return False
    if not (1 <= v <= 100):
        return False
    _agent_settings["max_steps"] = v
    return True


def _get_mysql_store():
    """获取 MySQL 内容向量库（懒加载 + 每次使用前增量同步）。

    MySQL 里的高亮/档案/对话历史会同步进来，提问时与本地知识库合并检索。
    每次调用都执行增量同步（sync_from_mysql 内部按指纹/增量判断，
    内容无变化时零开销），确保网页新加的高亮/档案/新对话立即能被检索到。
    """
    global _mysql_store, _mysql_store_loaded
    if not config.MYSQL_RAG_ENABLED:
        return None
    if not _mysql_store_loaded:
        _mysql_store_loaded = True
        store = rag.VecStore(config.MYSQL_STORE_DIR).load()
        if store.size == 0:
            rag.sync_from_mysql(store, config.MYSQL_SYNC_STATE, config.MYSQL_CHAT_LIMIT)
        _mysql_store = store
    elif _mysql_store is not None:
        # 之后每次使用前都增量同步，保证新高亮/档案/对话可检索
        try:
            rag.sync_from_mysql(_mysql_store, config.MYSQL_SYNC_STATE, config.MYSQL_CHAT_LIMIT)
        except Exception:
            pass
    return _mysql_store


def _web_search(query: str, max_results: int = 3) -> list:
    """联网搜索（Tavily API）。返回 [{title, snippet, url}]，失败/未配置返回空列表。

    Tavily 专为 AI 优化，返回结构化结果；api.tavily.com 国内可直连。
    未配置 TAVILY_API_KEY 时直接跳过（不报错），等价于关闭联网。
    """
    if not config.WEB_SEARCH_ENABLED or not config.TAVILY_API_KEY:
        return []
    try:
        import requests
        r = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": config.TAVILY_API_KEY,
                "query": query,
                "max_results": max_results,
                "search_depth": "basic",
            },
            timeout=15,
        )
        if r.status_code != 200:
            return []
        data = r.json()
        out = []
        for item in (data.get("results") or [])[:max_results]:
            out.append({
                "title": item.get("title", ""),
                "snippet": (item.get("content", "") or "")[:config.WEB_SEARCH_SNIPPET_LEN],
                "url": item.get("url", ""),
            })
        return out
    except Exception:
        return []


# 拒答话术：AI 表示"知识库里没有"时的常见说法
_REFUSAL_PHRASES = (
    "知识库之外", "在我的知识库之外", "没有相关资料", "我没有相关",
    "无法回答", "不在我的知识库", "知识库中没有", "知识库里没有",
    "找不到相关", "没有找到相关", "不在我的范围内", "超出我的知识",
    "我无法获取", "不在我的资料", "我没有这方面的", "我没有关于",
    "不在我的知识范围", "我没有收录", "不在我的能力范围",
)


def _is_refusal(text: str) -> bool:
    """检测回答是否为拒答（AI 表示知识库没有相关内容）。

    判据：包含拒答话术且回答较短（<200 字）。正常基于知识库的回答一般
    较长且不会整段说"知识库之外"，故误判率低。配合联网兜底：拒答即联网。
    """
    t = (text or "").strip()
    if not t or len(t) > 200:
        return False
    return any(p in t for p in _REFUSAL_PHRASES)


def _rebuild_master():
    """分支库内容变更后：清空总库向量文件，下次访问时全量重建。"""
    if "master" in _stores:
        _stores.pop("master", None)
    m_cfg = config.KNOWLEDGE_BASES.get("master")
    if m_cfg:
        vdir = m_cfg["vector_dir"]
        os.makedirs(vdir, exist_ok=True)
        for fn in ("vectors.npy", "meta.json"):
            fp = os.path.join(vdir, fn)
            if os.path.exists(fp):
                os.remove(fp)


def _resolve_kb(kb: str | None) -> str:
    """规范化知识库 key：非法/空 → 默认库。"""
    if kb in config.KNOWLEDGE_BASES:
        return kb
    return config.DEFAULT_KB


def _get_store(kb: str | None = None):
    """获取指定知识库的向量库（缓存 + 首次自动建库 + 总库自动同步）。"""
    key = _resolve_kb(kb)
    if key not in _stores:
        store = rag.get_store(key)
        cfg = config.KNOWLEDGE_BASES[key]
        if config.AUTO_REBUILD and store.size == 0:
            if cfg.get("is_master"):
                # 总库：先同步分支库文档，再从多目录建库
                if config.MASTER_AUTO_SYNC:
                    rag.sync_master_from_branches()
                dirs = {b: os.path.join(cfg["knowledge_dir"], b) for b in cfg.get("branches", [])}
                rag.build_from_dir_multi(dirs, store)
            else:
                rag.build_from_dir(cfg["knowledge_dir"], store)
        _stores[key] = store
    return _stores[key]


def _build_search_query(message: str, history: list | None) -> str:
    """上下文感知的检索词扩展：每轮（含首轮）都先搭"用户语言 → 资料术语"的桥。

    经验来源（kada 医学库实战，三轮调优的最大收益点）：
      首轮直接拿口语原文检索，会撞不上资料里的书面术语/专有名词——用户问
      "腰好痛"，资料写"腰痛、肾着"，BM25 字面失效、语义分数被稀释，最后被误判
      "没有相关资料"。所以首轮也必须扩展，而不是只在多轮时才改写。

    两段式：
      1. 每轮都让 LLM 把问题扩写成检索关键词串（口语原词 + 同义说法 + 可能
         出现在资料里的专有名词/术语/实体）；
      2. 有历史时附带上一轮用户问题，消解"那个/刚才说的"这类指代。
    LLM 不可用/超时 → 降级：有历史则原文拼接，无历史则原文（保证不因改写
    服务抖动导致整个助手不可用）。
    """
    recent = ""
    for m in reversed(history or []):
        if m.get("role") == "user" and m.get("content"):
            recent = m["content"]
            break

    sys = (
        "你是检索关键词扩展器。用户在一个个人知识库问答系统中提问，"
        "请把问题扩写成最适合检索的中文关键词串：包含口语原词、常见同义说法、"
        "以及可能出现在资料里的专有名词（项目名、工具名、技术术语、人名、书名）。"
        "只输出一行空格分隔的关键词，不要解释、不要标点符号、不要换行。"
    )
    usr = f"问题：{message}\n"
    if recent:
        usr += f"（上一轮用户问的是：{recent}）\n"
    usr += "检索关键词："

    expanded = _llm_complete(sys, usr, timeout=15)
    if expanded and len(expanded) <= 200:
        return expanded.strip()
    # 降级：保留上一轮上下文解决指代问题，否则直接用原文
    return f"{recent} {message}" if recent else message


# ---------- 多车道检索车道定义（借 kada 医学库经验，按本库实际内容设计） ----------
# 每条车道 = 引导词（拼进检索词，把该类型资料"引"上来）
#            + 特征词（对候选块做稳定重排，命中多的靠前）。
# features 同时用于"该块是否属于本车道"的加权判断，故取该类资料里高频出现的词。
RETRIEVAL_LANES = [
    {
        "key": "project",
        "name": "项目经验与技术方案",
        "keywords": "项目 方案 经验 复盘 实现 架构 部署 踩坑 优化 测试 代码 接口 排查",
        "features": ("项目", "方案", "经验", "复盘", "实现", "架构", "部署", "踩坑",
                     "优化", "测试", "代码", "接口", "排查", "配置", "报错", "流程"),
    },
    {
        "key": "learning",
        "name": "学习路线与成长规划",
        "keywords": "学习 路线 规划 计划 阶段 目标 入门 进阶 课程 进度 里程碑 训练",
        "features": ("学习", "路线", "规划", "计划", "阶段", "目标", "入门", "进阶",
                     "课程", "进度", "里程碑", "训练", "练习", "掌握", "基础", "方法"),
    },
    {
        "key": "self",
        "name": "自我认知与个人档案",
        "keywords": "性格 优势 短板 认知 价值观 梦想 定位 天赋 习惯 偏好 内耗 状态",
        "features": ("性格", "优势", "短板", "认知", "价值观", "梦想", "定位", "天赋",
                     "习惯", "偏好", "内耗", "状态", "想法", "追求", "人生", "特点"),
    },
]

