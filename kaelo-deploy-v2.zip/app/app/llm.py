# -*- coding: utf-8 -*-
"""统一 LLM 客户端：DeepSeek 云端 / Ollama 本地双后端。

阶段 2 可靠性：收敛 validate._call_deepseek / _llm_complete / _stream_chat
三处裸 requests 调用，统一提供：
  · 超时 + 指数退避重试（auth 类错误不重试）
  · 错误分类（auth/rate_limit/server/network/timeout）与统计
  · token 成本统计（DeepSeek usage / Ollama eval_count）
调用方通过 _llm_complete（非流式）/ _stream_chat（流式）使用，
统计可经 get_stats() 读取（供阶段 3 /health 与成本审计）。
"""
import json
import time
from collections import defaultdict

import requests

from . import config

# ============ 调用统计（进程级，可通过 get_stats 读取） ============
_CALL_STATS = {
    "calls": 0,
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_latency": 0.0,         # 成功调用总耗时（秒，含重试前的成功那次）
    "errors": defaultdict(int),   # 错误分类 -> 次数
    "last_error": None,
}


def _classify_error(status: int | None = None, exc: Exception | None = None) -> str:
    """错误分类：auth / rate_limit / server / network / timeout。"""
    if isinstance(exc, requests.exceptions.Timeout):
        return "timeout"
    if status is not None:
        if status in (401, 403):
            return "auth"
        if status == 429:
            return "rate_limit"
        if status >= 500:
            return "server"
    return "network"


def _record_usage(prompt_tokens: int, completion_tokens: int, latency: float = 0.0):
    _CALL_STATS["calls"] += 1
    _CALL_STATS["prompt_tokens"] += prompt_tokens
    _CALL_STATS["completion_tokens"] += completion_tokens
    _CALL_STATS["total_latency"] += latency


def _record_error(cat: str, detail: str):
    _CALL_STATS["errors"][cat] += 1
    _CALL_STATS["last_error"] = f"{cat}: {detail}"


def get_stats() -> dict:
    """返回调用统计快照（含错误分类明细与延迟）。"""
    calls = _CALL_STATS["calls"]
    return {
        "calls": calls,
        "prompt_tokens": _CALL_STATS["prompt_tokens"],
        "completion_tokens": _CALL_STATS["completion_tokens"],
        "total_tokens": _CALL_STATS["prompt_tokens"] + _CALL_STATS["completion_tokens"],
        "avg_latency_ms": round(_CALL_STATS["total_latency"] / calls * 1000, 1) if calls else 0.0,
        "total_latency_s": round(_CALL_STATS["total_latency"], 2),
        "errors": dict(_CALL_STATS["errors"]),
        "last_error": _CALL_STATS["last_error"],
    }


def reset_stats():
    _CALL_STATS["calls"] = 0
    _CALL_STATS["prompt_tokens"] = 0
    _CALL_STATS["completion_tokens"] = 0
    _CALL_STATS["total_latency"] = 0.0
    _CALL_STATS["errors"].clear()
    _CALL_STATS["last_error"] = None


def _llm_complete(system_prompt: str, user_prompt: str, timeout: int = 30,
                  max_tokens: int = 500, temperature: float = 0.2,
                  retries: int = 3) -> str | None:
    """非流式 LLM 调用（统一客户端）。成功返回文本；彻底失败返回 None。

    带指数退避重试（可重试错误最多 retries 次，退避 1s/2s/4s）；
    auth 类错误（Key 无效）不重试直接返回 None。
    """
    msgs = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]

    if config.CHAT_BACKEND == "deepseek":
        url = f"{config.DEEPSEEK_BASE_URL}/chat/completions"
        headers = {
            "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": config.CHAT_MODEL, "messages": msgs,
            "stream": False, "temperature": temperature, "max_tokens": max_tokens,
        }
        last_err = None
        for attempt in range(retries):
            t0 = time.perf_counter()
            try:
                with requests.post(url, json=payload, headers=headers, timeout=timeout) as r:
                    if r.status_code == 200:
                        data = r.json()
                        usage = data.get("usage", {})
                        _record_usage(usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0),
                                      time.perf_counter() - t0)
                        return data["choices"][0]["message"]["content"].strip()
                    cat = _classify_error(status=r.status_code)
                    _record_error(cat, f"HTTP {r.status_code}")
                    last_err = f"HTTP {r.status_code}"
                    if cat == "auth":
                        break  # Key 无效，重试无意义
            except requests.exceptions.Timeout:
                _record_error("timeout", f"after {timeout}s")
                last_err = "timeout"
            except Exception as e:
                _record_error("network", str(e)[:120])
                last_err = str(e)[:120]
            if attempt < retries - 1:
                time.sleep(1 << attempt)  # 退避 1s/2s/4s（rate_limit/server/network/timeout 可重试）
        if last_err:
            # 云端失败时兜底 Ollama 本地后端（保持原行为）
            return _llm_complete_ollama(msgs, timeout=timeout, max_tokens=max_tokens,
                                        temperature=temperature)
        return None

    # ---- Ollama 本地后端 ----
    return _llm_complete_ollama(msgs, timeout=timeout, max_tokens=max_tokens,
                                temperature=temperature)


def _llm_complete_ollama(msgs, timeout: int, max_tokens: int, temperature: float) -> str | None:
    """Ollama 非流式调用（含重试与统计）。"""
    payload = {
        "model": config.CHAT_MODEL, "messages": msgs,
        "stream": False, "options": {"temperature": temperature, "num_predict": max_tokens},
    }
    for attempt in range(3):
        t0 = time.perf_counter()
        try:
            with requests.post(f"{config.OLLAMA_HOST}/api/chat", json=payload, timeout=timeout) as r:
                if r.status_code == 200:
                    data = r.json()
                    _record_usage(data.get("prompt_eval_count", 0), data.get("eval_count", 0),
                                  time.perf_counter() - t0)
                    return data["message"]["content"].strip()
                _record_error(_classify_error(status=r.status_code), f"HTTP {r.status_code}")
        except requests.exceptions.Timeout:
            _record_error("timeout", f"after {timeout}s")
        except Exception as e:
            _record_error("network", str(e)[:120])
        if attempt < 2:
            time.sleep(1 << attempt)
    return None


def _stream_chat(messages, system_prompt: str):
    """调用生成模型并逐块 yield 文本。支持 ollama 本地 / deepseek 云端双后端。"""
    msgs = [{"role": "system", "content": system_prompt}] + messages

    if config.CHAT_BACKEND == "deepseek":
        # DeepSeek OpenAI 兼容接口（流式）
        url = f"{config.DEEPSEEK_BASE_URL}/chat/completions"
        headers = {
            "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": config.CHAT_MODEL,
            "messages": msgs,
            "stream": True,
        }
        t0 = time.perf_counter()
        with requests.post(url, json=payload, headers=headers, stream=True, timeout=300) as r:
            if r.status_code != 200:
                _record_error(_classify_error(status=r.status_code), f"HTTP {r.status_code}")
                yield f"[出错 {r.status_code}] {r.text[:200]}"
                return
            prompt_tokens = 0
            completion_tokens = 0
            for line in r.iter_lines(decode_unicode=True):
                if not line:
                    continue
                if not line.startswith("data:"):
                    continue
                data = line[len("data:"):].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except json.JSONDecodeError:
                    continue
                piece = obj.get("choices", [{}])[0].get("delta", {}).get("content", "")
                if piece:
                    yield piece
                usage = obj.get("usage") or {}
                prompt_tokens = usage.get("prompt_tokens", prompt_tokens)
                completion_tokens = usage.get("completion_tokens", completion_tokens)
            _record_usage(prompt_tokens, completion_tokens, time.perf_counter() - t0)
        return

    # ---- Ollama 本地后端 ----
    payload = {
        "model": config.CHAT_MODEL,
        "messages": msgs,
        "stream": True,
    }
    t0 = time.perf_counter()
    with requests.post(f"{config.OLLAMA_HOST}/api/chat", json=payload, stream=True, timeout=300) as r:
        r.raise_for_status()
        prompt_tokens = 0
        completion_tokens = 0
        for line in r.iter_lines(decode_unicode=True):
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("error"):
                _record_error("server", str(obj["error"]))
                yield "[出错] " + str(obj["error"])
                break
            piece = obj.get("message", {}).get("content", "")
            if piece:
                yield piece
            prompt_tokens = obj.get("prompt_eval_count", prompt_tokens)
            completion_tokens = obj.get("eval_count", completion_tokens)
            if obj.get("done"):
                break
        _record_usage(prompt_tokens, completion_tokens, time.perf_counter() - t0)
