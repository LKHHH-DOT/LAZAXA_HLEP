# -*- coding: utf-8 -*-
"""Lazaxa 手机事件反连路由：/api/v1/phone。

- GET  /api/v1/phone/events       → 最近手机事件（pending 优先，kb_gui 轮询弹窗）
- POST /api/v1/phone/events/{id}/read → 标记已读（弹窗后调用）
事件由 app/phone.py 后台轮询 adb 设备生成（见 main.py 后台任务），
写入 phone_events 表（app/db.py）。鉴权走全局管理令牌中间件（main.py）。
"""
from fastapi import APIRouter

from .. import db

router = APIRouter(prefix="/api/v1/phone", tags=["phone"])


@router.get("/events")
def list_events(limit: int = 20):
    """最近未处理完的手机事件（pending 优先、再按新→旧）。"""
    items = db.list_phone_events(limit=limit)
    pending = [it for it in items if it["status"] == "pending"]
    read = [it for it in items if it["status"] == "read"]
    return {"count": len(items), "pending": pending, "read": read}


@router.post("/events/{rid}/read")
def mark_read(rid: int):
    """标记一条手机事件为已读（前端弹窗后调用）。"""
    ok = db.mark_phone_event_read(rid)
    return {"ok": ok}
