# -*- coding: utf-8 -*-
"""个人档案路由：/api/profile 列表/保存/删除（敏感个人信息）。"""
from fastapi import APIRouter
from pydantic import BaseModel

from .. import db

router = APIRouter()


class ProfileBody(BaseModel):
    field: str          # 档案项名（如 性格/背景/目标）
    content: str        # 内容
    field_key: str = ""  # 英文标志（可选）
    visibility: str = "private"


class ProfileDelete(BaseModel):
    field: str


@router.get("/api/profile")
def api_profile_list():
    """列出全部个人档案项。"""
    items = db.list_profile()
    return {"ok": True, "items": items}


@router.post("/api/profile")
def api_profile_save(body: ProfileBody):
    """新增/更新一个档案项（field 唯一）。"""
    if not (body.field or "").strip() or not (body.content or "").strip():
        return {"ok": False, "error": "档案项和内容不能为空"}
    vis = body.visibility if body.visibility in ("private", "sensitive") else "private"
    ok = db.save_profile(body.field, body.content, body.field_key, vis)
    return {"ok": bool(ok)}


@router.post("/api/profile/delete")
def api_profile_delete(body: ProfileDelete):
    """删除一个档案项。"""
    ok = db.delete_profile_field(body.field)
    if not ok:
        return {"ok": False, "error": "删除失败，档案项可能不存在"}
    return {"ok": True}
