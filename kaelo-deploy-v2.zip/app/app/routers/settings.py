# -*- coding: utf-8 -*-
"""应用设置路由：/api/settings 读取/保存（密钥脱敏，保存后立即生效）。"""
from fastapi import APIRouter
from pydantic import BaseModel

from .. import config, db

router = APIRouter()

SECRET_KEYS = {"deepseek_api_key", "tavily_api_key"}


def _mask_secret(key: str, value: str) -> str:
    """密钥脱敏：只显示前 4 后 4，中间 *。"""
    if key in SECRET_KEYS and len(value) > 10:
        return value[:4] + "****" + value[-4:]
    return value


class SettingsBody(BaseModel):
    deepseek_api_key: str | None = None
    deepseek_base_url: str | None = None
    chat_model: str | None = None
    chat_backend: str | None = None
    ollama_host: str | None = None
    embed_model: str | None = None
    tavily_api_key: str | None = None
    test_question: str | None = None


@router.get("/api/settings")
def api_settings_get():
    """返回当前生效的设置（密钥脱敏）与默认值对照。"""
    s = db.all_settings()
    masked = {k: _mask_secret(k, v) for k, v in s.items()}
    return {
        "ok": True,
        "current": masked,   # 数据库已存的值（脱敏）
        "effective": {       # 实际生效值（含默认，密钥脱敏）
            "chat_model": config.CHAT_MODEL,
            "chat_backend": config.CHAT_BACKEND,
            "deepseek_base_url": config.DEEPSEEK_BASE_URL,
            "deepseek_api_key": _mask_secret("deepseek_api_key", config.DEEPSEEK_API_KEY),
            "ollama_host": config.OLLAMA_HOST,
            "embed_model": config.EMBED_MODEL,
            "tavily_api_key": _mask_secret("tavily_api_key", config.TAVILY_API_KEY),
        },
    }


@router.post("/api/settings")
def api_settings_save(body: SettingsBody):
    """保存设置（空字符串=删除该项/恢复默认）。敏感项为空表示不修改。"""
    fields = {
        "deepseek_api_key": body.deepseek_api_key,
        "deepseek_base_url": body.deepseek_base_url,
        "chat_model": body.chat_model,
        "chat_backend": body.chat_backend,
        "ollama_host": body.ollama_host,
        "embed_model": body.embed_model,
        "tavily_api_key": body.tavily_api_key,
    }
    saved = []
    for key, val in fields.items():
        if key in SECRET_KEYS:
            # 密钥脱敏值跳过（前端传 masked 时忽略），真正修改需完整新值
            if val and val == _mask_secret(key, db.get_setting(key, "")) or (val and "****" in val):
                continue
        if val is not None:
            db.set_setting(key, val)
            saved.append(key)
    if body.test_question:
        # 可选：保存后跑一次连通性测试（调用生成模型）
        try:
            import requests
            url = f"{config.DEEPSEEK_BASE_URL}/chat/completions"
            r = requests.post(url, json={
                "model": config.CHAT_MODEL,
                "messages": [{"role": "user", "content": body.test_question}],
                "max_tokens": 20,
            }, headers={"Authorization": f"Bearer {config.DEEPSEEK_API_KEY}"}, timeout=30)
            test = {"ok": r.status_code == 200, "status": r.status_code,
                    "msg": "连接成功" if r.status_code == 200 else r.text[:120]}
        except Exception as e:
            test = {"ok": False, "msg": f"连接失败: {e}"}
    else:
        test = None
    # 保存后：重新加载动态设置（立即生效）
    config.load_db_settings()
    return {"ok": True, "saved": saved, "test": test,
            "reload_msg": "设置已保存并生效（模型/密钥变更即时生效）"}
