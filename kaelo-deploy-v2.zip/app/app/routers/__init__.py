# -*- coding: utf-8 -*-
"""业务路由包（阶段 1：main.py 拆分）。

按职责拆分：pages（静态页）/ kb（知识库）/ chat（对话）/ highlights /
history / settings / profile / keys（对外 API Key 与 v1 对话）/ agent（Lazaxa）。
"""
