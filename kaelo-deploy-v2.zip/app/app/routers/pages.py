# -*- coding: utf-8 -*-
"""静态页面路由：主页 + 管理后台。"""
import os

from fastapi import APIRouter
from fastapi.responses import FileResponse

from ..state import WEB_DIR

router = APIRouter()


@router.get("/")
def index():
    return FileResponse(os.path.join(WEB_DIR, "index.html"))


@router.get("/admin")
def admin_page():
    return FileResponse(os.path.join(WEB_DIR, "admin.html"))
