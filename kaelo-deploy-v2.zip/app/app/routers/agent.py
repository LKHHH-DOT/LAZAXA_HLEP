# -*- coding: utf-8 -*-
"""Lazaxa智能体路由：/api/v1/agent（SSE 任务）与 /api/v1/agent/approve（审批）。

设计见 docs/Lazaxa智能体设计书.md。
agent 包保持函数内懒加载（避免 main 启动时注册工具/加载额外依赖）。
"""
import asyncio
import itertools
import json
import threading
import time

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter()

# agent 任务历史落库：同一会话窗口（30 分钟内）复用同一 MySQL 会话，否则新建
# （服务端保证对话历史落库，不依赖前端；2026-08-18 修复"今天记录查不到"）
_last_agent_session = [None, 0.0]
_AGENT_SESSION_WINDOW = 1800

# 对话轮次 id 生成（任务记录中心聚合键）：主对话每轮一个 r-<ms>-<seq>，
# 后台 worker 用 job.id（job-<ms>-<seq>），子代理沿用父 round 分组。
_ROUND_COUNTER = itertools.count(1)


def _new_round_id() -> str:
    return f"r-{int(time.time() * 1000)}-{next(_ROUND_COUNTER)}"


# 任务记录中心步骤详情展示上限（参数/结果文本截断，防传输过大）
_TASK_STEP_TEXT_CAP = 600


def _save_agent_history(user_msg: str, reply: str):
    """把一轮 agent 任务（用户请求 + 最终回复）写入 chat_sessions/chat_messages。"""
    from .. import db
    now = time.time()
    if (_last_agent_session[0] is not None
            and now - _last_agent_session[1] < _AGENT_SESSION_WINDOW):
        sid = _last_agent_session[0]
    else:
        sid = db.create_session(kb_key="agent", kb_name="智能体任务",
                                model="DeepSeek/agent")
        _last_agent_session[0] = sid
    if not sid:
        return
    db.add_message(sid, "user", user_msg, kb_key="agent")
    db.add_message(sid, "assistant", reply, kb_key="agent")
    _last_agent_session[1] = now


class AgentBody(BaseModel):
    message: str
    history: list | None = None     # 多轮上下文（前端传的历史 messages）
    max_steps: int | None = None    # 可选：步数上限覆盖
    mode: str | None = None         # 权限模式 locked/standard/relaxed（三级权限，缺省走后端默认）
    supervise: bool = False         # 边聊边做模式开关（开：长任务委派后台 worker，主对话不被阻塞）


class AgentApproveBody(BaseModel):
    task_id: str
    approved: bool
    edited_args: dict | None = None   # M5-2：用户编辑参数后批准（可选；仅 approved=True 时生效）


class AgentInstructionBody(BaseModel):
    text: str   # 老板传给后台任务的新指令（call_worker 面板直发）


class AgentPermissionsBody(BaseModel):
    workspace_strict: bool | None = None    # 工作区沙箱开关（None=不修改）


class AgentSettingsBody(BaseModel):
    max_steps: int | None = None    # 单次任务最大工具调用步数（1~100；None=不修改）


@router.get("/api/v1/agent/settings")
async def api_v1_agent_settings_get():
    """读取智能体运行参数（前端设置界面初始值）。"""
    from ..state import get_agent_settings
    return get_agent_settings()


@router.put("/api/v1/agent/settings")
async def api_v1_agent_settings_put(body: AgentSettingsBody):
    """更新智能体运行参数（用户在前端"设置"界面自定义，前端 config.json 为持久层）。"""
    from ..state import get_agent_settings, set_agent_setting
    if body.max_steps is not None and not set_agent_setting("max_steps", body.max_steps):
        raise HTTPException(status_code=400, detail="invalid max_steps (must be 1-100)")
    return get_agent_settings()


@router.get("/api/v1/agent/permissions")
async def api_v1_agent_permissions_get():
    """读取智能体权限开关状态（前端权限按钮初始值）。"""
    from ..state import get_permission_flags
    return get_permission_flags()


@router.put("/api/v1/agent/permissions")
async def api_v1_agent_permissions_put(body: AgentPermissionsBody):
    """更新智能体权限开关（用户在前端点按钮控制，权限交给用户）。"""
    from ..state import get_permission_flags, set_permission_flag
    if body.workspace_strict is not None and not set_permission_flag("workspace_strict", body.workspace_strict):
        raise HTTPException(status_code=400, detail="invalid permission flag")
    return get_permission_flags()


@router.post("/api/v1/agent")
async def api_v1_agent(body: AgentBody):
    """Lazaxa任务入口：SSE 流式返回全过程事件。

    事件类型：thinking / token / tool_call / tool_result /
    approval_request / done / error（见 app/agent/events.py）。
    每轮任务前注入相关长期记忆（get_memory_context，失败静默）；
    任务完成后按记忆意图自动沉淀用户消息（auto_sink_message，后台线程）。
    """
    from ..agent import run_agent_task, make_emitter
    from ..agent.events import sse_payload
    from ..memory import (
        get_memory_context, get_profile_block,
        auto_sink_message, auto_sink_praise,
    )
    from .. import config as _cfg
    from ..state import get_agent_settings

    # S1-5 输入长度护栏：超长指令直接拒绝（防 token 成本无上限 / 消息表撑爆）。
    # 放最前：任何记忆注入/沉淀线程都不必为注定被拒的输入空跑
    _input_len = len(body.message or "")
    if _input_len > _cfg.AGENT_MAX_INPUT_CHARS:
        raise HTTPException(
            status_code=400,
            detail=f"指令过长（{_input_len} 字符，上限 {_cfg.AGENT_MAX_INPUT_CHARS}），请精简后再发")

    # 正反馈沉淀：用户在任务完成后表达认可 → 后台线程把该任务提炼为经验入库
    # （三重防线防误触：正反馈词 + 10 分钟窗口 + 30 分钟防抖，见 memory.auto_sink_praise）
    if _cfg.MEMORY_AUTO_SINK_ENABLED:
        try:
            threading.Thread(target=auto_sink_praise, args=(body.message,),
                             daemon=True).start()
        except Exception:
            pass

    # 每轮记忆注入：与 /api/v1/chat 对齐（agent 模式补齐 M3 阶段 3 的自动记忆链路）
    mem_ctx = ""
    try:
        mem_ctx = get_memory_context(body.message)
    except Exception:
        mem_ctx = ""

    # 画像档案稳定注入：主人长期稳定的画像/偏好，每轮常驻（区别于按 query 检索的记忆）
    profile_ctx = ""
    try:
        profile_ctx = get_profile_block()
    except Exception:
        profile_ctx = ""

    # 边聊边做（后台任务）：绑定事件循环 + 记录权限模式（后台 worker 继承）；
    # 开关开启时注入督导引导，让主模型把长任务 delegate 出去而不是阻塞等待
    from ..jobs import manager as job_manager
    extra_sections = []
    try:
        job_manager.bind_loop(asyncio.get_running_loop())
        job_manager.set_context_mode(body.mode or _cfg.PERMISSION_DEFAULT_MODE)
    except Exception:
        pass
    if mem_ctx:
        extra_sections.append(mem_ctx)
    if profile_ctx:
        extra_sections.append(profile_ctx)
    if body.supervise:
        extra_sections.append(
            "【边聊边做模式·已开启】用户开着'边聊边做'开关：需要多步骤操作电脑/耗时较长的任务"
            "用 delegate_job 派成后台任务并立即回复'已开工'，绝不阻塞等它跑完；之后用户问进度/"
            "纠正做法/喊停时，用 check_jobs 查、call_worker 传话、cancel_job 取消，并结合系统"
            "注入的【后台任务状态】如实向用户汇报。若用户明确表示'你直接做完/我等你'，"
            "则自己同步执行，不用 delegate_job。")
    try:
        job_block = job_manager.context_block()
        if job_block:
            extra_sections.append(job_block)
    except Exception:
        pass
    extra_system = "\n\n".join(extra_sections) or None

    q: asyncio.Queue = asyncio.Queue()
    # 本轮任务聚合键（任务记录中心）：主对话每轮一个；worker/子代理沿用自己分组
    round_id = _new_round_id()

    async def event_gen():
        # 启动任务协程，逐条消费队列事件推送 SSE
        # 步数上限：请求显式传值优先，否则用前端设置（用户自定义），再退回默认
        max_steps = body.max_steps or get_agent_settings().get("max_steps")
        task = asyncio.create_task(
            run_agent_task(body.message, body.history,
                           emit=make_emitter(q), max_steps=max_steps,
                           mode=body.mode, extra_system=extra_system,
                           round_id=round_id))
        while True:
            try:
                event_type, payload = await asyncio.wait_for(q.get(), timeout=600)
            except asyncio.TimeoutError:
                yield sse_payload("error", message="任务超时（10 分钟无事件）")
                break
            # M3：每个 SSE 事件都注入本轮 round_id——断线时前端能认出轮次去回放
            # （含 token/thinking 等；payload 恒为 dict，见 make_emitter）
            if isinstance(payload, dict):
                payload["round_id"] = round_id
            if event_type == "done":
                # done 已由 _emit 包装落库为账本末行（同步 INSERT 先行）——
                # 查 last_agent_event_id 即该轮末事件 id，前端断线回放从它续
                try:
                    from ..db import last_agent_event_id
                    payload["event_id"] = last_agent_event_id(round_id)
                except Exception:
                    payload["event_id"] = 0
            yield sse_payload(event_type, **payload)
            if event_type == "done":
                # 历史落库：服务端把本轮任务（用户请求 + 最终回复）写入 MySQL
                # （2026-08-18 修复：之前依赖前端存历史，今天对话一条都没进库）
                try:
                    _save_agent_history(body.message, payload.get("reply", ""))
                except Exception:
                    pass
                # 记录最近任务摘要：供用户后续正反馈（"完成得不错"）触发经验沉淀
                from ..memory import note_task_done

                try:
                    note_task_done(body.message, payload.get("reply", ""),
                                   round_id=round_id)
                except Exception:
                    pass
                # M4c 失败教训沉淀：行为类失败终态（loop_capped/max_steps）后台
                # 提炼教训入记忆，未来同类任务可检索到；外部故障/空回复不沉淀。
                _stop = payload.get("stop_reason")
                if _cfg.MEMORY_LESSON_SINK_ENABLED and _stop in ("loop_capped", "max_steps"):
                    try:
                        from ..memory import sink_failure_lesson

                        threading.Thread(
                            target=sink_failure_lesson,
                            args=(body.message, _stop, payload.get("error", ""),
                                  payload.get("reply", ""),
                                  payload.get("tool_path"), round_id),
                            daemon=True).start()
                    except Exception:
                        pass
                # 自动沉淀（P1 只做最终答复轮）：assistant 完成回复后才写入记忆库，
                # 按原文快照剥离注入段（见 memory.auto_sink_message）；
                # 回复为空（任务出错/无输出）不沉淀；worker/子代理不走本路由天然跳过；
                # round_id 一并落库（A批2 溯源），出错轮可按轮清理污染记忆
                reply_text = (payload.get("reply") or "").strip()
                if _cfg.MEMORY_AUTO_SINK_ENABLED and reply_text:
                    threading.Thread(target=auto_sink_message,
                                     args=(body.message, None, round_id),
                                     daemon=True).start()
                break
        if not task.done():
            task.cancel()

    return StreamingResponse(event_gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@router.post("/api/v1/agent/approve")
def api_v1_agent_approve(body: AgentApproveBody):
    """审批应答：唤醒挂起的 agent 任务继续执行。

    edited_args（M5-2）：用户编辑参数后批准——后端以编辑后的参数执行该工具，
    并把 edited=True 与生效参数记入 approval_resolved 事件账。
    """
    from ..agent.approval import approval as approval_mgr
    ok = approval_mgr.resolve(body.task_id, body.approved,
                              edited_args=body.edited_args)
    if not ok:
        return {"ok": False, "error": "该审批请求不存在或已过期"}
    return {"ok": True, "approved": body.approved,
            "edited": bool(body.approved and body.edited_args is not None)}


@router.get("/api/v1/agent/jobs")
def api_v1_agent_jobs():
    """后台任务列表（"边聊边做"前端面板轮询；含审批等待详情，供弹窗）。"""
    from ..jobs import manager
    return {"jobs": manager.list_jobs()}


@router.post("/api/v1/agent/jobs/{job_id}/cancel")
async def api_v1_agent_job_cancel(job_id: str):
    """取消一个后台任务（执行中立即中断 / 排队中移除）。"""
    from ..jobs import manager
    try:
        manager.bind_loop(asyncio.get_running_loop())
    except Exception:
        pass
    if await manager._cancel_async(job_id):
        return {"ok": True, "job_id": job_id}
    return {"ok": False, "error": "任务不存在或已处于终态"}


@router.post("/api/v1/agent/jobs/{job_id}/instruction")
async def api_v1_agent_job_instruction(job_id: str, body: AgentInstructionBody):
    """向后台任务传话（老板新指令）：worker 每轮循环开头读取并按新指令调整。

    等价于主对话里的 call_worker 工具，任务面板直发用。
    """
    from ..jobs import manager
    text = (body.text or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="指令内容不能为空")
    if manager.send_instruction(job_id, text):
        return {"ok": True, "job_id": job_id}
    raise HTTPException(status_code=400,
                        detail="任务不存在或已结束（仅执行中/排队中可传话）")


def _fmt_task_time(dt) -> str:
    """审计行时间转展示字符串（datetime 或其它一律容错）。"""
    try:
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(dt or "")


def _parse_task_args(text: str | None):
    """步骤参数：JSON 字符串还原为对象；解析失败保留原文（截断防超长）。"""
    if not text:
        return {}
    try:
        obj = json.loads(text)
        return obj if isinstance(obj, (dict, list)) else {"value": obj}
    except Exception:
        s = str(text)
        return {"raw": s[:_TASK_STEP_TEXT_CAP]}


@router.get("/api/v1/agent/tasks")
def api_v1_agent_tasks(q: str = "", tool: str = "", minutes: int = 1440,
                       limit: int = 200, round_id: str = ""):
    """任务记录中心：把工具审计按「对话轮次」聚合成可搜索的任务卡列表。

    - 分组键 = round_id：主对话每轮（r-*）一卡、后台 worker（job-*）一卡、
      子代理并入父轮；旧记录 round_id 为空 → 退化为按 task_id 分组
      （一步一卡，仍可被关键词搜索命中）。
    - q: 模糊关键词（user_message / 工具名 / 参数 / 结果）
    - tool: 工具名精确过滤；minutes: 只看最近 N 分钟；limit: 卡数上限
    - round_id: 指定某轮（前端"展开单卡"只取该轮步骤）
    - 返回 tasks（按最近执行倒序）+ total，每卡 steps 为按执行顺序的步骤明细。
    """
    from ..db import query_agent_tasks

    rows = query_agent_tasks(q=q, tool=tool, minutes=minutes,
                             limit=int(limit) or 200, round_id=round_id)
    # 同轮记录按 id 升序返回；用 dict 收集分组（保持首现顺序，防 round 交错）
    groups: dict[str, dict] = {}
    for r in rows:
        key = r["round_id"] or r["task_id"]
        g = groups.get(key)
        if g is None:
            g = {"round_id": r["round_id"] or "", "task_id": r["task_id"],
                 "user_message": (r["user_message"] or "")[:200],
                 "min_id": int(r["id"]), "max_id": int(r["id"]),
                 "started_at": _fmt_task_time(r["created_at"]),
                 "tool_count": 0, "ok_count": 0, "steps": []}
            groups[key] = g
        g["steps"].append({
            "id": int(r["id"]),
            "task_id": r["task_id"],
            "parent_task_id": r["parent_task_id"] or "",
            "tool": r["tool_name"],
            "args": _parse_task_args(r["tool_args"]),
            "result": (r["tool_result"] or "")[:_TASK_STEP_TEXT_CAP],
            "risk": r["risk"], "mode": r["mode"], "decision": r["decision"],
            "approved": None if r["approved"] is None else bool(r["approved"]),
            "ok": None if r["ok"] is None else bool(r["ok"]),
            "at": _fmt_task_time(r["created_at"]),
        })
        g["max_id"] = max(g["max_id"], int(r["id"]))
        g["tool_count"] += 1
        if r["ok"]:
            g["ok_count"] += 1

    tasks = []
    for g in groups.values():
        tasks.append({
            "round_id": g["round_id"],
            "user_message": g["user_message"],
            "source": ("worker" if g["round_id"].startswith("job-")
                       else "legacy" if not g["round_id"]
                       else "main"),
            "started_at": g["started_at"],
            "tool_count": g["tool_count"],
            "ok_count": g["ok_count"],
            "steps": g["steps"],
        })
    tasks.sort(key=lambda t: t["steps"][-1]["id"], reverse=True)
    return {"tasks": tasks, "total": len(tasks)}


@router.get("/api/v1/agent/events")
def api_v1_agent_events(round_id: str = "", after: int = 0, limit: int = 500):
    """M3 事件账本回放：按轮次取全生命周期事件时间线（断线回放/时间线/审计用）。

    - round_id: 某轮（r-* 主对话 / job-* worker；子代理并入父轮，同 round_id）
    - after: 增量游标（只返回 id > after；前端持 last done 的 event_id 续拉）
    - limit: 单次条数上限（1~1000，默认 500）
    - 鉴权：与任务记录中心同款（全局 X-Admin-Token 中间件）
    - 返回 {events:[{id,type,step,ts,payload}], next_after, count}；
      next_after=最后一条 id（前端下轮 after 传它），空结果回显请求 after。
    """
    from ..db import query_agent_events

    events = query_agent_events(round_id, after=int(after or 0),
                                limit=int(limit or 500))
    return {"events": events,
            "next_after": int(events[-1]["id"]) if events else int(after or 0),
            "count": len(events)}
