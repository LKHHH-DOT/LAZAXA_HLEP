# -*- coding: utf-8 -*-
"""健康检查与运行指标路由（阶段 3 专业化）。

/api/health  —— 公开轻量存活检查（不触发向量库加载/重建）
/api/metrics —— 需管理令牌，返回完整运行指标（LLM 统计/检索耗时/成本估算）
"""
import time

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from .. import config, db, rag
from ..llm import get_stats as llm_stats
from ..state import _stores

router = APIRouter()


def _db_alive() -> tuple[bool, float]:
    t0 = time.perf_counter()
    try:
        conn = db._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        finally:
            conn.close()
        return True, round((time.perf_counter() - t0) * 1000, 1)
    except Exception:
        return False, 0.0


def _ollama_alive() -> tuple[bool, float]:
    t0 = time.perf_counter()
    try:
        import requests
        r = requests.get(f"{config.OLLAMA_HOST}/api/tags", timeout=2)
        ok = r.status_code == 200
        return ok, round((time.perf_counter() - t0) * 1000, 1)
    except Exception:
        return False, 0.0


# DeepSeek 公开价（元/千 token，2025-08 参考；实际以账单为准，可在此调整）
_DEEPSEEK_PRICE_IN = 0.001   # 输入（缓存未命中）
_DEEPSEEK_PRICE_OUT = 0.003  # 输出


def _store_integrity() -> dict:
    """各库"块数 vs 向量数"自检（借 kada 经验，直接读文件不加载库）。

    向量数 < 块数（增量加书后未补向量）时，该库语义检索只能覆盖部分块、
    实际以 BM25 为主——这是**静默降级**，必须能在健康检查里一眼看到；
    补齐命令：python scripts/embed_increment.py <kb>
    """
    import json
    import os

    import numpy as np

    out = {}
    for key, cfg in config.KNOWLEDGE_BASES.items():
        vdir = cfg.get("vector_dir") or ""
        meta_p = os.path.join(vdir, "meta.json")
        vec_p = os.path.join(vdir, "vectors.npy")
        n_chunks = n_vec = 0
        try:
            if os.path.exists(meta_p):
                with open(meta_p, "r", encoding="utf-8") as f:
                    n_chunks = len(json.load(f))
            if os.path.exists(vec_p):
                n_vec = int(np.load(vec_p, mmap_mode="r").shape[0])
        except Exception:
            continue
        if n_chunks or n_vec:
            out[key] = {"chunks": n_chunks, "vectors": n_vec,
                        "ok": n_chunks == n_vec}
    return out


@router.get("/api/health")
def api_health():
    """存活检查：DB/Ollama 连通 + 已加载向量库规模 + LLM 统计摘要。

    注意：不调用 _get_store()，避免健康检查触发向量库自动重建。
    """
    db_ok, db_ms = _db_alive()
    ollama_ok, ollama_ms = _ollama_alive()
    s = llm_stats()
    return {
        "status": "ok",
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "version": "1.0.0",
        # S1-4：audit_failures=进程内 agent 审计写库失败累计（>0 说明有审计在静默漏记）
        "db": {"alive": db_ok, "latency_ms": db_ms,
               "audit_failures": db.audit_failure_count(),
               "audit_failure_last": db.audit_failure_last()},
        "ollama": {"alive": ollama_ok, "latency_ms": ollama_ms},
        "backend": config.CHAT_BACKEND,
        "chat_model": config.CHAT_MODEL,
        "embed_model": config.EMBED_MODEL,
        "stores_loaded": {k: v.size for k, v in _stores.items()},
        # 块数 vs 向量数自检：ok=false 表示该库语义检索只覆盖部分块（需补向量）
        "vector_integrity": _store_integrity(),
        "llm": {"calls": s["calls"], "total_tokens": s["total_tokens"],
                "avg_latency_ms": s["avg_latency_ms"], "errors": s["errors"]},
    }


@router.get("/api/metrics")
def api_metrics():
    """完整运行指标（需管理令牌）：LLM 统计 + 检索耗时 + token 成本估算。"""
    s = llm_stats()
    est_cost = (
        (s["prompt_tokens"] / 1000) * _DEEPSEEK_PRICE_IN
        + (s["completion_tokens"] / 1000) * _DEEPSEEK_PRICE_OUT
    )
    db_ok, db_ms = _db_alive()
    return {
        "llm": s,
        "estimated_cost_rmb": round(est_cost, 4),
        "search": rag.search_stats(),
        "stores_loaded": {k: v.size for k, v in _stores.items()},
        "db_sessions": db.count_sessions(),
        "db_messages": db.count_messages(),
        # S1-4：审计失败计数（进程内累计）与 DB 实时连通一并可见
        "db": {"alive": db_ok, "latency_ms": db_ms,
               "audit_failures": db.audit_failure_count(),
               "audit_failure_last": db.audit_failure_last()},
        "admin_token_set": bool(config.ADMIN_TOKEN),
    }
