# -*- coding: utf-8 -*-
"""技能中心管理接口（2026-09-03 · Lazaxa 插件安装入口）。

技能 = Kaelo/skills/<name>.md（frontmatter description + 正文），放进目录后下一轮
对话即自动进入模型的技能目录（agent/skills.py 的 list_skills 动态扫盘，无需重启）。

本路由提供"安装/卸载"入口，让用户不用手搓 .md：
  GET    /api/v1/skills               已装技能列表（含文件大小/修改时间）
  POST   /api/v1/skills/md            直接提交 Markdown/文本（本地 .md 导入）
  POST   /api/v1/skills/url           网页链接：直链 .md/.txt 直接收录；HTML 页抓正文转技能
  POST   /api/v1/skills/zip           ZIP 技能包：解压提取一个或多个技能 .md
  DELETE /api/v1/skills/{name}        卸载技能

安全约束：
  · 技能名 kebab-case（同 agent/skills._SKILL_NAME_RE），文件只允许落在 SKILLS_DIR
  · ZIP 解压防 zip-slip：路径穿越 / 绝对路径 / 符号链接一律拒绝
  · URL 下载仅 http(s)、限 3 跳重定向、拒绝本机/内网地址（防 SSRF）、10s 超时、512KB 上限
  · 同名文件不允许静默覆盖（先卸载再装），避免误覆盖手写技能
  · 内容缺少 description frontmatter 时自动取正文前 80 字补全，保证能被技能目录收录
"""
import io
import os
import re
import socket
import urllib.request
import urllib.parse
import zipfile
from html.parser import HTMLParser

from fastapi import APIRouter, HTTPException, UploadFile

from .. import config
from ..agent import skills as agent_skills

router = APIRouter()

_MAX_DOWNLOAD = 512 * 1024          # URL 抓取上限 512KB
_MAX_HOPS = 3                       # 重定向最多跟随 3 跳
_MAX_ZIP = 10 * 1024 * 1024         # ZIP 上传上限 10MB
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_SLUG_SPLIT_RE = re.compile(r"[^a-z0-9]+")
_SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


# ---------------- 基础工具 ----------------

def _slugify(hint: str) -> str:
    """把任意提示（文件名/URL 尾段/标题）转成 kebab-case 技能名。"""
    s = _SLUG_SPLIT_RE.sub("-", (hint or "").lower())
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s[:80].strip("-")


def _skill_path(name: str) -> str:
    """校验技能名并返回其在技能目录内的绝对路径；不合法/越界返回空串。"""
    if not _SKILL_NAME_RE.match(name or ""):
        return ""
    root = os.path.abspath(config.SKILLS_DIR)
    path = os.path.abspath(os.path.join(root, name + ".md"))
    return path if path.startswith(root + os.sep) else ""


def _summary(text: str) -> str:
    """压缩成单行前 80 字，用作自动补全的一句话 description。"""
    clean = re.sub(r"\s+", " ", text or "").strip(" #*->•\n\t")
    return clean[:80] if clean else "（无描述，请人工补充）"


def _compose(content: str) -> str:
    """把任意文本整理成合法技能文件（保证 frontmatter 里有 description）。"""
    content = content.replace("\r\n", "\n").strip()
    if not content:
        raise HTTPException(status_code=400, detail="技能内容为空")
    if content.startswith("---"):
        meta, body = agent_skills._parse_frontmatter(content)
        if not meta.get("description"):
            if not body.strip():
                raise HTTPException(status_code=400, detail="技能内容为空（仅 frontmatter）")
            # 有 frontmatter 缺 description：补一行（保留原格式）
            head, _, rest = content.split("---", 2)
            fm = rest.split("---", 1)[0]
            fm = fm.rstrip() + "\ndescription: %s" % _summary(body)
            content = head + "---" + fm + "---" + rest.split("---", 1)[1]
        return content
    # 纯文本：统一包一层 frontmatter
    return "---\ndescription: %s\n---\n\n%s" % (_summary(content), content)


def _save_new(name_hint: str, content: str) -> dict:
    """按提示名把技能写入目录。同名已存在 → 409；名字无法生成 → 400。"""
    name = _slugify(name_hint)
    if not name:
        raise HTTPException(status_code=400,
                            detail="无法从该名字生成技能名（需含英文/数字，装包可用英文名）")
    path = _skill_path(name)
    if os.path.exists(path):
        raise HTTPException(status_code=409, detail="技能已存在：%s（请先卸载或换名导入）" % name)
    os.makedirs(config.SKILLS_DIR, exist_ok=True)
    text = _compose(content)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    meta, _ = agent_skills._parse_frontmatter(text)
    return {"name": name, "description": meta.get("description", "")}


# ---------------- URL 抓取 ----------------

class _TextExtract(HTMLParser):
    """HTML → 纯文本：跳过脚本/样式，块级标签转行。"""

    _SKIP = {"script", "style", "noscript", "template", "head", "nav", "footer"}
    _BREAK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6",
              "section", "article", "blockquote"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self._skip += 1
        elif tag in self._BREAK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self._SKIP and self._skip > 0:
            self._skip -= 1
        elif tag in self._BREAK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self._skip == 0:
            self.parts.append(data)

    def text(self) -> str:
        raw = "".join(self.parts)
        raw = re.sub(r"[ \t\u00a0]+", " ", raw)
        raw = re.sub(r"\n{3,}", "\n\n", raw)
        return raw.strip()


def _host_is_public(url: str) -> bool:
    """URL 必须 http(s) 且解析到的所有 IP 均为公网（防 SSRF 打内网）。"""
    try:
        u = urllib.parse.urlparse(url)
    except ValueError:
        return False
    if u.scheme not in ("http", "https") or not u.hostname:
        return False
    host = u.hostname.lower().rstrip(".")
    if host in ("localhost", "localhost.localdomain"):
        return False
    try:
        addrs = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except OSError:
        return False
    if not addrs:
        return False
    import ipaddress
    for info in addrs:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified):
            return False
    return True


def _download(url: str) -> tuple[bytes, str]:
    """下载 URL 内容（限公网 + 最多 3 跳重定向 + 512KB），返回 (bytes, content-type)。"""
    current = url
    for _ in range(_MAX_HOPS):
        if not _host_is_public(current):
            raise HTTPException(status_code=400,
                                detail="仅支持公网 http/https 链接（已拒绝本机/内网地址）")
        req = urllib.request.Request(current, headers={"User-Agent": _UA})
        try:
            resp = urllib.request.urlopen(req, timeout=10)
        except Exception as e:  # noqa: BLE001
            raise HTTPException(status_code=400, detail="链接打开失败：%s" % e) from e
        with resp:
            status = getattr(resp, "status", 200)
            loc = resp.headers.get("Location")
            if status in (301, 302, 303, 307, 308) and loc:
                current = urllib.parse.urljoin(current, loc)
                continue
            data = resp.read(_MAX_DOWNLOAD + 1)
            if len(data) > _MAX_DOWNLOAD:
                raise HTTPException(status_code=400,
                                    detail="网页内容超过 512KB，请下载后作为 .md/.zip 安装")
            return data, (resp.headers.get("Content-Type") or "").lower()
    raise HTTPException(status_code=400, detail="重定向次数过多")


def _decode(data: bytes) -> str:
    """解码下载内容：优先 utf-8，失败按 GBK 系兜底（常见中文站）。"""
    for enc in ("utf-8", "gb18030"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "ignore")


def _url_name(url: str, text: str) -> str:
    """从 URL 尾段推断技能名；否则从正文第一行。"""
    path = urllib.parse.urlparse(url).path
    tail = os.path.basename(path.rstrip("/"))
    if tail:
        name = _slugify(os.path.splitext(tail)[0])
        if name:
            return name
    first = next((ln.strip(" #-*") for ln in (text or "").splitlines() if ln.strip()), "")
    return _slugify(first) or "web-skill"


# ---------------- 路由 ----------------

@router.get("/api/v1/skills")
def list_skills():
    """已装技能列表（name/description/when_to_use/文件大小/修改时间）。"""
    items = agent_skills.list_skills()
    for it in items:
        path = _skill_path(it["name"])
        try:
            st = os.stat(path)
            it["size"] = st.st_size
            it["mtime"] = st.st_mtime
        except OSError:
            it["size"] = 0
            it["mtime"] = 0
    return {"skills": items}


@router.post("/api/v1/skills/md")
def import_md(body: dict):
    """导入 Markdown/文本技能。body: {content: str, name?: str}。"""
    content = (body.get("content") or "").strip()
    name_hint = (body.get("name") or "").strip() or "skill"
    if not content:
        raise HTTPException(status_code=400, detail="技能内容为空")
    return _save_new(name_hint, content)


@router.post("/api/v1/skills/url")
def import_url(body: dict):
    """抓取网页链接安装技能。body: {url: str}。"""
    url = (body.get("url") or "").strip()
    if not url:
        raise HTTPException(status_code=400, detail="缺少 url")
    data, ctype = _download(url)
    text = _decode(data)
    if "html" in ctype:
        parser = _TextExtract()
        parser.feed(text)
        text = parser.text() or text  # HTML 页抽正文
    name = _url_name(url, text)
    return _save_new(name, text)


@router.post("/api/v1/skills/zip")
async def import_zip(file: UploadFile):
    """上传 ZIP 技能包：解压提取所有 .md（防路径穿越），支持一包多技能。"""
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="文件为空")
    if len(raw) > _MAX_ZIP:
        raise HTTPException(status_code=400, detail="ZIP 超过 10MB")
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile as e:
        raise HTTPException(status_code=400, detail="不是有效的 ZIP 文件") from e

    installed: list[str] = []
    conflicts: list[str] = []
    skipped: list[str] = []
    seen: set[str] = set()
    for info in zf.infolist():
        fname = info.filename.replace("\\", "/")
        parts = [p for p in fname.split("/") if p not in ("", ".")]
        if info.is_dir():
            continue
        mode = (info.external_attr >> 16) & 0xFFFF  # Unix 文件类型位（symlink 检测）
        symlink = (mode & 0xF000) == 0xA000
        unsafe = fname.startswith("/") or ".." in parts or symlink
        if not fname.lower().endswith(".md"):
            skipped.append(fname)  # 非技能文件：不入库（如 README、图片）
            continue
        if unsafe:
            skipped.append("⚠ " + fname)
            continue
        try:
            content = zf.read(info).decode("utf-8", "ignore")
        except Exception:  # noqa: BLE001
            skipped.append(fname)
            continue
        base = os.path.basename(fname)
        stem = os.path.splitext(base)[0].lower()
        if stem.startswith(("readme", "read-me", "license", "changelog", "description")):
            skipped.append(fname)  # 包内说明文档：不入库
            continue
        name = _slugify(os.path.splitext(base)[0])
        if not name or name in seen:
            conflicts.append(base or fname)
            continue
        seen.add(name)
        try:
            res = _save_new(name, content)
            installed.append(res["name"])
        except HTTPException as e:
            (conflicts if e.status_code == 409 else skipped).append(base)
    zf.close()
    return {"installed": installed, "conflicts": conflicts, "skipped": skipped}


@router.delete("/api/v1/skills/{name}")
def delete_skill(name: str):
    """卸载技能（删除技能目录内对应 .md）。"""
    path = _skill_path(name)
    if not path or not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="技能不存在：%s" % name)
    os.remove(path)
    return {"deleted": name}
