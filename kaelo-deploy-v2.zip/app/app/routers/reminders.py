# -*- coding: utf-8 -*-
"""Lazaxa 笔记到期提醒路由：/api/v1/reminders。

- GET /api/v1/reminders/today  → 今天到期的未处理提醒（kb_gui 轮询）
- POST /api/v1/reminders/{id}/read → 标记已读
提醒由 app/reminders.py 定时扫描 Obsidian 笔记生成（见 main.py 后台任务）。
"""
from datetime import date

from fastapi import APIRouter

from .. import db

router = APIRouter(prefix="/api/v1/reminders", tags=["reminders"])


@router.get("/today")
def today_reminders():
    """今天到期的提醒（pending 优先，read 次之，按 id 升序）。"""
    items = db.list_reminders_by_date(date.today().isoformat())
    pending = [it for it in items if it["status"] == "pending"]
    read = [it for it in items if it["status"] == "read"]
    return {"count": len(items), "pending": pending, "read": read}


@router.post("/{rid}/read")
def mark_read(rid: int):
    """标记一条提醒为已读（前端弹窗后调用）。"""
    ok = db.mark_reminder_read(rid)
    return {"ok": ok}
