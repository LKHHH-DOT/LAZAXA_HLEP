# -*- coding: utf-8 -*-
"""对话路由：RAG 检索 + 人设约束 + 流式回答（/api/chat，SSE 事件流）。

从 main.py 拆分而来（阶段 1 工程地基），检索/联网/拒答逻辑原样保留。
阶段 2 遗留收尾（M5）：响应格式由自定义 `__META__` 文本流迁移为 SSE 事件流，
与 /api/v1/agent 统一为 `data: {json}` 协议。事件类型：
  - meta      检索来源元数据（query_used / sources / session_id / kb），首个事件
  - token     回答流式文本（多次）
  - meta_web  拒答补救时追加的网络来源（可选，出现于 token 之后）
  - done      回答结束（含 session_id / kb）
  - error     生成异常
"""
import threading

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .. import config, db
from ..persona import build_system_prompt
from ..llm import _stream_chat
from ..state import (
    _get_store,
    _get_mysql_store,
    _resolve_kb,
    _build_search_query,
    _web_search,
    _is_refusal,
    RETRIEVAL_LANES,
)

router = APIRouter()

# MySQL 历史对话降噪词表（借 kada 医学库经验）：早期对话里常留下"知识库之外/
# 仅供参考"这类拒答与客套话，它们会挤占检索名额、把真正的资料挤下去。
# 仅对"对话"来源生效——高亮/档案是用户主动记录的内容，即便含这些词也不过滤。
_MYSQL_NOISE = (
    "知识库之外", "知识库未载", "没有相关资料", "未找到相关", "没有找到相关",
    "没有相关记录", "仅供参考", "建议咨询", "建议向", "抱歉", "不好意思",
    "无法回答", "我不清楚", "请提供更多", "没有足够的信息",
)


def _is_mysql_noise(text: str) -> bool:
    """MySQL 对话块是否为低价值噪声（拒答/客套）。"""
    return bool(text) and any(w in text for w in _MYSQL_NOISE)


def _lane_search(store, query: str, base_k: int) -> list:
    """多车道检索（借 kada 医学库经验）：分道配额 + 特征词重排 + 相关性闸门。

    与 kada 的差异（我们库小，2123 块，kada 是 96 万块）：
      车道引导词只用来【排序与配额】，绝不作为"进入上下文"的门槛——每条车道
      的候选必须同时出现在"原查询"的结果集里（相关性闸门），否则会出现
      "为了凑满车道，把硬件学习路线塞进 RAG 提问的上下文"这类稀释。
      kada 库大、每条车道都有自己的书，可以放开；小库必须收紧。

    流程：原查询取基准相关集 → 每条车道从自己的候选池里挑出"同时属于基准集"
    的块，按车道特征词命中数稳定重排、各留 per_lane 名 → 剩余名额用基准集里
    分数最高的块补满（跨车道块级去重，kada v3 踩过"先去重再截断导致车道变空"的坑）。
    """
    base = store.search(query, top_k=base_k)
    if not base:
        return []
    base_txt = {h["text"] for h in base}
    per_lane = config.LANE_PER_LANE_K
    used: set[str] = set()
    out: list = []
    for idx, lane in enumerate(RETRIEVAL_LANES):
        cands = store.search(f"{query} {lane['keywords']}", top_k=config.LANE_CANDIDATES)
        lane_hits = [c for c in cands if c["text"] in base_txt]  # 相关性闸门
        # 车道内按分数降序（不做特征词重排：实测会为"特征词更多"牺牲"分数最高"，
        # 把金标 top-1 从 100% 拉低到 91.7%；车道的作用是"分类配额保覆盖"，
        # 不是推翻相关性排序——kada 库大可以重排，我们库小以相关性优先）
        lane_hits.sort(key=lambda h: -h.get("score", 0))
        picked = 0
        for h in lane_hits:
            if h["text"] in used:
                continue
            used.add(h["text"])
            h["lane"] = lane["key"]
            h["lane_name"] = lane["name"]
            h["_lane_idx"] = idx
            out.append(h)
            picked += 1
            if picked >= per_lane:
                break
    # 补位：基准集里尚未入选的块按原分数（base 已按分数降序）依次补满
    for h in base:
        if len(out) >= base_k:
            break
        if h["text"] in used:
            continue
        used.add(h["text"])
        out.append(h)
    return out


class ChatBody(BaseModel):
    message: str
    kb: str | None = None                      # 目标知识库 key
    history: list | None = None  # [{"role": "user"/"assistant", "content": ...}, ...]
    session_id: int | None = None  # 会话模型修正（阶段 2）：前端持同一 session_id 归组多轮对话


@router.post("/api/chat")
def api_chat(body: ChatBody):
    """RAG 检索 + 人设约束 + 流式回答（支持多知识库/多身份/多轮上下文）。

    单库检索：分支库（经验/个人/知识）只搜本库 + MySQL 内容；
    总库(master) 本身汇集全部分支，天然三库同搜。
    流式格式：第一行是 __META__:{json}\n，包含检索来源信息；后续行是纯文本回答。
    同时把对话持久化到 MySQL（会话 + 用户消息 + 助手消息）。
    """
    # S1-5 输入长度护栏：超长提问直接拒绝（防 RAG/LLM token 成本无上限）
    _msg_len = len(body.message or "")
    if _msg_len > config.AGENT_MAX_INPUT_CHARS:
        raise HTTPException(
            status_code=400,
            detail=f"提问过长（{_msg_len} 字符，上限 {config.AGENT_MAX_INPUT_CHARS}），请精简后再问")
    kb = _resolve_kb(body.kb)
    store = _get_store(kb)
    cfg = config.KNOWLEDGE_BASES[kb]
    # 多轮上下文感知检索：LLM 改写检索词（失败降级为原文拼接）
    query = _build_search_query(body.message, body.history)

    # ---- 单库检索：只搜当前库（master 天然含全部分支），先截断到 TOP_K ----
    # 默认走多车道（项目经验/学习路线/自我认知 各留名额），避免某一类资料
    # 因字面更贴近提问而占满名额，把其他同样有用的资料挤下去（借 kada 经验）。
    hits = (_lane_search(store, query, config.TOP_K)
            if (config.LANES_ENABLED and store.size) else [])
    if not hits:
        hits = store.search(query, top_k=config.TOP_K)

    # ---- 检索质量评估：命中太少或分数过低时，用原文重查一次补救 ----
    if not hits or (hits[0].get("score", 0) < 0.30 and len(hits) < 3):
        alt = store.search(body.message, top_k=config.TOP_K)
        if alt:
            seen_txt = {h.get("text", "") for h in hits}
            for h in alt:
                t = h.get("text", "")
                if t in seen_txt:
                    continue
                seen_txt.add(t)
                hits.append(h)
                if len(hits) >= config.TOP_K * 2:
                    break
        if not hits:
            hits = alt
    hits = hits[: config.TOP_K]  # 本地库最多 TOP_K 条，给 MySQL 留出份额

    # ---- MySQL 内容（高亮/档案/对话历史）单独检索：降噪 + 限量 ----
    # 取较大候选池（TOP_K*3）先过滤噪声，再截到 MYSQL_HITS_LIMIT 块，
    # 把上下文名额还给真正的知识库资料（借 kada 经验）。
    mysql_hits = []
    mysql_store = _get_mysql_store()
    if mysql_store and mysql_store.size:
        raw = mysql_store.search(query, top_k=config.TOP_K * 3)
        if not raw:
            raw = mysql_store.search(body.message, top_k=config.TOP_K * 3)
        for h in raw:
            src = h.get("source", "")
            # 只对对话来源过滤：高亮/档案是用户主动记录，不因话术词误杀
            if "对话:" in src and _is_mysql_noise(h.get("text", "")):
                continue
            mysql_hits.append(h)
            if len(mysql_hits) >= config.MYSQL_HITS_LIMIT:
                break

    # 合并去重：本地 + MySQL 各 TOP_K 条，总量 ≤ TOP_K*2
    seen_src = {h.get("source", "") for h in hits}
    for h in mysql_hits:
        s = h.get("source", "")
        if s in seen_src:
            continue
        seen_src.add(s)
        hits.append(h)

    # 重新编号 rank：按车道分组（车道内按分数降序），MySQL/无车道块排在最后
    _no_lane = len(RETRIEVAL_LANES)
    hits.sort(key=lambda h: (h.get("_lane_idx", _no_lane), -h.get("score", 0)))
    for i, h in enumerate(hits, start=1):
        h["rank"] = i
    hits = hits[: config.TOP_K * 2]

    # ---- 联网搜索兜底：本地+MySQL 都没找到相关内容时，自动联网搜索 ----
    # 注意：hits 现在按车道分组再截断，hits[0] 不代表最高分，故取全局最高分判断
    _top_score = max((h.get("score", 0) for h in hits), default=0.0)
    web_results = []
    _need_web = config.WEB_SEARCH_ENABLED and (
        not hits or _top_score < config.WEB_SEARCH_MIN_SCORE
    )
    if _need_web:
        web_results = _web_search(query or body.message, config.WEB_SEARCH_MAX_RESULTS)

    # 组装上下文：检索结果按车道分组（带分组标题）+ 网络搜索结果
    context_parts = []
    _cur_lane = None
    for h in hits:
        _lane_name = h.get("lane_name")
        if _lane_name and _lane_name != _cur_lane:
            context_parts.append(f"【{_lane_name}】")
            _cur_lane = _lane_name
        context_parts.append(f"- {h['text']}")
    if web_results:
        for wr in web_results:
            context_parts.append(f"- [网络搜索] {wr['title']}：{wr['snippet']}")
    context_text = "\n".join(context_parts)

    # 提示词：有网络搜索结果时加一句说明
    if web_results and not hits:
        system_prompt = build_system_prompt(cfg["persona"], None)
        system_prompt += "\n\n【网络搜索结果】（以下来自 DuckDuckGo 搜索，请据此回答并注明来源）：\n" + context_text
    else:
        system_prompt = build_system_prompt(cfg["persona"], context_text or None)

    # ---- 长期记忆注入（M3 阶段 3）：检索相关记忆 + 画像稳定段附在提示中 ----
    # 延迟敏感：fastembed 已由 main.py 预热 + LRU 缓存，常规 <100ms；失败静默降级
    # 分层（P1，借 Agent-Memory）：画像稳定段（profile 少而稳，每轮常驻）
    # + 动态检索段（memory/experience/preference 随问题检索）
    try:
        from ..memory import (
            get_memory_context, get_profile_block,
            MEM_CTX_HEADER, MEM_PROFILE_HEADER,
        )

        memory_ctx = get_memory_context(body.message)
        profile_ctx = get_profile_block()
    except Exception:
        memory_ctx, profile_ctx = "", ""
    if memory_ctx:
        system_prompt += "\n\n" + MEM_CTX_HEADER + "：\n" + memory_ctx
    if profile_ctx:
        system_prompt += "\n\n" + MEM_PROFILE_HEADER + "：\n" + profile_ctx

    # 检索来源元数据（前端展示用 + 落库追溯；lane 便于排查"哪条车道缺料"）
    sources_meta = [
        {
            "rank": h["rank"],
            "source": h["source"],
            "text": h["text"][:120],
            "score": round(h.get("score", 0), 4),
            "lane": h.get("lane", ""),
        }
        for h in hits
    ]
    # 网络搜索来源（前端用 type=web 区分，渲染为可点击链接而非加载原文）
    if web_results:
        for i, wr in enumerate(web_results, start=1):
            sources_meta.append({
                "rank": len(hits) + i,
                "source": f"[网络] {wr['title'][:40]}",
                "text": wr["snippet"],
                "score": 0.0,
                "type": "web",
                "url": wr["url"],
            })

    # ---- 持久化：会话归组（阶段 2 会话模型修正） ----
    # 前端持同一 session_id 多轮对话时复用该会话；不传/无效则新建（兼容旧前端）。
    # 多轮语义由前端 history 携带，这里只负责把消息归到同一个会话下便于历史回看。
    session_id = None
    if body.session_id:
        session_id = db.get_session(body.session_id)
        session_id = session_id["id"] if session_id else None
    if not session_id:
        session_id = db.create_session(kb_key=kb, kb_name=cfg["name"], model=config.CHAT_MODEL)
    if session_id:
        db.add_message(session_id, "user", body.message, kb_key=kb,
                       retrieved=sources_meta, query_used=query)

    # ---- 正反馈沉淀：用户在任务完成后表达认可 → 后台线程提炼为经验入库 ----
    # 与 agent 入口一致；三重防线防误触（正反馈词 + 10 分钟窗口 + 30 分钟防抖）
    if config.MEMORY_AUTO_SINK_ENABLED:
        try:
            from ..memory import auto_sink_praise

            threading.Thread(target=auto_sink_praise, args=(body.message,),
                             daemon=True).start()
        except Exception:
            pass

    # ---- 规则式自动沉淀：移到下方最终答复轮（assistant 完整回答后）触发 ----
    # P1 防污染：绝不在"收到消息即沉淀"（此时不知本轮是否答成，且原文可能被
    # 注入段污染）；统一在 done 前按原文快照沉淀（见 _stream_sse 尾部）。

    messages = list(body.history or []) + [{"role": "user", "content": body.message}]

    def _stream_sse(sid=session_id):
        """SSE 事件流：meta（来源）→ token（打字机）→ [meta_web + token（拒答补救）] → done。

        回答全程累积到 full，流结束后把完整回答落库（与旧版一致）。
        """
        from ..agent.events import sse_payload  # 轻量模块，函数内导入遵循 agent 懒加载约定

        meta = {"query_used": query, "sources": sources_meta, "session_id": sid, "kb": kb}
        yield sse_payload("meta", **meta)
        full = ""
        errored = False
        try:
            for piece in _stream_chat(messages, system_prompt):
                full += piece
                yield sse_payload("token", text=piece)
            # ---- 拒答检测补救：AI 说"知识库之外"等拒答时，联网搜索补充 ----
            # 体验：先如实告诉用户知识库没有，再联网帮用户搜索（用户认可的方式）
            if (_is_refusal(full)
                    and not web_results
                    and config.WEB_SEARCH_ENABLED
                    and config.TAVILY_API_KEY):
                web2 = _web_search(query or body.message, config.WEB_SEARCH_MAX_RESULTS)
                if web2:
                    web_meta = []
                    for i, wr in enumerate(web2, start=1):
                        web_meta.append({
                            "rank": len(hits) + i,
                            "source": f"[网络] {wr['title'][:40]}",
                            "text": wr["snippet"],
                            "score": 0.0,
                            "type": "web",
                            "url": wr["url"],
                        })
                    # 分隔提示（普通 token，用户能看到"先没有→再联网"的过程）
                    sep = "\n\n---\n🔍 知识库未命中，已联网搜索补充：\n\n"
                    yield sse_payload("token", text=sep)
                    full += sep
                    # 补充网络来源（前端解析 meta_web 事件，追加到来源列表）
                    yield sse_payload("meta_web", sources=web_meta)
                    # 基于网络结果重新生成补充回答
                    web_ctx = "\n".join(
                        f"- [网络搜索] {wr['title']}：{wr['snippet']}" for wr in web2
                    )
                    web_prompt = build_system_prompt(cfg["persona"], None)
                    web_prompt += ("\n\n【网络搜索结果】（以下来自 Tavily 搜索，"
                                   "请据此回答用户问题并注明来源）：\n" + web_ctx)
                    for piece in _stream_chat(messages, web_prompt):
                        full += piece
                        yield sse_payload("token", text=piece)
        except Exception as e:  # 生成异常：推送 error 事件，不让前端卡在等待
            errored = True
            yield sse_payload("error", message=f"生成失败：{e}")
        finally:
            if sid and full.strip():
                db.add_message(sid, "assistant", full, kb_key=kb)
        # 自动沉淀（P1 只做最终答复轮）：assistant 完整回答后才写入记忆库。
        # 出错/无回答不沉淀；worker/子代理轮不走本路由，天然跳过，防重复写。
        if (not errored and config.MEMORY_AUTO_SINK_ENABLED and full.strip()):
            try:
                from ..memory import auto_sink_message

                threading.Thread(target=auto_sink_message, args=(body.message,),
                                 daemon=True).start()
            except Exception:
                pass
        yield sse_payload("done", session_id=sid, kb=kb)

    return StreamingResponse(
        _stream_sse(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "X-Retrieved": str(len(hits)), "X-KB": kb},
    )
