# -*- coding: utf-8 -*-
"""高亮条目路由：/api/highlights 增删改查。"""
from fastapi import APIRouter
from pydantic import BaseModel

from .. import db

router = APIRouter()


class HighlightBody(BaseModel):
    title: str
    content: str = ""
    category: str = "通用"
    tags: str = ""
    level: int = 3
    source: str = ""


class HighlightUpdate(BaseModel):
    title: str | None = None
    content: str | None = None
    category: str | None = None
    tags: str | None = None
    level: int | None = None
    source: str | None = None


@router.get("/api/highlights")
def api_highlights(category: str | None = None, q: str | None = None):
    """高亮条目列表（按重要级别降序）。"""
    items = db.list_highlights(category=category, q=q)
    cats = db.highlight_categories()
    return {"ok": True, "items": items, "categories": cats}


@router.get("/api/highlights/{hid}")
def api_highlight_get(hid: int):
    item = db.get_highlight(hid)
    if not item:
        return {"ok": False, "error": "条目不存在"}
    return {"ok": True, "item": item}


@router.post("/api/highlights")
def api_highlight_create(body: HighlightBody):
    if not (body.title or body.content):
        return {"ok": False, "error": "标题或内容不能都为空"}
    hid = db.create_highlight(
        title=body.title.strip(),
        content=body.content.strip(),
        category=body.category.strip() or "通用",
        tags=body.tags.strip(),
        level=max(1, min(5, body.level)),
        source=body.source.strip(),
    )
    if hid is None:
        return {"ok": False, "error": "数据库写入失败"}
    return {"ok": True, "id": hid}


@router.put("/api/highlights/{hid}")
def api_highlight_update(hid: int, body: HighlightUpdate):
    upd = {k: (v.strip() if isinstance(v, str) else v) for k, v in body.model_dump().items() if v is not None}
    if not upd:
        return {"ok": False, "error": "没有要更新的字段"}
    if "level" in upd:
        upd["level"] = max(1, min(5, upd["level"]))
    ok = db.update_highlight(hid, **upd)
    return {"ok": bool(ok)} if ok else {"ok": False, "error": "更新失败，条目可能不存在"}


@router.delete("/api/highlights/{hid}")
def api_highlight_delete(hid: int):
    ok = db.delete_highlight(hid)
    return {"ok": bool(ok)} if ok else {"ok": False, "error": "删除失败，条目可能不存在"}
