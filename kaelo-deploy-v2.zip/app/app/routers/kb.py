# -*- coding: utf-8 -*-
"""知识库路由：列表/模型信息/上传/来源/删除/维护/校验/详情/统计/台账。"""
import os

from fastapi import APIRouter, File, UploadFile
from pydantic import BaseModel

from .. import config, rag, validate, db
from ..persona import get_persona_name
from ..state import _get_store, _get_mysql_store, _resolve_kb, _rebuild_master, _stores

router = APIRouter()


class DeleteBody(BaseModel):
    source: str  # 要删除的文档来源（文件名）
    kb: str | None = None


@router.get("/api/kbs")
def api_kbs():
    """返回全部可用知识库列表（key/名称/图标/描述/块数）。"""
    out = []
    for key, cfg in config.KNOWLEDGE_BASES.items():
        store = _get_store(key)
        out.append({
            "key": key,
            "name": cfg["name"],
            "avatar": cfg.get("avatar", "📚"),
            "desc": cfg.get("desc", ""),
            "kb_size": store.size if store else 0,
            "persona_name": get_persona_name(cfg.get("persona", "")),
        })
    return {"kbs": out, "default": config.DEFAULT_KB}


@router.get("/api/models")
def api_models(kb: str | None = None):
    """返回当前使用的生成/嵌入模型与指定知识库规模。"""
    store = _get_store(kb)
    return {
        "chat_model": config.CHAT_MODEL,
        "embed_model": config.EMBED_MODEL,
        "kb_size": store.size if store else 0,
        "backend": config.CHAT_BACKEND,
        "kb": _resolve_kb(kb),
    }


@router.post("/api/upload")
async def api_upload(kb: str | None = None, file: UploadFile = File(...)):
    """上传文档（md/txt）→ 切块 → 动态加入指定知识库。

    同名文档再次上传 = 整体替换（先删旧块再加新块），避免新旧版本共存造成检索冲突。
    """
    store = _get_store(kb)
    # 校验扩展名 + 防路径穿越：仅接受纯文件名（拒绝 ../、/、\ 等路径成分）
    name = os.path.basename((file.filename or "").replace("\\", "/")).strip()
    if not name or name in (".", "..") or name != os.path.basename(name):
        return {"ok": False, "error": "非法文件名"}
    if not name.lower().endswith((".md", ".txt")):
        return {"ok": False, "error": "仅支持 .md / .txt 文件"}
    # 读取内容
    content_bytes = await file.read()
    try:
        text = content_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return {"ok": False, "error": "文件编码需为 UTF-8"}
    if not text.strip():
        return {"ok": False, "error": "文件内容为空"}

    kb_key = _resolve_kb(kb)
    cfg = config.KNOWLEDGE_BASES[kb_key]
    # 上传到分支库时：先写入分支库真实源目录（总库从这里同步），再入库
    if not cfg.get("is_master"):
        kb_dir = cfg["knowledge_dir"]
        os.makedirs(kb_dir, exist_ok=True)
        doc_path = os.path.abspath(os.path.join(kb_dir, name))
        # 双保险：确保最终路径仍在知识库目录内（防目录穿越）
        if os.path.dirname(doc_path) != os.path.abspath(kb_dir):
            return {"ok": False, "error": "非法文件名"}
        with open(doc_path, "w", encoding="utf-8") as f:
            f.write(text)
        # 文档写入后：总库同步分支变更并强制重建总库向量
        if config.MASTER_AUTO_SYNC:
            rag.sync_master_from_branches()
            _rebuild_master()

    # 切块入库（来源标注为上传文件名）；同名来源自动整体替换
    chunks = rag._split_text(text)
    res = store.update_source(name, chunks)

    # 台账登记（MySQL）：同名文件=替换旧版，记录块数
    db.upsert_kb_doc(kb_key, cfg["name"], name, len(chunks))

    # 入库后自动检查：规则校验 + 冲突检测 + AI核查
    check = validate.check_upload(store, name)

    return {
        "ok": True,
        "file": name,
        "chunks": len(chunks),
        "removed": res["removed"],   # 替换时被删掉的旧块数
        "added": res["added"],       # 本次新增的块数
        "replaced": res["removed"] > 0,
        "kb_size": store.size,
        "check": check,              # 检查报告
    }


@router.get("/api/sources")
def api_sources(kb: str | None = None):
    """列出指定知识库全部来源文档：文件名、块数、首次/最近入库时间。"""
    store = _get_store(kb)
    return {"kb": _resolve_kb(kb), "kb_size": store.size, "sources": store.list_sources()}


@router.post("/api/delete")
def api_delete(body: DeleteBody):
    """删除指定来源文档的全部块（不可恢复，删除前请确认）。"""
    store = _get_store(body.kb)
    # 防路径穿越：仅接受纯来源名（拒绝 ../、/、\ 等路径成分）
    source = (body.source or "").strip()
    if not source or source in (".", "..") or os.path.basename(source) != source:
        return {"ok": False, "error": "非法来源名"}
    removed = store.delete_source(source)
    # 台账：标记该文档已删除
    kb_key = _resolve_kb(body.kb)
    db.mark_kb_doc_removed(kb_key, source)
    # 分支库删除时：同步删除源目录文档 + 总库对应来源
    cfg = config.KNOWLEDGE_BASES[kb_key]
    if not cfg.get("is_master") and config.MASTER_AUTO_SYNC:
        # 删除分支源目录文件（source 已校验为纯文件名，拼接安全）
        fpath = os.path.abspath(os.path.join(cfg["knowledge_dir"], source))
        if os.path.dirname(fpath) != os.path.abspath(cfg["knowledge_dir"]):
            return {"ok": False, "error": "非法来源名"}
        if os.path.exists(fpath):
            os.remove(fpath)
        # 同步到总库
        rag.sync_master_from_branches()
        # 总库删除该来源（[分支] 文件名）
        master_store = _stores.get("master")
        if master_store:
            master_store.delete_source(f"[{kb_key}] {source}")
        _rebuild_master()
    return {
        "ok": True,
        "source": source,
        "removed": removed,
        "kb_size": store.size,
        "kb": _resolve_kb(body.kb),
    }


@router.post("/api/maint")
def api_maint(kb: str | None = None):
    """一键知识库维护：精确去重 → 语义合并 → 低价值提炼。返回报告。"""
    from .. import maint
    store = _get_store(kb)
    report = maint.run_maintenance(store)
    report["kb_size"] = store.size
    return report


@router.post("/api/validate")
def api_validate(kb: str | None = None, sample_ratio: float = 0.1, golden_top_k: int = 5):
    """知识库校验：规则全量 + AI 事实核查(抽样) + 金标问题检索测试。"""
    store = _get_store(kb)
    return validate.run_validation(store, ai_sample_ratio=sample_ratio, golden_top_k=golden_top_k)


@router.get("/api/source/{name}")
def api_source_detail(name: str, kb: str | None = None):
    """查看某来源文档的全部块内容（预览）。MySQL 内容来源也支持。"""
    store = _get_store(kb)
    chunks = [m for m in store.meta if m.get("source") == name]
    if not chunks:
        # MySQL 内容：到 MySQL 向量库查
        mysql_store = _get_mysql_store()
        if mysql_store:
            chunks = [m for m in mysql_store.meta if m.get("source") == name]
    if not chunks:
        return {"ok": False, "error": "未找到该来源"}
    return {
        "ok": True,
        "source": name,
        "count": len(chunks),
        "chunks": [{"text": m["text"], "created_at": m.get("created_at", "")} for m in chunks],
    }


@router.get("/api/kb/stats")
def api_kb_stats(kb: str | None = None):
    """知识库健康指标：规模、来源数、平均块长、重复率、潜在冲突数。"""
    from collections import Counter
    store = _get_store(kb)
    if store.size == 0:
        return {"kb": _resolve_kb(kb), "kb_size": 0, "sources": 0, "avg_len": 0, "dup_rate": 0, "issues": 0}
    # 块长度统计
    lens = [len(m["text"]) for m in store.meta]
    avg_len = round(sum(lens) / len(lens), 1) if lens else 0
    # 重复率
    text_counts = Counter(m["text"] for m in store.meta)
    dup_count = sum(1 for c in text_counts.values() if c > 1)
    dup_rate = round(dup_count / len(text_counts) * 100, 1) if text_counts else 0
    # 来源数
    sources = len(set(m.get("source", "") for m in store.meta))
    # 规则问题数（快速检查，不调 AI）
    issues = 0
    for m in store.meta:
        t = m.get("text", "").strip()
        if len(t) < 10 or len(t) > 500:
            issues += 1
    return {
        "kb": _resolve_kb(kb),
        "kb_size": store.size,
        "sources": sources,
        "avg_len": avg_len,
        "min_len": min(lens) if lens else 0,
        "max_len": max(lens) if lens else 0,
        "dup_rate": dup_rate,
        "dup_count": dup_count,
        "issues": issues,
        "health": "GOOD" if issues == 0 and dup_rate < 5 else ("FAIR" if issues < 5 and dup_rate < 15 else "NEEDS_ATTENTION"),
    }


@router.get("/api/kb-docs")
def api_kb_docs(kb: str | None = None):
    """文档台账列表（active 在前）。"""
    docs = db.list_kb_docs(kb_key=_resolve_kb(kb) if kb else None)
    return {"ok": True, "docs": docs}
