# -*- coding: utf-8 -*-
"""对话历史路由：/api/history 会话列表与详情。"""
from fastapi import APIRouter

from .. import db
from ..state import _resolve_kb

router = APIRouter()


@router.get("/api/history")
def api_history(kb: str | None = None, limit: int = 20):
    """最近会话列表（可过滤知识库），每次对话自动生成一个会话。"""
    sessions = db.get_sessions(kb_key=_resolve_kb(kb) if kb else None, limit=limit)
    return {"ok": True, "sessions": sessions}


@router.get("/api/history/{sid}")
def api_history_detail(sid: int):
    """某个会话的全部消息（含检索来源）。"""
    msgs = db.get_messages(sid)
    return {"ok": True, "messages": msgs}
