# -*- coding: utf-8 -*-
"""对外 API Key 路由：Key 管理（创建/列出/删除/启停）+ v1 对话接口。

设计说明：
  - Key 只在创建时返回一次明文，数据库仅存 SHA-256 哈希
  - 对外接口统一用 Authorization: Bearer <key> 头鉴权
  - 目前只有 chat（对话）一个权限 scope；按需扩展时在 scopes 里加即可
"""
from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from .. import config, db
from ..persona import build_system_prompt
from ..llm import _stream_chat
from ..ratelimit import limiter
from ..state import _resolve_kb, _get_store, _get_mysql_store, _build_search_query

router = APIRouter()


class ApiKeyBody(BaseModel):
    name: str = "未命名"
    scopes: list[str] = ["chat"]


class ApiChatBody(BaseModel):
    message: str
    kb: str = "master"


@router.get("/api/apikeys")
def api_list_apikeys():
    """列出全部 API Key（只含前缀与状态，不含明文）。"""
    keys = db.list_api_keys()
    return {"ok": True, "keys": keys}


@router.post("/api/apikeys")
def api_create_apikey(body: ApiKeyBody):
    """生成一个新 API Key。返回的 key 明文仅此一次可见。"""
    scopes = [s for s in (body.scopes or []) if isinstance(s, str) and s.strip()] or ["chat"]
    # 安全校验：只允许已知 scope
    allowed = {"chat"}
    scopes = [s for s in scopes if s in allowed] or ["chat"]
    created = db.create_api_key(body.name, scopes)
    if not created:
        return {"ok": False, "error": "创建失败（数据库不可用）"}
    return {"ok": True, "key": created}


@router.delete("/api/apikeys/{kid}")
def api_delete_apikey(kid: int):
    """删除一个 API Key（立即失效）。"""
    return {"ok": bool(db.delete_api_key(kid))}


@router.post("/api/apikeys/{kid}/toggle")
def api_toggle_apikey(kid: int):
    """启用/禁用 API Key。"""
    row = db._execute("SELECT status FROM api_keys WHERE id=%s", (int(kid),), fetch_one=True)
    if not row:
        return {"ok": False, "error": "Key 不存在"}
    new_status = "disabled" if row.get("status") == "active" else "active"
    return {"ok": bool(db.set_api_key_status(kid, new_status)), "status": new_status}


def _require_api_key(authorization: str | None = None) -> dict:
    """从 Authorization: Bearer <key> 头提取并校验 API Key。
    有效则返回该 Key 记录（含 scopes）；否则返回 None。
    """
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        raw = authorization[7:].strip()
    else:
        raw = authorization.strip()
    if not raw:
        return None
    return db.find_api_key(raw)


@router.post("/api/v1/chat")
def api_v1_chat(body: ApiChatBody, request: Request,
                authorization: str | None = Header(None)):
    """对外对话接口：通过 API Key 鉴权后，基于知识库回答。

    用途：他人凭 Key 通过此接口了解你（个人知识库 / 高亮 / 档案）。
    鉴权：Authorization: Bearer <你的Key>
    权限：需要 chat scope（默认即有）。
    限流：按 API Key 与来源 IP 双维度滑动窗口（防刷爆账单）。
    返回：非流式 JSON {reply, sources, kb}。
    """
    record = _require_api_key(authorization)
    if record is None:
        raise HTTPException(status_code=401, detail="API Key 无效或已禁用")
    if "chat" not in (record.get("scopes") or []):
        raise HTTPException(status_code=403, detail="该 Key 无 chat 权限")

    # 限流：Key 维度（按记录 id）+ IP 维度（来源地址）
    ok, reason = limiter.check(str(record.get("id")), request.client.host)
    if not ok:
        return JSONResponse(status_code=429, content={"detail": reason})

    kb = _resolve_kb(body.kb)
    store = _get_store(kb)
    cfg = config.KNOWLEDGE_BASES[kb]

    # 与网页端一致的检索流程：LLM 改写检索词 → 单库检索 → 质量重查 → 合并 MySQL
    query = _build_search_query(body.message, None)
    hits = store.search(query, top_k=config.TOP_K)
    if not hits or (hits[0].get("score", 0) < 0.30 and len(hits) < 3):
        alt = store.search(body.message, top_k=config.TOP_K)
        if alt:
            seen_src = {h.get("source", "") for h in hits}
            for h in alt:
                s = h.get("source", "")
                if s in seen_src:
                    continue
                seen_src.add(s)
                hits.append(h)
                if len(hits) >= config.TOP_K * 2:
                    break
            if not hits:
                hits = alt
    hits = hits[: config.TOP_K]  # 本地库最多 TOP_K 条，给 MySQL 留出份额

    mysql_hits = []
    mysql_store = _get_mysql_store()
    if mysql_store and mysql_store.size:
        mysql_hits = mysql_store.search(query, top_k=config.TOP_K)
        if not mysql_hits:
            mysql_hits = mysql_store.search(body.message, top_k=config.TOP_K)
        mysql_hits = mysql_hits[: config.TOP_K]
    seen_src = {h.get("source", "") for h in hits}
    for h in mysql_hits:
        s = h.get("source", "")
        if s in seen_src:
            continue
        seen_src.add(s)
        hits.append(h)

    hits.sort(key=lambda h: h.get("score", 0), reverse=True)
    for i, h in enumerate(hits, start=1):
        h["rank"] = i
    hits = hits[: config.TOP_K * 2]
    context_text = "\n".join(f"- {h['text']}" for h in hits)
    system_prompt = build_system_prompt(cfg["persona"], context_text or None)
    sources = [{"rank": h["rank"], "source": h["source"], "score": round(h.get("score", 0), 4)} for h in hits]

    # 非流式回答（对外接口简单返回完整文本即可）
    full = _stream_chat([{"role": "user", "content": body.message}], system_prompt)
    reply = "".join(full) if not isinstance(full, str) else full

    # 记录对话（与网页端一致落库，便于追溯）
    session_id = db.create_session(kb_key=kb, kb_name=cfg["name"], model=config.CHAT_MODEL)
    if session_id:
        db.add_message(session_id, "user", body.message, kb_key=kb, retrieved=sources, query_used=query)
        if reply and reply.strip():
            db.add_message(session_id, "assistant", reply, kb_key=kb)

    return {"ok": True, "kb": kb, "reply": reply, "sources": sources, "session_id": session_id}
