# -*- coding: utf-8 -*-
"""FastAPI 入口：组合业务路由 + 全局管理令牌鉴权 + 静态资源挂载。

阶段 1（工程地基）拆分后的组合层：
  · 业务路由按职责拆到 app/routers/（pages/kb/chat/highlights/history/
    settings/profile/keys/agent）
  · 共享状态与知识库辅助函数在 app/state.py
  · 统一 LLM 客户端在 app/llm.py
本文件只保留：
  1. FastAPI 实例与启动初始化（MySQL 表结构、动态设置加载）
  2. 管理接口令牌鉴权中间件（白名单外的 /api/* 统一 401）
  3. 静态页面与静态资源挂载
  4. uvicorn 入口（保持 `app.main:app` 可导入，供 pytest / start.bat 使用）
"""
import os
import threading

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import config, db
from .log_util import setup_logging, get_logger
from .state import WEB_DIR
from .routers import (pages, kb, chat, highlights, history, settings, profile,
                      keys, agent, health, reminders, skills, phone)

setup_logging()  # 统一日志：控制台 + logs/app.log 轮转（幂等）
logger = get_logger("main")

# ---- 长期记忆预热（M3 阶段 3）：后台加载嵌入模型，避免首个对话请求冷启动 1-2s ----
def _warm_memory():
    try:
        from .memory import warm_up

        warm_up()
        logger.info("长期记忆模型预热完成")
    except Exception as e:  # noqa: BLE001
        logger.warning(f"长期记忆预热失败（不影响主流程）: {e}")


# 延迟启动：等应用全部模块 import 完成再预热，
# 避免预热线程与主线程并发 import agent 工具模块（obsidian 等）触发 import 锁死锁
_warm_timer = threading.Timer(5.0, _warm_memory)
_warm_timer.daemon = True
_warm_timer.start()

# ---- 笔记到期提醒后台任务：每 6 小时扫描一次 Obsidian，提取今天/明天提醒入库 ----
_REMINDER_SCAN_SECONDS = 6 * 3600


def _run_reminder_loop():
    import time

    from .reminders import scan_vault_for_reminders

    while True:
        try:
            scan_vault_for_reminders()
        except Exception as e:  # noqa: BLE001
            logger.warning("提醒扫描失败（不影响主流程）: %s", e)
        time.sleep(_REMINDER_SCAN_SECONDS)


threading.Thread(target=_run_reminder_loop, daemon=True).start()

# ---- 手机事件反连后台轮询（C批1）：adb 设备通知/电量 → 桌面提醒 ----
# 设备没连/adb 不可用时内部静默跳过；异常只记 warning 不影响主流程


def _run_phone_loop():
    from .phone import run_loop

    run_loop(seconds=config.PHONE_MONITOR_SECONDS,
             low_pct=config.PHONE_BATTERY_LOW_PCT)


if config.PHONE_MONITOR_ENABLED:
    threading.Thread(target=_run_phone_loop, daemon=True).start()
    logger.info("手机事件反连监控已启动（每 %ss 轮询，低电量阈值 %d%%）",
                config.PHONE_MONITOR_SECONDS, config.PHONE_BATTERY_LOW_PCT)

app = FastAPI(title="本地语音 RAG 助理 · 多知识库")

# ============ 管理接口令牌鉴权（阶段 0 安全兜底） ============
# 除白名单外，所有 /api/* 接口都必须携带管理令牌（X-Admin-Token 或 Authorization: Bearer）。
# ADMIN_TOKEN 未配置时 fail-closed：管理接口一律 401，防止局域网内未授权访问。
_PUBLIC_API_PATHS = {"/api/kbs", "/api/models", "/api/chat", "/api/v1/chat", "/api/health"}


def _check_admin_token(request: Request) -> bool:
    token = (request.headers.get("X-Admin-Token") or "").strip()
    if not token:
        auth = request.headers.get("Authorization") or ""
        if auth.lower().startswith("bearer "):
            token = auth[7:].strip()
    return bool(config.ADMIN_TOKEN) and token == config.ADMIN_TOKEN


@app.middleware("http")
async def admin_auth_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/") and path not in _PUBLIC_API_PATHS and not _check_admin_token(request):
        return JSONResponse(status_code=401, content={"detail": "需要管理令牌（X-Admin-Token 请求头）"})
    return await call_next(request)


if not config.ADMIN_TOKEN:
    logger.warning("ADMIN_TOKEN 未配置：所有管理接口（上传/删除/设置/档案等）已拒绝访问，请在根目录 .env 中设置 ADMIN_TOKEN")

# 启动时初始化 MySQL 表结构（幂等；失败仅告警，不阻断主流程）
db.init_db()
# 启动时从 MySQL 加载动态设置（API Key/模型/接口），覆盖 config 默认值
config.load_db_settings()

# ---- 业务路由 ----
for r in (pages, kb, chat, highlights, history, settings, profile, keys,
          agent, health, reminders, skills, phone):
    app.include_router(r.router)

# 静态资源（web 目录）
os.makedirs(WEB_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=False)
