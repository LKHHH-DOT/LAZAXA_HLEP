# -*- coding: utf-8 -*-
"""结构化规划层（M4b · 借 dsh goal/plan 包与 Anthropic"显式展示规划"）。

把"在文字里写计划"升级为可创建、可更新、每轮强制可见的结构化状态：
- plan_create 建计划（goal + 步骤列表）→ 建计划变更事件
- plan_update 按状态机推进步骤（pending→in_progress→done/skipped/blocked）
- plan_get 取当前计划全文
- loop 每轮模型调用前把【当前执行计划】渲染段注入系统上下文

关键设计（与 08 路线差异，见 M4b 细化方案 D1）：
- 不新建 agent_plans DB 表；计划是任务内高频更新的瞬态，存内存单例（LRU 防泄漏），
  每次 create/update 经 M3 log_agent_event 落 plan_created/plan_updated 事件——
  既持久化（前端断线回放可重建计划时间线），又保持"模型可见即已记录"单一事实源。
- 状态机只允许合理流转，防模型乱标；非法跳转报错回灌自纠。
- 任何 db 异常静默降级（计划内存态不受影响）；无 round_id（测试/裸调）明确报错不写脏。
"""
import json
import threading
import time
from collections import OrderedDict

from . import task_context
from .events import EventType

# ---- 状态机 ----
PLAN_STATES = ("pending", "in_progress", "done", "skipped", "blocked")
# 允许的流转：每对 (from, to) —— done 必须经过 in_progress（防跳步假完成）
_PLAN_TRANSITIONS = {
    ("pending", "in_progress"), ("pending", "skipped"),
    ("pending", "blocked"),
    ("in_progress", "done"), ("in_progress", "blocked"),
    ("in_progress", "pending"),            # 回退重做
    ("blocked", "in_progress"),            # 解阻后恢复
    ("blocked", "pending"),                # 解阻后重排
    ("done", "in_progress"),               # 改主意重做
}
_STATE_ICON = {"pending": "⬜", "in_progress": "🔄", "done": "✅",
               "skipped": "⏭️", "blocked": "⛔"}

# 长度护栏（防超长计划烧上下文）
PLAN_MAX_STEPS = 12
PLAN_MAX_GOAL = 200
PLAN_MAX_TITLE = 80
PLAN_MAX_NOTE = 200
_PLAN_STORE_MAX_ROUNDS = 32   # LRU 上限：超过按最旧轮淘汰，防内存泄漏


class PlanStep:
    def __init__(self, step_id: str, title: str, status: str = "pending",
                 note: str = ""):
        self.step_id = step_id
        self.title = title
        self.status = status
        self.note = note

    def to_dict(self) -> dict:
        return {"step_id": self.step_id, "title": self.title,
                "status": self.status, "note": self.note}


class Plan:
    def __init__(self, round_id: str, goal: str, steps: list[PlanStep]):
        self.round_id = round_id
        self.goal = goal
        self.steps = steps
        self.created_at = time.time()
        self.updated_at = self.created_at

    def render(self) -> str:
        """渲染为紧凑文本（每轮注入 / 工具返回）。"""
        lines = [f"目标：{self.goal}"]
        for s in self.steps:
            icon = _STATE_ICON.get(s.status, "•")
            note = f"　{s.note}" if s.note else ""
            lines.append(f"{icon} [{s.step_id}] {s.title}{note}")
        done_n = sum(1 for s in self.steps if s.status == "done")
        lines.append(f"进度：{done_n}/{len(self.steps)}")
        return "\n".join(lines)


class PlanStore:
    """按 round_id 键控的内存计划库（LRU 上限防泄漏，线程安全）。"""

    def __init__(self):
        self._plans: "OrderedDict[str, Plan]" = OrderedDict()
        self._lock = threading.Lock()

    # ---- 内部 ----
    def _get(self, round_id: str) -> Plan | None:
        p = self._plans.get(round_id)
        if p is not None:
            self._plans.move_to_end(round_id)  # LRU 触碰
        return p

    def _set(self, round_id: str, plan: Plan) -> None:
        self._plans[round_id] = plan
        self._plans.move_to_end(round_id)
        while len(self._plans) > _PLAN_STORE_MAX_ROUNDS:
            self._plans.popitem(last=False)

    # ---- 对外 ----
    def create(self, round_id: str, goal: str, steps: list) -> Plan:
        goal = (goal or "").strip()[:PLAN_MAX_GOAL]
        step_objs = []
        for i, t in enumerate((steps or [])[:PLAN_MAX_STEPS], 1):
            title = (t.get("title") if isinstance(t, dict) else str(t)).strip()
            if not title:
                title = f"步骤 {i}"
            step_objs.append(PlanStep(step_id=f"s{i}",
                                      title=title[:PLAN_MAX_TITLE]))
        plan = Plan(round_id, goal, step_objs)
        with self._lock:
            self._set(round_id, plan)
        _emit_plan_event(EventType.PLAN_CREATED, plan, {})
        return plan

    def update(self, round_id: str, step_id: str, status: str,
               note: str = "") -> tuple[Plan | None, str]:
        """推进计划步骤。返回 (最新 Plan, 错误消息)；成功时 error 为空。"""
        status = (status or "").strip().lower()
        if status not in PLAN_STATES:
            return None, f"未知状态：{status}。可选：{'/'.join(PLAN_STATES)}"
        with self._lock:
            plan = self._get(round_id)
            if plan is None:
                return None, "当前没有计划，请先调用 plan_create 建立计划。"
            step = next((s for s in plan.steps if s.step_id == step_id), None)
            if step is None:
                return None, f"找不到步骤 {step_id}。可用：{', '.join(s.step_id for s in plan.steps)}"
            if (step.status, status) not in _PLAN_TRANSITIONS and step.status != status:
                return None, (f"不允许从「{step.status}」直接跳到「{status}」"
                              f"（计划状态机限制）。合法路径参考：进行中→完成/受阻/回退，"
                              f"受阻→恢复/重排，完成→重做。")
            from_status = step.status
            step.status = status
            step.note = (note or "").strip()[:PLAN_MAX_NOTE]
            plan.updated_at = time.time()
            changed = {"step_id": step_id, "from": from_status,
                       "to": status, "note": step.note}
            snapshot = plan.render()
        _emit_plan_event(EventType.PLAN_UPDATED, plan, changed)
        return plan, ""

    def get(self, round_id: str) -> Plan | None:
        with self._lock:
            return self._get(round_id)

    def clear(self, round_id: str) -> None:
        with self._lock:
            self._plans.pop(round_id, None)


def _emit_plan_event(event_type: EventType, plan: Plan, extra: dict) -> None:
    """计划变更落 M3 事件账本（失败静默，不影响计划内存态）。"""
    try:
        from ..db import log_agent_event
        log_agent_event(str(event_type), {
            "goal": plan.goal,
            "steps": [s.to_dict() for s in plan.steps],
            **extra,
        }, round_id=plan.round_id)
    except Exception:
        pass


# 全局单例（与 registry 风格一致）
plan_store = PlanStore()
