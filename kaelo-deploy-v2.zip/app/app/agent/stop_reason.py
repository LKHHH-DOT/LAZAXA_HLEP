# -*- coding: utf-8 -*-
"""任务停止原因枚举（P2 · 借 DeerFlow stop_reason 统一语义，单一来源）。

loop/子代理/jobs 不再各自写字符串字面量，统一引用本枚举；
对外事件与审计仍输出 .value 字符串（兼容前端与历史记录）。
取值：
  completed      正常完成（模型直接回复）
  error          模型调用异常 / 任务出错
  max_steps      工具调用步数超过上限
  loop_capped    循环熔断硬停（同一工具同参反复调用，无实质进展）
  empty_response 模型连续空回复，兜底收尾
  cancelled      被用户/上级取消
  timeout        任务整体超时（jobs 层）
"""
from enum import Enum


class StopReason(str, Enum):
    COMPLETED = "completed"
    ERROR = "error"
    MAX_STEPS = "max_steps"
    LOOP_CAPPED = "loop_capped"
    EMPTY_RESPONSE = "empty_response"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
