# -*- coding: utf-8 -*-
"""DeepSeek function calling 流式封装。

复用现有 config（DEEPSEEK_API_KEY / DEEPSEEK_BASE_URL / CHAT_MODEL），
风格与 main.py 的 _stream_chat 一致（requests + OpenAI 兼容接口）。

一次请求返回：
- 若模型要调工具 → chat_response.tool_calls: [ToolCall]
- 若模型直接回复 → chat_response.content: str
"""

import json
import time

import requests

from .. import config

# S1-1（M1 止血）：瞬时错误（429/5xx）指数退避重试上限与重试集。
# 4xx（参数/鉴权问题）与其它错误不重试，避免放大成本。
_MAX_RETRIES = 3
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class ToolCall:
    """一次工具调用（模型发起的）。"""

    def __init__(self, id: str, name: str, args: dict):
        self.id = id
        self.name = name
        self.args = args

    def to_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "args": self.args}


class ChatResponse:
    """一次 chat.completions 的返回。"""

    def __init__(self, content: str, tool_calls: list[ToolCall], finish_reason: str | None,
                 usage: dict | None = None):
        self.content = content          # 直接回复的文本（无工具调用时）
        self.tool_calls = tool_calls    # 模型要调的工具（可为空）
        self.finish_reason = finish_reason
        self.usage = usage              # S1-2：{"prompt_tokens","completion_tokens","total_tokens"}（流末 usage chunk）

    @property
    def has_tool_calls(self) -> bool:
        return bool(self.tool_calls)

    def to_assistant_message(self) -> dict:
        """转成可追加进 messages 的 assistant 消息（含 tool_calls 字段）。"""
        msg = {"role": "assistant", "content": self.content or ""}
        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.name, "arguments": json.dumps(tc.args, ensure_ascii=False)},
                }
                for tc in self.tool_calls
            ]
        return msg


def chat(messages: list[dict], tools: list[dict] | None = None, on_token=None,
         temperature: float = 0.2, timeout: int = 300) -> ChatResponse:
    """调用 DeepSeek chat.completions（流式）。

    - messages: 完整对话（system/user/assistant/tool 消息）
    - tools:    function calling 定义列表（来自 registry.openai_schemas()）
    - on_token: 流式回调 on_token(text)（仅在无工具调用、直接输出时触发）
    返回 ChatResponse。
    """
    url = f"{config.DEEPSEEK_BASE_URL}/chat/completions"
    headers = {
        "Authorization": f"Bearer {config.DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": config.CHAT_MODEL,
        "messages": messages,
        "stream": True,
        "temperature": temperature,
        # S1-2：请求流末 usage chunk（服务端不支持该字段时会忽略，不会 400）
        "stream_options": {"include_usage": True},
    }
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"

    # S1-1：瞬时错误指数退避（1s/2s/4s）。每次尝试重置流式缓冲，
    # 防止半截流与下一次成功响应拼串。
    for attempt in range(_MAX_RETRIES):
        content_parts: list[str] = []
        tool_calls_buf: dict[int, dict] = {}   # index -> {id,name,args_buf}
        finish_reason = None                    # 末尾 chunk 携带，如 stop/length/…
        usage = None                            # 流末 usage chunk（S1-2）
        try:
            with requests.post(url, json=payload, headers=headers,
                               stream=True, timeout=timeout) as r:
                if r.status_code != 200:
                    err = RuntimeError(
                        f"DeepSeek API 错误 {r.status_code}: {r.text[:300]}")
                    if r.status_code in _RETRYABLE_STATUS and attempt < _MAX_RETRIES - 1:
                        time.sleep(2 ** attempt)
                        continue
                    raise err
                for line in r.iter_lines(decode_unicode=True):
                    if not line or not line.startswith("data:"):
                        continue
                    data = line[len("data:"):].strip()
                    if data == "[DONE]":
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    # S1-2：usage chunk（choices 为空，仅带 usage 字段）
                    if obj.get("usage"):
                        usage = obj["usage"]
                    choice = obj.get("choices", [{}])[0] if obj.get("choices") else {}
                    delta = choice.get("delta", {})
                    # 解析 finish_reason（P2）：区分"正常结束 stop / 长度截断 length / 工具调用"
                    if choice.get("finish_reason"):
                        finish_reason = choice["finish_reason"]
                    if delta.get("content"):
                        content_parts.append(delta["content"])
                        if on_token:
                            on_token(delta["content"])
                    for tc in delta.get("tool_calls") or []:
                        idx = tc.get("index", 0)
                        buf = tool_calls_buf.setdefault(idx, {"id": "", "name": "", "args_buf": ""})
                        if tc.get("id"):
                            buf["id"] = tc["id"]
                        if tc.get("function", {}).get("name"):
                            buf["name"] = tc["function"]["name"]
                        if tc.get("function", {}).get("arguments"):
                            buf["args_buf"] += tc["function"]["arguments"]
        except requests.RequestException as e:
            # 连接/读流中断等瞬时故障：指数退避后重试
            if attempt < _MAX_RETRIES - 1:
                time.sleep(2 ** attempt)
                continue
            raise
        break

    tool_calls: list[ToolCall] = []
    for buf in tool_calls_buf.values():
        raw_args = buf["args_buf"]
        try:
            args = json.loads(raw_args) if raw_args else {}
        except json.JSONDecodeError as e:
            # S1-3：解析失败不再静默空参——原样回灌给模型自纠（registry 执行前拦截）
            args = {"__parse_error__": f"参数 JSON 解析失败: {e} | 原始参数片段: {raw_args[:200]}"}
        if not isinstance(args, dict):
            args = {"__parse_error__": f"工具参数不是 JSON 对象: {str(raw_args)[:200]}"}
        tool_calls.append(ToolCall(id=buf["id"] or f"call_{len(tool_calls)}", name=buf["name"], args=args))

    return ChatResponse(content="".join(content_parts), tool_calls=tool_calls,
                        finish_reason=finish_reason, usage=usage)


def tool_message(tool_call_id: str, content: str) -> dict:
    """构造工具执行结果消息（追加进 messages）。"""
    return {"role": "tool", "tool_call_id": tool_call_id, "content": content}
