# -*- coding: utf-8 -*-
"""M5 工具流水线默认钩子注册（dsh pre/execute/post 事件瀑布的 Kaelo 落法）。

- approval gate（async，审批挂起）：见 app/agent/approval.py::approval_gate_hook
- audit post：工具调用/审批审计落 agent_tasks（原 loop._audit，中立化到此）
- trim post：超长工具结果修剪，修剪后文本写入 result.model_text（只影响模型所见，
  result.text 保留原文供审计/截图路径提取），与旧 loop 行为逐字等价

register_default_hooks 在 app/agent/__init__.py 注册工具后调用一次（幂等）。
"""

from . import context
from .. import config
from .registry import ToolResult


def audit_tool_call(user_message, task_id, tool_name, args, risk,
                    mode: str, decision: str,
                    approved: bool | None, result_text: str, ok: bool | None,
                    parent_task_id: str = "", round_id: str = "",
                    token_usage: dict | None = None,
                    element_id: str = "", retries: int | None = None):
    """工具调用/审批审计落库（agent_tasks 表）。任何异常静默，绝不阻断主流程。

    （M5 从 loop._audit 原样迁入，子代理路径仍复用本函数。）
    element_id/retries：P2-2 审计增强，分别来自 args 的控件引用与本步 ToolResult.meta。
    """
    try:
        from ..db import log_agent_task
        token_in = token_out = None
        if token_usage:
            token_in = token_usage.get("prompt_tokens")
            token_out = token_usage.get("completion_tokens")
        log_agent_task(task_id, tool_name, args, risk, approved,
                       result_text, ok, user_message=user_message,
                       mode=mode, decision=decision,
                       parent_task_id=parent_task_id, round_id=round_id,
                       token_in=token_in, token_out=token_out,
                       element_id=element_id, retries=retries)
    except Exception as e:
        # 正常情况 log_agent_task 内部已兜底计数；这里只兜"它自己都抛了"的极少数
        try:
            from ..db import bump_audit_failure
            bump_audit_failure(f"pipeline.audit: {type(e).__name__}: {e}")
        except Exception:
            pass


def audit_post_hook(name: str, args: dict, risk: str, ctx,
                    result: ToolResult) -> ToolResult:
    """post：审计留痕（原文 result.text/error；decision/approved 由 gate 回写 ctx）。"""
    # P2-2：控件引用（UI 动作定向用）与本步自动重试次数（工具经 result.meta 上报）
    element_id = str((args or {}).get("element_id") or "")
    retries = (result.meta or {}).get("retries")
    audit_tool_call(
        ctx.user_message, ctx.task_id, name, args, risk,
        mode=ctx.mode, decision=ctx.decision, approved=ctx.approved,
        result_text=result.text or result.error or "", ok=result.ok,
        parent_task_id=ctx.parent_task_id, round_id=ctx.round_id,
        token_usage=ctx.token_usage,
        element_id=element_id, retries=retries)
    return result


def trim_post_hook(name: str, args: dict, risk: str, ctx,
                   result: ToolResult) -> ToolResult:
    """post：超长结果修剪（层一）。修剪文本放 model_text，原文 text 不动。

    gate 拦截（未执行）无需修剪；error 短文案也不会超阈值。
    """
    if not result.ok or result.gate_blocked:
        return result
    text = result.text or ""
    if (config.CONTEXT_COMPACT_ENABLED
            and len(text) > config.TOOL_RESULT_TRIM_CHARS):
        result.model_text = context.trim_tool_result(
            text, config.TOOL_RESULT_TRIM_CHARS,
            config.CONTEXT_ARCHIVE_DIR, ctx.compact_name or "tool_result")
    return result


def register_default_hooks(reg) -> None:
    """注册 M5 默认流水线钩子（幂等：重复调用不重复挂）。"""
    from .approval import approval_gate_hook
    if approval_gate_hook not in reg._gate_hooks:
        reg.add_gate_hook(approval_gate_hook)
    # post 执行顺序：先审计（原文）后修剪（设 model_text）
    if audit_post_hook not in reg._post_hooks:
        reg.add_post_hook(audit_post_hook)
    if trim_post_hook not in reg._post_hooks:
        reg.add_post_hook(trim_post_hook)
