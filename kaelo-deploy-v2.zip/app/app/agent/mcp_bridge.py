# -*- coding: utf-8 -*-
"""通用 MCP 客户端基建（2026-08-17 · MCP 集成调研落地）。

让 Lazaxa 作为 MCP 客户端（stdio），启动外部 MCP server 子进程，
模型通过工具调用外部 server 暴露的工具——相当于给 Lazaxa 装了
"标准插座"，任何支持 MCP 的软件（Blender/Krita/VLC/FFmpeg…）都能插上。

协议：JSON-RPC 2.0 over stdio（MCP 标准）。
  initialize → notifications/initialized → tools/list → tools/call
实现要点：
  - 每个 server 一个常驻子进程，首次调用时懒启动
  - 一次只处理一个请求（threading.Lock，MCP stdio 是串行协议）
  - 读取带超时；进程异常退出自动重启
  - 返回统一 ToolResult，绝不裸抛
"""
import json
import logging
import subprocess
import threading
import time

from .registry import ToolResult

logger = logging.getLogger(__name__)

# 单次工具调用返回的最大字符数（防刷爆上下文）
_MAX_RESULT_CHARS = 12000
# 读取响应超时（秒）
_READ_TIMEOUT = 120.0
# 初始化握手超时（秒）
_INIT_TIMEOUT = 30.0
# 进程退出后自动重启的最大次数（防死循环拉起）
_MAX_RESTARTS = 3


class MCPServerClient:
    """单个 MCP server 的 stdio 客户端（进程 + 请求锁）。"""

    def __init__(self, name: str, spec: dict):
        self.name = name
        self.spec = spec
        self._proc: subprocess.Popen | None = None
        self._lock = threading.Lock()
        self._restarts = 0
        self._last_error = ""

    # ---------- 进程管理 ----------

    def _spawn(self) -> None:
        """启动子进程并完成 MCP initialize 握手。"""
        command = self.spec["command"]
        args = list(self.spec.get("args", []))
        cwd = self.spec.get("cwd")
        # 注意：env 必须为 None（继承父进程环境）而非空 dict——
        # Popen 传空 dict 会完全清空子进程环境变量，导致 Winsock 等
        # 系统 DLL 初始化失败（WinError 10106）。
        env = dict(self.spec.get("env", {})) or None
        try:
            self._proc = subprocess.Popen(
                [command] + args, cwd=cwd, env=env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True,
                encoding="utf-8", errors="replace", bufsize=1,
            )
        except FileNotFoundError:
            self._last_error = f"MCP server '{self.name}' 启动失败：找不到命令 {command}"
            raise RuntimeError(self._last_error)
        # 握手：initialize
        self._send({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "lazaxa-mcp", "version": "0.1"},
            },
        })
        try:
            self._read_response(_INIT_TIMEOUT)
        except Exception:
            self._kill()
            raise
        # initialized 通知（无需响应）
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
        self._restarts = 0
        self._last_error = ""

    def _send(self, obj: dict) -> None:
        if self._proc is None or self._proc.poll() is not None:
            raise RuntimeError(f"MCP server '{self.name}' 进程未运行")
        self._proc.stdin.write(json.dumps(obj) + "\n")
        self._proc.stdin.flush()

    def _read_response(self, timeout: float) -> dict:
        """读一行 stdout 并解析 JSON；超时或进程退出抛异常。"""
        deadline = time.time() + timeout
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                raise TimeoutError(f"MCP server '{self.name}' 响应超时")
            if self._proc.poll() is not None:
                stderr = self._proc.stderr.read()[-2000:] if self._proc.stderr else ""
                raise RuntimeError(
                    f"MCP server '{self.name}' 异常退出（code={self._proc.returncode}）: {stderr[-500:]}")
            line = self._proc.stdout.readline()
            if line:
                try:
                    return json.loads(line)
                except json.JSONDecodeError:
                    continue  # 忽略非 JSON 输出（如启动日志）
            time.sleep(0.05)

    def _kill(self) -> None:
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.kill()
            except Exception:
                pass
        self._proc = None

    # ---------- 对外接口 ----------

    def _ensure_ready(self) -> None:
        """确保进程在运行（懒启动 + 崩溃自动重启）。"""
        if self._proc is None or self._proc.poll() is not None:
            if self._restarts >= _MAX_RESTARTS:
                raise RuntimeError(
                    f"MCP server '{self.name}' 连续失败 {self._restarts} 次，"
                    f"已停止重试。{self._last_error}")
            self._spawn()
            self._restarts += 1

    def call(self, method: str, params: dict, timeout: float = _READ_TIMEOUT) -> dict:
        """调用一个 MCP 方法（tools/list / tools/call 等），返回 result 字典。"""
        with self._lock:
            self._ensure_ready()
            req_id = int(time.time() * 1000) % 1000000 + 1
            self._send({"jsonrpc": "2.0", "id": req_id, "method": method, "params": params})
            resp = self._read_response(timeout)
            if "error" in resp and resp.get("error"):
                err = resp["error"]
                msg = err.get("message") or str(err)
                raise RuntimeError(f"MCP server '{self.name}' 错误: {msg}")
            return resp.get("result") or {}

    def list_tools(self) -> list[dict]:
        """列出 server 暴露的工具（name + description + inputSchema）。"""
        try:
            result = self.call("tools/list", {}, timeout=_INIT_TIMEOUT)
        except RuntimeError as e:
            raise RuntimeError(f"无法连接 MCP server '{self.name}'（{e}）——"
                               f"请确认依赖已安装且 server 可启动") from e
        return result.get("tools") or []

    def call_tool(self, name: str, arguments: dict) -> str:
        """调用一个具体工具，返回文本结果。"""
        result = self.call("tools/call", {"name": name, "arguments": arguments or {}})
        content = result.get("content") or []
        parts = []
        for item in content:
            if isinstance(item, dict):
                if item.get("type") == "text":
                    parts.append(str(item.get("text", "")))
                elif item.get("type") == "image":
                    parts.append(f"[图片: {item.get('mimeType', '')} data:{str(item.get('data', ''))[:40]}…]")
            else:
                parts.append(str(item))
        text = "\n".join(parts) if parts else json.dumps(result, ensure_ascii=False)
        if len(text) > _MAX_RESULT_CHARS:
            text = text[:_MAX_RESULT_CHARS] + f"\n…（结果过长已截断，全文 {len(text)} 字符）"
        return text or "（工具返回空结果）"

    def close(self) -> None:
        self._kill()


# 全局客户端缓存：{server_name: MCPServerClient}
_clients: dict[str, MCPServerClient] = {}
_clients_lock = threading.Lock()


def get_client(name: str, spec: dict) -> MCPServerClient:
    """按名字取（或创建）MCP 客户端实例。"""
    with _clients_lock:
        client = _clients.get(name)
        if client is None:
            client = MCPServerClient(name, spec)
            _clients[name] = client
        return client


def format_tools_brief(tools: list[dict], max_items: int = 60) -> str:
    """把工具列表格式化成给模型看的文本（名称 + 一句话描述）。

    全部工具塞进上下文会爆 token，只保留名称与描述首句，
    参数 schema 由工具内部按需查询（mcp_tool_schema）。
    """
    lines = []
    for t in tools[:max_items]:
        name = t.get("name", "")
        desc = (t.get("description") or "").strip().replace("\n", " ")
        lines.append(f"· {name} — {desc[:100]}")
    if len(tools) > max_items:
        lines.append(f"…（共 {len(tools)} 个，仅显示前 {max_items} 个）")
    return "\n".join(lines)
