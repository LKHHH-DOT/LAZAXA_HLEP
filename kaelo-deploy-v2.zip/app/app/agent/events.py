# -*- coding: utf-8 -*-
"""SSE 事件协议：agent 循环向前端推送的过程事件。

M5-2 起本模块是**协议契约的唯一事实源**：
- `EventType`：事件类型枚举（后端所有 emit/记账点改用枚举常量，字符串散落成为历史）；
- `EVENT_SCHEMA`：每类事件的 payload 必填字段契约（供测试校验 + 前端按契约实现）；
- `sse_payload`：统一出口，payload 自动带协议版本号 `v`——前端按 `v` 分支解析，
  旧前端忽略新字段（向后兼容），后端可安全演进字段。

事件类型语义：
- thinking        状态条"思考中（第 N 步）"
- token           最终回复流式文本
- tool_call       开始调用工具
- tool_result     工具执行结果（成功/失败 + 一行摘要）
- approval_request   需要用户审批（挂起，等前端应答）
- approval_resolved  审批结果（落 agent_events，非 SSE wire）
- compaction      上下文压缩/清理发生（reason: history/threshold/overflow/tool_clear）
- subagent_start/subagent_end/subagent_parallel_start/subagent_parallel_end  子代理委派过程
- done            任务结束（含统计）
- error           错误
- plan_created/plan_updated  结构化计划变更（落 agent_events）
- request/assistant/turn_start  M3 账本内部事件（模型可见即已记录）

done 事件携带 stop_reason（停因，取值见 app/agent/stop_reason.py）：
completed / error / max_steps / loop_capped / empty_response / cancelled / timeout。
"""

import json
from enum import StrEnum

# 协议版本：payload 字段语义变化时递增，前端按 v 分支解析。
EVENT_PROTOCOL_VERSION = 1


class EventType(StrEnum):
    """事件类型枚举（str 子类：与旧字符串字面量可直接比较/序列化）。"""
    THINKING = "thinking"
    TOKEN = "token"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    APPROVAL_REQUEST = "approval_request"
    APPROVAL_RESOLVED = "approval_resolved"
    COMPACTION = "compaction"
    SUBAGENT_START = "subagent_start"
    SUBAGENT_END = "subagent_end"
    SUBAGENT_PARALLEL_START = "subagent_parallel_start"
    SUBAGENT_PARALLEL_END = "subagent_parallel_end"
    DONE = "done"
    ERROR = "error"
    PLAN_CREATED = "plan_created"
    PLAN_UPDATED = "plan_updated"
    REQUEST = "request"
    ASSISTANT = "assistant"
    TURN_START = "turn_start"


# 每类事件的 payload **必填字段**契约（其余字段为可选扩展，前端须忽略未知字段）。
# 只声明前端/评估依赖的稳定字段，不追求覆盖全部可选字段。
EVENT_SCHEMA: dict[EventType, tuple[str, ...]] = {
    EventType.THINKING: ("step",),
    EventType.TOKEN: ("text",),
    EventType.TOOL_CALL: ("name",),
    EventType.TOOL_RESULT: ("name", "ok"),
    EventType.APPROVAL_REQUEST: ("task_id", "tool", "args", "risk"),
    EventType.APPROVAL_RESOLVED: ("task_id", "tool", "approved"),
    EventType.COMPACTION: ("reason",),
    EventType.SUBAGENT_START: ("task",),
    EventType.SUBAGENT_END: ("task",),
    EventType.SUBAGENT_PARALLEL_START: ("count",),
    EventType.SUBAGENT_PARALLEL_END: ("count",),
    EventType.DONE: ("reply",),
    EventType.ERROR: ("message",),
    EventType.PLAN_CREATED: ("goal", "steps"),
    EventType.PLAN_UPDATED: ("goal", "steps"),
    EventType.REQUEST: (),
    EventType.ASSISTANT: (),
    EventType.TURN_START: (),
}


def missing_fields(event_type, payload: dict | None) -> list[str]:
    """返回该事件缺失的必填字段名（未知事件类型返回 []，不做契约约束）。"""
    required = EVENT_SCHEMA.get(event_type)
    if not required:
        return []
    payload = payload or {}
    return [k for k in required if payload.get(k) is None]


def sse_payload(event_type, **kwargs) -> str:
    """把事件转成 SSE 文本（data: {...} 单行）。

    - event_type 接受 EventType 或字符串（内部归一为字符串值）；
    - kwargs 合并进 payload，type 固定，自动带协议版本号 v。
    """
    payload = {"type": str(event_type), "v": EVENT_PROTOCOL_VERSION}
    payload.update(kwargs)
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
