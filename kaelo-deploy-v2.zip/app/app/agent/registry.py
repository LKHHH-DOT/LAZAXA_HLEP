# -*- coding: utf-8 -*-
"""工具注册表：一切工具皆可插拔。

- @registry.register 装饰器注册工具
- ToolResult 统一工具返回（ok/error/text/brief）
- openai_schemas() 导出 function calling 定义
"""

import asyncio
import contextvars
import inspect
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from dataclasses import dataclass


# 屏幕被占用的统一提示（M5 随屏幕锁从 loop 迁入；喂回模型，让它稍后重试或先干不抢屏幕的事）
SCREEN_BUSY_NOTE = (
    "屏幕/键鼠正被其他任务占用（可能是后台任务在操作界面）。"
    "请稍后重试本操作，或先做不依赖界面的工作（如查文件/检索/整理），"
    "等界面空闲后再操作。")


class ToolResult:
    """工具执行的统一返回。

    - ok:    是否成功（工具层不抛异常，失败也返回 ok=False + error）
    - error: 失败原因（喂回给模型，让模型调整策略）
    - text:  完整结果（可能被截断）
    - brief: 一行摘要（给前端展示用）
    - model_text: M5 流水线 post 钩子修剪后"喂给模型"的文本；空表示用 text/error。
                  text 始终保留原文（审计/截图路径提取用），model_text 只影响模型所见。
    - gate_blocked / decision: M5 流水线 gate（审批）关卡拦截标记与权限决策，
                  loop 据此走"未执行"收尾（不入 tool_path、不计数 fail_streak）。
    - meta:  结构化附加信息（P2-2 审计用，如 {"retries": 2}）；不参与模型可见文本，
              由 post 审计钩子取用后落 agent_tasks 专列。
    """

    def __init__(self, text: str = "", error: str = "", brief: str = "",
                 model_text: str = "", gate_blocked: bool = False,
                 decision: str = "", meta: dict | None = None):
        self.ok = not error
        self.text = text
        self.error = error
        self.brief = brief or (text[:80] + ("…" if len(text) > 80 else ""))
        self.model_text = model_text
        self.gate_blocked = gate_blocked
        self.decision = decision
        self.meta = meta or {}

    @classmethod
    def ok_result(cls, text: str, brief: str = "") -> "ToolResult":
        return cls(text=text, brief=brief)

    @classmethod
    def err_result(cls, error: str) -> "ToolResult":
        return cls(error=error)


@dataclass
class HookResult:
    """流水线关卡（pre/gate）钩子的裁决。

    - allow=True  放行；allow=False 短路拦截，model_text 回灌模型、brief 给前端。
    - decision: 权限决策（gate 用：deny/ask 后被拒记 rejected），写入 ctx 供 post 审计。
    """
    allow: bool = True
    model_text: str = ""
    brief: str = ""
    decision: str = ""

    @classmethod
    def pass_(cls) -> "HookResult":
        return cls(allow=True)

    @classmethod
    def block(cls, model_text: str, brief: str, decision: str = "") -> "HookResult":
        return cls(allow=False, model_text=model_text, brief=brief, decision=decision)


@dataclass
class ExecContext:
    """一次工具执行的任务级上下文（M5 流水线钩子消费；loop 根任务构造）。

    钩子不再从闭包偷 loop 局部变量，全部经此显式传入——加新关卡不改 loop 大脑。
    """
    mode: str = "standard"            # 权限模式 locked/standard/relaxed
    round_id: str = ""                # 对话轮次（审计/事件聚合键）
    parent_task_id: str = ""          # 父任务 id（子代理谱系）
    user_message: str = ""            # 原始用户指令（审计）
    task_id: str = ""                 # 本次工具调用的审计 id
    compact_name: str = ""            # 任务压缩名（post trim 归档用）
    screen_sem: object = None         # 屏幕互斥锁（screen_lock 工具用，可空）
    screen_wait: float = 0.0          # 等屏幕锁的超时秒
    emit: object = None               # async 事件回调（gate 发 approval_request）
    token_usage: dict | None = None   # 本模型轮 token 用量（挂第一条审计行）
    # —— gate 钩子回写，post 审计钩子读取 ——
    decision: str = ""
    approved: bool | None = None
    edited_args: dict | None = None   # M5-2：用户"编辑参数后批准"的参数（非 None 时替代原 args 执行）


class Tool:
    """一个工具的定义。

    name:        模型调用名（如 "run_command"）
    display_name: 前端展示名（中文，如 "运行命令"；缺省用 name）
    description: 给模型看的说明（决定模型会不会用、怎么用）
    parameters:  JSON Schema（OpenAI function calling 格式）
    risk:        safe | sensitive | dangerous（审批分级，见 approval.py）
    timeout:     执行超时（秒）
    fn:          实际执行函数 fn(**args) -> ToolResult
    screen_lock: 是否独占"屏幕/键鼠"资源（期3 多任务并行）：True 的工具在
                 多任务并发时需先申请全局屏幕互斥锁（见 loop._screen_sem），
                 防止多个任务同时操作同一界面互相干扰。
    """

    def __init__(self, name, description, parameters, risk, timeout, fn,
                 display_name: str | None = None, screen_lock: bool = False):
        self.name = name
        self.display_name = display_name or name
        self.description = description
        self.parameters = parameters
        self.risk = risk
        self.timeout = timeout
        self.fn = fn
        self.screen_lock = screen_lock

    def to_openai_schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolRegistry:
    """工具注册表：按名注册、按名执行（带超时控制）。"""

    def __init__(self):
        self._tools: dict[str, Tool] = {}
        self._pool = ThreadPoolExecutor(max_workers=8)
        # M5 工具流水线钩子链（dsh pre/execute/post 事件瀑布的 Kaelo 落法）：
        # _pre_hooks  同步关卡：补充校验/幂等/工作区检查，返回 HookResult.block 即短路
        # _gate_hooks async 关卡：审批挂起（需要 await 用户应答），任一 block 即拦截
        # _post_hooks 同步后处理：(name,args,risk,ctx,result)->result，修剪/审计
        self._pre_hooks: list = []
        self._gate_hooks: list = []
        self._post_hooks: list = []

    def add_pre_hook(self, fn) -> None:
        self._pre_hooks.append(fn)

    def add_gate_hook(self, fn) -> None:
        self._gate_hooks.append(fn)

    def add_post_hook(self, fn) -> None:
        self._post_hooks.append(fn)

    def register(self, tool: Tool) -> Tool:
        if tool.name in self._tools:
            raise ValueError(f"工具 {tool.name} 重复注册")
        self._tools[tool.name] = tool
        return tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return sorted(self._tools.keys())

    def openai_schemas(self) -> list[dict]:
        """导出全部工具的 OpenAI function calling 定义（供 chat.completions tools 参数）。"""
        return [t.to_openai_schema() for t in self._tools.values()]

    @staticmethod
    def _type_mismatch(ptype: str, value) -> bool:
        """宽松类型判定：拦截明显错误，放行可被工具内安全强转的标量。

        策略（A批4 工具参数强校验）：
          - string:  只接受 str/int/float（纯数字会被工具 str 化），拒绝 bool/容器
          - integer / number: 接受 int/float（含整值浮点），拒绝 str/bool/容器
          - boolean: 只接受 bool
          - array / object: 只接受 list / dict
        返回 True=类型不符。
        """
        if ptype == "string":
            return not isinstance(value, (str, int, float))
        if ptype in ("integer", "number"):
            return not isinstance(value, (int, float)) or isinstance(value, bool)
        if ptype == "boolean":
            return not isinstance(value, bool)
        if ptype == "array":
            return not isinstance(value, list)
        if ptype == "object":
            return not isinstance(value, dict)
        return False

    def _validate_args(self, name: str, parameters: dict | None,
                       args: dict | None) -> str:
        """执行前按 JSON Schema 轻量校验。返回 ''=通过；否则返回错误描述。

        - 必填项缺失（schema.required）→ 明确报缺哪个参数
        - 声明了 type 的参数类型明显不符 → 报期望/实收类型
        - 数组元素做首元素抽查（防整数组遍历拖慢校验）
        - 未声明的多余键放行（与历史行为一致：由工具 fn 自行兜底/报 TypeError）
        """
        parameters = parameters or {}
        props = (parameters.get("properties") or {})
        if args is None:
            args = {}
        if not isinstance(args, dict):
            return f"参数必须是 JSON 对象，实际收到 {type(args).__name__}"
        for key in parameters.get("required") or []:
            if args.get(key) is None:
                return f"缺少必填参数 {key}"
        for key, val in args.items():
            if val is None:
                continue
            spec = props.get(key)
            if not spec:
                continue
            ptype = spec.get("type")
            if ptype and self._type_mismatch(ptype, val):
                return (f"参数 {key} 应为 {ptype} 类型，"
                        f"实际收到 {type(val).__name__}")
            if ptype == "array" and val:
                item_type = (spec.get("items") or {}).get("type")
                # 数组元素全量抽查（工具数组通常 ≤20，逐项校验成本可忽略）
                if item_type:
                    for item in val:
                        if self._type_mismatch(item_type, item):
                            return (f"参数 {key} 的数组元素应为 {item_type} 类型，"
                                    f"实际收到 {type(item).__name__}")
        return ""

    def _precheck(self, name: str, tool: "Tool", args: dict) -> str:
        """执行前检查（parse 哨兵 + JSON Schema 轻校验）。返回 ''=通过，否则=错误文案。"""
        # S1-3：工具参数来自模型输出，JSON 解析失败时会带 __parse_error__ 哨兵。
        # 不执行 fn（拿残缺参数硬跑只会放大漂移），直接把解析错误回灌给模型自纠。
        if isinstance(args, dict) and args.get("__parse_error__"):
            return (f"工具 {name} 的参数解析失败，未执行。请检查刚才调用的参数格式后重新发起。"
                    f"详情：{str(args['__parse_error__'])[:200]}")
        verr = self._validate_args(name, tool.parameters, args)
        if verr:
            return f"工具 {name} 参数校验失败：{verr}。请修正参数后重试。"
        return ""

    def _exec_fn(self, name: str, args: dict, timeout: float | None = None) -> ToolResult:
        """同步执行核心：线程池 + copy_context + 超时/异常封装（execute 与 arun 共用）。"""
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult.err_result(f"未知工具: {name}")
        t0 = time.time()
        try:
            # M4b：工具运行在 ThreadPoolExecutor 线程，经 asyncio.to_thread 已丢一层
            # context。用 copy_context 把调用方（loop 设置的任务上下文）快照传进线程，
            # 使 plan_* 等工具能读到 current_round_id；未设 contextvar 时为空跑，
            # 对现有不读上下文的工具零影响。
            fut = self._pool.submit(
                contextvars.copy_context().run, tool.fn, **(args or {}))
            result = fut.result(timeout=timeout or tool.timeout)
        except FutureTimeout:
            return ToolResult.err_result(f"工具 {name} 执行超时（>{timeout or tool.timeout}s）")
        except TypeError as e:
            return ToolResult.err_result(f"工具 {name} 参数错误: {e}")
        except Exception as e:
            return ToolResult.err_result(f"工具 {name} 执行异常: {type(e).__name__}: {e}")
        if not isinstance(result, ToolResult):
            result = ToolResult.ok_result(str(result))
        result.brief = result.brief or f"{name}（{time.time() - t0:.1f}s）"
        return result

    def execute(self, name: str, args: dict, timeout: float | None = None) -> ToolResult:
        """同步执行入口（保留给测试/旧调用）：precheck + 执行，**不过 async gate**。

        agent 主循环统一走 async arun（含审批 gate）；此入口不挂起、不审批，
        行为与 M5 改造前等价（参数强校验 + 超时 + 异常捕获，绝不裸抛）。
        """
        tool = self.get(name)
        if tool is None:
            return ToolResult.err_result(f"未知工具: {name}")
        err = self._precheck(name, tool, args)
        if err:
            return ToolResult.err_result(err)
        return self._exec_fn(name, args, timeout)

    async def run_gates(self, name: str, args: dict, risk: str,
                        ctx: "ExecContext") -> HookResult:
        """只跑 pre + gate 关卡（子代理执行由 loop 接管时用：先统一过审再执行）。

        pre 为同步短路；gate 为 async（审批挂起）。任一拦截即返回 block，
        并把 decision/approved 回写 ctx 供审计。全部通过返回 HookResult.pass_。
        """
        for h in self._pre_hooks:
            hr = h(name, args, risk, ctx)
            if hr is not None and not hr.allow:
                ctx.decision = hr.decision or ctx.decision
                ctx.approved = False
                return hr
        for h in self._gate_hooks:
            hr = await h(name, args, risk, ctx)
            if hr is not None and not hr.allow:
                ctx.decision = hr.decision or ctx.decision
                ctx.approved = False
                return hr
            if hr is not None and hr.decision:
                ctx.decision = hr.decision
                if ctx.approved is None:
                    ctx.approved = True
        return HookResult.pass_()

    def run_posts(self, name: str, args: dict, risk: str,
                  ctx: "ExecContext", result: ToolResult) -> ToolResult:
        """跑 post 后处理链（修剪/审计），逐个可改 result。任何钩子异常不阻断。"""
        for h in self._post_hooks:
            try:
                out = h(name, args, risk, ctx, result)
                if isinstance(out, ToolResult):
                    result = out
            except Exception:
                continue
        return result

    async def arun(self, name: str, args: dict, ctx: "ExecContext") -> ToolResult:
        """M5 统一异步流水线入口：pre → gate（审批）→ 执行（屏幕锁/同步异步）→ post。

        - gate 拦截：返回 ok=False、gate_blocked=True、decision 已写、post 仍跑（审计留痕）；
        - 同步 fn 走线程池（copy_context）；async fn（coroutine function）直接 await；
        - screen_lock 工具在此申请 ctx.screen_sem（从 loop 迁入，多任务不抢屏）。
        """
        tool = self.get(name)
        if tool is None:
            return ToolResult.err_result(f"未知工具: {name}")
        risk = tool.risk
        # 1) pre + gate 关卡
        gate = await self.run_gates(name, args, risk, ctx)
        if not gate.allow:
            blocked = ToolResult.err_result(gate.model_text)
            blocked.brief = gate.brief
            blocked.gate_blocked = True
            blocked.decision = ctx.decision or gate.decision
            return self.run_posts(name, args, risk, ctx, blocked)
        # 2) 执行（屏幕互斥锁 + sync/async fn）。同步路径复用 execute（precheck+线程池），
        #    保持 execute 为可被测试 monkeypatch 的唯一同步执行点；async fn 直接 await。
        #    M5-2：gate 若带回"编辑后参数"（用户编辑批准），以编辑后的为准执行/审计。
        exec_args = ctx.edited_args if ctx.edited_args is not None else args
        is_async = inspect.iscoroutinefunction(getattr(tool, "fn", None))
        screen = ctx.screen_sem
        need_screen = bool(getattr(tool, "screen_lock", False) and screen is not None)
        if need_screen:
            got = await screen.try_acquire(ctx.screen_wait or 30.0)
            if not got:
                busy = ToolResult.err_result(SCREEN_BUSY_NOTE)
                return self.run_posts(name, exec_args, risk, ctx, busy)
            try:
                result = await (self._arun_fn(tool, name, exec_args) if is_async
                                else asyncio.to_thread(self.execute, name, exec_args))
            finally:
                screen.release()
        else:
            result = await (self._arun_fn(tool, name, exec_args) if is_async
                            else asyncio.to_thread(self.execute, name, exec_args))
        # 3) post 后处理（修剪/审计）
        return self.run_posts(name, exec_args, risk, ctx, result)

    async def _arun_fn(self, tool: "Tool", name: str, args: dict) -> ToolResult:
        """执行 async 工具 fn（预留：子代理等需要事件循环的工具可声明 async fn）。"""
        t0 = time.time()
        try:
            result = await tool.fn(**(args or {}))
        except TypeError as e:
            result = ToolResult.err_result(f"工具 {name} 参数错误: {e}")
        except Exception as e:
            result = ToolResult.err_result(f"工具 {name} 执行异常: {type(e).__name__}: {e}")
        if not isinstance(result, ToolResult):
            result = ToolResult.ok_result(str(result))
        result.brief = result.brief or f"{name}（{time.time() - t0:.1f}s）"
        return result


# 全局单例（与 main.py 的 _stores 风格一致）
registry = ToolRegistry()
