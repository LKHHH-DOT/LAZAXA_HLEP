# -*- coding: utf-8 -*-
"""超长上下文与压缩工程（2026-08-17 · 四层方案落地）。

背景
----
此前 Lazaxa 无任何上下文压缩机制：多轮历史硬截断最后 20 条
（AGENT_HISTORY_LIMIT），任务内 messages 无限累积——长任务早期关键信息
（目标/约束/已完成步骤）会丢失，且逼近 DeepSeek 上下文窗口。

本模块对齐 docs/Lazaxa超长上下文与压缩工程方案.md：
  - estimate_chars    消息字符数估算（不引入 tokenizer，够用即可）
  - trim_tool_result  层一：超长工具结果修剪（保头尾 + 占位符 + 原文归档）
  - compact_history   层二+三：超阈值时把更早的对话用 LLM 压成结构化
                      "任务交接单"，保留最近 N 轮；压缩前原文归档 JSONL；
                      LLM 失败退化为基础截断
  - _split_keep_recent 按"轮"切分旧段与保留段

触发策略（层四）由 loop.py 接入：
  - 预防性：跨任务 history / 任务内 messages 超阈值自动压缩
  - 故障兜底：DeepSeek 返回 400（上下文超限）→ 紧急压缩重试一次
总开关 config.CONTEXT_COMPACT_ENABLED，关闭即回退旧行为。
"""
import json
import logging
import os
import time

from . import llm

logger = logging.getLogger(__name__)


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def estimate_chars(messages: list[dict]) -> int:
    """粗略估算 messages 的总字符数（不依赖 tokenizer，够用即可）。"""
    total = 0
    for m in messages:
        total += len(str(m.get("content") or ""))
        for tc in m.get("tool_calls") or []:
            fn = tc.get("function", {})
            total += len(str(fn.get("name") or ""))
            total += len(str(fn.get("arguments") or ""))
    return total


# ---------- 层一：工具结果修剪 ----------

def _archive_text(text: str, archive_dir: str | None, name: str) -> str:
    """单个文本追加归档（JSONL，含 kind/ts 便于复盘）。"""
    if not archive_dir:
        return "(未归档)"
    os.makedirs(archive_dir, exist_ok=True)
    path = os.path.join(archive_dir, f"{name}.jsonl")
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(
            {"ts": _ts(), "kind": "trim", "text": text},
            ensure_ascii=False) + "\n")
    return path


def trim_tool_result(text: str, limit: int = 2000,
                     archive_dir: str | None = None,
                     name: str = "tool_result") -> str:
    """层一：超长工具结果修剪。超过 limit 保留头尾 + 占位符，完整原文归档。

    未超限则原样返回。返回文本附带归档路径，模型需要细节时可去读归档。
    """
    if len(text) <= limit:
        return text
    path = _archive_text(text, archive_dir, name)
    note = f"\n…[已截断，共 {len(text)} 字符，完整输出已存 {path}]…\n"
    tail_n = min(int(limit * 0.3), len(text))
    head_n = max(limit - len(note) - tail_n, 100)
    return text[:head_n] + note + text[-tail_n:]


# ---------- 层一点五：旧工具结果批量清理（Observation Masking，M4a） ----------

# 清理占位符：行动记录（assistant.tool_calls）保留，只隐藏更早的观察结果，
# 模型知道"查过什么、传了什么参数"，需要细节时重新调用工具即可。
_TOOL_CLEARED_PLACEHOLDER = (
    "…[旧工具结果已清理以节省上下文；本次调用记录（工具名与参数）保留在上文，"
    "如需该信息请重新调用对应工具获取]…"
)


def clear_old_tool_results(messages: list[dict], *, keep_n: int = 10,
                           exclude_tools: tuple = ()) -> tuple:
    """层一点五：把更早的 role=tool 结果替换为占位符（JetBrains Observation Masking）。

    与 LLM 交接单压缩的区别：本函数**不调用模型、不丢行动记录、无损结构**——
    assistant 消息的 tool_calls（工具名+参数）原样保留，只把更早的工具"观察结果"
    换成占位符，成本远低于 LLM 摘要，且不会引入摘要误差。应在 compact_history
    之前、消息总量达到更低阈值时先执行。

    - keep_n: 从尾部保留最近 N 条工具结果原文（当前工作上下文不清理）
    - exclude_tools: 保护清单，这些工具的结果永不清理（如记忆检索/计划查看）
    返回 (new_messages, cleared_count)；无 tool 消息/不足 keep_n 时原样返回、计数 0。
    浅拷贝，不改原列表。
    """
    exclude = set(exclude_tools or ())
    # 1) 建立 tool_call_id -> 工具名 映射（来自各 assistant 消息的 tool_calls）
    id_to_name: dict[str, str] = {}
    for m in messages:
        if m.get("role") == "assistant":
            for tc in (m.get("tool_calls") or []):
                fn = tc.get("function", {})
                cid = tc.get("id")
                if cid and fn.get("name"):
                    id_to_name[cid] = fn["name"]
    # 2) 收集全部 tool 结果下标，尾部 keep_n 条保留原文
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    if len(tool_idx) <= keep_n:
        return messages, 0
    # 注意 lst[:-0] == lst[:0] == []，keep_n=0（全清）必须单独分支
    clear_idx = set(tool_idx) if keep_n <= 0 else set(tool_idx[:-keep_n])
    out, cleared = [], 0
    for i, m in enumerate(messages):
        if i in clear_idx:
            name = id_to_name.get(m.get("tool_call_id"), "")
            if name in exclude:
                out.append(m)  # 保护清单：保留原文
                continue
            m = dict(m)
            m["content"] = _TOOL_CLEARED_PLACEHOLDER
            cleared += 1
        out.append(m)
    return out, cleared


# ---------- 层二+三：LLM 交接单压缩 ----------

def _split_keep_recent(messages: list[dict], keep_recent: int):
    """按"轮"切分：从尾部保留最近 keep_recent 个 user 消息及其内容，其余为旧段。

    返回 (旧段, 保留段)。不足 keep_recent 轮时旧段为空。
    """
    user_idx = [i for i, m in enumerate(messages) if m.get("role") == "user"]
    if not user_idx or len(user_idx) <= keep_recent:
        return [], messages
    split_at = user_idx[-keep_recent]
    return messages[:split_at], messages[split_at:]


def _archive_messages(messages: list[dict], archive_dir: str, name: str) -> str:
    """把将被压缩的 messages 原文追加到 JSONL（防信息丢失，可检索复盘）。"""
    os.makedirs(archive_dir, exist_ok=True)
    path = os.path.join(archive_dir, f"{name}.jsonl")
    with open(path, "a", encoding="utf-8") as f:
        for m in messages:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
    return path


def _sample(messages: list[dict], max_input: int) -> list[dict]:
    """超长输入的首尾采样：保留头部（目标/指令）与尾部（最近进展），中段省略。"""
    head, tail, used = [], [], 0
    for m in messages:
        size = len(str(m.get("content") or ""))
        if used + size <= int(max_input * 0.6):
            head.append(m)
            used += size
        else:
            break
    used2 = 0
    for m in reversed(messages[len(head):]):
        size = len(str(m.get("content") or ""))
        if used2 + size <= int(max_input * 0.4):
            tail.insert(0, m)
            used2 += size
        else:
            break
    return head + [{"role": "user",
                    "content": "…[中段已省略，完整对话见归档]…"}] + tail


def _llm_summarize(old: list[dict], max_input: int) -> str:
    """调用 DeepSeek 把旧对话压成结构化交接单（低温度，只取正文）。"""
    if estimate_chars(old) > max_input:
        old = _sample(old, max_input)
    prompt = [
        {"role": "system", "content": (
            "你是上下文压缩器。下面给出一段 AI 助手与用户的过往对话（含工具调用与结果），"
            "请将其压缩为一份结构化\"任务交接单\"，保留继续执行任务仍关键的信息。格式：\n"
            "【任务交接单】\n目标(Goal): ...\n已完成(Accomplished):\n- ...\n"
            "进行中(In Progress): ...\n约束(Constraints): ...\n"
            "相关文件(Relevant Files): ...\n下一步(Next Steps): ...\n"
            "要求：只保留与任务相关的信息，忽略寒暄与噪声；每项 1-3 条要点；"
            "只输出交接单本身，不要任何解释，不要 Markdown 代码块。")},
        {"role": "user", "content": json.dumps(old, ensure_ascii=False)},
    ]
    resp = llm.chat(prompt, tools=None, temperature=0.2, timeout=120)
    summary = (resp.content or "").strip()
    if not summary:
        raise RuntimeError("压缩模型返回空摘要")
    return summary


def _fallback_head(old: list[dict]) -> str:
    """LLM 压缩失败时的基础兜底：保留最早的用户指令作为头部摘要。"""
    head = next((str(m.get("content") or "")[:300] for m in old
                 if m.get("role") == "user"
                 and str(m.get("content") or "").strip()), "")
    if head:
        return f"（中间对话已截断归档；以下为最早的指令开头）\n原始指令：{head}…"
    return "（中间对话已截断归档）"


def compact_history(messages: list[dict], *, keep_recent: int = 3,
                    threshold: int = 30000,
                    archive_dir: str | None = None,
                    name: str = "compact",
                    max_input: int = 60000) -> list[dict]:
    """层二+三：超阈值时把 messages 更早部分压成 LLM 交接单，保留最近轮次。

    - 未超阈值 / 无可压缩内容 → 原样返回（调用者据此判断是否真的压缩了）
    - 超阈值 → 归档旧段 → LLM 交接单（失败退化为基础截断）→
      重组为 [原 system] + [交接单 system(S1-7)] + [最近 keep_recent 轮]
    """
    if not messages or estimate_chars(messages) <= threshold:
        return messages
    system_msgs = [m for m in messages if m.get("role") == "system"]
    body = [m for m in messages if m.get("role") != "system"]
    if not body:
        return messages
    old, tail = _split_keep_recent(body, keep_recent)
    if not old:
        return messages
    if archive_dir:
        _archive_messages(old, archive_dir, name)
    try:
        summary = _llm_summarize(old, max_input)
        handoff = summary
    except Exception as e:
        logger.warning("LLM 摘要压缩失败，退化为基础截断: %s", e)
        handoff = _fallback_head(old)
    # S1-7：交接单以 system 角色注入（而非 user）——交接单本质是"系统对当前
    # 任务状态的维护摘要"，不是用户讲话，避免：(a) 语义上污染用户指令区；
    # (b) 若被安排在 assistant(tool_call) 与其 tool response 之间破坏配对校验。
    # 分隔标记让模型把"交接单"与真实 system 提示（角色定义/守则）区分开。
    handoff_msg = {"role": "system", "content": (
        "【上下文交接单】（更早的对话已压缩归档，以下为摘要，供继续当前任务参考；"
        "如需细节可读归档文件）\n"
        "----- 交接单开始 -----\n"
        + handoff +
        "\n----- 交接单结束 -----")}
    return system_msgs + [handoff_msg] + tail
