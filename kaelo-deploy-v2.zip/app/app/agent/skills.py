# -*- coding: utf-8 -*-
"""技能体系（批次 E1 · 借鉴 harness skills seam，Python 重写）。

技能 = 一段可复用的操作指南（Markdown），教会 Lazaxa 怎么做一类任务。
存放位置：config.SKILLS_DIR（默认 Kaelo/skills/），每个技能一个 <name>.md：

    ---
    description: 一句话说明（注入模型目录时展示）
    when_to_use: 何时该用（可选，附加路由提示）
    version: 1.0.0（可选，B批2 技能版本化：内容更新时递增，便于追踪）
    reference: <所属主技能名>（可选，B批2：附属规范文档，不单独暴露为技能）
    ---
    正文：具体步骤、可调用的工具名、注意事项（use_skill 按需加载）

对齐 harness skills 的核心设计（见 docs/subsystems/skills.zh.md）：
  - 目录只给模型 name + description（省 token），正文按需加载、不缓存
  - 技能名 kebab-case（^[a-z0-9]+(?:-[a-z0-9]+)*$）
  - 面向模型工具 use_skill(name)：校验名字 → 按需读正文返回

B批2（工程纪律 · 技能 frontmatter 校验/版本化）：
  - list_skills 不再把 reference 附属文档当独立技能暴露进模型目录；
  - validate_skills() 提供显式健康校验（error/warning/info 分级报告），
    供 config doctor / 人工体检使用，问题一目了然。
"""
import os
import re

from .registry import Tool, ToolResult
from .. import config

_SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_SKILL_VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")   # 技能版本（B批2，x.y.z）


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """解析轻量 YAML frontmatter（--- 包裹的 key: value 行）→ (meta, 正文)。"""
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    meta: dict = {}
    for line in parts[1].strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, _, val = line.partition(":")
        meta[key.strip()] = val.strip().strip('"').strip("'")
    return meta, parts[2].strip()


def _scan_files(skills_dir: str):
    """遍历技能目录下合法 kebab-case 的 .md，产出 (name, path)。"""
    if not os.path.isdir(skills_dir):
        return
    for fn in sorted(os.listdir(skills_dir)):
        if not fn.endswith(".md"):
            continue
        name = fn[:-3]
        if _SKILL_NAME_RE.match(name):
            yield name, os.path.join(skills_dir, fn)


def _read_meta(path: str) -> dict:
    """读取 frontmatter 元数据；读取/解析异常返回 {}（由调用方决定跳过）。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            meta, _ = _parse_frontmatter(f.read())
    except Exception:
        return {}
    return meta


# S1-10：技能目录扫描缓存。list_skills 在每次 agent 任务开始时被系统提示
# 构建调用，逐文件读 frontmatter 属重复 I/O；技能文件总数少但读盘可省则省。
# 失效策略：按目录签名（目录路径 + 每个 .md 的文件名/mtime_ns/大小）比较，
# 任何文件增删改 → 签名变化 → 自动重扫重建。进程内单槽即可（目录固定）。
_cache_sig: tuple | None = None
_cache_skills: list[dict] | None = None


def _dir_signature(skills_dir: str) -> tuple | None:
    """计算技能目录当前签名；目录不存在返回 None。"""
    if not os.path.isdir(skills_dir):
        return None
    entries = []
    for name, path in _scan_files(skills_dir):
        try:
            st = os.stat(path)
            entries.append((name, st.st_mtime_ns, st.st_size))
        except OSError:
            continue
    return (skills_dir, tuple(entries))


def list_skills() -> list[dict]:
    """扫描技能目录，返回技能元数据列表 [{name, description, when_to_use, version}]。

    reference 附属文档（frontmatter 带 reference 字段，如某技能包的规范文件）
    不单独暴露为技能，跳过；解析失败、无 description、技能名不合法的文件
    同样跳过（不报错，防单文件损坏拖垮全部）。
    （S1-10：命中目录签名则返回缓存结果，文件增删改自动失效重扫；
    对外始终返回浅拷贝，防调用方（如 routers/skills 追加 size/mtime）污染缓存。）
    """
    global _cache_sig, _cache_skills
    sig = _dir_signature(config.SKILLS_DIR)
    if sig is None:
        return []
    if sig == _cache_sig and _cache_skills is not None:
        return [dict(s) for s in _cache_skills]
    skills: list[dict] = []
    for name, path in _scan_files(config.SKILLS_DIR):
        meta = _read_meta(path)
        if meta.get("reference") or not meta.get("description"):
            continue
        skills.append({
            "name": name,
            "description": meta["description"],
            "when_to_use": meta.get("when_to_use", ""),
            "version": meta.get("version", ""),
        })
    _cache_sig, _cache_skills = sig, skills
    return [dict(s) for s in skills]


def get_skill(name: str) -> str | None:
    """按技能名读取完整正文（frontmatter 的 when_to_use/version 并入开头）。未找到返回 None。"""
    if not _SKILL_NAME_RE.match(name):
        return None
    path = os.path.join(config.SKILLS_DIR, f"{name}.md")
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return None
    meta, body = _parse_frontmatter(text)
    head = f"# 技能：{name}"
    if meta.get("version"):
        head += f"\n\n> 版本：{meta['version']}（内容有更新时请同步递增）"
    if meta.get("when_to_use"):
        head += f"\n\n## 何时使用\n{meta['when_to_use']}"
    return f"{head}\n\n## 操作指南\n{body}"


def skill_catalog_block() -> str:
    """构建注入系统提示的技能目录段（只含 name + description，省 token）。

    技能为空时返回空串（不注入目录块）。
    """
    skills = list_skills()
    if not skills:
        return ""
    lines = ["可用技能（先调用 use_skill 加载正文再执行，不要凭名字猜测做法）："]
    for s in skills:
        lines.append(f"- {s['name']}: {s['description']}")
    return "\n".join(lines)


def validate_skills(skills_dir: str | None = None) -> dict:
    """显式校验技能目录健康（B批2 · 技能 frontmatter 校验/版本化）。

    与 list_skills 的"坏文件静默跳过"互补：本函数把每个文件的问题分级摊开，
    供 config doctor / 维护体检使用。返回：
      {"ok": 无 error 级问题, "total": .md 总数,
       "issues": [{"name", "level", "msg"}, ...]}
      - error:   技能名非法 / frontmatter 缺失或损坏 / 缺 description / 正文为空
      - warning: description 超长或含 Markdown 结构（目录注入污染） / 缺 version /
                 version 格式非法 / frontmatter name 与文件名不一致
      - info:    reference 附属文档（不入模型目录，属某主技能）
    """
    d = skills_dir or config.SKILLS_DIR
    if not os.path.isdir(d):
        return {"ok": False, "total": 0,
                "issues": [{"name": "<目录>", "level": "error",
                            "msg": f"技能目录不存在: {d}"}]}
    issues: list[dict] = []
    total = 0
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".md"):
            continue
        total += 1
        name = fn[:-3]
        path = os.path.join(d, fn)
        if not _SKILL_NAME_RE.match(name):
            issues.append({"name": fn, "level": "error",
                           "msg": f"技能名不合法（应为 kebab-case）: {name}"})
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
        except OSError as e:
            issues.append({"name": name, "level": "error", "msg": f"读取失败: {e}"})
            continue
        if not text.startswith("---"):
            issues.append({"name": name, "level": "error",
                           "msg": "缺少 YAML frontmatter（文件需以 --- 开头）"})
            continue
        meta, body = _parse_frontmatter(text)
        if meta.get("reference"):
            issues.append({"name": name, "level": "info",
                           "msg": "reference 附属文档（不入模型目录，属: %s）"
                                  % meta["reference"]})
            continue
        if not meta.get("description"):
            issues.append({"name": name, "level": "error", "msg": "缺少 description"})
        desc = meta.get("description", "")
        if len(desc) > 200:
            issues.append({"name": name, "level": "warning",
                           "msg": f"description 过长（{len(desc)} 字），目录注入费 token，"
                                  "建议 ≤200 字单行一句话"})
        elif re.search(r"\n|#|\|", desc):
            issues.append({"name": name, "level": "warning",
                           "msg": "description 含 Markdown 结构/多行，目录注入会污染系统提示，"
                                  "建议单行一句话"})
        fm_name = meta.get("name")
        if fm_name and str(fm_name).strip() != name:
            issues.append({"name": name, "level": "warning",
                           "msg": f"frontmatter name({fm_name}) 与文件名({name}) 不一致，"
                                  "建议重命名文件保持一致或去掉该字段"})
        if not body.strip():
            issues.append({"name": name, "level": "error", "msg": "正文为空"})
            continue
        version = meta.get("version", "")
        if not version:
            issues.append({"name": name, "level": "warning",
                           "msg": "缺 version（建议补 version: 1.0.0，内容更新时递增，"
                                  "便于追踪技能版本）"})
        elif not _SKILL_VERSION_RE.match(version):
            issues.append({"name": name, "level": "warning",
                           "msg": f"version 格式非法: {version}（应为 x.y.z，如 1.0.0）"})
    return {"ok": all(i["level"] != "error" for i in issues),
            "total": total, "issues": issues}


def _use_skill(name: str) -> ToolResult:
    """按需加载技能正文（只读，safe）。找不到时列出可用技能名引导模型。"""
    if not name or not _SKILL_NAME_RE.match(name):
        names = ", ".join(s["name"] for s in list_skills()) or "（暂无技能）"
        return ToolResult.err_result(
            f"技能名不合法（应为 kebab-case，如 file-organizer）。可用技能：{names}")
    content = get_skill(name)
    if content is None:
        names = ", ".join(s["name"] for s in list_skills()) or "（暂无技能）"
        return ToolResult.err_result(f"技能不存在: {name}。可用技能：{names}")
    return ToolResult.ok_result(content, brief=f"已加载技能: {name}")


def register_all(r):
    """注册技能工具（E1）。"""
    r.register(Tool(
        name="use_skill",
        display_name="🧠 加载技能",
        description=(
            "按需加载一个技能的操作指南正文（Markdown）。系统提示已列出可用技能目录"
            "（name + description）；确定要执行某项技能时，先调用本工具读正文，再按正文步骤操作。"
            "找不到的技能会返回可用技能清单。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "技能名（kebab-case，如 file-organizer）"},
            },
            "required": ["name"],
        },
        risk="safe", timeout=30, fn=_use_skill,
    ))
