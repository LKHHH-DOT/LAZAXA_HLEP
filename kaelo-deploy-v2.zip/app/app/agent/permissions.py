# -*- coding: utf-8 -*-
"""三级权限体系（借鉴 Claude Code 权限模式 + Android 运行时权限 + 企业审批审计）。

三类权限动作（评估序 deny > ask > allow，deny 优先于任何 allow）：
  - allow：自动执行，不弹窗
  - ask ：挂起等用户审批（前端弹窗应答）
  - deny ：直接拒绝并回填模型，不执行不弹窗

三个权限模式（前端三态切换，API 每请求携带 mode）：
  - locked   🚫 锁定：只放行只读核心白名单，其余一律 deny（≈ Claude Code dontAsk）
  - standard 🔒 标准：safe allow；sensitive/dangerous ask（默认，即现状行为）
  - relaxed  📝 省心：safe/sensitive allow；dangerous ask（≈ Claude Code acceptEdits）
    —— 切到省心需 PIN 会话解锁（前端控制，后端只审计不校验）

run_command 内容分级（不随模式放宽，任何模式生效）：
  - run_command 不按一刀切 dangerous 处理，而是看命令内容：
      · 命中硬性断路器（rm -rf / format / shutdown 等）→ 强制 ask
      · 命中删除类模式（Remove-Item / del / rm / rmdir 等"删文件"）→ ask
      · 普通命令（查看/复制/移动/安装等）→ allow，自动执行
    这样"删文件要通过、其他不需要"，日常命令不被误拦截。

安全机制（大厂标配）：
  - 硬性断路器：命中不可逆系统级操作（rm -rf 级）→ 强制 ask，任何模式不可绕过
  - 受保护目录：文件类工具触碰系统/敏感目录 → deny，默认拒绝
  - 敏感文件黑名单：工作区内含密钥/隐私的路径（.env/keys/config.json/history/data/version）读+写都 deny
  - 工作区白名单：文件类工具只能操作仓库（工作区）内路径，仓库外一律 deny（两者合一沙箱）
  - 审计留痕：每次决策记录 mode 与 decision（agent_tasks 表，见 loop.py）
"""
import os
import re

from .. import config
from ..state import get_permission_flags

# ---------- 模式与决策常量 ----------
MODE_LOCKED = "locked"
MODE_STANDARD = "standard"
MODE_RELAXED = "relaxed"
MODES = (MODE_LOCKED, MODE_STANDARD, MODE_RELAXED)

DECISION_ALLOW = "allow"
DECISION_ASK = "ask"
DECISION_DENY = "deny"

# 每模式 × 风险级 → 默认动作
_MODE_RISK_ACTION = {
    MODE_LOCKED:   {"safe": DECISION_ASK, "sensitive": DECISION_DENY, "dangerous": DECISION_DENY},
    MODE_STANDARD: {"safe": DECISION_ALLOW, "sensitive": DECISION_ASK, "dangerous": DECISION_ASK},
    MODE_RELAXED:  {"safe": DECISION_ALLOW, "sensitive": DECISION_ALLOW, "dangerous": DECISION_ASK},
}

# locked 模式显式放行的只读核心工具白名单（kb 检索/记忆检索/截图/OCR 不影响系统状态）
_LOCKED_ALLOWLIST = {"kb_query", "memory_search", "screen_capture", "screen_ocr"}

# run_command 删除类模式：命中视为"删文件"，任何模式都需人工确认
# （rm -rf / Remove-Item -Recurse 等大面积删除已在 PERMISSION_HARD_BLOCK 覆盖）
_DELETION_PATTERNS = [
    re.compile(r"\bremove-item\b", re.IGNORECASE),
    re.compile(r"\bremove\b", re.IGNORECASE),
    re.compile(r"\brmdir\b", re.IGNORECASE),
    re.compile(r"\bclear-content\b", re.IGNORECASE),   # 清空文件内容（破坏数据）
    re.compile(r"\bclear-item\b", re.IGNORECASE),
    re.compile(r"\bwipe\b", re.IGNORECASE),
    re.compile(r"\btruncate\b", re.IGNORECASE),
    # 短别名（del/rm/rd/erase）要求后跟空白/引号/斜杠，避免误伤 Get-DeliveryOptimization 等
    re.compile(r"\b(del|rm|rd|erase)\b(?=[\s\"'/\\]|$)", re.IGNORECASE),
]


def _hits_deletion(command: str) -> bool:
    """run_command 是否命中删除类操作（普通删文件/删目录/清空内容）。"""
    return any(pat.search(command) for pat in _DELETION_PATTERNS)


# 备份/推送类命令 → 强制人工确认（backup_to_cloud 工具已停用，但磁盘上仍有 backup.py 脚本，
# 防止智能体绕过审批直接跑脚本，也防裸 git push/clone 等远程操作）
_BACKUP_PATTERNS = [
    re.compile(r"backup\.py", re.IGNORECASE),
    re.compile(r"\bgit\s+push", re.IGNORECASE),
    re.compile(r"\bgit\s+remote\s+add\b", re.IGNORECASE),
    re.compile(r"\bgit\s+clone\b", re.IGNORECASE),
]


def _hits_backup(command: str) -> bool:
    """run_command 是否命中备份/远程推送类操作（任何模式都人工确认）。"""
    return any(pat.search(command) for pat in _BACKUP_PATTERNS)


def normalize_mode(mode: str | None) -> str:
    """规范化权限模式；非法/缺省回退 standard。"""
    return mode if mode in MODES else MODE_STANDARD


def _hits_hard_block(tool_name: str, args: dict) -> bool:
    """硬性断路器：不可逆系统级破坏 → 任何模式都强制 ask（保留人工判断权）。"""
    text = ""
    if tool_name == "run_command":
        text = str(args.get("command") or args.get("script") or "")
    elif tool_name in ("write_file", "read_file", "list_dir"):
        text = str(args.get("path") or "")
    if not text:
        return False
    return any(pat.search(text) for pat in config.PERMISSION_HARD_BLOCK)


def _hits_protected_path(tool_name: str, args: dict) -> bool:
    """受保护目录：文件类工具触碰系统/敏感目录 → deny（默认拒绝读/写）。"""
    if tool_name not in ("write_file", "read_file", "list_dir"):
        return False
    path = str(args.get("path") or "").strip()
    if not path:
        return False
    norm = path.replace("\\", "/").lower()
    return any(norm.startswith(d) for d in config.PERMISSION_PROTECTED_DIRS)


def _hits_blocked_path(tool_name: str, args: dict) -> bool:
    """敏感文件黑名单（行为守则禁区 A）：工作区内含密钥/隐私的路径也一律 deny。

    覆盖文件类工具（read/write/list/search + office），读和写都拦。
    边界用"路径段"匹配（selfiterate/data 不误伤 selfiterate/data_backup）。
    """
    path = _file_tool_path(tool_name, args)
    if not path:
        return False
    target = os.path.abspath(os.path.normpath(path)).lower()
    workspace = os.path.abspath(config.AGENT_WORKSPACE).lower()
    if not (target == workspace or target.startswith(workspace + os.sep)):
        return False  # 仓库外交给工作区白名单，这里只管仓库内的敏感路径
    rel = target[len(workspace):].lstrip("\\/").replace("\\", "/")
    return any(rel == b or rel.startswith(b + "/") for b in config.PERMISSION_BLOCKED_PATHS)


# 受工作区白名单约束的文件类工具 → 其路径参数名
_FILE_TOOLS = {
    "read_file": "path",
    "write_file": "path",
    "list_dir": "path",
    "search_files": "path",
    "office_excel_read": "path",
    "office_excel_write": "path",
    "office_excel_summary": "path",
    "office_word_read": "path",
    "office_word_write": "path",
    "office_pdf_read": "path",
}


def _file_tool_path(tool_name: str, args: dict) -> str | None:
    """文件类工具 → 返回其路径参数（无则 None）。"""
    key = _FILE_TOOLS.get(tool_name)
    if not key:
        return None
    return str(args.get(key) or "").strip() or None


# 全盘敏感路径段（工作区开关关闭=放开沙箱时启用）：任一路径段命中即拒绝，
# 防止越界访问工作区外的密钥/隐私文件。段名精确匹配（.env.example 是模板，不算敏感）。
_GLOBAL_BLOCKED_SEGMENTS = {".env", "keys", "config.json", "history"}


def _hits_global_blocked_path(path: str) -> bool:
    """放开工作区后的全局敏感黑名单：任意路径命中敏感段（.env/keys/config.json/history）→ deny。"""
    target = os.path.abspath(os.path.normpath(path)).lower()
    segments = [seg for seg in target.split(os.sep) if seg]
    return any(seg in _GLOBAL_BLOCKED_SEGMENTS for seg in segments)


def _in_workspace(path: str) -> bool:
    """路径是否位于允许的操作目录内：工作区（AGENT_WORKSPACE）或桌面临时目录（AGENT_TEMP_DIR）。

    临时目录是守则"临时文件纪律"规定的中间产物落点（行为守则新增条目），
    视为工作区同等权限，方便智能体自由读写；敏感段黑名单仍全局生效。
    Windows 大小写不敏感；相对路径按进程 cwd 解析后再比较。
    """
    workspace = os.path.abspath(config.AGENT_WORKSPACE).lower()
    target = os.path.abspath(os.path.normpath(path)).lower()
    if target == workspace or target.startswith(workspace + os.sep):
        return True
    temp = os.path.abspath(config.AGENT_TEMP_DIR).lower()
    return target == temp or target.startswith(temp + os.sep)


def decide(mode: str | None, risk: str, tool_name: str, args: dict) -> tuple:
    """权限决策入口：返回 (decision, reason)。

    评估序（与 Claude Code 一致：deny 优先）：
      1. 硬性断路器 → ask（强制人工确认，不可绕过）
      2. 受保护目录 → deny（默认拒绝）
      2.4 敏感文件黑名单 → deny（工作区内含密钥/隐私的路径，读+写都不行）
      2.5 工作区白名单 → deny（文件类工具只能操作仓库内路径，任何模式不可绕过）
      3. locked 模式 → 白名单 allow / 其余 deny
      4. run_command 内容分级 → 删除类 ask / 普通命令 allow（任何模式生效）
      5. 其他工具：模式 × 风险默认策略
    """
    mode = normalize_mode(mode)
    # 1. 硬性断路器：即使 relaxed 也强制人工确认
    if _hits_hard_block(tool_name, args):
        return DECISION_ASK, "hard-block"
    # 2. 受保护目录：默认拒绝
    if _hits_protected_path(tool_name, args):
        return DECISION_DENY, "protected-path"
    # 2.4 敏感文件黑名单（行为守则禁区 A）：.env/keys/config.json/history/data/version 读+写都 deny
    if _hits_blocked_path(tool_name, args):
        return DECISION_DENY, "blocked-path"
    # 2.5 工作区白名单（两者合一沙箱）：文件类工具只能操作仓库（工作区）内路径
    #     前端"工作区开关"（workspace_strict）关闭时放开沙箱——但全局敏感黑名单
    #     仍拦 .env/keys/config.json/history 任意路径段，受保护目录/硬断路器/删除确认照旧。
    tool_path = _file_tool_path(tool_name, args)
    if tool_path and not _in_workspace(tool_path):
        if get_permission_flags().get("workspace_strict", True):
            return DECISION_DENY, "workspace-outside"
        if _hits_global_blocked_path(tool_path):
            return DECISION_DENY, "blocked-path-global"
    # 3. locked 模式：只放行只读核心白名单
    if mode == MODE_LOCKED:
        if tool_name in _LOCKED_ALLOWLIST:
            return DECISION_ALLOW, "locked-allowlist"
        return DECISION_DENY, "locked-mode"
    # 4. run_command 内容分级：删除类、备份/推送类 → 人工确认；普通命令自动执行
    if tool_name == "run_command":
        command = str(args.get("command") or args.get("script") or "")
        if _hits_deletion(command):
            return DECISION_ASK, "deletion-command"
        if _hits_backup(command):
            return DECISION_ASK, "backup-command"
        return DECISION_ALLOW, "run-command-auto"
    # 5. 其他工具：模式 × 风险默认策略
    action = _MODE_RISK_ACTION[mode].get(risk, DECISION_ASK)
    return action, f"{mode}:{risk}"
