# -*- coding: utf-8 -*-
"""审批分级与挂起/恢复（async 版）。

M0 简化版：approval 只做分级判定 + 挂起事件推送 + 应答唤醒。
sensitive/dangerous 操作会发出 approval_request 事件，等前端应答。
应答接口（POST /api/v1/agent/approve）在 main.py 中挂载，调用本模块唤醒挂起的任务。

真实审批链路（前后端配合）：
1. loop 遇到 sensitive/dangerous 工具 → await approval.ask() 挂起（asyncio.Event）
2. SSE 推送 approval_request（含 task_id、工具名、参数）
3. 前端弹窗 → 用户选择 → POST /approve {task_id, approved}
4. ApprovalManager.resolve() 置位事件 → loop 继续执行
"""

import asyncio
import json
import re
import threading

from .events import EventType

# 分级：safe 自动执行；sensitive 需确认（可恢复操作）；dangerous 需确认（不可逆/影响系统）
RISK_AUTO = "safe"
RISK_CONFIRM = ("sensitive", "dangerous")


# ---- P2-1：安全场景话术（对标 computer_use 的「确认模式」分类，本地化为中文模板）----
# 三类场景，只影响"怎么向用户交代"，不改变权限决策（decide() 判什么还是什么）：
#   handoff        须由用户本人完成的收尾步骤 → 智能体停手，请用户来点最后一下
#   pre-approval   外发数据类动作 → 预授权须明确「什么数据 + 发给谁 + 为什么」
#   always-confirm 即使事先授权，也要在执行前确认的高影响动作
_HANDOFF_PATTERNS = (
    re.compile(r"password|passwd|改密|新密码|重置密码", re.IGNORECASE),
    re.compile(r"captcha|验证码|人机验证|滑动验证", re.IGNORECASE),
    re.compile(r"two[-_ ]?factor|\botp\b|二次验证|双因子", re.IGNORECASE),
    re.compile(r"忽略.{0,8}(安全|证书|警告)|bypass.{0,16}(https|warning|interstitial)",
               re.IGNORECASE),
)
_TRANSMIT_PATTERNS = (
    re.compile(r"\bscp\b|\bsftp\b", re.IGNORECASE),
    re.compile(r"curl.{0,200}(--data|-d\s|--form|-F\s)", re.IGNORECASE),
    re.compile(r"invoke-restmethod", re.IGNORECASE),
    re.compile(r"upload|上传|发布到|publish_to_lazaxa", re.IGNORECASE),
    re.compile(r"smtp|sendmail|发邮件|发送邮件", re.IGNORECASE),
)
_ALWAYS_CONFIRM_PATTERNS = (
    re.compile(r"\bdelete\b|remove-item|\bremove\b|删除|\buninstall\b", re.IGNORECASE),
    re.compile(r"winget install|choco install|安装|installer|setup\.exe|\.msi\b",
               re.IGNORECASE),
    re.compile(r"icacls|takeown|chmod|chown|\bnet user\b|权限", re.IGNORECASE),
    re.compile(r"支付|付款|下单|充值|转账|payment", re.IGNORECASE),
)

_HANDOFF_TIP = (
    "⛔ 这一步属于「须由你本人完成」的收尾（改密 / 验证码 / 登录二次验证 / 绕过安全警告）："
    "建议你亲自点最后一下；我不代做，也不会替你忽略浏览器安全警告。")
_PREAPPROVAL_TIP = (
    "⚠️ 这是「向外传输数据」的动作。请核对三点——① 传的是什么数据 ② 发给谁（账号 / 地址 / 仓库）"
    "③ 为什么需要；只有你在本次指令里明确点出这三点才算预授权，否则请现在确认。")
_ALWAYS_CONFIRM_TIP = (
    "⚠️ 这属于「即使事先授权也要在执行前确认」的动作（删数据 / 装新软件 / 改账号权限 / 交易）："
    "请确认本次的具体对象与后果后再放行。")


def _flatten_args(tool_name: str, args: dict) -> str:
    """工具名 + 参数序列化成一段文本，供关键字分类（分类只做话术，不做裁决）。"""
    try:
        body = json.dumps(args or {}, ensure_ascii=False)
    except Exception:
        body = str(args)
    return f"{tool_name} {body}"


def guidance_for(tool_name: str, args: dict) -> str:
    """按 computer_use 的确认模式分类，给出本次操作的场景话术（无匹配返回空串）。

    可能同时命中多类（如"上传前先改密"），按 handoff → pre-approval → always-confirm
    顺序拼接，保证最该先看的那条在最前。
    """
    text = _flatten_args(tool_name, args)
    tips = []
    if any(p.search(text) for p in _HANDOFF_PATTERNS):
        tips.append(_HANDOFF_TIP)
    if any(p.search(text) for p in _TRANSMIT_PATTERNS):
        tips.append(_PREAPPROVAL_TIP)
    if any(p.search(text) for p in _ALWAYS_CONFIRM_PATTERNS):
        tips.append(_ALWAYS_CONFIRM_TIP)
    return "\n".join(tips)


class _PendingRequest:
    def __init__(self, task_id: str, tool_name: str, args: dict, risk: str):
        self.task_id = task_id
        self.tool_name = tool_name
        self.args = args
        self.risk = risk
        self.event = asyncio.Event()
        self.approved: bool | None = None
        self.timeout_seconds = 300   # 前端 5 分钟内不答复 → 视为拒绝


class ApprovalManager:
    """审批管理器（进程内单例，跨线程安全）。"""

    def __init__(self):
        self._pending: dict[str, _PendingRequest] = {}
        self._resolved_edits: dict[str, dict] = {}   # M5-2：用户"编辑参数后批准"的参数，待 gate 取用
        self._lock = threading.Lock()

    def should_confirm(self, risk: str) -> bool:
        return risk in RISK_CONFIRM

    @staticmethod
    def _describe(tool_name: str, args: dict) -> tuple[str, str]:
        """审批请求的上下文摘要：工具展示名 + 参数预览（供前端弹窗说明"要做什么"）。"""
        display_name = ""
        try:
            from .registry import registry
            tool = registry.get(tool_name)
            display_name = tool.display_name if tool else ""
        except Exception:
            pass
        try:
            preview = json.dumps(args, ensure_ascii=False)
        except Exception:
            preview = str(args)
        if len(preview) > 200:
            preview = preview[:200] + "…"
        return display_name, f"{display_name or tool_name}：{preview}"

    async def ask(self, task_id: str, tool_name: str, args: dict, risk: str,
                  emit) -> bool:
        """挂起等用户审批。返回 True=允许执行；False=拒绝/超时。

        emit: 用于推送 approval_request SSE 事件的异步回调。
        """
        if risk == RISK_AUTO:
            return True
        req = _PendingRequest(task_id, tool_name, args, risk)
        with self._lock:
            self._pending[task_id] = req
        display_name, context_summary = self._describe(tool_name, args)
        guidance = guidance_for(tool_name, args)
        if guidance:
            context_summary = f"{context_summary}\n{guidance}"
        await emit("approval_request", {"task_id": task_id, "tool": tool_name,
                                        "display_name": display_name,
                                        "args": args, "risk": risk,
                                        "context_summary": context_summary,
                                        "guidance": guidance})
        try:
            await asyncio.wait_for(req.event.wait(), timeout=req.timeout_seconds)
        except asyncio.TimeoutError:
            req.approved = False
        finally:
            with self._lock:
                self._pending.pop(task_id, None)
        return bool(req.approved)

    def resolve(self, task_id: str, approved: bool,
                edited_args: dict | None = None) -> bool:
        """前端应答审批。返回 True=该任务确实在等待中。

        edited_args：用户编辑参数后批准（M5-2）。仅当 approved 且为 dict 时生效，
        由 gate 经 take_edited_args 取用并以编辑后参数执行。
        """
        with self._lock:
            req = self._pending.get(task_id)
            if req is None:
                return False
            req.approved = approved
            if approved and isinstance(edited_args, dict):
                self._resolved_edits[task_id] = edited_args
            else:
                self._resolved_edits.pop(task_id, None)
            req.event.set()
            return True

    def take_edited_args(self, task_id: str) -> dict | None:
        """取走该任务"编辑后批准"的参数（取后即清，避免跨任务残留）。"""
        with self._lock:
            return self._resolved_edits.pop(task_id, None)

    def pending_count(self) -> int:
        with self._lock:
            return len(self._pending)


# 全局单例
approval = ApprovalManager()


# ---- M5 工具流水线：审批 gate 钩子 + 关卡文案（与 loop 旧硬编码逐字一致）----

def deny_model_text(reason: str) -> str:
    """权限策略拒绝时回灌模型的文案（M4a 三要素：未执行/严禁编造/如实告知）。"""
    return (
        f"此操作被权限策略拒绝（{reason}）。【该工具未实际执行，你没有获得任何真实结果】，"
        "严禁猜测、虚构或凭印象编造该工具本应返回的内容。请改用不涉及该范围的方式；"
        "若任务因此无法完成，必须如实告知用户“该操作被权限拒绝、未能执行”，"
        "并请求授权或调整要求。")


REJECTED_MODEL_TEXT = (
    "用户拒绝了此操作。【该工具未实际执行，你没有获得任何真实结果】，"
    "严禁猜测、虚构或凭印象编造该工具本应返回的内容。请换一种方式；"
    "若无法继续，必须如实告知用户“该操作被用户拒绝、未能执行”或停止，不得编造结果。")


async def approval_gate_hook(name: str, args: dict, risk: str, ctx):
    """M5 流水线 gate：把原 loop 硬编码的“权限决策 + 审批挂起”统一为可插拔关卡。

    - deny：直接拦截（不弹窗、不挂起），回灌拒绝文案；
    - ask ：approval.ask 挂起等用户应答（超时=拒绝），approval_resolved 落 M3 事件账；
    - allow：放行。decision/approved 回写 ctx，供 post 审计钩子消费。
    延迟导入 permissions/config/db，避免模块加载期循环依赖。
    """
    from .permissions import DECISION_ASK, DECISION_DENY, decide
    from .registry import HookResult
    from .. import config

    decision, reason = decide(ctx.mode, risk, name, args)
    ctx.decision = decision
    if decision == DECISION_DENY:
        ctx.approved = False
        return HookResult.block(deny_model_text(reason),
                                brief=f"权限拒绝({reason})", decision=DECISION_DENY)
    if decision == DECISION_ASK:
        allowed = await approval.ask(ctx.task_id, name, args, risk, ctx.emit)
        # M5-2：用户"编辑参数后批准"→ 取走编辑参数，交给 registry.arun 以编辑后参数执行
        edited = approval.take_edited_args(ctx.task_id) if allowed else None
        if edited is not None:
            ctx.edited_args = edited
        # M3 approval_resolved：审批结果落账（请求事件已由 ask 的 wire emit 带出）
        if config.AGENT_EVENTS_ENABLED and ctx.round_id:
            try:
                from ..db import log_agent_event
                log_agent_event(EventType.APPROVAL_RESOLVED,
                                {"task_id": ctx.task_id, "tool": name,
                                 "args": edited if edited is not None else args,
                                 "risk": risk,
                                 "approved": bool(allowed),
                                 "edited": edited is not None},
                                round_id=ctx.round_id, task_id=ctx.task_id,
                                parent_task_id=ctx.parent_task_id)
            except Exception:
                pass
        ctx.approved = bool(allowed)
        if not allowed:
            return HookResult.block(REJECTED_MODEL_TEXT,
                                    brief="用户拒绝执行", decision=DECISION_ASK)
    else:
        ctx.approved = True
    return HookResult.pass_()
