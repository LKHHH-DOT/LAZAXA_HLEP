# -*- coding: utf-8 -*-
"""发布工具：把 Lazaxa 自产出项目归档到 LAZAXA 私有仓库（projects/<项目名>/ 一项目一文件夹）。

仓库分工（用户 2026-08-17 确定的双仓库模型）：
  - super-fiesta（LKHHH-DOT/super-fiesta）：Lazaxa 设备源码（云端归档，已不在智能体工具内维护）
  - LAZAXA（LKHHH-DOT/LAZAXA）：智能体自产出/独立完成的项目，由 publish_to_lazaxa 维护

安全设计（与 scripts/backup.py 同一套思路）：
  - 复制项目时排除密钥/运行数据（.env / config.json / keys / data / venv 等）
  - 提交前对已复制的文件做"文件名 + 内容"双重敏感校验，命中即中止
"""
import os
import re
import shutil
import subprocess
from datetime import datetime

from ..registry import Tool, ToolResult, ToolRegistry

# 工作区根（本模块位于 SelfIterate/app/agent/tools/ 下，向上 5 级 = Kaelo）
WORKSPACE = os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))))

# LAZAXA 远程仓库与 Deploy Key（.env 配置；key 未配置则退化为默认 SSH）
LAZAXA_REPO = os.environ.get("LAZAXA_REPO", "ssh://git@github.com/LKHHH-DOT/LAZAXA.git")
LAZAXA_DEPLOY_KEY = os.environ.get("LAZAXA_DEPLOY_KEY", "")
# 本地镜像仓库（clone 到工作区的兄弟目录，是工具的私有工作副本，不进入设备仓库）
LAZAXA_REPO_DIR = os.environ.get(
    "LAZAXA_REPO_DIR", os.path.join(os.path.dirname(WORKSPACE), "LAZAXA"))

# 复制项目时排除的目录/文件名（密钥与运行数据永不发布）
# _test/tmp 等中间产物目录也排除：智能体发布前无需清理项目内测试残留（2026-08-18）
COPY_EXCLUDE_DIRS = {".git", "__pycache__", "venv", ".venv", "node_modules",
                     "data", "version", "storage", "models", "_archive",
                     "history", "logs", "keys", "_test", "test_tmp",
                     "tmp", "_tmp", "__tmp__", ".tmp"}
COPY_EXCLUDE_FILES = {".env", ".env.local", "config.json", "thumbs.db", "desktop.ini"}

# 敏感文件名模式（提交前兜底）
SENSITIVE_FILENAME = [
    re.compile(r"(^|[/\\])\.env$"),
    re.compile(r"\.env\.(?!example)"),
    re.compile(r"config\.json$"),
    re.compile(r"\.(pem|key|p12|pfx|jks|crt)$"),
    re.compile(r"(^|[/\\])\.ssh[/\\]"),
]
# 敏感内容模式：值判定=引号包裹字符串 / 纯裸字符串；全大写变量名与 . 变量引用不算
SENSITIVE_CONTENT = re.compile(
    r"(?:sk-|tvly-|pk-|ghp_|github_pat_)[A-Za-z0-9_\-]{12,}|"
    r"['\"]?(?:api_key|apikey|admin_token|secret|token|password)['\"]?\s*[=:]\s*"
    r"(?:['\"]([^'\"]{8,})['\"]|([A-Za-z0-9_\-]{12,}))",
    re.IGNORECASE)
VAR_NAME_STYLE = re.compile(r"^[A-Z][A-Z0-9_]{7,}$")
MAX_CONTENT_SCAN_BYTES = 1_000_000   # 只扫描 1MB 以内的文本文件
CONTENT_SCAN_HEAD_BYTES = 64_000     # 每个文件只读头部 64KB


def _git(cmd: list, cwd: str, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", **kw)


def _ssh_env() -> dict:
    """构造带 Deploy Key 的 SSH 环境（未配置 key 时用默认 SSH，BatchMode 防挂起）。"""
    env = dict(os.environ)
    if LAZAXA_DEPLOY_KEY and os.path.isfile(LAZAXA_DEPLOY_KEY):
        env["GIT_SSH_COMMAND"] = (
            f'ssh -i "{LAZAXA_DEPLOY_KEY}" -o IdentitiesOnly=yes '
            "-o StrictHostKeyChecking=accept-new -o BatchMode=yes"
        )
    return env


def _ensure_repo() -> str | None:
    """确保本地镜像仓库存在且与远程同步。返回 None=成功，否则错误信息。"""
    if os.path.isdir(os.path.join(LAZAXA_REPO_DIR, ".git")):
        p = _git(["git", "pull", "--ff-only", "origin", "main"],
                 LAZAXA_REPO_DIR, env=_ssh_env())
        if p.returncode != 0:
            return f"同步本地 LAZAXA 镜像失败: {p.stderr.strip()}"
        return None
    os.makedirs(os.path.dirname(LAZAXA_REPO_DIR), exist_ok=True)
    p = _git(["git", "clone", LAZAXA_REPO, LAZAXA_REPO_DIR],
             os.path.dirname(LAZAXA_REPO_DIR), env=_ssh_env())
    if p.returncode != 0:
        return f"clone LAZAXA 仓库失败: {p.stderr.strip()}"
    return None


def _copy_project(src: str, dst: str) -> None:
    """复制项目内容到镜像目录（排除密钥与运行数据）。"""
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            if item in COPY_EXCLUDE_DIRS:
                continue
            shutil.copytree(s, d, ignore=shutil.ignore_patterns(
                *COPY_EXCLUDE_DIRS, *COPY_EXCLUDE_FILES))
        elif item not in COPY_EXCLUDE_FILES:
            shutil.copy2(s, d)


def _sensitive_in_text(text: str) -> str | None:
    """逐行扫描文本，命中密钥样式返回命中片段（跨行不匹配，防空值键误伤）。"""
    for line in text.splitlines():
        for m in SENSITIVE_CONTENT.finditer(line):
            hit = m.group(1) or m.group(2) or m.group(0)
            if VAR_NAME_STYLE.match(hit):
                continue
            return hit
    return None


def _check_published(pub_dir: str) -> str | None:
    """对已复制到镜像的项目做敏感校验。返回 None=通过，否则命中说明。"""
    for root, _dirs, files in os.walk(pub_dir):
        for f in files:
            path = os.path.join(root, f)
            rel = os.path.relpath(path, pub_dir).replace("\\", "/")
            for pat in SENSITIVE_FILENAME:
                if pat.search(rel):
                    return f"文件名命中敏感模式: {rel}"
            if os.path.getsize(path) > MAX_CONTENT_SCAN_BYTES:
                continue
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                    head = fh.read(CONTENT_SCAN_HEAD_BYTES)
            except OSError:
                continue
            hit = _sensitive_in_text(head)
            if hit:
                return f"文件内容疑似密钥（{hit}）: {rel}"
    return None


def _publish_to_lazaxa(project_dir: str, description: str = "") -> ToolResult:
    """把工作区内的项目目录发布到 LAZAXA 仓库 projects/<项目名>/。"""
    # 1. 解析并校验项目路径（相对路径按工作区解析，必须位于工作区内）
    if not os.path.isabs(project_dir):
        project_dir = os.path.normpath(os.path.join(WORKSPACE, project_dir))
    project_dir = os.path.abspath(project_dir)
    if not os.path.isdir(project_dir):
        return ToolResult.err_result(f"项目目录不存在: {project_dir}")
    try:
        inside = os.path.commonpath([WORKSPACE, project_dir]) == WORKSPACE
    except ValueError:
        inside = False
    if not inside:
        return ToolResult.err_result("只能发布工作区内的项目（设备源码不属于自产出项目，不在发布范围）")
    # 设备源码整体目录不得当项目发布（防把整套源码误发到自产出仓库）
    if project_dir == WORKSPACE:
        return ToolResult.err_result("不能发布整个工作区，请指定具体的自产出项目目录")

    project_name = os.path.basename(project_dir.rstrip("/\\"))
    if not project_name:
        return ToolResult.err_result("无法确定项目名")

    # 2. 确保本地镜像仓库就绪
    err = _ensure_repo()
    if err:
        return ToolResult.err_result(err)

    # 3. 复制项目到 projects/<name>/（先清旧再复制，保证镜像同步）
    pub_dir = os.path.join(LAZAXA_REPO_DIR, "projects", project_name)
    if os.path.isdir(pub_dir):
        shutil.rmtree(pub_dir)
    os.makedirs(pub_dir, exist_ok=True)
    _copy_project(project_dir, pub_dir)

    # 4. 提交前敏感校验（复制后、入库前）
    hit = _check_published(pub_dir)
    if hit:
        return ToolResult.err_result(f"已中止发布（项目含疑似敏感内容，请处理后重试）: {hit}")

    # 5. 项目无 README 时自动补一个归档说明
    readme = os.path.join(pub_dir, "README.md")
    if not os.path.isfile(readme):
        with open(readme, "w", encoding="utf-8") as f:
            f.write(f"# {project_name}\n\n")
            f.write(f"> 由 Lazaxa 智能体发布 · {datetime.now().strftime('%Y-%m-%d')}\n\n")
            if description.strip():
                f.write(description.strip() + "\n\n")
            f.write("## 说明\n\n（归档时自动生成，可在仓库内补充详情）\n")

    # 6. 提交 + 推送
    _git(["git", "add", "-A"], LAZAXA_REPO_DIR)
    msg = f"publish: {project_name}"
    if description.strip():
        msg += f" · {description.strip()}"
    commit = _git(["git", "commit", "-m", msg], LAZAXA_REPO_DIR)
    if commit.returncode != 0:
        if "nothing to commit" in (commit.stdout + commit.stderr):
            return ToolResult.ok_result("项目内容与已发布版本一致，无需更新", brief="☁️ 已同步 LAZAXA")
        return ToolResult.err_result(f"提交失败: {commit.stderr.strip()}")
    push = _git(["git", "push", "origin", "HEAD"], LAZAXA_REPO_DIR, env=_ssh_env())
    if push.returncode != 0:
        return ToolResult.err_result(f"提交成功但推送失败: {push.stderr.strip()}")
    return ToolResult.ok_result(
        f"已发布项目 {project_name} 到 LAZAXA 仓库 projects/{project_name}/",
        brief="☁️ 已发布 LAZAXA")


def register_all(r: ToolRegistry):
    """注册 LAZAXA 发布工具。"""
    r.register(Tool(
        name="publish_to_lazaxa",
        display_name="☁️ 发布到 LAZAXA",
        description=(
            "把 Lazaxa 自产出/独立完成的项目发布到 LAZAXA 私有仓库归档"
            "（projects/<项目名>/，每项目一个文件夹）。"
            "适合完成一个独立项目后把成果存档。"
            "参数 project_dir：工作区内的项目目录（相对或绝对路径）。"
            "本工具只发布智能体自产出项目（→ LAZAXA）；设备源码不在发布范围。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "要发布的项目目录（工作区内，相对或绝对路径）",
                },
                "description": {
                    "type": "string",
                    "description": "项目说明（可选，写入归档 README）",
                },
            },
            "required": ["project_dir"],
        },
        risk="dangerous",
        timeout=240,
        fn=_publish_to_lazaxa,
    ))
