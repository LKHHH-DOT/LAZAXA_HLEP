# -*- coding: utf-8 -*-
"""长期记忆工具：记忆/经验/偏好的向量化存取（Sanctum Qdrant 底座）。

对应 Sanctum/Sanctum定位与技术方案.md 阶段 1（M3 记忆系统-长层）。
三个工具：
  - memory_add:     写入一条记忆/经验/偏好
  - memory_search:  语义检索，支持按 类型/时间/敏感度/标签 过滤
  - memory_delete:  按 id / 类型 / 标签 删除

实现要点：
  - 懒加载：qdrant_client / fastembed 在函数内 import（遵循 agent 包约定，
    避免 main 启动时加载重型依赖、拖慢服务启动）
  - 单例：嵌入模型与 Qdrant 连接进程级复用（只初始化一次，控制冷启动成本）
  - 本地闭环：嵌入（fastembed 离线模型）与检索（本机 Qdrant）全程本地，向量不出网
  - 统一返回 ToolResult，绝不裸抛异常
"""

import os
import threading
import time
import uuid

from ..registry import Tool, ToolResult, ToolRegistry

# 记忆类型枚举（payload.type 取值）
# 轻量分层（借 Agent-Memory L 级思想，不拆库只打 type）：
#   memory=L1 对话事件/待办/说过的话（量多、按需检索）
#   experience=L2 场景经验/踩过的坑（可复用套路）
#   preference=L2 偏好/习惯/约定
#   profile=L3 长期画像/稳定身份事实（少而稳，每轮常驻注入）
MEMORY_TYPES = ("memory", "experience", "preference", "profile")

# 敏感度枚举（payload.sensitivity 取值）
SENSITIVITY_LEVELS = ("low", "high")

# ---- 模块级单例（进程内只初始化一次） ----
_model_lock = threading.Lock()
_model_cache = None          # fastembed TextEmbedding 实例
_client_lock = threading.Lock()
_client_cache = None         # QdrantClient 实例
_ready = False               # 集合是否已确保存在（避免每次调用都探测）


def _get_model():
    """懒加载 + 进程级单例：fastembed 嵌入模型（bge-small-zh，512 维，离线）。"""
    from ... import config as _cfg

    global _model_cache
    if _model_cache is not None:
        return _model_cache
    with _model_lock:
        if _model_cache is None:
            # 国内模型下载：走镜像 + 禁用 Xet 协议（hf-mirror 不支持）
            os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
            os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
            from fastembed import TextEmbedding

            _model_cache = TextEmbedding(
                model_name=_cfg.SANCTUM_EMBED_MODEL,
                cache_dir=_cfg.SANCTUM_MODEL_DIR,
            )
    return _model_cache


def _get_client():
    """懒加载 + 进程级单例：Qdrant HTTP 客户端（REST 127.0.0.1:6333）。"""
    from ... import config as _cfg

    global _client_cache
    if _client_cache is not None:
        return _client_cache
    with _client_lock:
        if _client_cache is None:
            from qdrant_client import QdrantClient

            _client_cache = QdrantClient(url=_cfg.SANCTUM_QDRANT_URL)
    return _client_cache


def _ensure_collection() -> str | None:
    """确保记忆集合存在且维度匹配。返回 None=正常；否则返回错误信息。"""
    from ... import config as _cfg
    from qdrant_client.models import Distance, VectorParams

    client = _get_client()
    name = _cfg.SANCTUM_COLLECTION
    if not client.collection_exists(name):
        client.create_collection(
            collection_name=name,
            vectors_config=VectorParams(size=_cfg.SANCTUM_EMBED_DIM,
                                        distance=Distance.COSINE),
        )
        return None
    # 已存在：校验维度，防止换模型后向量不匹配
    info = client.get_collection(name)
    dim = info.config.params.vectors.size
    if dim != _cfg.SANCTUM_EMBED_DIM:
        return (f"记忆集合维度不符（期望 {_cfg.SANCTUM_EMBED_DIM}，实际 {dim}），"
                f"请用 SANCTUM_EMBED_DIM 对齐或重建集合")
    return None


def _embed(texts):
    """批量文本转向量（list[np.ndarray]）。"""
    model = _get_model()
    return list(model.embed(texts))


def _now_payload(text: str, mtype: str, tags, sensitivity: str, source: str,
                 round_id: str = "") -> dict:
    """构造 payload：文本 + 分类 + 溯源（source/round_id）+ 时间戳。

    round_id：自动沉淀路径由服务端每轮生成（r-<ms>-<seq>），写入 payload 便于
    按轮追溯/清理污染记忆（A批2 记忆防污染反馈环）；LLM 直写时留空。
    """
    ts = time.time()
    payload = {
        "text": text,
        "type": mtype,
        "tags": list(tags or []),
        "sensitivity": sensitivity,
        "source": source,
        "created_at": ts,          # 数值时间戳：供 Range 过滤（如"最近 N 天"）
        "created_iso": time.strftime("%Y-%m-%d %H:%M", time.localtime(ts)),
    }
    if round_id:
        payload["round_id"] = round_id
    return payload


def _exists_same_text(text: str, mtype: str, source: str) -> bool:
    """精确查重：库内是否已存在「同文本 + 同来源（+ 同类型）」记录。

    防"同一偏好/事实反复沉淀"（auto_sink 与 LLM 重复写入同一内容）。
    依赖 Qdrant 对 payload 的等值匹配，无需嵌入计算；异常视为不重复（放行）。
    """
    from qdrant_client.models import (
        FieldCondition, Filter, MatchValue,
    )

    conditions = [
        FieldCondition(key="text", match=MatchValue(value=text)),
        FieldCondition(key="source", match=MatchValue(value=source)),
    ]
    if mtype:
        conditions.append(FieldCondition(key="type",
                                         match=MatchValue(value=mtype)))
    try:
        total = _get_client().count(
            collection_name=_cfg_name(),
            count_filter=Filter(must=conditions),
        ).count
        return total > 0
    except Exception:
        return False


def _cfg_name() -> str:
    """懒取集合名（避免在函数内多次 import config）。"""
    from ... import config as _cfg

    return _cfg.SANCTUM_COLLECTION


# ============ memory_add ============

def _memory_add(text: str, type: str = "memory", tags=None,
                sensitivity: str = "low", source: str = "agent",
                round_id: str = "") -> ToolResult:
    """写入一条记忆/经验/偏好/画像。返回记忆 id 与当前库内条数。

    写前精确查重（同文本同来源不重复插入），防自动沉淀把同一偏好反复入库。
    round_id：溯源键（自动沉淀由服务端填本轮 id），仅写入 payload，不影响查重。
    """
    from ... import config as _cfg
    from qdrant_client.models import PointStruct

    text = (text or "").strip()
    if not text:
        return ToolResult.err_result("text 不能为空")
    mtype = (type or "memory").strip().lower()
    if mtype not in MEMORY_TYPES:
        return ToolResult.err_result(f"type 必须是 {list(MEMORY_TYPES)} 之一，收到: {type}")
    sens = (sensitivity or "low").strip().lower()
    if sens not in SENSITIVITY_LEVELS:
        return ToolResult.err_result(f"sensitivity 必须是 {list(SENSITIVITY_LEVELS)} 之一，收到: {sensitivity}")

    err = _ensure_collection()
    if err:
        return ToolResult.err_result(err)

    # 写入防重（P1）：同文本同来源已存在 → 直接跳过，不重复嵌入/入库
    src = (source or "agent").strip() or "agent"
    if _exists_same_text(text, mtype, src):
        return ToolResult.ok_result("已存在相同内容（同文本同来源），未重复写入。",
                                    brief="已存在，未重复写入")

    try:
        vector = _embed([text])[0]
        mem_id = str(uuid.uuid4())
        client = _get_client()
        client.upsert(
            collection_name=_cfg.SANCTUM_COLLECTION,
            points=[PointStruct(
                id=mem_id,
                vector=vector,
                payload=_now_payload(text, mtype, tags, sens, source,
                                     round_id=(round_id or "").strip()),
            )],
        )
        total = client.count(collection_name=_cfg.SANCTUM_COLLECTION).count
    except Exception as e:
        return ToolResult.err_result(f"记忆写入失败: {type(e).__name__}: {e}")

    brief = f"已记住（{mtype}）"
    detail = (f"已写入记忆\nid: {mem_id}\n类型: {mtype}\n敏感度: {sens}\n"
              f"标签: {', '.join(tags) if tags else '（无）'}\n"
              f"来源: {src}\n当前库内记忆数: {total}\n内容: {text[:100]}{'…' if len(text) > 100 else ''}")
    return ToolResult.ok_result(detail, brief=brief)


# ============ memory_search ============

def _build_filter(mtype: str = "", days: int = 0, sensitivity: str = "low",
                  tags=None, source: str = "", round_id: str = "") -> "Filter | None":
    """按 类型/时间/敏感度/标签/来源/轮次 构造 Qdrant Filter；全部为空则返回 None（全量检索）。"""
    from qdrant_client.models import (
        FieldCondition, Filter, MatchValue, Range,
    )

    conditions = []
    if mtype and mtype.strip().lower() in MEMORY_TYPES:
        conditions.append(FieldCondition(key="type",
                                         match=MatchValue(value=mtype.strip().lower())))
    if sensitivity and sensitivity.strip().lower() == "low":
        # 默认只检索低敏感记忆；查高敏感需显式传 sensitivity="high" 或 "all"
        conditions.append(FieldCondition(key="sensitivity",
                                         match=MatchValue(value="low")))
    elif sensitivity and sensitivity.strip().lower() == "high":
        conditions.append(FieldCondition(key="sensitivity",
                                         match=MatchValue(value="high")))
    # 最近 N 天（created_at 数值时间戳过滤）
    if days and days > 0:
        conditions.append(FieldCondition(key="created_at",
                                         range=Range(gte=time.time() - days * 86400)))
    # 标签：数组字段需"同时包含全部给定标签"
    for tag in (tags or []):
        tag = (tag or "").strip()
        if tag:
            conditions.append(FieldCondition(key="tags", match=MatchValue(value=tag)))
    # 来源精确匹配（预灌幂等清理/按来源检索用）
    if source and source.strip():
        conditions.append(FieldCondition(key="source",
                                         match=MatchValue(value=source.strip())))
    # 轮次精确匹配（A批2 溯源：查/删某轮自动沉淀的记录）
    if round_id and round_id.strip():
        conditions.append(FieldCondition(key="round_id",
                                         match=MatchValue(value=round_id.strip())))
    if not conditions:
        return None
    return Filter(must=conditions)


def _memory_search(query: str, type: str = "", top_k: int = 5, days: int = 0,
                   sensitivity: str = "low", tags=None,
                   round_id: str = "") -> ToolResult:
    """语义检索记忆/经验，支持过滤。返回按相似度降序的命中列表。

    round_id：溯源过滤（查某轮自动沉淀的记录，一般由排查场景使用）。
    """
    from ... import config as _cfg

    query = (query or "").strip()
    if not query:
        return ToolResult.err_result("query 不能为空")
    top_k = max(1, min(int(top_k or 5), 20))

    err = _ensure_collection()
    if err:
        return ToolResult.err_result(err)

    try:
        query_vector = _embed([query])[0]
        client = _get_client()
        result = client.query_points(
            collection_name=_cfg.SANCTUM_COLLECTION,
            query=query_vector,
            query_filter=_build_filter(type, days, sensitivity, tags,
                                       round_id=round_id),
            limit=top_k,
        )
        hits = result.points
    except Exception as e:
        return ToolResult.err_result(f"记忆检索失败: {type(e).__name__}: {e}")

    if not hits:
        return ToolResult.ok_result("未检索到相关记忆（可考虑放宽 type/时间/敏感度过滤）",
                                    brief="0 条命中")

    lines = [f"检索到 {len(hits)} 条记忆："]
    for i, hit in enumerate(hits, 1):
        p = hit.payload or {}
        lines.append(
            f"{i}. [{p.get('type', '?')}] {p.get('text', '')}\n"
            f"   相似度 {hit.score:.3f} | {p.get('created_iso', '')} "
            f"| 标签 {', '.join(p.get('tags') or []) or '无'} | id {hit.id}"
        )
    text = "\n".join(lines)
    return ToolResult.ok_result(text, brief=f"{len(hits)} 条命中")


# ============ memory_delete ============

def _memory_delete(ids=None, type: str = "", tags=None, source: str = "",
                   round_id: str = "") -> ToolResult:
    """删除记忆：按 id（优先）或 类型/标签/来源/轮次 过滤删除。至少提供一种删除条件。"""
    from ... import config as _cfg
    from qdrant_client.models import FilterSelector, PointIdsList

    ids = [str(i) for i in (ids or []) if str(i).strip()]
    filter_ = _build_filter(type, days=0, sensitivity="all", tags=tags,
                            source=source, round_id=round_id)

    if not ids and filter_ is None:
        return ToolResult.err_result("请提供删除条件：ids、type、tags、source、round_id 至少一个")

    client = _get_client()
    try:
        if ids:
            selector = PointIdsList(points=ids)
        else:
            selector = FilterSelector(filter=filter_)
        client.delete(collection_name=_cfg.SANCTUM_COLLECTION,
                      points_selector=selector)
        remaining = client.count(collection_name=_cfg.SANCTUM_COLLECTION).count
    except Exception as e:
        return ToolResult.err_result(f"记忆删除失败: {type(e).__name__}: {e}")

    parts = []
    if ids:
        parts.append(f"{len(ids)} 个 id")
    if type:
        parts.append(f"类型={type}")
    if tags:
        parts.append(f"标签={tags}")
    if source:
        parts.append(f"来源={source}")
    if round_id:
        parts.append(f"轮次={round_id}")
    text = f"删除完成（按 {' + '.join(parts)}），当前库内记忆数: {remaining}"
    return ToolResult.ok_result(text, brief=f"删除完成，剩 {remaining} 条")


# ============ 公共检索接口（供记忆注入/外部模块复用） ============

def retrieve(query: str, top_k: int = 3, type: str = "", days: int = 0,
             sensitivity: str = "low") -> list:
    """公共语义检索接口：返回 [{id, text, type, tags, created_iso, score}]。

    默认仅低敏感记忆（注入路径安全基线）；供 app/memory.py 记忆注入复用，
    避免重复初始化模型与连接。任何异常静默返回空列表（调用方降级，不阻断主流程）。
    """
    from ... import config as _cfg

    query = (query or "").strip()
    if not query:
        return []
    try:
        err = _ensure_collection()
        if err:
            return []
        query_vector = _embed([query])[0]
        hits = _get_client().query_points(
            collection_name=_cfg.SANCTUM_COLLECTION,
            query=query_vector,
            query_filter=_build_filter(type, days, sensitivity),
            limit=max(1, min(int(top_k or 3), 20)),
        ).points
        return [
            {
                "id": h.id,
                "text": (h.payload or {}).get("text", ""),
                "type": (h.payload or {}).get("type", ""),
                "tags": (h.payload or {}).get("tags", []),
                "created_iso": (h.payload or {}).get("created_iso", ""),
                "score": round(h.score, 4),
            }
            for h in hits
        ]
    except Exception:
        return []


def retrieve_recent(type: str = "", limit: int = 3,
                    sensitivity: str = "low") -> list:
    """取某类型最近写入的若干条（按 created_at 数值降序，客户端排序）。

    供画像稳定段注入（type=profile 少而稳、每轮常驻）与"最近 N 条"场景；
    Qdrant 端不做 order_by（避免依赖字段索引），滚动拉取后本地排序。
    返回结构同 retrieve；任何异常静默返回空列表。
    """
    from ... import config as _cfg

    limit = max(1, min(int(limit or 3), 20))
    try:
        err = _ensure_collection()
        if err:
            return []
        f = _build_filter(type, days=0, sensitivity=sensitivity)
        points = []
        offset = None
        while True:
            page = _get_client().scroll(
                collection_name=_cfg.SANCTUM_COLLECTION,
                limit=100,
                filter=f,
                offset=offset,
            ).points
            points.extend(page)
            if len(page) < 100:
                break
            offset = page[-1].id
    except Exception:
        return []
    points.sort(key=lambda p: (p.payload or {}).get("created_at", 0.0),
                reverse=True)
    return [
        {
            "id": p.id,
            "text": (p.payload or {}).get("text", ""),
            "type": (p.payload or {}).get("type", ""),
            "tags": (p.payload or {}).get("tags", []),
            "created_iso": (p.payload or {}).get("created_iso", ""),
            "score": 0.0,
        }
        for p in points[:limit]
    ]


# ============ 注册 ============

def register_all(r: ToolRegistry):
    """注册长期记忆三工具。risk：写/查为 safe（本地自用），删为 sensitive（不可逆，需确认）。"""
    r.register(Tool(
        name="memory_add",
        description=(
            "写入一条长期记忆。用于记住重要事实、用户偏好、经验教训、"
            "任务总结、长期画像等需要跨会话保留的内容。"
            "type 四选一：memory=客观事实/对话事件/说过的话，"
            "experience=经验教训/踩过的坑/解决套路，preference=偏好/习惯/约定，"
            "profile=长期画像/稳定身份事实（如'我是谁/用的工具/作息习惯'，每轮常驻注入）。"
            "相同内容（同文本同来源）不会重复写入。"
            "tags 建议 1-3 个便于检索。sensitivity=high 表示敏感内容（默认 low）。"
            "注意：内容若来自 Obsidian 笔记（「笔记」），只记录笔记位置与重点摘要"
            "（如'在 项目/xxx.md 里记录了 yyy 要点'），不要把笔记全文复制进记忆。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "要记住的内容（原文）"},
                "type": {"type": "string", "description": "记忆类型: memory/experience/preference/profile", "default": "memory"},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "标签列表，便于分类检索"},
                "sensitivity": {"type": "string", "description": "敏感度: low/high", "default": "low"},
                "source": {"type": "string", "description": "来源标注，建议填写（便于日后按来源检索/清理），默认 agent"},
                "round_id": {"type": "string", "description": "溯源轮次标识，自动沉淀由系统填充，一般无需填写"},
            },
            "required": ["text"],
        },
        risk="safe",
        timeout=60,
        fn=_memory_add,
    ))
    r.register(Tool(
        name="memory_search",
        description=(
            "语义检索长期记忆。当需要回忆之前记住的事、查经验教训、"
            "确认用户偏好/画像时使用。支持按类型/最近天数/敏感度/标签过滤。"
            "type=experience 可专门查经验；type=profile 可查长期画像；days=N 查最近 N 天；"
            "默认只检索低敏感记忆，确需高敏感内容请传 sensitivity=high。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "检索的语义问题或关键词"},
                "type": {"type": "string", "description": "过滤类型: memory/experience/preference/profile，空=全部"},
                "top_k": {"type": "integer", "description": "最多返回条数，默认 5，最大 20"},
                "days": {"type": "integer", "description": "只看最近 N 天，0=不限"},
                "sensitivity": {"type": "string", "description": "low=只查低敏感(默认), high=只查高敏感, all=全部"},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "必须同时包含的标签"},
                "round_id": {"type": "string", "description": "溯源过滤：只看某轮自动沉淀的记录（排查污染用，一般不用）"},
            },
            "required": ["query"],
        },
        risk="safe",
        timeout=60,
        fn=_memory_search,
    ))
    r.register(Tool(
        name="memory_delete",
        description=(
            "删除长期记忆（不可逆，需用户确认）。可按 id 精确删除，"
            "或按 type/tags/source/round_id 批量删除。至少提供一种条件。"
            "source 按来源删除：如预灌档案的 [档案] 文件名，可用于清理整批导入内容。"
            "round_id 按轮次删除：可清理某轮自动沉淀写入的记录（记忆防污染溯源清理）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "ids": {"type": "array", "items": {"type": "string"}, "description": "要删除的记忆 id 列表"},
                "type": {"type": "string", "description": "按类型删除: memory/experience/preference/profile"},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "按标签删除（同时包含）"},
                "source": {"type": "string", "description": "按来源精确删除，如 [档案] 04_技术栈全景档案.md"},
                "round_id": {"type": "string", "description": "按轮次精确删除（溯源清理某轮自动沉淀）"},
            },
            "required": [],
        },
        risk="sensitive",
        timeout=30,
        fn=_memory_delete,
    ))
