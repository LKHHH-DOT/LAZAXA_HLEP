# -*- coding: utf-8 -*-
"""窗口与应用控制工具集（批次 C · 移植自 AIPC tools/open_app.py + core/windows_api.py）。

能力：
  - open_app：打开应用/网址/文件（支持中文名映射 + PATH 查找）
  - window_control：激活/最小化/最大化/恢复/关闭窗口（按标题模糊匹配）

实现要点：
  - 窗口控制走 Win32 API（ctypes 纯标准库），无需 pywinauto
  - 写操作统一 risk="sensitive" 走审批
  - open_app 对 target 做注入黑名单校验；window_control 动作白名单
  - 返回统一 ToolResult，不裸抛
"""
import json
import os
import re
import subprocess
import webbrowser

from ..registry import Tool, ToolResult

# 常见应用映射（中文/别名 -> 可执行名或协议）
_APP_MAPPING = {
    "记事本": "notepad.exe", "notepad": "notepad.exe",
    "计算器": "calc.exe", "calc": "calc.exe",
    "命令提示符": "cmd.exe", "cmd": "cmd.exe", "终端": "wt.exe",
    "资源管理器": "explorer.exe", "explorer": "explorer.exe",
    "设置": "ms-settings:", "控制面板": "control",
    "任务管理器": "taskmgr.exe",
    "word": "WINWORD.EXE", "excel": "EXCEL.EXE", "powerpoint": "POWERPNT.EXE",
    "微信": "WeChat", "wechat": "WeChat", "钉钉": "DingTalk", "qq": "QQ",
    "腾讯会议": "TencentMeeting",
}

# 用户电脑自定义工具（对应 docs/工具.txt，2026-08-17 接入 computer-tools 技能）
# 中文名/别名 -> 完整路径；open_app 按名字即可打开
_USER_TOOLS = {
    "超智工具": r"D:\Users\Hasee\Desktop\other_work\TRAEpj\超智工具",
    "网站转址器": r"D:\Users\Hasee\Desktop\other_work\TRAEpj\网站转址器",
    "游戏串流": r"D:\Allapp\GameViewer\GameViewer.exe",
    "gameviewer": r"D:\Allapp\GameViewer\GameViewer.exe",
    "opencode": r"D:\Allapp\OpenCode\opencode-cli.exe",
    "inkscape": r"D:\Allapp\inkscape\bin\inkscape.exe",
    "krita": r"D:\Allapp\Krita (x64)\bin\krita.exe",
    "blender": r"D:\Allapp\blender\blender.exe",
    "upbge": r"D:\Allapp\upbge-0.52-alpha-windows-x86_64-2026-04-26\bin\Release\blender.exe",
    "openplc": r"C:\Users\Hasee\AppData\Local\Programs\open-plc-editor\OpenPLC Editor.exe",
    "obsidian": r"D:\Allapp\obsidian\Obsidian.exe",
    "vlc": r"D:\Allapp\VLC\vlc.exe",
    "ffmpeg": r"C:\ffmpeg\ffmpeg-2026-02-15-git-33b215d155-essentials_build\bin\ffmpeg.exe",
}

# open_app 注入黑名单：命中直接拒绝
_OPEN_APP_FORBIDDEN = re.compile(r"[;&|`]|^(del|rmdir|format|shutdown|reg)\b", re.IGNORECASE)

# window_control 允许的动作
_WIN_ACTIONS = {"activate", "minimize", "maximize", "restore", "close"}

# 打开应用后自动置前的窗口标题关键字（exe 基名 -> 标题关键字列表）
# 解决"应用开在助手窗口后面 → 键盘输入/截图落到错误窗口"的问题
_APP_TITLE_KEYWORDS = {
    "notepad.exe": ["记事本", "Notepad"],
    "calc.exe": ["计算器", "Calculator"],
    "cmd.exe": ["命令提示符", "Command Prompt"],
    "wt.exe": ["Windows Terminal", "终端"],
    "explorer.exe": ["资源管理器", "File Explorer"],
    "taskmgr.exe": ["任务管理器", "Task Manager"],
    "control.exe": ["控制面板", "Control Panel"],
}

# 最近一次成功激活/打开应用的窗口标题（供 keyboard_type 做兜底前台校验）
_last_target = ""


def _last_target_title() -> str:
    """返回最近一次成功激活/打开应用的窗口标题（空串表示尚无目标）。"""
    return _last_target


# 窗口标题中英别名：中文用户习惯说"记事本"，但系统可能显示英文 "Notepad"。
# 校验/查找时任一别名命中即算匹配，避免因系统语言导致误拒（已踩坑）。
_TITLE_ALIASES = {
    "记事本": ("记事本", "notepad"),
    "计算器": ("计算器", "calculator"),
    "命令提示符": ("命令提示符", "cmd"),
    "控制面板": ("控制面板", "control panel"),
    "任务管理器": ("任务管理器", "task manager"),
    "资源管理器": ("资源管理器", "file explorer"),
}


def _title_keywords(title: str) -> list:
    """展开标题关键字：原名 + 中英别名，用于窗口查找/前台校验。"""
    kws = [title]
    kws.extend(_TITLE_ALIASES.get(title, ()))
    return kws


# ============ 窗口控制（Win32 API，ctypes 精简版） ============

class _Windows:
    """Win32 窗口 API 精简封装（只保留 window_control 需要的部分）。"""

    def __init__(self):
        import ctypes
        self._ctypes = ctypes
        self.user32 = ctypes.windll.user32

    def _title_of(self, hwnd) -> str:
        length = self.user32.GetWindowTextLengthW(hwnd)
        if not length:
            return ""
        buf = self._ctypes.create_unicode_buffer(length + 1)
        self.user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value

    def find(self, title: str):
        """按标题模糊匹配第一个可见窗口，返回 (hwnd, 标题)；未找到返回 (None, '')。"""
        import ctypes
        result = {"hwnd": None, "title": ""}

        def cb(hwnd, _lParam):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            t = self._title_of(hwnd)
            if t and title.lower() in t.lower():
                result["hwnd"] = hwnd
                result["title"] = t
                return False  # 找到即停
            return True

        CBFN = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        self.user32.EnumWindows(CBFN(cb), 0)
        return result["hwnd"], result["title"]

    def find_all(self, title: str) -> list:
        """按标题模糊匹配**所有**可见窗口，返回 [(hwnd, 标题)] 列表。

        与 find()（取第一个即停）的区别：同名多窗口（如开两个"微信"）时
        用于歧义消解——ui_list/ui_find 靠它给出候选清单，而不是含糊报错。
        """
        import ctypes
        result = []

        def cb(hwnd, _lParam):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            t = self._title_of(hwnd)
            if t and title.lower() in t.lower():
                result.append((hwnd, t))
            return True

        CBFN = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        self.user32.EnumWindows(CBFN(cb), 0)
        return result

    def enum_visible(self, only_titled: bool = True) -> list:
        """枚举可见顶层窗口，返回 [{"hwnd","title","pid"}]（供 list_apps 用）。

        only_titled=True 时跳过无标题窗口（多为后台辅助窗口，噪声大）。
        """
        import ctypes
        result = []

        def cb(hwnd, _lParam):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            t = self._title_of(hwnd)
            if only_titled and not t:
                return True
            pid = ctypes.c_ulong(0)
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            result.append({"hwnd": int(hwnd), "title": t, "pid": int(pid.value)})
            return True

        CBFN = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        self.user32.EnumWindows(CBFN(cb), 0)
        return result

    def activate(self, hwnd) -> bool:
        # 最小化时先恢复，再置前台
        if self.user32.IsIconic(hwnd):
            self.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        # 经典技巧：模拟按一次 Alt 键，绕过 Windows 的前台锁定限制
        # （后台进程直接 SetForegroundWindow 经常被系统拒绝，先触发一次
        #   键盘事件刷新前台许可即可成功，pyautogui 等库同样依赖此 hack）
        self.user32.keybd_event(0x12, 0, 0, 0)  # VK_MENU down
        self.user32.keybd_event(0x12, 0, 2, 0)  # VK_MENU up (KEYEVENTF_KEYUP)
        return bool(self.user32.SetForegroundWindow(hwnd))

    def minimize(self, hwnd) -> bool:
        return bool(self.user32.ShowWindow(hwnd, 6))  # SW_MINIMIZE

    def maximize(self, hwnd) -> bool:
        return bool(self.user32.ShowWindow(hwnd, 3))  # SW_MAXIMIZE

    def restore(self, hwnd) -> bool:
        return bool(self.user32.ShowWindow(hwnd, 9))  # SW_RESTORE

    def close(self, hwnd) -> bool:
        return bool(self.user32.PostMessageW(hwnd, 0x0010, 0, 0))  # WM_CLOSE


_windows = None


def _get_windows() -> _Windows:
    """懒加载 Windows API 封装。"""
    global _windows
    if _windows is None:
        _windows = _Windows()
    return _windows


# ============ 工具实现（fn(**args) 具名参数，registry.execute 解包调用） ============

def _open_app(target: str | None = None) -> ToolResult:
    """打开应用/网址/文件。"""
    target = str(target or "").strip()
    if not target:
        return ToolResult.err_result("缺少参数 target（应用名/网址/文件路径）")
    if _OPEN_APP_FORBIDDEN.search(target):
        return ToolResult.err_result(f"target 含危险字符，已拒绝执行: {target}")
    try:
        low = target.lower()
        # 网址
        if low.startswith(("http://", "https://", "www.")):
            url = target if "://" in target else "https://" + target
            webbrowser.open(url)
            return ToolResult.ok_result(f"已打开网址: {url}", brief=f"打开网址 {url}")
        # 本地文件 / 目录（必须优先：Windows 盘符路径含 ":"，会误入协议分支）
        if os.path.exists(target):
            os.startfile(target)
            return ToolResult.ok_result(f"已打开: {target}", brief=f"打开 {target}")
        # 协议（ms-settings: 等；文件路径已在上面排除）
        if ":" in target:
            os.startfile(target)
            return ToolResult.ok_result(f"已打开: {target}", brief=f"打开 {target}")
        # 已知映射（内置 + 用户自定义工具表）
        exe = (_APP_MAPPING.get(low) or _APP_MAPPING.get(target)
               or _USER_TOOLS.get(low) or _USER_TOOLS.get(target))
        if not exe:
            # 按 PATH 查找
            try:
                r = subprocess.run(["where", target], capture_output=True, text=True, timeout=10)
                if r.returncode == 0 and r.stdout.strip():
                    exe = r.stdout.strip().splitlines()[0]
            except Exception:
                exe = None
        if not exe:
            return ToolResult.err_result(
                f"无法找到应用 '{target}'。可用内置名称：记事本/计算器/微信/word/excel 等；"
                "用户工具：blender/inkscape/krita/obsidian/vlc/ffmpeg/opencode/upbge/openplc/"
                "游戏串流/超智工具/网站转址器（详见 computer-tools 技能）；"
                "或提供完整路径（如 D:\\xxx\\app.exe）。")
        if os.path.isdir(exe):
            os.startfile(exe)  # 映射目标是目录（如超智工具项目）→ 打开资源管理器
            return ToolResult.ok_result(f"已打开目录: {exe}", brief=f"打开 {exe}")
        subprocess.Popen(exe, shell=True)
        # 自动置前刚打开的应用窗口：否则应用会开在助手窗口后面，
        # 后续 keyboard_type / screen_capture 会落到错误窗口（已踩坑）。
        global _last_target
        activated = ""
        title_keys = _APP_TITLE_KEYWORDS.get(os.path.basename(str(exe)).lower())
        if title_keys:
            import time
            win = _get_windows()
            for _ in range(8):          # 最多等约 3 秒窗口出现
                time.sleep(0.4)
                for kw in title_keys:
                    hwnd, real = win.find(kw)
                    if hwnd:
                        if win.activate(hwnd):
                            activated = real
                            _last_target = real
                        break
                if activated:
                    break
        note = ("，已置前窗口 '%s'" % activated) if activated \
            else "（未找到窗口，可用 window_control 激活后再操作）"
        return ToolResult.ok_result("已打开应用: %s%s" % (target, note),
                                    brief="打开 %s" % target)
    except Exception as e:
        return ToolResult.err_result(f"打开 '{target}' 失败: {e}")


def _window_control(title: str = "", action: str = "activate") -> ToolResult:
    """激活/最小化/最大化/恢复/关闭窗口（按标题模糊匹配）。"""
    title = str(title or "").strip()
    action = str(action or "activate").strip().lower()
    if not title:
        return ToolResult.err_result("缺少参数 title（窗口标题关键字，可用 screen_ocr 查看窗口标题）")
    if action not in _WIN_ACTIONS:
        return ToolResult.err_result(f"未知动作 '{action}'，可用: {sorted(_WIN_ACTIONS)}")
    try:
        win = _get_windows()
        hwnd, real_title = None, ""
        for kw in _title_keywords(title):   # 中英别名任一命中即可
            hwnd, real_title = win.find(kw)
            if hwnd:
                break
        if hwnd is None:
            return ToolResult.err_result(f"未找到标题含 '{title}' 的可见窗口。可用 screen_ocr 查看当前打开的窗口标题。")
        ok = {"activate": win.activate, "minimize": win.minimize,
              "maximize": win.maximize, "restore": win.restore,
              "close": win.close}[action](hwnd)
        if not ok:
            return ToolResult.err_result(f"窗口操作失败（可能被系统拦截）: {action} '{real_title}'")
        if action == "activate":
            global _last_target
            _last_target = real_title   # 记录目标窗口，供 keyboard_type 兜底前台校验
        out = json.dumps({"action": action, "hwnd": hwnd, "title": real_title}, ensure_ascii=False)
        return ToolResult.ok_result(out, brief=f"{action} '{real_title}'")
    except Exception as e:
        return ToolResult.err_result(f"窗口操作失败: {e}")


def _list_apps(only_titled: bool = True) -> ToolResult:
    """列出当前可见窗口（标题 + 句柄 + 进程号），供定位/确认目标应用。

    比 UI 控件树更轻：只枚举顶层窗口，用于「现在开着哪些程序/窗口标题是什么」，
    再据此决定 window_control 激活谁、或给 ui_list 传什么 window_title。
    """
    try:
        wins = _get_windows().enum_visible(bool(only_titled))
        items = []
        for w in wins:
            items.append({"title": w["title"] or "(无标题)",
                          "hwnd": w["hwnd"], "pid": w["pid"]})
        if not items:
            return ToolResult.ok_result(
                json.dumps({"count": 0, "items": []}, ensure_ascii=False),
                brief="当前无可见窗口")
        out = {"count": len(items), "items": items}
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False)[:6000],
                                    brief=f"当前 {len(items)} 个可见窗口")
    except Exception as e:
        return ToolResult.err_result(f"枚举窗口失败: {e}")


# ============ 注册 ============

def register_all(r):
    """注册窗口与应用控制工具（批次 C 阶段 2）。"""
    r.register(Tool(
        name="open_app",
        description=("打开应用/网址/文件。支持中文名（记事本/微信/计算器等）、"
                     "可执行名（notepad.exe）、完整路径或 http 网址。"
                     "此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "target": {"type": "string", "description": "应用名/网址/文件路径"},
        }, "required": ["target"]},
        risk="sensitive", timeout=20, fn=_open_app, screen_lock=True,
    ))
    r.register(Tool(
        name="window_control",
        description=("控制窗口：激活(activate)/最小化(minimize)/最大化(maximize)/"
                     "恢复(restore)/关闭(close)，按标题模糊匹配。"
                     "标题可用 screen_ocr 查看。此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "title": {"type": "string", "description": "窗口标题关键字"},
            "action": {"type": "string", "description": "activate/minimize/maximize/restore/close，默认 activate"},
        }, "required": ["title"]},
        risk="sensitive", timeout=20, fn=_window_control, screen_lock=True,
    ))
    r.register(Tool(
        name="list_apps",
        description=("列出当前可见的桌面窗口（标题 + 句柄 + 进程号），用于「现在开着哪些程序」"
                     "及确认准确窗口标题。只读、不影响系统状态。"
                     "建议：先用它确认标题，再用 window_control 激活目标窗口，"
                     "然后 ui_list 读该窗口控件树。"),
        parameters={"type": "object", "properties": {
            "only_titled": {"type": "boolean",
                            "description": "true（默认）=只列有标题的窗口；false=含无标题窗口"},
        }},
        risk="safe", timeout=15, fn=_list_apps,
    ))
