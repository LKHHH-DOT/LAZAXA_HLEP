# -*- coding: utf-8 -*-
"""结构化规划工具（M4b · 借 dsh goal/plan 包）。

- plan_create(goal, steps)：建立执行计划（覆盖同轮旧计划）
- plan_update(step_id, status, note)：按状态机推进某一步，返回最新全量计划
- plan_get()：查看当前计划

设计：
- 工具从 task_context.current_round_id 取轮次；取不到（测试/裸调）明确报错，绝不写脏数据。
- 每次变更落 M3 agent_events 事件账本（plan_store 内部做，失败静默）。
- 全部 risk=safe，不触发审批。
"""
from ... import config  # noqa: F401
from .. import task_context
from ..plan_store import PLAN_STATES, plan_store
from ..registry import Tool, ToolResult


def _current_round() -> str:
    rid = task_context.get_round_id()
    if not rid:
        raise ValueError(
            "无法确定当前任务轮次（上下文未绑定）。plan_* 只能由 agent 循环内的"
            "根任务调用；在测试或外部直接调用时请先设置任务上下文。")
    return rid


def _plan_create(goal: str, steps: list) -> ToolResult:
    """建立结构化执行计划。"""
    goal = (goal or "").strip()
    if not goal:
        return ToolResult.err_result("plan_create 需要 goal（任务目标）")
    if not steps:
        return ToolResult.err_result(
            "plan_create 需要 steps 非空列表，如 [{\"title\": \"步骤一\"}, ...]")
    try:
        rid = _current_round()
    except ValueError as e:
        return ToolResult.err_result(str(e))
    try:
        plan = plan_store.create(rid, goal, steps)
    except Exception as e:
        return ToolResult.err_result(f"建立计划失败：{type(e).__name__}: {e}")
    return ToolResult.ok_result(
        f"执行计划已建立（目标：{plan.goal}）：\n{plan.render()}\n"
        "每完成一步立即用 plan_update 标记进度；计划有变用 plan_update 调整。",
        brief=f"📋 计划已建 {len(plan.steps)} 步")


def _plan_update(step_id: str, status: str, note: str = "") -> ToolResult:
    """推进计划某一步的状态（pending→in_progress→done/skipped/blocked）。"""
    if not step_id or not status:
        return ToolResult.err_result("plan_update 需要 step_id 与 status")
    try:
        rid = _current_round()
    except ValueError as e:
        return ToolResult.err_result(str(e))
    plan, err = plan_store.update(rid, step_id, status, note)
    if err:
        return ToolResult.err_result(err)
    return ToolResult.ok_result(
        f"步骤 {step_id} 已更新为「{status}」。当前计划：\n{plan.render()}\n"
        "全部步骤完成后即可向用户总结收尾。",
        brief=f"✅ {step_id} → {status}")


def _plan_get() -> ToolResult:
    """查看当前执行计划。"""
    rid = task_context.get_round_id()
    plan = plan_store.get(rid) if rid else None
    if plan is None:
        return ToolResult.ok_result(
            "当前没有结构化计划。若任务环节多（≥3 步）或步骤不确定，"
            "先调用 plan_create 建立计划再执行。", brief="无计划")
    return ToolResult.ok_result(plan.render(), brief="📋 查看计划")


def register_all(r):
    """注册结构化规划三工具。"""
    r.register(Tool(
        name="plan_create",
        display_name="📋 建执行计划",
        description=(
            "为一个复杂任务建立**结构化执行计划**（目标 + 有序步骤列表）。"
            "适用：任务有 3 个以上环节、或执行步骤不确定、或用户要求'先规划再动手'时，"
            "在动手前先建计划；此后每轮系统会自动把【当前执行计划】注入给你看，"
            "每完成一步立即用 plan_update 标记进度，全部完成即收尾。"
            "同一任务重复调用会覆盖旧计划（重建）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "goal": {"type": "string",
                         "description": "任务目标（≤200 字，一句话讲清要达成什么）"},
                "steps": {"type": "array", "items": {"type": "object",
                          "properties": {"title": {"type": "string",
                                    "description": "该步骤内容（≤80 字）"}},
                          "required": ["title"]},
                          "description": "有序步骤列表（≤12 步；按依赖先后排列，每步一个验收点）"},
            },
            "required": ["goal", "steps"],
        },
        risk="safe",
        timeout=15,
        fn=_plan_create,
    ))
    r.register(Tool(
        name="plan_update",
        display_name="🔄 推进计划",
        description=(
            "更新计划中某一步的状态：pending=待办 / in_progress=进行中 / "
            "done=已完成 / skipped=跳过 / blocked=受阻。"
            "状态机只允许合理流转（如 进行中→完成/受阻，受阻→恢复，完成→重做）。"
            "每完成一步立即调用，并可在 note 里写一句话验收小结；"
            "返回更新后的**全量计划**，据此判断下一步。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "step_id": {"type": "string",
                            "description": "步骤 id（plan_create 返回的 s1/s2/...）"},
                "status": {"type": "string", "enum": list(PLAN_STATES),
                           "description": "目标状态"},
                "note": {"type": "string", "default": "",
                         "description": "该步验收小结 / 受阻原因（≤200 字，可选）"},
            },
            "required": ["step_id", "status"],
        },
        risk="safe",
        timeout=15,
        fn=_plan_update,
    ))
    r.register(Tool(
        name="plan_get",
        display_name="👀 查计划",
        description=(
            "查看当前执行计划全文（目标 + 各步状态 + 进度）。"
            "适用：想确认自己规划到哪、下一步该做什么，或用户问'你的计划是什么'。"
        ),
        parameters={"type": "object", "properties": {}},
        risk="safe",
        timeout=15,
        fn=_plan_get,
    ))
