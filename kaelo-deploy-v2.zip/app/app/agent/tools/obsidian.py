# -*- coding: utf-8 -*-
"""Obsidian 笔记工具（对接方案 C：Local REST API 插件）。

依赖：Obsidian 需安装社区插件 "Local REST API"（默认端口 27123）。
配置读取：插件 data.json（.obsidian/plugins/local-rest-api/data.json）里的
apiKey / port 自动读取，无需写进 .env；插件未安装/未启用时给出明确安装提示，不崩溃。

风险分级（配合三级权限体系）：
  - 读/搜/列 → safe    （只读，自动执行）
  - 写/追加   → sensitive（省心模式下自动放行，标准模式弹窗）
  - 删除      → dangerous（不可逆，任何模式人工确认）
"""
import json
import os
import ssl
import urllib.parse
import urllib.request

from ... import config
from ..registry import Tool, ToolResult

_MAX_READ_CHARS = 8000   # 单篇笔记最多返回字符数
_MAX_SEARCH = 20         # 搜索最多返回条数

# 插件用自签名证书：本地回环 + Bearer 鉴权，跳过证书校验（等价 curl -k）
_SSL_UNVERIFIED = ssl._create_unverified_context()


def _plugin_config() -> dict | None:
    """读取插件配置（apiKey/port）。文件不存在或损坏返回 None。"""
    try:
        with open(config.OBSIDIAN_PLUGIN_DATA, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def _request(method: str, path: str, body: str | None = None) -> tuple:
    """向 Obsidian Local REST API 发请求。返回 (ok, text/error)。"""
    cfg = _plugin_config()
    if cfg is None:
        return False, (
            "Obsidian Local REST API 插件未就绪：请先在 Obsidian 安装并启用「Local REST API」"
            "插件（设置 → 第三方插件 → 关闭安全模式 → 浏览 → Local REST API → 安装并启用），"
            "然后重试。")
    port = int(cfg.get("port") or config.OBSIDIAN_DEFAULT_PORT)
    api_key = str(cfg.get("apiKey") or "")
    url = f"{config.OBSIDIAN_BASE_URL}:{port}{path}"
    req = urllib.request.Request(url, method=method)
    req.add_header("Authorization", f"Bearer {api_key}")
    req.add_header("Content-Type", "text/markdown")
    if body is not None:
        req.data = body.encode("utf-8")
    try:
        with urllib.request.urlopen(req, timeout=15, context=_SSL_UNVERIFIED) as resp:
            return True, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", errors="replace")[:300]
        return False, f"Obsidian API 错误 {e.code}: {msg}"
    except Exception as e:
        return False, f"Obsidian 连接失败: {type(e).__name__}: {e}"


def _vault_path(note_path: str) -> str:
    """笔记路径规范成 vault 相对路径：去首尾斜杠、自动补 .md、URL 编码。"""
    p = note_path.strip().strip("/").strip("\\")
    if not p:
        return ""
    if not p.lower().endswith(".md"):
        p += ".md"
    return urllib.parse.quote(p)


def _obsidian_list(path: str = "") -> ToolResult:
    """列出笔记库内容（可指定目录）。"""
    folder = str(path or "").strip().strip("/")
    # 本插件版本：GET /vault/{目录} 返回该目录内容，GET /vault/ 返回根目录
    p = f"/vault/{urllib.parse.quote(folder)}" if folder else "/vault/"
    ok, text = _request("GET", p)
    if not ok:
        # 插件对空目录/不存在目录返回 404：按"空"处理而非报错
        if "404" in text:
            return ToolResult.ok_result("（目录为空或不存在）", brief="空目录")
        return ToolResult.err_result(text)
    try:
        data = json.loads(text)
    except Exception:
        return ToolResult.err_result(f"解析响应失败: {text[:200]}")
    files = data.get("files") if isinstance(data, dict) else (data or [])
    if not files:
        return ToolResult.ok_result("（该目录为空）", brief="空目录")
    lines = []
    for f in files:
        name = str(f)
        if name.endswith("/"):     # 目录项带尾斜杠
            lines.append("📁 " + name.rstrip("/"))
        else:
            lines.append("📄 " + name)
    return ToolResult.ok_result("\n".join(lines), brief=f"列出 {len(files)} 项")


def _obsidian_read(note: str, limit: int = 8000) -> ToolResult:
    """读取一篇笔记的内容（Markdown）。"""
    if not note:
        return ToolResult.err_result("参数缺失：note（笔记相对路径，如 日记/2026-08-16.md）")
    ok, text = _request("GET", f"/vault/{_vault_path(note)}")
    if not ok:
        return ToolResult.err_result(text)
    if len(text) > _MAX_READ_CHARS:
        text = text[:_MAX_READ_CHARS] + f"\n\n…（内容过长已截断，全文 {len(text)} 字符）"
    return ToolResult.ok_result(text or "（空笔记）", brief=f"读取 {note}")


def _obsidian_write(note: str, content: str = "") -> ToolResult:
    """创建/覆盖一篇笔记（UTF-8 Markdown）。"""
    if not note:
        return ToolResult.err_result("参数缺失：note（笔记相对路径）")
    ok, text = _request("PUT", f"/vault/{_vault_path(note)}", body=str(content))
    if not ok:
        return ToolResult.err_result(text)
    return ToolResult.ok_result(f"已写入笔记：{note}（{len(content)} 字符）", brief=f"写入 {note}")


def _obsidian_append(note: str, content: str = "") -> ToolResult:
    """向笔记末尾追加内容（笔记不存在则创建）。"""
    if not note or not content:
        return ToolResult.err_result("参数缺失：note（笔记相对路径）与 content（追加内容）")
    ok, text = _request("POST", f"/vault/{_vault_path(note)}", body=str(content))
    if not ok:
        return ToolResult.err_result(text)
    return ToolResult.ok_result(f"已追加到笔记：{note}", brief=f"追加 {note}")


def _obsidian_search(query: str, max_results: int = 10) -> ToolResult:
    """全文搜索笔记内容。query 用关键词或短语，返回匹配的笔记路径。"""
    query = str(query or "").strip()
    if not query:
        return ToolResult.err_result("参数缺失：query（搜索关键词）")
    max_results = max(1, min(int(max_results or 10), _MAX_SEARCH))
    q = urllib.parse.quote(query)
    ok, text = _request("POST", f"/search/simple/?query={q}&contextLength=80")
    if not ok:
        return ToolResult.err_result(text)
    try:
        hits = json.loads(text)[:max_results]
    except Exception:
        return ToolResult.err_result(f"解析响应失败: {text[:200]}")
    if not hits:
        return ToolResult.ok_result("没有找到匹配的笔记。", brief="搜索 0 条")
    lines = []
    for h in hits:
        path = h.get("filename") or h.get("path") or ""
        # matches 为命中片段数组，每项含 context（上下文文本）
        ctxs = h.get("matches") or []
        ctx = ""
        if isinstance(ctxs, list) and ctxs:
            ctx = str(ctxs[0].get("context", ""))
        ctx = ctx[:120].replace("\n", " ")
        lines.append(f"▸ {path}\n  …{ctx}…")
    brief = f"命中 {len(hits)} 篇"
    return ToolResult.ok_result("\n".join(lines), brief=brief)


def _obsidian_delete(note: str) -> ToolResult:
    """删除一篇笔记（不可逆，需用户确认）。"""
    if not note:
        return ToolResult.err_result("参数缺失：note（笔记相对路径）")
    ok, text = _request("DELETE", f"/vault/{_vault_path(note)}")
    if not ok:
        return ToolResult.err_result(text)
    return ToolResult.ok_result(f"已删除笔记：{note}", brief=f"删除 {note}")


def _walk_vault_md() -> list:
    """遍历 vault 下全部 .md 笔记（排除 .obsidian 目录）。

    返回 [(相对路径, 绝对路径)]，按路径排序。直接读文件系统（比 REST API 稳，无分页）。
    """
    base = config.OBSIDIAN_VAULT_PATH
    if not os.path.isdir(base):
        return []
    files = []
    for root, dirs, names in os.walk(base):
        dirs[:] = [d for d in dirs if d != ".obsidian"]
        for n in names:
            if n.lower().endswith(".md"):
                full = os.path.join(root, n)
                rel = os.path.relpath(full, base).replace("\\", "/")
                files.append((rel, full))
    return sorted(files)


def _obsidian_sync_kb() -> ToolResult:
    """把整个笔记库同步进知识库（独立库 kb='obsidian'，可被 kb_query 检索）。"""
    from ... import rag

    files = _walk_vault_md()
    if not files:
        return ToolResult.err_result("笔记库为空或目录不存在，没有可同步的笔记")
    chunks, srcs = [], []
    for rel, full in files:
        try:
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except Exception:
            continue
        for c in rag._split_text(text):
            chunks.append(c)
            srcs.append("obsidian://" + rel)
    if not chunks:
        return ToolResult.err_result("笔记内容为空，无法同步")
    # 全量重建（vault 规模小，重建最干净，避免旧块残留）
    for fn in ("vectors.npy", "meta.json"):
        fp = os.path.join(config.OBSIDIAN_STORE_DIR, fn)
        if os.path.exists(fp):
            os.remove(fp)
    store = rag.VecStore(config.OBSIDIAN_STORE_DIR).load()
    store.add_with_sources(chunks, srcs)
    return ToolResult.ok_result(
        f"已同步 {len(files)} 篇笔记、{len(chunks)} 个片段到知识库（kb='obsidian'）。"
        f"之后可直接问我笔记里记过的内容。",
        brief=f"同步 {len(files)} 篇/{len(chunks)} 块")


# ============ 注册 ============

def register_all(r):
    """注册 Obsidian 六工具。display_name 用中文（前端展示）；描述绑定"笔记"语义。

    重要：Obsidian 笔记库在用户口中就叫「笔记」——用户说"记一下笔记 / 帮我记个
    待办 / 写篇日记 / 查我的笔记"，就应使用这里的工具，无需用户说"Obsidian"。
    """
    r.register(Tool(
        name="obsidian_list",
        display_name="📚 笔记列表",
        description=(
            "列出 Obsidian 笔记库（用户口中的「笔记」）中的文件与文件夹。"
            "不带 path 列出根目录，传 path 可列指定文件夹（如 日记）。"
            "用于了解笔记库结构，如用户说'看看我的笔记有哪些'。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "要列出的文件夹路径（相对库根，可选）"},
            },
            "required": [],
        },
        risk="safe", timeout=30, fn=_obsidian_list,
    ))
    r.register(Tool(
        name="obsidian_read",
        display_name="📖 读笔记",
        description=(
            "读取 Obsidian 笔记（用户口中的「笔记」）内容（Markdown 原文）。"
            "note 为库内相对路径，如 项目/周报.md 或 日记/2026-08-16.md，可省略 .md 后缀。"
            "用户说'打开/看看/读一下那篇笔记'时使用。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "笔记相对路径（库根为起点）"},
                "limit": {"type": "integer", "description": "最多返回字符数，默认 8000"},
            },
            "required": ["note"],
        },
        risk="safe", timeout=30, fn=_obsidian_read,
    ))
    r.register(Tool(
        name="obsidian_write",
        display_name="📝 写笔记",
        description=(
            "创建或覆盖一篇 Obsidian 笔记（用户口中的「笔记」，Markdown）。"
            "这是用户说'记一下/记个笔记/写篇笔记/记个待办/写日记'时的首选工具！"
            "若笔记已存在则整体覆盖，需要保留旧内容请先用 obsidian_read 读取。"
            "note 为库内相对路径。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "笔记相对路径（可带子文件夹，如 日记/2026-08-16.md）"},
                "content": {"type": "string", "description": "笔记完整内容（Markdown）"},
            },
            "required": ["note", "content"],
        },
        risk="sensitive", timeout=30, fn=_obsidian_write,
    ))
    r.register(Tool(
        name="obsidian_append",
        display_name="✍️ 追加笔记",
        description=(
            "向 Obsidian 笔记（用户口中的「笔记」）末尾追加内容（不存在则创建）。"
            "适合持续记录、日志、待办追加等场景，如'把 xxx 追加到今天的日记里'。"
            "note 为库内相对路径。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "笔记相对路径"},
                "content": {"type": "string", "description": "要追加的 Markdown 内容"},
            },
            "required": ["note", "content"],
        },
        risk="sensitive", timeout=30, fn=_obsidian_append,
    ))
    r.register(Tool(
        name="obsidian_search",
        display_name="🔍 搜笔记",
        description=(
            "全文搜索 Obsidian 笔记（用户口中的「笔记」）内容（关键词/短语），"
            "返回命中笔记路径与上下文片段。用户说'我记在哪了/找找我的笔记里有没有'时使用。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词或短语"},
                "max_results": {"type": "integer", "description": "最多返回条数，默认 10，最大 20"},
            },
            "required": ["query"],
        },
        risk="safe", timeout=30, fn=_obsidian_search,
    ))
    r.register(Tool(
        name="obsidian_delete",
        display_name="🗑 删笔记",
        description=(
            "删除一篇 Obsidian 笔记（用户口中的「笔记」，不可逆操作，系统会弹出确认）。"
            "note 为库内相对路径。删除前建议先用 obsidian_search/obsidian_read 确认目标。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "要删除的笔记相对路径"},
            },
            "required": ["note"],
        },
        risk="dangerous", timeout=30, fn=_obsidian_delete,
    ))
    r.register(Tool(
        name="obsidian_sync_kb",
        display_name="📤 同步笔记到知识库",
        description=(
            "把整个笔记库（用户口中的「笔记」）同步进知识库（独立库 kb='obsidian'）。"
            "同步后用户提问时可以检索到笔记内容，如'我的笔记里记过 xxx 吗'。"
            "用户明确说'把笔记同步到知识库/同步笔记'时才调用；平时笔记用 obsidian_search 搜索即可。"
            "注意：这是全量重建，会覆盖上次同步结果，耗时视笔记量而定。"
        ),
        parameters={
            "type": "object",
            "properties": {},
            "required": [],
        },
        risk="sensitive", timeout=300, fn=_obsidian_sync_kb,
    ))
