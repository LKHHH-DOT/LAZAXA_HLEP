# -*- coding: utf-8 -*-
"""办公文档工具（批次 D · 设计书 §4.3 + §7.3）。

能力：
  - Excel：读 / 写 / 汇总（openpyxl，无 Office 也能跑）
  - Word：读 / 生成（python-docx）
  - PDF：文本提取（pdfplumber）
  - run_python_script：模型现写一段 Python，沙箱化执行（限时 + 限工作区 + 默认禁网）

设计原则（对齐项目既有约定）：
  - 懒加载：openpyxl/python-docx/pdfplumber 只在首次调用时才 import，
    后端启动不因办公依赖变慢；缺依赖时返回明确错误提示（同 gui.py 风格）。
  - 风险分级：只读 safe；写操作 sensitive（写前自动生成 .bak 备份，可恢复）；
    run_python_script 归 dangerous（任意代码，任何权限模式都弹窗确认）。
  - 受保护目录：与 files 工具（read_file/write_file/list_dir）保持一致，
    office 工具读写系统/敏感目录直接拒绝（permissions.py 只覆盖那三个工具名，
    这里必须自带检查，防止绕过）。
  - 函数具名参数签名（fn(**args)，registry.execute 解包调用）。
  - 返回统一 ToolResult；任何异常转 ok=False 喂回模型，不裸抛。
"""
import os
import shutil
import subprocess
import sys
import tempfile

from ..registry import Tool, ToolResult
from ... import config


def _protected_check(path: str) -> str | None:
    """受保护目录检查：命中系统/敏感目录返回拒绝原因，否则 None。"""
    if not path:
        return None
    norm = path.replace("\\", "/").lower()
    for d in config.PERMISSION_PROTECTED_DIRS:
        if norm.startswith(d):
            return f"路径在受保护目录内（{d}），已拒绝访问"
    return None


def _backup_file(path: str) -> str:
    """写文件前自动备份为 <path>.bak（仅当原文件存在），返回备份路径。"""
    if os.path.exists(path):
        bak = path + ".bak"
        try:
            shutil.copy2(path, bak)
            return bak
        except Exception:
            return ""
    return ""


def _tail(text: str, limit: int) -> str:
    """保留末尾 limit 字符（错误/结果通常在尾部），并标记截断。"""
    if len(text) <= limit:
        return text
    return f"...[已截断 {len(text) - limit} 字符]...\n" + text[-limit:]


def _cell_str(v) -> str:
    """单元格值转可读文本（None → 空串）。"""
    return "" if v is None else str(v)


# ============ Excel（openpyxl） ============

def _excel_read(path: str, sheet: str = "") -> ToolResult:
    """读取 Excel 指定工作表（默认第一个）全部数据，输出为行列文本。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    if not os.path.isfile(path):
        return ToolResult.err_result(f"文件不存在: {path}")
    try:
        from openpyxl import load_workbook
    except ImportError:
        return ToolResult.err_result("缺少依赖 openpyxl，请先安装：pip install openpyxl")
    try:
        wb = load_workbook(path, data_only=True)
    except Exception as e:
        return ToolResult.err_result(f"无法打开 Excel（可能不是有效 .xlsx 文件）：{e}")
    ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
    rows = []
    for row in ws.iter_rows(values_only=True):
        cells = [_cell_str(c) for c in row]
        if any(c.strip() for c in cells):  # 跳过全空行
            rows.append(cells)
    lines = [f"工作表: {ws.title}　共 {len(rows)} 行 × {ws.max_column} 列"]
    for i, row in enumerate(rows[:200], 1):
        lines.append(f"第{i}行: " + " | ".join(row))
    if len(rows) > 200:
        lines.append(f"… 其余 {len(rows) - 200} 行已省略（如需完整数据请用 run_python_script 或缩小范围）")
    return ToolResult.ok_result("\n".join(lines), brief=f"Excel {len(rows)} 行")


def _excel_summary(path: str) -> ToolResult:
    """汇总 Excel：各工作表名称、行列数、表头与每列统计。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    if not os.path.isfile(path):
        return ToolResult.err_result(f"文件不存在: {path}")
    try:
        from openpyxl import load_workbook
    except ImportError:
        return ToolResult.err_result("缺少依赖 openpyxl，请先安装：pip install openpyxl")
    try:
        wb = load_workbook(path, data_only=True)
    except Exception as e:
        return ToolResult.err_result(f"无法打开 Excel：{e}")
    lines = [f"文件: {os.path.basename(path)}　工作表数: {len(wb.sheetnames)}"]
    for name in wb.sheetnames:
        ws = wb[name]
        header = [c.value for c in ws[1]] if ws.max_row >= 1 else []
        header_txt = " | ".join(_cell_str(c) for c in header)
        lines.append(f"  · {name}：{ws.max_row} 行 × {ws.max_column} 列　表头: {header_txt}")
    return ToolResult.ok_result("\n".join(lines), brief=f"Excel 共 {len(wb.sheetnames)} 个工作表")


def _excel_write(path: str, data, headers=None, sheet: str = "Sheet1") -> ToolResult:
    """把二维数组写入 Excel（headers 为表头行，data 为数据行）。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    if not data:
        return ToolResult.err_result("data 参数不能为空（至少一行数据）")
    try:
        from openpyxl import Workbook
    except ImportError:
        return ToolResult.err_result("缺少依赖 openpyxl，请先安装：pip install openpyxl")
    try:
        bak = _backup_file(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        wb = Workbook()
        ws = wb.active
        ws.title = sheet[:31]  # Excel 工作表名上限 31 字符
        if headers:
            ws.append(headers)
        for row in data:
            if isinstance(row, (list, tuple)):
                ws.append(list(row))
            else:
                ws.append([row])
        wb.save(path)
    except Exception as e:
        return ToolResult.err_result(f"写入 Excel 失败：{e}")
    note = f"，已备份原文件为 .bak" if bak else ""
    return ToolResult.ok_result(f"已写入 {path}（{len(data)} 行数据{note}）",
                                brief=f"写入 Excel {len(data)} 行")


# ============ Word（python-docx） ============

def _word_read(path: str) -> ToolResult:
    """提取 Word 文档（.docx）全部段落与表格文本。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    if not os.path.isfile(path):
        return ToolResult.err_result(f"文件不存在: {path}")
    try:
        from docx import Document
    except ImportError:
        return ToolResult.err_result("缺少依赖 python-docx，请先安装：pip install python-docx")
    try:
        doc = Document(path)
    except Exception as e:
        return ToolResult.err_result(f"无法打开 Word（仅支持 .docx）：{e}")
    lines = [f"段落数: {len(doc.paragraphs)}"]
    for p in doc.paragraphs:
        if p.text.strip():
            lines.append(p.text)
    if doc.tables:
        lines.append(f"\n表格数: {len(doc.tables)}")
        for ti, table in enumerate(doc.tables, 1):
            lines.append(f"[表{ti}]")
            for row in table.rows[:50]:
                lines.append(" | ".join(_cell_str(c.text) for c in row.cells))
    text = "\n".join(lines)
    return ToolResult.ok_result(_tail(text, 20000), brief=f"Word {len(doc.paragraphs)} 段")


def _word_write(path: str, title: str = "", paragraphs=None) -> ToolResult:
    """生成 Word 文档：title 为标题，paragraphs 为正文段落列表。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    try:
        from docx import Document
    except ImportError:
        return ToolResult.err_result("缺少依赖 python-docx，请先安装：pip install python-docx")
    try:
        bak = _backup_file(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        doc = Document()
        if title:
            doc.add_heading(title, level=1)
        for p in paragraphs or []:
            doc.add_paragraph(str(p))
        doc.save(path)
    except Exception as e:
        return ToolResult.err_result(f"生成 Word 失败：{e}")
    note = f"，已备份原文件为 .bak" if bak else ""
    return ToolResult.ok_result(f"已生成 {path}（{len(paragraphs or [])} 段正文{note}）",
                                brief=f"生成 Word {len(paragraphs or [])} 段")


# ============ PDF（pdfplumber） ============

def _pdf_read(path: str, page: int = 0, max_chars: int = 10000) -> ToolResult:
    """提取 PDF 文本。page=0 提取全部页；指定页码（从 1 开始）只提取该页。"""
    blocked = _protected_check(path)
    if blocked:
        return ToolResult.err_result(blocked)
    if not os.path.isfile(path):
        return ToolResult.err_result(f"文件不存在: {path}")
    try:
        import pdfplumber
    except ImportError:
        return ToolResult.err_result("缺少依赖 pdfplumber，请先安装：pip install pdfplumber")
    try:
        with pdfplumber.open(path) as pdf:
            n_pages = len(pdf.pages)
            if page:
                pages = [pdf.pages[page - 1]]
                label = f"第{page}页"
            else:
                pages = pdf.pages
                label = f"全部 {n_pages} 页"
            parts = []
            for pg in pages:
                parts.append(pg.extract_text() or "")
            text = "\n".join(parts)
    except Exception as e:
        return ToolResult.err_result(f"无法解析 PDF：{e}")
    if not text.strip():
        return ToolResult.ok_result(f"PDF（{label}）未提取到文本（可能是扫描件/图片型 PDF，建议用 OCR 处理）",
                                    brief=f"PDF {label} 无文本")
    return ToolResult.ok_result(_tail(text, max_chars), brief=f"PDF {label} {len(text)} 字")


# ============ run_python_script（沙箱执行） ============

def _run_python_script(code: str, timeout: int = 120, allow_network: bool = False,
                       cwd: str = "") -> ToolResult:
    """在临时目录中执行模型写的 Python 代码（限时 + 限工作区 + 默认禁网）。

    安全约束（设计书 §7.3-3）：
      - 脚本写入临时目录执行，不落工作区
      - 工作目录 = 配置的工作区（AGENT_WORKSPACE）或参数 cwd
      - 限时 timeout 秒，超时用 taskkill 杀掉整个进程树
      - 默认禁网（allow_network=False）：用无效代理覆盖环境变量，
        对 urllib/requests 等遵循代理的库立即失败
    风险：dangerous（任意代码），任何权限模式都弹窗由用户确认脚本内容。
    """
    if not code or not code.strip():
        return ToolResult.err_result("code 参数不能为空")
    if len(code) > 20000:
        return ToolResult.err_result("脚本过长（>20000 字符），请拆分为更小的任务")
    timeout = max(5, min(int(timeout or 120), 600))
    workdir = cwd or config.AGENT_WORKSPACE
    if not os.path.isdir(workdir):
        workdir = config.AGENT_WORKSPACE
    run_dir = tempfile.mkdtemp(prefix="lazaxa_run_")
    script_path = os.path.join(run_dir, "run.py")
    try:
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(code)
        env = os.environ.copy()
        if not allow_network:
            # 禁网：无效代理（urllib/requests/httpx 等遵循代理的库会立即失败）
            for k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                      "http_proxy", "https_proxy", "all_proxy"):
                env[k] = "http://127.0.0.1:9"
        env["PYTHONIOENCODING"] = "utf-8"
        proc = subprocess.Popen(
            [sys.executable, "-u", script_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            cwd=workdir, env=env,
            creationflags=0x08000000 if os.name == "nt" else 0,  # CREATE_NO_WINDOW
        )
        try:
            out, err = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            # 超时：杀掉整个进程树（脚本可能起了子进程）
            try:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                               capture_output=True, timeout=10)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            return ToolResult.err_result(f"脚本执行超时（>{timeout}s，已终止进程树）")
        out_text = (out or "") + ("\n[stderr]\n" + err if err else "")
        out_text = _tail(out_text, 32000)
        if proc.returncode == 0:
            return ToolResult.ok_result(out_text, brief="脚本执行成功")
        return ToolResult.err_result(f"脚本退出码 {proc.returncode}\n{out_text}")
    except Exception as e:
        return ToolResult.err_result(f"脚本启动失败: {type(e).__name__}: {e}")
    finally:
        shutil.rmtree(run_dir, ignore_errors=True)


# ============ 注册 ============

def register_all(r):
    """注册批次 D 办公七工具（按 risk 拆分：只读 safe / 写入 sensitive / 脚本 dangerous）。"""
    r.register(Tool(
        name="office_excel_read",
        display_name="📊 读 Excel",
        description=(
            "读取 Excel 表格（.xlsx/.xlsm）内容。path 为文件路径，sheet 可选（不填读第一个工作表）。"
            "适合用户说'看看这个表格/读取 Excel'。若只需了解表格结构（几个表/几行几列/表头），"
            "用 office_excel_summary 更省 token。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Excel 文件路径"},
                "sheet": {"type": "string", "description": "工作表名（可选，默认第一个）"},
            },
            "required": ["path"],
        },
        risk="safe", timeout=60, fn=_excel_read,
    ))
    r.register(Tool(
        name="office_excel_write",
        display_name="📝 写 Excel",
        description=(
            "把数据写入/覆盖 Excel 文件。data 为二维数组（每行一个列表），"
            "headers 可选（表头行，放在第一行）。写前自动备份原文件为 .bak。"
            "适合生成报表、整理数据导出。文件路径可不存在（自动创建目录）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "要写入的 Excel 文件路径"},
                "data": {"type": "array", "description": "数据行，二维数组，如 [[\"张三\",90],[\"李四\",85]]"},
                "headers": {"type": "array", "description": "表头行（可选），如 [\"姓名\",\"分数\"]"},
                "sheet": {"type": "string", "description": "工作表名（可选，默认 Sheet1）"},
            },
            "required": ["path", "data"],
        },
        risk="sensitive", timeout=60, fn=_excel_write,
    ))
    r.register(Tool(
        name="office_excel_summary",
        display_name="📋 汇总 Excel",
        description=(
            "快速了解 Excel 文件结构：各工作表名称、行数、列数、表头。"
            "不读具体数据，比 office_excel_read 更省 token。适合先看结构再决定怎么处理。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Excel 文件路径"},
            },
            "required": ["path"],
        },
        risk="safe", timeout=60, fn=_excel_summary,
    ))
    r.register(Tool(
        name="office_word_read",
        display_name="📄 读 Word",
        description=(
            "读取 Word 文档（.docx）全部段落与表格文本。"
            "适合用户说'打开/看看/读取那份 Word 文档'。注意：仅支持 .docx，.doc 老格式不支持。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Word 文件路径"},
            },
            "required": ["path"],
        },
        risk="safe", timeout=60, fn=_word_read,
    ))
    r.register(Tool(
        name="office_word_write",
        display_name="✍️ 生成 Word",
        description=(
            "生成 Word 文档（.docx）。title 为文档标题（可选），paragraphs 为正文段落列表。"
            "写前自动备份原文件为 .bak。适合生成报告、总结、周报等。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "要生成的 Word 文件路径"},
                "paragraphs": {"type": "array", "description": "正文段落列表，每项一段文本"},
                "title": {"type": "string", "description": "文档标题（可选）"},
            },
            "required": ["path", "paragraphs"],
        },
        risk="sensitive", timeout=60, fn=_word_write,
    ))
    r.register(Tool(
        name="office_pdf_read",
        display_name="📑 读 PDF",
        description=(
            "提取 PDF 文档文本内容。page 可选（从 1 开始，不填提取全部页）；"
            "max_chars 为返回文本上限（默认 10000）。"
            "注意：扫描件/图片型 PDF 无文字层，此工具提取不到文本，可提示用户用 OCR 处理。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "PDF 文件路径"},
                "page": {"type": "integer", "description": "指定页码（从 1 开始，可选，默认全部页）"},
                "max_chars": {"type": "integer", "description": "返回文本最大字符数（可选，默认 10000）"},
            },
            "required": ["path"],
        },
        risk="safe", timeout=120, fn=_pdf_read,
    ))
    r.register(Tool(
        name="run_python_script",
        display_name="🔧 运行 Python 脚本",
        description=(
            "执行一段 Python 代码（模型现写），解决预置工具覆盖不了的复杂需求："
            "批量重命名、数据清洗、生成报表、文件整理、复杂计算等。"
            "code 为完整 Python 源码（可含 import、函数、print 输出）；"
            "工作目录为桌面工作区，输出 stdout/stderr 回传。"
            "默认禁网（allow_network 留空即禁）；timeout 限时（默认 120 秒）。"
            "执行任意代码有风险，涉及敏感操作会弹窗确认。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "要执行的 Python 源码"},
                "timeout": {"type": "integer", "description": "执行超时秒数（可选，默认 120，上限 600）"},
                "allow_network": {"type": "boolean", "description": "是否允许联网（可选，默认 False 禁网）"},
                "cwd": {"type": "string", "description": "工作目录（可选，默认桌面工作区）"},
            },
            "required": ["code"],
        },
        risk="dangerous", timeout=630, fn=_run_python_script,
    ))
