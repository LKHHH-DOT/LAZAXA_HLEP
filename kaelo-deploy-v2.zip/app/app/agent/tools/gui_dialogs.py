# -*- coding: utf-8 -*-
"""系统"另存为"对话框保存原语（P3 GUI 真屏验收第五版沉淀，2026-09-04）。

背景：AI 让应用"保存到指定目录"时，Win11 的新式"另存为"对话框默认焦点在
"文件名"框。若把完整路径当成文件名塞进去，对话框看似保存成功、实际按当前
目录/默认文件名落盘（真屏验收连踩 3 轮得出的教训，详见
SelfIterate/scripts/test_agent_gui_milestones.py 与 skills/gui-file-dialogs.md）。

正确姿势（与真人完全一致）：
  ① 鼠标点"文件路径"组件（地址栏 ToolBar auto_id=1001，名称 '地址: …'）
     → 面包屑切"可输入完整路径"态（OS 级点击后焦点自动落入地址编辑框）
  ② Ctrl+A 全选 → 剪贴板粘贴目标目录（IME/反斜杠/中文全免疫）→ 回车提交导航
  ③ 回读地址栏名称应变为 '地址: <目标目录>' → 断言目录真的切过去了
  ④ 点回"文件名"框（FileNameControlHost 内 Edit auto_id=1001）
     → Ctrl+A → 粘贴纯文件名（绝不写整路径）
  ⑤ 触发"保存"按钮（Button auto_id=1，UIA invoke，免坐标）
以 os.path.exists(目标完整路径) 作为唯一成功判据（读盘事实最权威）。

坐标坑：UIA rectangle() 是 DIP，鼠标点击须换算物理像素（125% 缩放错位已踩坑）。
"""
import ctypes
import json
import os
import time

from ..registry import Tool, ToolResult
from . import gui

# 默认认可的对话框标题关键词（中英）。必要时可经 window_title 传入其它标题。
_DEFAULT_DLG_HINTS = ("另存为", "save as")

# 回读地址栏是否切到目标目录的轮询时间
_NAV_WAIT_SECS = 4.0
_SAVE_VERIFY_SECS = 4.0


# ---------------------------------------------------------------------------
# UIA 对话框基础工具（懒加载，异常一律返回 None/空，不裸抛）
# ---------------------------------------------------------------------------
def _desktop_uia():
    """pywinauto UIA Desktop（懒加载，失败返回 None）。"""
    try:
        return gui._lazy_uia()
    except Exception:
        return None


def _foreground_dialog_hwnd(title_hints) -> int:
    """若当前前台窗口标题命中关键词，返回其句柄；否则返回 0。"""
    try:
        real = gui._foreground_title().strip()
    except Exception:
        real = ""
    if not real:
        return 0
    low = real.lower()
    if not any(h.lower() in low for h in title_hints):
        return 0
    return gui._foreground_hwnd()


def _dialog_wrapper(hwnd):
    """拿对话框 UIA wrapper；失败返回 None。"""
    try:
        desktop = _desktop_uia()
        if desktop is None:
            return None
        return desktop.window(handle=int(hwnd))
    except Exception:
        return None


def _dialog_desc(w, control_type):
    """枚举对话框内指定 control_type 的后代控件（容忍单个坏节点）。"""
    out = []
    if w is None:
        return out
    try:
        els = w.descendants()
    except Exception:
        return out
    for el in els:
        try:
            info = el.element_info
            if (info.control_type or "") == control_type:
                out.append(el)
        except Exception:
            continue
    return out


def _physical_point(hwnd, dip_x, dip_y):
    """UIA DIP 坐标 → 物理屏幕坐标（显示缩放>100% 校正）。

    坑：pywinauto UIA wrapper.rectangle() 返回 DIP，125% 缩放下与鼠标点击的
    物理坐标错位。用窗口物理矩形(GetWindowRect)与 UIA 矩形(DIP)比例换算。
    换算失败原样返回（100% 缩放下 DIP==物理，结果正确）。
    """
    try:
        user32 = ctypes.windll.user32
        rp = ctypes.wintypes.RECT()
        if not user32.GetWindowRect(int(hwnd), ctypes.byref(rp)):
            return int(dip_x), int(dip_y)
        w = _dialog_wrapper(hwnd)
        if w is None:
            return int(dip_x), int(dip_y)
        rd = w.rectangle()
        dw = float(rd.right - rd.left) or 1.0
        dh = float(rd.bottom - rd.top) or 1.0
        sx = (rp.right - rp.left) / dw
        sy = (rp.bottom - rp.top) / dh
        px = rp.left + (int(dip_x) - rd.left) * sx
        py = rp.top + (int(dip_y) - rd.top) * sy
        return int(px), int(py)
    except Exception:
        return int(dip_x), int(dip_y)


def _el_center_physical(hwnd, el, x_frac=0.5, y_frac=0.5):
    """UIA 元素上任意比例点 → 物理坐标；(0,0) 表示失败。"""
    try:
        r = el.rectangle()
        cx = r.left + (r.right - r.left) * float(x_frac)
        cy = r.top + (r.bottom - r.top) * float(y_frac)
        return _physical_point(hwnd, int(cx), int(cy))
    except Exception:
        return 0, 0


def _click_el(hwnd, el, desc, x_frac=0.5, y_frac=0.5):
    """引擎真实鼠标点击 UIA 元素某点。返回 (ok, note)。"""
    px, py = _el_center_physical(hwnd, el, x_frac, y_frac)
    if px <= 0 or py <= 0:
        return False, f"{desc}物理坐标换算失败"
    r = gui._mouse_click(x=px, y=py)
    if not r.ok:
        return False, r.error or f"引擎点击{desc}失败"
    return True, f"引擎点击{desc} @({px},{py})"


def _element_value(el):
    """读 UIA 元素当前值（ValuePattern 官方读法 get_value()）。

    读不到返回 ''（软校验，不因窗口文本/Name 干扰而误报）。
    """
    try:
        v = el.get_value()
        return str(v) if v else ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# 控件定位
# ---------------------------------------------------------------------------
def _find_address_bar(w):
    """地址栏（"文件路径"组件）：ToolBar auto_id=1001，名称以 '地址:' 开头。

    名称后缀就是当前所在目录，可回读做导航断言。找不到返回 None。
    """
    for el in _dialog_desc(w, "ToolBar"):
        try:
            if (el.element_info.automation_id or "") == "1001":
                return el
        except Exception:
            continue
    for el in _dialog_desc(w, "ToolBar"):
        try:
            n = (el.window_text() or "").strip()
            if n.startswith("地址") or n.lower().startswith("address"):
                return el
        except Exception:
            continue
    return None


def _address_bar_dir(w):
    """读地址栏当前目录（去 '地址:' 前缀）；读不到返回 ''。"""
    bar = _find_address_bar(w)
    if bar is None:
        return ""
    try:
        n = (bar.window_text() or "").strip()
    except Exception:
        return ""
    return n.replace("地址", "", 1).lstrip(":： \t")


def _find_filename_edit(w):
    """"文件名"输入框：FileNameControlHost(ComboBox) 内的 Edit；兜底 auto_id=1001。"""
    for el in _dialog_desc(w, "ComboBox"):
        try:
            if (el.element_info.automation_id or "") == "FileNameControlHost":
                try:
                    kids = el.descendants()
                except Exception:
                    kids = []
                for k in kids:
                    try:
                        if (k.element_info.control_type or "") == "Edit":
                            return k
                    except Exception:
                        continue
        except Exception:
            continue
    for el in _dialog_desc(w, "Edit"):
        try:
            if (el.element_info.automation_id or "") == "1001":
                return el
        except Exception:
            continue
    return None


def _find_save_button(w):
    """"保存"按钮：名称以 保存/Save 开头优先，auto_id='1' 兜底。"""
    for el in _dialog_desc(w, "Button"):
        try:
            n = (el.window_text() or "").strip()
            if n.startswith("保存") or n.lower().startswith("save"):
                return el
        except Exception:
            continue
    for el in _dialog_desc(w, "Button"):
        try:
            if (el.element_info.automation_id or "") == "1":
                return el
        except Exception:
            continue
    return None


# ---------------------------------------------------------------------------
# 第五版保存序列
# ---------------------------------------------------------------------------
def _navigate_dir(hwnd, w, dlg_hint, save_dir):
    """第 1 步：地址栏导航到 save_dir。返回 (ok, note)。

    鼠标点"文件路径"组件 → Ctrl+A → 剪贴板粘贴目录 → 回车 → 回读地址栏名称。
    回读未确认时 Ctrl+L 聚焦兜底重试一遍。仍不中即失败（不静默存错目录）。
    """
    bar = _find_address_bar(w)
    if bar is None:
        return False, "未找到地址栏组件（ToolBar auto_id=1001）"
    # ① 点击地址栏右 3/4 空白 → 面包屑切"可输入完整路径"编辑态
    ok_c, note_c = _click_el(hwnd, bar, "地址栏(文件路径)", x_frac=0.72, y_frac=0.5)
    if not ok_c:
        return False, note_c
    time.sleep(0.45)

    def _paste_and_enter():
        ra = gui._keyboard_press(keys=["ctrl", "a"])
        if not ra.ok:
            return False, ra.error or "Ctrl+A 失败"
        time.sleep(0.1)
        try:
            gui._set_clipboard_text(save_dir)
        except Exception as e:
            return False, f"剪贴板写入失败: {e}"
        rv = gui._keyboard_press(keys=["ctrl", "v"])
        if not rv.ok:
            return False, rv.error or "Ctrl+V 失败"
        time.sleep(0.2)
        re2 = gui._keyboard_press(keys=["enter"])   # 输完立刻回车提交导航
        if not re2.ok:
            return False, re2.error or "地址栏导航 Enter 失败"
        return True, ""

    def _wait_nav():
        norm = os.path.normpath(save_dir).lower()
        deadline = time.time() + _NAV_WAIT_SECS
        while time.time() < deadline:
            time.sleep(0.35)
            ww = _dialog_wrapper(hwnd)
            cur = _address_bar_dir(ww) if ww else ""
            if cur and os.path.normpath(cur).lower() == norm:
                return True
        return False

    ok_p, err_p = _paste_and_enter()
    if not ok_p:
        return False, err_p
    if _wait_nav():
        return True, f"文件路径组件已点开，路径回车后导航到目录：{save_dir}"
    # 鼠标点击未让焦点落进地址框 → Ctrl+L 兜底（Windows 标准聚焦地址栏）
    rl = gui._keyboard_press(keys=["ctrl", "l"])
    if not rl.ok:
        return False, rl.error or "Ctrl+L 聚焦地址栏失败"
    time.sleep(0.3)
    ok_p2, err_p2 = _paste_and_enter()
    if not ok_p2:
        return False, err_p2
    if _wait_nav():
        return True, f"(Ctrl+L 兜底) 地址栏已导航到目录：{save_dir}"
    return False, f"回车后地址栏未回读到目标目录（目标 {save_dir}）"


def _fill_filename(hwnd, w, fname):
    """第 2 步：点回"文件名"框 → 覆盖输入纯文件名。返回 (ok, note)。"""
    edit = _find_filename_edit(w)
    if edit is None:
        return False, "未找到'文件名'输入框（FileNameControlHost/auto_id=1001）"
    ok_c, note_c = _click_el(hwnd, edit, "文件名框")
    if not ok_c:
        return False, note_c
    time.sleep(0.25)
    ra = gui._keyboard_press(keys=["ctrl", "a"])       # 全选默认预填文本
    if not ra.ok:
        return False, ra.error or "Ctrl+A 失败"
    time.sleep(0.1)
    try:
        gui._set_clipboard_text(fname)                  # 中文/特殊字符全免疫
    except Exception as e:
        return False, f"剪贴板写入失败: {e}"
    rv = gui._keyboard_press(keys=["ctrl", "v"])
    if not rv.ok:
        return False, rv.error or "Ctrl+V 失败"
    time.sleep(0.3)
    # 回读校验（ValuePattern；读不到不强求——粘贴+焦点可靠）
    rb = _element_value(edit)
    if rb and fname not in rb:
        return False, f"文件名写入未通过回读：期望含 '{fname}'，实际 '{rb[:80]}'"
    note = note_c + (f"；写文件名 '{fname}'" + (f"，回读含文件名" if rb else "（值不可回读）"))
    return True, note


def _trigger_save(hwnd, w):
    """第 3 步：触发"保存"按钮。返回 (ok, note)。"""
    btn = _find_save_button(w)
    if btn is None:
        return False, "未找到'保存'按钮"
    # UIA invoke 免坐标最稳；缺 invoke 才退化坐标点击
    try:
        btn.invoke()
        return True, "保存按钮(UIA invoke)已触发"
    except Exception:
        pass
    try:
        btn.click_input()
        return True, "保存按钮(click_input)已触发"
    except Exception:
        pass
    ok_c, note_c = _click_el(hwnd, btn, "保存按钮")
    if not ok_c:
        return False, note_c
    return True, "保存按钮(引擎坐标点击)已触发"


# ---------------------------------------------------------------------------
# 工具主体
# ---------------------------------------------------------------------------
def _save_dialog(path: str = "", window_title: str = "") -> ToolResult:
    """在已打开的"另存为/保存"对话框里，按第五版流程保存到 path。

    path = 完整目标路径（目录+文件名，目录不存在自动创建）。
    前置：保存对话框须已在前台（模型先用 keyboard_press Ctrl+S 等打开它）。
    唯一成功判据：path 真实落盘。
    """
    try:
        path = str(path or "").strip()
        if not path:
            return ToolResult.err_result("缺少参数 path（完整目标路径，目录+文件名）")
        save_dir, fname = os.path.split(path)
        if not save_dir or not fname:
            return ToolResult.err_result(
                f"path 需是完整路径（含目录与文件名）：{path}")
        os.makedirs(save_dir, exist_ok=True)

        hints = tuple(h for h in (str(window_title or "").strip(),) + _DEFAULT_DLG_HINTS if h)
        hwnd = _foreground_dialog_hwnd(hints)
        if not hwnd:
            return ToolResult.err_result(
                f"当前前台窗口不是'另存为/保存'对话框（前台='{gui._foreground_title()}'）。"
                "请先用 keyboard_press(ctrl+s) 等打开保存对话框并激活后再调用本工具。")
        w = _dialog_wrapper(hwnd)
        if w is None:
            return ToolResult.err_result("另存为对话框 UIA 取窗失败（可改用 screen_describe 看图操作）")

        steps = []
        # 第 1 步：地址栏导航目录
        ok_nav, note_nav = _navigate_dir(hwnd, w, hints, save_dir)
        steps.append(note_nav)
        if not ok_nav:
            return ToolResult.err_result("保存中断（目录导航失败，绝不静默存错位置）：" + note_nav)
        # 第 2 步：点回文件名框，写纯文件名
        time.sleep(0.4)
        ok_fn, note_fn = _fill_filename(hwnd, w, fname)
        steps.append(note_fn)
        if not ok_fn:
            return ToolResult.err_result("保存中断（写文件名失败）：" + note_fn)
        # 第 3 步：触发保存
        ok_sv, note_sv = _trigger_save(hwnd, w)
        steps.append(note_sv)
        # 第 4 步：落盘断言（唯一成功判据）
        deadline = time.time() + _SAVE_VERIFY_SECS
        while time.time() < deadline:
            if os.path.exists(path):
                out = {"path": path, "ok": True, "steps": steps}
                return ToolResult.ok_result(
                    json.dumps(out, ensure_ascii=False),
                    brief=f"已保存：{fname}（目标目录落盘确认）")
            time.sleep(0.3)
        return ToolResult.err_result(
            f"保存按钮已触发但 {_SAVE_VERIFY_SECS}s 内未在目标路径看到文件：{path}。"
            "步骤：" + "；".join(steps) + "。可再调用本工具重试，或改用 screen_describe 看对话框当前状态。")
    except Exception as e:
        return ToolResult.err_result(f"另存为对话框保存失败: {e}")


def register_all(r):
    """注册"另存为"对话框保存原语。"""
    r.register(Tool(
        name="save_dialog",
        description=("在已打开的 Windows 系统'另存为/保存'对话框中，按真人流程把文件保存到指定"
                     "完整路径（目录自动创建）：点'文件路径'(地址栏)→粘贴目录→回车导航→"
                     "点回'文件名'框→粘贴纯文件名→触发'保存'按钮。返回最终落盘路径（读盘确认）。"
                     "适用：记事本/写字板/各类桌面软件点保存弹系统对话框、要存到指定目录时。"
                     "前置：先用 keyboard_press(ctrl+s) 等打开'另存为'对话框并保持前台；"
                     "若对话框标题不是默认的'另存为'，请传 window_title。"),
        parameters={"type": "object", "properties": {
            "path": {"type": "string",
                     "description": "完整目标保存路径，含目录和文件名（如 "
                                    "C:\\Users\\Hasee\\Desktop\\LazaxaTemp\\报告.txt）"},
            "window_title": {"type": "string",
                             "description": "可选：'另存为'对话框标题关键字；默认自动识别另存为/Save As"},
        }, "required": ["path"]},
        risk="sensitive", timeout=60, fn=_save_dialog, screen_lock=True,
    ))
