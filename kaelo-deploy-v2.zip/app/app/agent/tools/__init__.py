# -*- coding: utf-8 -*-
"""工具集汇总注册。

新增工具：在 tools/ 下新建模块并在此处调用其 register_all()。
"""

from ..registry import ToolRegistry
from . import (adb, gui, gui_dialogs, kb, lazaxa, mcp_tools, memory, obsidian,
               office, plan, security, shell, subagent, supervise, verify, web,
               windows)


def register_all(r: ToolRegistry):
    """注册全部已实现的工具。"""
    shell.register_all(r)
    memory.register_all(r)
    kb.register_all(r)
    gui.register_all(r)
    gui_dialogs.register_all(r)
    windows.register_all(r)
    obsidian.register_all(r)
    office.register_all(r)
    subagent.register_all(r)
    lazaxa.register_all(r)
    adb.register_all(r)
    mcp_tools.register_all(r)
    security.register_all(r)
    supervise.register_all(r)
    verify.register_all(r)
    web.register_all(r)
    plan.register_all(r)
