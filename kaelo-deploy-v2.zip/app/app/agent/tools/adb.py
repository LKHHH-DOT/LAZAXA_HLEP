# -*- coding: utf-8 -*-
r"""ADB / Linux 设备工具（2026-08-17 · 电脑工具接入·ADB 落地）。

对接用户 Linux 小设备（工具清单："adb shell，所有你要会用 Linux"）。
直接封装 adb 命令为结构化工具，走 subprocess 执行，统一返回 ToolResult。

工具：
  - adb_devices：列出已连接的设备（safe）
  - adb_shell：在设备上执行 shell 命令（sensitive）
  - adb_install：安装 APK（sensitive）
  - adb_screenshot：截取设备屏幕到临时目录（safe）
  - adb_push_pull：在设备与电脑间传文件（sensitive）

adb 可执行文件从 PATH 查找（工具清单里 adb 已在 PATH：C:/PLATFORM-TOOLS/adb.exe）。
"""
import os
import shutil
import subprocess
import time

from ... import config
from ..registry import Tool, ToolResult

_MAX_SHELL_OUT = 6000    # adb_shell 单次输出上限
_MAX_INSTALL_OUT = 2000  # adb_install 输出上限
_ADB_CMD = shutil.which("adb") or os.environ.get("ADB_PATH", "adb")


def _run_adb(args: list[str], timeout: int = 60, max_out: int = _MAX_SHELL_OUT) -> ToolResult:
    """执行一条 adb 命令。返回 (ok, text)。"""
    try:
        proc = subprocess.run(
            [_ADB_CMD] + args, capture_output=True, text=True,
            timeout=timeout, encoding="utf-8", errors="replace",
        )
    except FileNotFoundError:
        return ToolResult.err_result(
            f"找不到 adb 命令（{_ADB_CMD}）。请确认 Android 平台工具已安装并加入 PATH。")
    except subprocess.TimeoutExpired:
        return ToolResult.err_result(f"adb 命令超时（>{timeout}s）: {' '.join(args)}")
    out = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    out = out.strip()
    if proc.returncode != 0:
        return ToolResult.err_result(
            f"adb 命令失败（code={proc.returncode}）: {out[:_MAX_SHELL_OUT]}")
    if len(out) > max_out:
        out = out[:max_out] + f"\n…（输出过长已截断）"
    return ToolResult.ok_result(out or "（无输出）")


# ============ 工具实现 ============

def _adb_devices() -> ToolResult:
    """列出已连接的 Android/Linux 设备。"""
    res = _run_adb(["devices", "-l"])
    if not res.ok:
        return res
    lines = [l for l in res.text.splitlines() if l.strip() and not l.startswith("List of")]
    if not lines:
        return ToolResult.ok_result("当前没有已连接的设备。请用 USB 连接并开启调试，"
                                    "或 `adb connect <ip>:<port>` 无线连接。", brief="0 设备")
    return ToolResult.ok_result("已连接设备：\n" + "\n".join(lines), brief=f"{len(lines)} 台设备")


def _adb_shell(command: str) -> ToolResult:
    """在设备上执行 shell 命令（Linux 命令）。"""
    command = str(command or "").strip()
    if not command:
        return ToolResult.err_result("参数缺失：command（要执行的 Linux 命令，如 ls /sdcard）")
    return _run_adb(["shell", command], timeout=120)


def _adb_install(apk_path: str, force: bool = True) -> ToolResult:
    """向设备安装 APK。apk_path 为电脑上的 APK 文件路径。"""
    apk_path = str(apk_path or "").strip()
    if not apk_path:
        return ToolResult.err_result("参数缺失：apk_path（APK 文件路径）")
    if not os.path.isfile(apk_path):
        return ToolResult.err_result(f"APK 文件不存在: {apk_path}")
    args = ["install"] + (["-r"] if force else []) + [apk_path]
    res = _run_adb(args, timeout=300, max_out=_MAX_INSTALL_OUT)
    if not res.ok:
        return res
    return ToolResult.ok_result(f"安装成功：{os.path.basename(apk_path)}\n{res.text}",
                                brief=f"已安装 {os.path.basename(apk_path)}")


def _adb_screenshot() -> ToolResult:
    """截取设备当前屏幕，保存到桌面临时目录，返回截图路径。"""
    shot_dir = os.path.join(config.AGENT_TEMP_DIR, "adb_shots")
    os.makedirs(shot_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    local = os.path.join(shot_dir, f"adb_{ts}.png")
    remote = f"/sdcard/lazaxa_shot_{ts}.png"
    # 先截到设备，再拉到本地（旧版 adb 的 screencap 直接输出到 stdout 会卡在某些设备）
    r1 = _run_adb(["shell", "screencap", "-p", remote], timeout=60)
    if not r1.ok:
        return r1
    r2 = _run_adb(["pull", remote, local], timeout=60)
    if not r2.ok:
        return r2
    _run_adb(["shell", "rm", "-f", remote], timeout=30)  # 清理设备临时文件
    if os.path.isfile(local):
        return ToolResult.ok_result(f"已保存设备截图：{local}", brief="已截图")
    return ToolResult.err_result("截图失败：文件未生成")


def _adb_push_pull(mode: str, local: str, remote: str) -> ToolResult:
    """设备与电脑间传文件。mode=pull 设备→电脑；mode=push 电脑→设备。"""
    mode = str(mode or "").strip().lower()
    local = str(local or "").strip()
    remote = str(remote or "").strip()
    if mode not in ("pull", "push"):
        return ToolResult.err_result("参数缺失/错误：mode 必须是 pull（设备→电脑）或 push（电脑→设备）")
    if not local or not remote:
        return ToolResult.err_result("参数缺失：local 与 remote 都要填（pull 时 local 为电脑保存路径，"
                                     "push 时 local 为电脑源文件）")
    if mode == "push" and not os.path.isfile(local):
        return ToolResult.err_result(f"电脑源文件不存在: {local}")
    if mode == "pull":
        d = os.path.dirname(local)
        if d:
            os.makedirs(d, exist_ok=True)
    args = [mode, local, remote]
    res = _run_adb(args, timeout=300)
    if not res.ok:
        return res
    return ToolResult.ok_result(f"已{mode}：{local} ↔ {remote}\n{res.text}", brief=f"已{mode}文件")


# ============ 注册 ============

def register_all(r):
    """注册 ADB 五工具。"""
    r.register(Tool(
        name="adb_devices",
        display_name="📱 设备列表",
        description=(
            "列出已连接的 Android/Linux 设备（用户的 Linux 小设备走 adb 连接）。"
            "用户说'连上设备/看看设备在不在/设备列表'时用。"
        ),
        parameters={"type": "object", "properties": {}, "required": []},
        risk="safe", timeout=30, fn=_adb_devices,
    ))
    r.register(Tool(
        name="adb_shell",
        display_name="🖥 设备执行命令",
        description=(
            "在已连接的 Android/Linux 设备（用户的 Linux 小设备）上执行 shell 命令。"
            "Linux 命令均可：ls / pwd / cat / find / apt 等。"
            "用户说'在设备上跑个命令/查看设备文件/装个软件'时用。"
            "命令输出较长会被截断。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "要在设备上执行的 Linux 命令，如 ls /sdcard"},
            },
            "required": ["command"],
        },
        risk="sensitive", timeout=150, fn=_adb_shell,
    ))
    r.register(Tool(
        name="adb_install",
        display_name="📦 安装 APK",
        description=(
            "向已连接的 Android/Linux 设备安装 APK 应用。apk_path 为电脑上 APK 的完整路径。"
            "用户说'给设备装个应用/安装 APK'时用。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "apk_path": {"type": "string", "description": "电脑上 APK 文件的完整路径"},
                "force": {"type": "boolean", "description": "是否强制安装（-r 保留数据，默认 true）"},
            },
            "required": ["apk_path"],
        },
        risk="sensitive", timeout=330, fn=_adb_install,
    ))
    r.register(Tool(
        name="adb_screenshot",
        display_name="📸 设备截图",
        description=(
            "截取已连接设备（用户的 Linux 小设备）当前屏幕，保存到桌面临时目录并返回路径。"
            "用户说'看看设备屏幕/截个设备图'时用。"
        ),
        parameters={"type": "object", "properties": {}, "required": []},
        risk="safe", timeout=90, fn=_adb_screenshot,
    ))
    r.register(Tool(
        name="adb_push_pull",
        display_name="📤 设备传文件",
        description=(
            "在设备与电脑之间传输文件。pull=设备文件拉到电脑（local 为电脑保存路径）；"
            "push=电脑文件传到设备（local 为电脑源文件，remote 为设备目标路径）。"
            "用户说'把设备上的文件拷过来/传个文件到设备'时用。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "mode": {"type": "string", "description": "pull（设备→电脑）或 push（电脑→设备）"},
                "local": {"type": "string", "description": "电脑侧文件路径"},
                "remote": {"type": "string", "description": "设备侧文件路径（如 /sdcard/xxx）"},
            },
            "required": ["mode", "local", "remote"],
        },
        risk="sensitive", timeout=330, fn=_adb_push_pull,
    ))
