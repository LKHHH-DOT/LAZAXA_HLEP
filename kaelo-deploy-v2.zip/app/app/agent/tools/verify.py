# -*- coding: utf-8 -*-
"""结果独立验证闸门工具（2026-09-05 · A批3）。

背景
----
"LLM 不可靠是第一假设"：智能体上一步工具返回"成功"只是自述，可能出错（命令
退出码为 0 但没生成文件、写错路径、被拦截等）。收尾前应做一次**独立断言**，
不信任上一步输出，而是直接读文件系统/进程表核对终态产物。

verify_result 即该"最小闭环"闸门：
  - 校验项全部为独立只读断言（文件存在性/内容子串/最近修改时间/目录模式匹配/
    进程状态），不依赖上一步工具的输出
  - 关键设计：file_newer_than 用"刚被写入"代替"存在"，防拿旧文件冒充新产物
  - 全部通过才 ok=True（brief 汇总）；任一失败 err_result → 模型换策略重做再验证

判读范式：任何写文件/装软件/起停进程/改界面的任务，在回复"完成"前
对最重要 1-3 个终态产物调用本工具做断言。
"""

import fnmatch
import os
import subprocess
import sys
import time

from ..registry import Tool, ToolResult

CREATE_NO_WINDOW = 0x08000000  # Windows：隐藏子进程窗口
_DEFAULT_FRESH_SECONDS = 300   # "刚写入"默认窗口：5 分钟内改动视为本次产物


def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _tasklist_running(name: str) -> bool:
    """Windows tasklist 判断指定进程名是否在运行（不含扩展名差异归一同 .exe）。"""
    exe = name if name.lower().endswith(".exe") else name + ".exe"
    r = subprocess.run(
        ["tasklist", "/FO", "CSV", "/NH", "/FI", f"IMAGENAME eq {exe}"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=20, creationflags=CREATE_NO_WINDOW,
    )
    return bool(r.stdout and f"{exe}" in r.stdout.lower())


def _run_check(c: dict) -> str:
    """执行单个校验项，返回 PASS/FAIL 文本行。"""
    kind = (c.get("kind") or "").strip()
    if kind == "file_exists":
        path = c.get("path", "")
        expect = bool(c.get("expect", True))
        ok = os.path.exists(path) == expect
        state = "存在" if os.path.exists(path) else "不存在"
        return (f"[{'PASS' if ok else 'FAIL'}] file_exists: {path} "
                f"({state}，期望{'存在' if expect else '不存在'})")
    if kind == "file_newer_than":
        path = c.get("path", "")
        seconds = int(c.get("seconds") or _DEFAULT_FRESH_SECONDS)
        if not os.path.exists(path):
            return f"[FAIL] file_newer_than: {path} 不存在（期望刚被写入）"
        age = time.time() - os.path.getmtime(path)
        ok = age <= seconds
        return (f"[{'PASS' if ok else 'FAIL'}] file_newer_than: {path} "
                f"修改于 {int(age)}s 前（窗口 {seconds}s）")
    if kind in ("file_contains", "file_not_contains"):
        path = c.get("path", "")
        text = c.get("text", "")
        if not os.path.exists(path):
            return f"[FAIL] {kind}: {path} 不存在，无法核对内容"
        try:
            content = _read_text(path)
        except OSError as e:
            return f"[FAIL] {kind}: 读取 {path} 失败: {e}"
        found = text in content
        if kind == "file_contains":
            ok = found
            return (f"[{'PASS' if ok else 'FAIL'}] file_contains: {path} "
                    f"含目标子串（{len(text)} 字符）")
        ok = not found
        return (f"[{'PASS' if ok else 'FAIL'}] file_not_contains: {path} "
                f"已排除目标子串")
    if kind == "dir_contains":
        directory = c.get("dir") or c.get("path", "")
        pattern = c.get("pattern", "*")
        if not os.path.isdir(directory):
            return f"[FAIL] dir_contains: {directory} 不是有效目录"
        try:
            names = os.listdir(directory)
        except OSError as e:
            return f"[FAIL] dir_contains: 读取目录失败: {e}"
        matched = [n for n in names if fnmatch.fnmatch(n, pattern)]
        ok = bool(matched)
        sample = ", ".join(matched[:3]) or "无"
        return (f"[{'PASS' if ok else 'FAIL'}] dir_contains: {directory} "
                f"匹配 {pattern} → {sample}")
    if kind == "process":
        name = c.get("name", "")
        running = bool(c.get("running", True))
        actual = _tasklist_running(name)
        ok = actual == running
        return (f"[{'PASS' if ok else 'FAIL'}] process: {name} "
                f"当前{'运行中' if actual else '已退出'}（期望{'运行' if running else '退出'}）")
    return f"[SKIP] 未知校验类型: {kind or '(空)'}"


def verify_result(checks=None, description: str = "") -> ToolResult:
    """执行一组独立断言。全部通过 = 验证成功；任一失败 = 验证失败（err_result）。

    checks: 校验项列表，每项 {kind, path/dir/name, text/pattern, expect/running,
    seconds}，kind 支持：
      - file_exists:      path 存在性（expect 默认 true）
      - file_newer_than:  path 在 seconds 秒内被修改（默认 300s，判"刚写入"）
      - file_contains:    path 文本包含 text 子串
      - file_not_contains:path 文本不含 text 子串
      - dir_contains:     dir 目录内存在匹配 pattern（glob）的文件
      - process:          name 进程是否在运行（running 默认 true）
    description: 本次断言意图（仅作结果可读性说明，不参与判定）。
    """
    checks = checks if isinstance(checks, list) else []
    if not checks:
        msg = "checks 不能为空：至少给一项独立断言"
        return ToolResult(text=msg, error=msg)

    lines = []
    if description:
        lines.append(f"验证意图: {description}")
    passed = 0
    for c in checks:
        line = _run_check(c if isinstance(c, dict) else {})
        lines.append(line)
        if line.startswith("[PASS]"):
            passed += 1
    total = len(checks)
    lines.append(f"验证结果: {passed}/{total} 项通过")
    detail = "\n".join(lines)
    if passed == total:
        brief = f"验证通过（{passed}/{total} 项）"
        return ToolResult(text=detail, brief=brief)
    # 失败：text 带完整明细（喂回模型让它看清哪项 FAIL 再修复），error 标记失败态
    brief = f"验证失败（{passed}/{total} 项通过）"
    return ToolResult(text=detail, error=f"验证失败（{passed}/{total} 项通过）",
                      brief=brief)


def register_all(r):
    """注册结果独立验证闸门工具（只读断言，risk=safe 自动执行）。"""
    r.register(Tool(
        name="verify_result",
        display_name="结果验证",
        description=(
            "任务收尾闸门：对终态产物做独立断言（不信任上一步工具的自述成功，"
            "直接读文件系统/进程表核对）。适合写文件/生成报表/装软件/起停进程/"
            "GUI 操作完成后、回复'完成'之前调用，断言 1-3 个最关键产物。"
            "checks 支持：file_exists（文件已生成）、file_newer_than（文件是刚写入的，"
            "防拿旧文件冒充）、file_contains（内容含预期子串）、file_not_contains（内容不含"
            "残留）、dir_contains（目录里生成了匹配文件）、process（进程已启动/已退出）。"
            "全部通过才返回成功；任一失败会明确标 FAIL，据错误调整方案后重做再验证。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "description": {"type": "string",
                                "description": "本次断言意图说明（如：确认备份文件已生成）"},
                "checks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "kind": {"type": "string",
                                     "description": "断言类型: file_exists / file_newer_than / "
                                                    "file_contains / file_not_contains / "
                                                    "dir_contains / process"},
                            "path": {"type": "string", "description": "目标文件路径"},
                            "dir": {"type": "string", "description": "目标目录（dir_contains 用）"},
                            "pattern": {"type": "string", "description": "glob 文件名模式，默认 *"},
                            "text": {"type": "string", "description": "要核对的目标子串"},
                            "name": {"type": "string", "description": "进程名（process 用），如 notepad"},
                            "expect": {"type": "boolean", "description": "file_exists: true=应存在(默认) / false=应不存在"},
                            "running": {"type": "boolean", "description": "process: true=应在运行(默认) / false=应已退出"},
                            "seconds": {"type": "integer", "description": "file_newer_than 新鲜窗口秒数，默认 300"},
                        },
                        "required": ["kind"],
                    },
                    "description": "独立断言列表（至少 1 项）",
                },
            },
            "required": ["checks"],
        },
        risk="safe",
        timeout=30,
        fn=verify_result,
    ))
