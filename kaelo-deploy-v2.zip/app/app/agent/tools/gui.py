# -*- coding: utf-8 -*-
"""GUI 自动化工具集（批次 C · 移植自 AIPC/ui_controller）。

能力：截图（screen_capture）、屏幕文字识别（screen_ocr）、按文字定位
（find_on_screen）、鼠标点击（mouse_click）、键盘输入（keyboard_type）、
按键/快捷键（keyboard_press）。基于 pyautogui + pytesseract。

设计原则（对齐 AIPC整合方案.md §3）：
  - 懒加载：pyautogui/pytesseract/PIL 等重依赖只在首次调用时才 import，
    后端启动不因 GUI 依赖变慢；缺依赖（如 Tesseract 引擎未装）时工具返回
    明确错误提示，而不是崩溃。
  - 写操作（点击/输入/按键）统一 risk="sensitive" 走审批弹窗；
    只读操作（截图/OCR/定位）risk="safe" 自动执行。
  - 返回统一 ToolResult；任何异常转 ok=False 喂回模型，不裸抛。
  - 坐标体系：OCR 在截图上识别，截图与 pyautogui 同为物理像素，
    定位坐标可直接用于点击（DPI 缩放下一致，AIPC 已验证该链路）。
"""
import json
import os
import re
import threading

from ..registry import Tool, ToolResult
from ... import config

# 危险快捷键黑名单：命中直接拒绝（防止锁屏/呼出系统管理器/退出等失控操作）
_HOTKEY_BLACKLIST = {
    "win+l", "win+r", "win+u", "win+x", "win+e",
    "ctrl+alt+del", "ctrl+alt+esc", "ctrl+shift+esc",
    "alt+f4", "alt+tab", "ctrl+esc",
}

# 懒加载缓存（首次调用才 import，模块导入零开销）
_pyautogui = None
_pytesseract = None
_PIL_Image = None
_pg_lock = threading.Lock()
_tesseract_checked = False
_tesseract_ready = False
_uia = None
_uia_checked = False
_uia_ready = False


def _lazy_pyautogui():
    """懒加载 pyautogui（线程安全）。"""
    global _pyautogui
    if _pyautogui is None:
        with _pg_lock:
            if _pyautogui is None:
                import pyautogui  # 重依赖：首次调用才加载
                pyautogui.PAUSE = 0.1  # 每步操作间隔，避免动作太快被系统忽略
                _pyautogui = pyautogui
    return _pyautogui


def _lazy_pytesseract():
    """懒加载 pytesseract 并探测 Tesseract 引擎（结果缓存）。"""
    global _pytesseract, _tesseract_checked, _tesseract_ready
    if _pytesseract is None:
        with _pg_lock:
            if _pytesseract is None:
                import pytesseract
                # 自动探测常见安装路径（AIPC ocr_parser 同款逻辑）
                for p in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                          r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                          r"D:\ALLAPP\Tesseract-OCR\tesseract.exe"):
                    if os.path.exists(p):
                        pytesseract.pytesseract.tesseract_cmd = p
                        break
                _pytesseract = pytesseract
    if not _tesseract_checked:
        with _pg_lock:
            if not _tesseract_checked:
                _tesseract_checked = True
                try:
                    _pytesseract.get_tesseract_version()
                    _tesseract_ready = True
                except Exception:
                    _tesseract_ready = False
    return _pytesseract


def _ocr_available() -> str:
    """检查 OCR 引擎可用性，返回 '' 表示可用，否则返回缺失原因。"""
    if not _tesseract_ready:
        _lazy_pytesseract()
    if not _tesseract_ready:
        return ("Tesseract-OCR 引擎未安装。请安装 Tesseract 5.x（勾选 chi_sim 中文包），"
                "参考 docs/AIPC整合方案.md §5；安装后重启后端生效。")
    return ""


# ============ UI 控件树（视觉升级方案 §4.1，pywinauto UIAutomation） ============

# 可交互控件类型（UIAutomation control_type，过滤掉纯容器/静态文本等噪声）
_INTERACTIVE_TYPES = {
    "Button", "Edit", "ComboBox", "CheckBox", "RadioButton", "TabItem",
    "ListItem", "MenuItem", "Hyperlink", "TreeItem", "Slider", "Spinner",
    "SplitButton", "Custom", "DataItem",
}


def _lazy_uia():
    """懒加载 pywinauto UIA 后端（线程安全；检测可用性并缓存结果）。"""
    global _uia, _uia_checked, _uia_ready
    if _uia is None:
        with _pg_lock:
            if _uia is None:
                try:
                    from pywinauto import Desktop
                    _uia = Desktop(backend="uia")
                    _uia_ready = True
                except Exception:
                    _uia_ready = False
    if not _uia_checked:
        with _pg_lock:
            if not _uia_checked:
                _uia_checked = True
                if _uia_ready:
                    try:
                        _uia.windows()  # 试枚举一次，确认 UIA 服务可用
                    except Exception:
                        _uia_ready = False
    return _uia


def _ui_available() -> str:
    """检查 UIAutomation 可用性，返回 '' 表示可用，否则返回缺失原因。"""
    _lazy_uia()
    if not _uia_ready:
        return ("UI 控件树不可用：pywinauto 未安装或 UIAutomation 服务不可用。"
                "可改用 screen_analyze（OCR 元素表）定位目标。")
    return ""


def _foreground_hwnd() -> int:
    """当前前台窗口句柄（读不到返回 0）。"""
    try:
        import ctypes
        return int(ctypes.windll.user32.GetForegroundWindow())
    except Exception:
        return 0


class _WinAmbiguous(Exception):
    """标题关键字命中多个可见窗口（同名多窗口歧义）。wins=[(hwnd, title)]。"""

    def __init__(self, wins):
        self.wins = wins
        super().__init__(f"标题命中 {len(wins)} 个可见窗口")


def _resolve_target_window(desktop, window_title: str):
    """按标题关键字解析目标窗口，返回 pywinauto Window 对象。

    - 支持中英别名展开（记事本↔Notepad）；
    - 同名多窗口（如开两个"微信"）不再含糊报错，抛 _WinAmbiguous 携带候选清单，
      由 ui_list/ui_find 层格式化给模型（让模型用精确标题或先 window_control 激活）。
    """
    from .windows import _get_windows, _title_keywords
    wins, seen = [], set()
    for kw in _title_keywords(str(window_title)):
        for hwnd, t in _get_windows().find_all(kw):
            if hwnd not in seen:          # 同一窗口被多个关键字命中只算一次
                seen.add(hwnd)
                wins.append((hwnd, t))
    if not wins:
        raise RuntimeError(
            f"窗口 '{window_title}' 未找到可见实例（可先 screen_ocr 查看实际窗口标题）")
    if len(wins) > 1:
        raise _WinAmbiguous(wins)
    win = desktop.window(handle=wins[0][0])
    win.wait("exists", timeout=3)
    return win


def _ui_depth(win, el, cap: int = 16) -> int:
    """控件相对窗口根的层级深度（max_depths 限深用）；读不到返回 -1。"""
    d = 0
    cur = el
    try:
        while d < cap:
            parent = cur.parent()
            if parent is None or parent.handle == getattr(cur, "handle", None):
                break
            if parent.handle == win.handle:
                break
            cur = parent
            d += 1
    except Exception:
        return -1
    return d


def _ui_collect_nodes(window_title: str = "", max_items: int | None = None,
                      max_depths: int | None = None) -> tuple:
    """收集窗口可交互控件（ui_list / ui_find / element_id 定向共用）。

    指定 window_title 按标题找窗口，否则用当前前台窗口。
    返回 (items, hwnd)，items 元素：
      {id, type, name, x, y, width, height, center, [depth], _el}
      - id  ：稳定元素引用（UIA AutomationId 优先，退化「类型:名称#序号」），
              供动作工具 element_id 定向（见 _ui_resolve_node）；
      - _el ：pywinauto 控件包装（内部用，序列化前必须剥离）。
    max_items：None=用 config.UI_LIST_MAX_ITEMS（给模型看的输出限长）；
               0=不限（ui_find / element_id 定向解析必须不限，否则目标控件
               排在第 60 个之后会被误判失效）。max_depths 给定时按层级限深。
    """
    reason = _ui_available()
    if reason:
        raise RuntimeError(reason)
    desktop = _uia
    if window_title:
        win = _resolve_target_window(desktop, window_title)
    else:
        hwnd = _foreground_hwnd()
        if not hwnd:
            raise RuntimeError("无法获取前台窗口句柄")
        win = desktop.window(handle=hwnd)
        win.wait("exists", timeout=3)
    items = []
    limit = config.UI_LIST_MAX_ITEMS if max_items is None else (max_items or 10 ** 9)
    used_ids, name_seq = set(), {}
    try:
        descendants = win.descendants()
    except Exception:
        descendants = []
    for el in descendants:
        try:
            info = el.element_info
            ctype = info.control_type or ""
            if ctype not in _INTERACTIVE_TYPES:
                continue
            name = (el.window_text() or "").strip()
            if not name:
                continue
            depth = _ui_depth(win, el) if max_depths is not None else None
            if max_depths is not None and depth >= 0 and depth > int(max_depths):
                continue
            # 稳定 id：AutomationId 跨刷新稳定；缺失时用「类型:名称#序号」兜底
            auto_id = str(getattr(info, "automation_id", "") or "").strip()
            if auto_id:
                eid = f"{ctype}:{auto_id}"
            else:
                base = f"{ctype}:{name}"
                n = name_seq.get(base, 0)
                name_seq[base] = n + 1
                eid = f"{base}#{n}"
            while eid in used_ids:          # 同 AutomationId 重复 → 加后缀去重
                eid += "'"
            used_ids.add(eid)
            rect = el.rectangle()
            x, y = int(rect.left), int(rect.top)
            w, h = int(rect.right - rect.left), int(rect.bottom - rect.top)
            item = {"id": eid, "type": ctype, "name": name,
                    "x": x, "y": y, "width": w, "height": h,
                    "center": [x + w // 2, y + h // 2], "_el": el}
            if depth is not None:
                item["depth"] = depth
            items.append(item)
            if len(items) >= limit:
                break
        except Exception:
            continue
    return items, int(getattr(win, "handle", 0) or 0)


def _ui_public(item: dict) -> dict:
    """剥离内部字段（_el），得到可序列化的控件描述。"""
    return {k: v for k, v in item.items() if not k.startswith("_")}


def _ui_resolve_node(element_id: str, window_title: str = ""):
    """按 element_id 重新定位控件，返回 (item, 控件包装)。

    element_id 来自最近一次 ui_list/ui_find 的 id。界面结构变化后引用会失效
    （与上游 computer_use 契约一致：结构重建/元素移除 → 引用全失效），
    此时抛出明确错误，要求重新观察后再操作，绝不猜测、不硬点。
    """
    eid = str(element_id or "").strip()
    if not eid:
        raise RuntimeError("缺少 element_id（来自 ui_list/ui_find 的控件 id）")
    items, _hwnd = _ui_collect_nodes(str(window_title or "").strip(), 0)
    for it in items:
        if it["id"] == eid:
            return it, it["_el"]
    raise RuntimeError(
        f"element_id '{eid}' 已失效（界面结构可能已变化）。"
        "请重新调用 ui_list / ui_find 获取最新 element_id 后再操作。")


# UI 控件树快照缓存（disable_diff 增量语义）：hwnd -> {element_id: 签名}
_ui_tree_cache: dict = {}
_UI_TREE_CACHE_MAX = 32


def _ui_signature(item: dict) -> tuple:
    """控件签名（增量比对用）：类型/名称/几何。"""
    return (item["type"], item["name"], item["x"], item["y"],
            item["width"], item["height"])


def _ui_cache_put(hwnd: int, items: list) -> None:
    """写入控件树快照（供下次增量比对；超上限做简单先进先出淘汰）。"""
    if len(_ui_tree_cache) >= _UI_TREE_CACHE_MAX and hwnd not in _ui_tree_cache:
        _ui_tree_cache.pop(next(iter(_ui_tree_cache)))
    _ui_tree_cache[hwnd] = {it["id"]: _ui_signature(it) for it in items}


def _ui_diff(hwnd: int, items: list) -> tuple:
    """与上次快照比对，返回 (changed, removed)。changed 为公开后的控件列表。"""
    old = _ui_tree_cache.get(hwnd) or {}
    cur = {it["id"]: _ui_signature(it) for it in items}
    changed = [_ui_public(it) for it in items if old.get(it["id"]) != _ui_signature(it)]
    removed = [k for k in old if k not in cur]
    return changed, removed


def _ui_list(window_title: str = "", max_items: int | None = None,
             disable_diff: bool = False, max_depths: int | None = None) -> ToolResult:
    """列出当前前台窗口（或指定标题窗口）的可交互 UI 控件，供模型了解界面结构。

    默认返回「与上次观察相比的增量」（界面没变就只回一句 no_change，省上下文）；
    需要全量树时传 disable_diff=true。max_depths 可选，按层级限深。
    """
    try:
        title = str(window_title or "").strip()
        items, hwnd = _ui_collect_nodes(title, max_items, max_depths)
        wname = title or "前台窗口"
        if not items:
            return ToolResult.err_result(
                f"窗口 '{wname}' 未读到可交互控件（可能窗口不存在/无标题/自绘 UI）。"
                "可改用 screen_analyze 走 OCR 元素表定位目标。")
        # 增量模式：只有「曾观察过该窗口」才给 diff，首次一律全量（让模型先看清结构）
        if not disable_diff and hwnd in _ui_tree_cache:
            changed, removed = _ui_diff(hwnd, items)
            _ui_cache_put(hwnd, items)
            if not changed and not removed:
                return ToolResult.ok_result(
                    json.dumps({"window": wname, "changed": False, "count": len(items),
                                "summary": "界面自上轮观察无变化（需要全量树请传 disable_diff=true）"},
                               ensure_ascii=False),
                    brief="界面无变化")
            return ToolResult.ok_result(
                json.dumps({"window": wname, "changed": True, "count": len(items),
                            "changed_count": len(changed), "removed": removed,
                            "items": changed,
                            "summary": f"相对上轮观察：{len(changed)} 个控件新增/变更、"
                                       f"{len(removed)} 个移除（需要全量树请传 disable_diff=true）"},
                           ensure_ascii=False),
                brief=f"界面变化：{len(changed)} 变更 / {len(removed)} 移除")
        _ui_cache_put(hwnd, items)
        out = {"window": wname, "changed": True, "full": True, "count": len(items),
               "items": [_ui_public(it) for it in items]}
        text = json.dumps(out, ensure_ascii=False)
        return ToolResult.ok_result(text, brief=f"识别 {len(items)} 个控件")
    except _WinAmbiguous as e:
        cands = [{"hwnd": h, "title": t[:60]} for h, t in e.wins]
        return ToolResult.err_result(
            f"标题含 '{title}' 的可见窗口有 {len(e.wins)} 个："
            f"{json.dumps(cands, ensure_ascii=False)[:500]}。"
            "请用更精确的窗口标题重试，或先 window_control 激活目标窗口"
            "（激活后可不传 window_title，直接读前台窗口）")
    except Exception as e:
        return ToolResult.err_result(
            f"UI 控件树读取失败: {e}（可改用 screen_analyze 走 OCR 元素表）")


def _ui_find(text: str = "", control_type: str = "", window_title: str = "",
             occurrence: int = 1) -> ToolResult:
    """在控件树中按名称关键字或控件类型定位元素，返回 id/中心坐标/边界框。

    返回的 id 是稳定元素引用，可直接传给 mouse_click/keyboard_type/
    set_value/perform_action 的 element_id 参数做定向操作（比坐标更不容易点错）。
    """
    try:
        target = str(text or "").strip().lower()
        ctype = str(control_type or "").strip()
        if not target and not ctype:
            return ToolResult.err_result("缺少参数 text（名称关键字）或 control_type（控件类型）")
        title = str(window_title or "").strip()
        items, _hwnd = _ui_collect_nodes(title, 0)
        matches = []
        for it in items:
            if ctype and it["type"].lower() != ctype.lower():
                continue
            if target and target not in it["name"].lower():
                continue
            matches.append(it)
        if not matches:
            # 失败时返回候选控件（2026-08-18 修复：让模型看到真实控件再调整目标）
            cands = [{"id": it["id"], "type": it["type"], "name": it["name"][:40],
                      "center": it["center"]} for it in items[:12]]
            hint = (json.dumps(cands, ensure_ascii=False)[:500] if cands
                    else "（控件树为空，可先调用 ui_list 查看）")
            return ToolResult.err_result(
                f"控件树中未找到匹配（text='{text}' type='{control_type}'）。"
                f"候选控件（前 12 个）：{hint}。如界面为自绘（如微信），"
                "请改用 screen_describe（VLM）描述屏幕后再定位。")
        idx = min(int(occurrence), len(matches)) - 1
        m = matches[idx]
        out = {"found": True, "id": m["id"], "type": m["type"], "name": m["name"],
               "x": m["center"][0], "y": m["center"][1],
               "bbox": [m["x"], m["y"], m["width"], m["height"]],
               "occurrence": idx + 1, "total_matches": len(matches)}
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"定位 {m['type']} '{m['name']}' @{tuple(m['center'])}")
    except _WinAmbiguous as e:
        cands = [{"hwnd": h, "title": t[:60]} for h, t in e.wins]
        return ToolResult.err_result(
            f"标题含 '{title}' 的可见窗口有 {len(e.wins)} 个："
            f"{json.dumps(cands, ensure_ascii=False)[:500]}。"
            "请用更精确的窗口标题重试，或先 window_control 激活目标窗口"
            "（激活后可不传 window_title，直接读前台窗口）")
    except Exception as e:
        return ToolResult.err_result(f"UI 定位失败: {e}（可改用 OCR 路径 find_on_screen）")


# ============ 语义层：本地 VLM 图像理解（视觉升级方案 §5，screen_describe） ============

_vlm_checked = False
_vlm_ready = False


def _vlm_available() -> str:
    """检查本地视觉模型可用性，返回 '' 表示可用，否则返回缺失原因（结果缓存）。"""
    global _vlm_checked, _vlm_ready
    if not _vlm_checked:
        with _pg_lock:
            if not _vlm_checked:
                _vlm_checked = True
                try:
                    import requests
                    r = requests.get(f"{config.OLLAMA_HOST}/api/tags", timeout=3)
                    models = [m.get("name", "") for m in r.json().get("models", [])]
                    _vlm_ready = any(config.VLM_MODEL in name for name in models)
                except Exception:
                    _vlm_ready = False
    if not _vlm_ready:
        return (f"本地视觉模型 {config.VLM_MODEL} 不可用（Ollama 未运行或模型未拉取）。"
                f"请确认 Ollama 已启动并执行 ollama pull {config.VLM_MODEL}，重启后生效。"
                "可用 OCR/控件树路径替代。")
    return ""


def _clean_vlm_output(text: str, max_len: int = 600) -> str:
    """轻量后处理：去 Markdown 代码围栏、压多余空行、限长截断。

    小 VLM（gemma3:4b）输出常带 ```json 围栏或空行噪音，主模型解析不了；
    截断防冗长描述（英文废话/分点列举）撑爆主模型上下文。
    """
    if not text:
        return ""
    t = re.sub(r"```(?:json|markdown|text|xml)?\s*", "", text)
    t = t.replace("```", "")
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{2,}", "\n", t).strip()
    if len(t) > max_len:
        t = t[:max_len].rstrip() + "…"
    return t


def _vlm_describe_image(img, question: str = "") -> str:
    """把 PIL 截图交给本地视觉模型，返回语义描述文本。

    走 Ollama /api/generate（images 字段传 base64 PNG），流式关闭。
    稳定性加固（2026-09-04，真屏调研 gemma3:4b 乱输出教训）：
      - 低温采样（temperature=0.2, top_p=0.9）降低随机性与幻觉；
      - 有提问 → 强制"直接简短中文结论、无法确认就答无法确认、不猜测"；
        无提问 → 自动描述限 80 字内；num_predict 同步收窄；
      - 输出后处理 _clean_vlm_output（去代码围栏/压空行/限长），保证主模型可用。
    无 VLM 时抛出 RuntimeError（含原因），由调用方转为工具错误。
    """
    import base64
    import io
    import requests
    reason = _vlm_available()
    if reason:
        raise RuntimeError(reason)
    q = (str(question or "")).strip()
    if q:
        prompt = (
            "你正在看一张电脑屏幕截图。请先仔细看图，然后只针对下面的提问给出简短中文结论。"
            "硬性要求：1) 直接回答，不超过 100 字，不要复述提问、不要分点列举、"
            "不要解释推理过程；2) 只依据截图中真实可见的内容，看不到/不确定就说「无法确认」，"
            "绝不猜测编造（尤其文字内容与窗口标题要照实读）；3) 不要输出 Markdown/代码围栏。\n"
            f"提问：{q}"
        )
    else:
        prompt = (
            "请用简体中文简要描述这张电脑截图，不超过 80 字：这是什么类型的界面/窗口、"
            "有哪些主要元素（按钮/输入框/菜单/弹窗/提示等）、有没有错误、需要注意的地方。"
            "只描述图中真实存在的内容，不要猜测编造，不要输出 Markdown/代码围栏。"
        )
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
    r = requests.post(f"{config.OLLAMA_HOST}/api/generate", json={
        "model": config.VLM_MODEL,
        "prompt": prompt,
        "images": [b64],
        "stream": False,
        # 低温+限长：gemma3:4b 默认采样随机性大，英文倾向/分点废话/幻觉多为高温产物
        "options": {"num_predict": 220, "temperature": 0.2, "top_p": 0.9},
    }, timeout=config.VLM_TIMEOUT)
    r.raise_for_status()
    text = (r.json().get("response") or "").strip()
    if not text:
        raise RuntimeError("视觉模型返回为空")
    return _clean_vlm_output(text)


def _screen_describe(region=None, question: str = "") -> ToolResult:
    """截图 + 本地视觉模型 → 看懂屏幕语义（不只读文字）。"""
    try:
        pg = _lazy_pyautogui()
        img = _grab_screen(pg, region)
        text = _vlm_describe_image(img, question)
        out = {"description": text, "model": config.VLM_MODEL,
               "question": (str(question or "").strip() or "自动描述")}
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=text[:60])
    except Exception as e:
        return ToolResult.err_result(f"图像理解失败: {e}")


def _screenshot_dir() -> str:
    """截图保存目录（自动创建）。"""
    d = config.AGENT_SCREENSHOT_DIR
    os.makedirs(d, exist_ok=True)
    return d


def _save_screenshot(img) -> str:
    """截图保存为 PNG，返回文件路径。"""
    import time
    from datetime import datetime
    d = _screenshot_dir()
    name = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    path = os.path.join(d, f"screen_{name}.png")
    img.save(path, "PNG")
    return path


def _grab_screen(pg, region=None):
    """全屏/区域截图，返回 PIL Image。"""
    if region:
        x, y, w, h = (int(v) for v in region)
        return pg.screenshot(region=(x, y, w, h))
    return pg.screenshot()


# ============ 行动-观察闭环（视觉升级方案 §4.2） ============

def _diff_blocks(before, after, grid=(8, 8)):
    """before/after 像素差异 → 变化块并集 bounding box 与块数。

    实现：ImageChops.difference → 灰度 → 阈值化 → 网格分块统计变化像素占比。
    返回 (bbox, n)：bbox=[x, y, w, h]（变化区域并集，屏幕坐标系），n=变化块数；
    无显著变化返回 None。全程 PIL 零新依赖。
    """
    from PIL import ImageChops, ImageStat
    if before.size != after.size:
        after = after.resize(before.size)
    diff = ImageChops.difference(before.convert("RGB"), after.convert("RGB"))
    gray = diff.convert("L").point(lambda p: 255 if p > config.UI_DIFF_THRESHOLD else 0)
    w, h = gray.size
    gw, gh = grid
    bw, bh = w // gw, h // gh
    changed = []
    for gy in range(gh):
        for gx in range(gw):
            box = (gx * bw, gy * bh, min((gx + 1) * bw, w), min((gy + 1) * bh, h))
            region = gray.crop(box)
            stat = ImageStat.Stat(region)
            ratio = stat.mean[0] / 255.0
            if ratio > config.UI_DIFF_MIN_RATIO:
                changed.append(box)
    if not changed:
        return None
    x0 = min(b[0] for b in changed)
    y0 = min(b[1] for b in changed)
    x1 = max(b[2] for b in changed)
    y1 = max(b[3] for b in changed)
    return [x0, y0, x1 - x0, y1 - y0], len(changed)


def _verify_after(before_path: str, action: str) -> str:
    """写操作后的自动验证：延时 → 截图 → 与操作前快照对比，返回差异摘要 JSON。

    结果只回传"变化摘要"（区域数/bbox/中心 + before/after 路径），供模型判断
    操作是否达预期，同时避免截图本身刷爆上下文（视觉升级方案 §7）。
    """
    import time
    pg = _lazy_pyautogui()
    time.sleep(config.UI_VERIFY_WAIT_MS / 1000.0)
    after_img = _grab_screen(pg)
    after_path = _save_screenshot(after_img)
    try:
        from PIL import Image
        before_img = Image.open(before_path)
        before_img.load()
    except Exception:
        before_img = None
    if before_img is None:
        return json.dumps({"after": after_path, "changed": None,
                           "summary": f"{action}后已截图（操作前快照缺失，无法对比）"},
                          ensure_ascii=False)
    res = _diff_blocks(before_img, after_img)
    if res is None:
        return json.dumps({"before": before_path, "after": after_path,
                           "changed": False,
                           "summary": f"{action}后屏幕无显著变化（可能界面未响应，可等待后再次截图确认）"},
                          ensure_ascii=False)
    bbox, n = res
    cx, cy = bbox[0] + bbox[2] // 2, bbox[1] + bbox[3] // 2
    out = {"before": before_path, "after": after_path, "changed": True,
           "regions": n, "bbox": bbox, "center": [cx, cy],
           "summary": f"{action}后屏幕出现 {n} 处变化，主变化区域中心 ({cx},{cy})"}
    # 闭环升级（阶段 2b，config.UI_VERIFY_VLM 默认开启）：VLM 可用时对操作后截图
    # 自动生成"结果是否达预期"判断（gemma3:4b，每次写操作多花几秒；VLM 不可用自动跳过）。
    if config.UI_VERIFY_VLM and not _vlm_available():
        try:
            import time as _t
            _t.sleep(config.UI_VERIFY_WAIT_MS / 1000.0)
            judge = _vlm_describe_image(after_img, f"{action}后截图发生了什么变化？是否成功？")
            out["judge"] = judge
            out["summary"] = f"{action}后：{judge}"
        except Exception:
            pass
    return json.dumps(out, ensure_ascii=False)


def _verify_before(pg) -> str:
    """写操作前的快照：返回截图路径（验证闭环用），总开关关闭时返回空串。"""
    if not config.UI_VERIFY_ENABLED:
        return ""
    try:
        return _save_screenshot(_grab_screen(pg))
    except Exception:
        return ""


# ============ 工具实现（fn(**args) 具名参数，registry.execute 解包调用） ============

def _screen_capture(region=None) -> ToolResult:
    """全屏/指定区域截图，返回保存路径与尺寸。"""
    try:
        pg = _lazy_pyautogui()
        img = _grab_screen(pg, region)
        path = _save_screenshot(img)
        w, h = img.size
        text = json.dumps({"path": path, "width": w, "height": h,
                           "region": region or "full"}, ensure_ascii=False)
        return ToolResult.ok_result(text, brief=f"截图已保存 {w}x{h}")
    except Exception as e:
        return ToolResult.err_result(f"截图失败: {e}")


def _screen_ocr(region=None, min_confidence: float | None = None) -> ToolResult:
    """识别当前屏幕全部文字，返回文字块+坐标+置信度。"""
    reason = _ocr_available()
    if reason:
        return ToolResult.err_result(reason)
    try:
        pg = _lazy_pyautogui()
        img = _grab_screen(pg, region)
        min_conf = float(min_confidence if min_confidence is not None
                         else config.OCR_MIN_CONFIDENCE)
        ts = _lazy_pytesseract()
        data = ts.image_to_data(img, lang=config.OCR_LANG, config="--psm 6",
                                output_type=ts.Output.DICT)
        blocks = []
        for i in range(len(data["text"])):
            text = (data["text"][i] or "").strip()
            conf = float(data["conf"][i])
            if not text or conf <= 0 or conf < min_conf:
                continue
            blocks.append({
                "text": text,
                "confidence": round(conf, 1),
                "x": int(data["left"][i]), "y": int(data["top"][i]),
                "width": int(data["width"][i]), "height": int(data["height"][i]),
                "center": [int(data["left"][i] + data["width"][i] / 2),
                           int(data["top"][i] + data["height"][i] / 2)],
            })
        # 限制返回条数，防止结果过长喂爆上下文（保留屏幕主区域优先）
        blocks = blocks[:100]
        text = json.dumps({"count": len(blocks), "items": blocks}, ensure_ascii=False)
        return ToolResult.ok_result(text, brief=f"识别到 {len(blocks)} 处文字")
    except Exception as e:
        return ToolResult.err_result(f"OCR 识别失败: {e}")


def _find_on_screen(text: str = "", occurrence: int = 1) -> ToolResult:
    """按文字定位屏幕元素，返回中心坐标/边界框/置信度。

    未找到时返回屏幕上的部分可见文字，帮助模型自行调整目标文字。
    """
    reason = _ocr_available()
    if reason:
        return ToolResult.err_result(reason)
    try:
        target = str(text or "").strip()
        if not target:
            return ToolResult.err_result("缺少参数 text（要查找的文字）")
        pg = _lazy_pyautogui()
        img = _grab_screen(pg)
        ts = _lazy_pytesseract()
        data = ts.image_to_data(img, lang=config.OCR_LANG, config="--psm 6",
                                output_type=ts.Output.DICT)
        matches = []
        all_text = []
        for i in range(len(data["text"])):
            text = (data["text"][i] or "").strip()
            if not text:
                continue
            all_text.append(text)
            if target.lower() in text.lower():
                conf = float(data["conf"][i])
                matches.append({
                    "text": text, "confidence": round(conf, 1),
                    "x": int(data["left"][i]), "y": int(data["top"][i]),
                    "width": int(data["width"][i]), "height": int(data["height"][i]),
                })
        if not matches:
            hint = "，".join(all_text[:15]) or "（屏幕无可见文字）"
            # 乱码/自绘界面检测（2026-08-18 + 2026-09-06 加强）：目标是中文，但 OCR
            # 读出的文字与目标**一个汉字都不重合** → 整屏识别失败（如微信自绘界面
            # 把中文读成零散噪声"口 一 …"），引导改用 VLM，别让模型反复试错。
            # 注意判据必须是"字符零重合"而非"不含中文"：乱码噪声往往也含汉字，
            # 只查"有没有读出中文"会漏网（老判据的盲区）。
            has_cjk_target = any("\u4e00" <= ch <= "\u9fff" for ch in target)
            if has_cjk_target:
                target_chars = set(ch for ch in target if "\u4e00" <= ch <= "\u9fff")
                seen_all = "".join(all_text[:60])   # 重合判定多看些字，展示仍截断
                if not any(ch in seen_all for ch in target_chars):
                    return ToolResult.err_result(
                        f"未在屏幕上找到文字 '{target}'，且 OCR 读出的文字与其无一字重合"
                        f"（{hint}），疑似整屏乱码。本机 OCR 对中文/自绘界面（如微信）"
                        "识别很差，请改用 screen_describe（VLM）描述当前屏幕内容来确认"
                        "界面，再根据描述中的文字重新定位。")
            return ToolResult.err_result(
                f"未在屏幕上找到文字 '{target}'。屏幕上的可见文字：{hint}。"
                "请用 screen_ocr 查看完整屏幕内容后重新定位。")
        # 按出现顺序取第 occurrence 个；找不到则取最后一个
        idx = min(occurrence, len(matches)) - 1
        m = matches[idx]
        cx, cy = m["x"] + m["width"] // 2, m["y"] + m["height"] // 2
        out = {"found": True, "text": m["text"], "confidence": m["confidence"],
               "x": cx, "y": cy, "bbox": [m["x"], m["y"], m["width"], m["height"]],
               "occurrence": idx + 1, "total_matches": len(matches)}
        text = json.dumps(out, ensure_ascii=False)
        return ToolResult.ok_result(text, brief=f"定位 '{target}' @({cx},{cy})")
    except Exception as e:
        return ToolResult.err_result(f"定位失败: {e}")


# ---------------- screen_analyze（M2 阶段 3 · 屏幕理解） ----------------

def _dedupe_overlaps(blocks):
    """去重：OCR 常把同一文字识别出多个重叠块，保留置信度最高的那个。

    按置信度降序贪心：新块与已保留块交集面积 > 较小块 50% 视为重复。
    """
    out = []
    for b in sorted(blocks, key=lambda x: -x["confidence"]):
        bad = False
        for k in out:
            ix = max(0, min(b["x"] + b["width"], k["x"] + k["width"]) - max(b["x"], k["x"]))
            iy = max(0, min(b["y"] + b["height"], k["y"] + k["height"]) - max(b["y"], k["y"]))
            if ix * iy > 0.5 * min(b["width"] * b["height"], k["width"] * k["height"]):
                bad = True
                break
        if not bad:
            out.append(b)
    return out


def _join_text(a: str, b: str) -> str:
    """相邻文字合并：中英混排加空格（"Open"+"File"→"Open File"），中文贴紧。"""
    if a and b and a[-1].isascii() and b[0].isascii():
        return a + " " + b
    return a + b


def _group_into_elements(blocks, gap_px: int = 14):
    """把 OCR 文字块合并成屏幕元素：同行且横向间隙小的块合并为一个可点击元素。

    步骤：① 按 y 中心分桶成行；② 行内按 x 排序、间隙 ≤ gap_px 的相邻块合并；
    ③ 输出元素（合并文本 + 并集边界框 + 最低置信度）。
    """
    rows = []
    for b in sorted(blocks, key=lambda x: (x["y"], x["x"])):
        cy = b["y"] + b["height"] / 2
        target = None
        for row in rows:
            if row["y_top"] - b["height"] * 0.5 <= cy <= row["y_bottom"] + b["height"] * 0.5:
                target = row
                break
        if target is None:
            target = {"y_top": b["y"], "y_bottom": b["y"] + b["height"], "blocks": []}
            rows.append(target)
        target["y_top"] = min(target["y_top"], b["y"])
        target["y_bottom"] = max(target["y_bottom"], b["y"] + b["height"])
        target["blocks"].append(b)

    elements = []
    for row in rows:
        cur = None
        for b in sorted(row["blocks"], key=lambda x: x["x"]):
            if cur is None or b["x"] - (cur["x"] + cur["width"]) > gap_px:
                if cur:
                    elements.append(cur)
                cur = {"x": b["x"], "y": b["y"], "width": b["width"],
                       "height": b["height"], "text": b["text"],
                       "confidence": b["confidence"]}
            else:
                cur["width"] = (b["x"] + b["width"]) - cur["x"]
                cur["height"] = max(cur["height"], b["y"] + b["height"] - cur["y"])
                cur["text"] = _join_text(cur["text"], b["text"])
                cur["confidence"] = min(cur["confidence"], b["confidence"])
        if cur:
            elements.append(cur)
    return elements


def _screen_analyze(region=None, focus: str = "") -> ToolResult:
    """理解当前屏幕：截图+OCR → 精炼「屏幕元素表」，供模型操作前看清布局。"""
    reason = _ocr_available()
    if reason:
        return ToolResult.err_result(reason)
    try:
        pg = _lazy_pyautogui()
        img = _grab_screen(pg, region)
        w, h = img.size
        ts = _lazy_pytesseract()
        data = ts.image_to_data(img, lang=config.OCR_LANG, config="--psm 6",
                                output_type=ts.Output.DICT)
        blocks = []
        min_conf = float(config.OCR_MIN_CONFIDENCE)
        for i in range(len(data["text"])):
            t = (data["text"][i] or "").strip()
            conf = float(data["conf"][i])
            if not t or conf <= 0 or conf < min_conf:
                continue
            blocks.append({"text": t, "confidence": conf,
                           "x": int(data["left"][i]), "y": int(data["top"][i]),
                           "width": int(data["width"][i]), "height": int(data["height"][i])})
        elements = _group_into_elements(_dedupe_overlaps(blocks))
        if focus:
            f = str(focus).strip()
            elements = [e for e in elements if f.lower() in e["text"].lower()]
        # 左上→右下排序，限制条数防刷爆上下文
        elements.sort(key=lambda e: (e["y"], e["x"]))
        shown = elements[:config.SCREEN_ANALYZE_MAX_ITEMS]
        out = [{"text": e["text"], "confidence": round(e["confidence"], 1),
                "x": e["x"], "y": e["y"], "width": e["width"], "height": e["height"],
                "center": [e["x"] + e["width"] // 2, e["y"] + e["height"] // 2]}
               for e in shown]
        text = json.dumps({"width": w, "height": h, "total": len(elements),
                           "shown": len(out), "elements": out}, ensure_ascii=False)
        note = f"识别 {len(elements)} 个元素" + (f"，按 '{focus}' 过滤" if focus else "")
        return ToolResult.ok_result(text, brief=note)
    except Exception as e:
        return ToolResult.err_result(f"屏幕分析失败: {e}")


def _mouse_click(x: int | None = None, y: int | None = None, text: str = "",
                 button: str = "left", clicks: int = 1,
                 occurrence: int = 1, element_id: str = "") -> ToolResult:
    """点击：给 element_id（控件引用）定向点击，或给坐标 (x,y)，或给文字 text 定位后点击。

    优先顺序：element_id > 坐标 > 文字。
    自动附带"行动-观察闭环"：操作前快照 → 点击 → 操作后快照 →
    差异摘要回填（见视觉升级方案 §4.2）。
    """
    try:
        pg = _lazy_pyautogui()
        eid = str(element_id or "").strip()
        if eid:
            # 控件引用定向：比坐标稳（不受界面轻微位移影响），引用失效会明确报错
            it, _el = _ui_resolve_node(eid)
            x, y = it["center"]
        elif x is None or y is None:
            target = str(text or "").strip()
            if not target:
                return ToolResult.err_result("缺少 element_id、坐标 (x,y) 或要点击的文字 text")
            found = _find_on_screen(text=target, occurrence=occurrence)
            if not found.ok:
                return found
            data = json.loads(found.text)
            x, y = data["x"], data["y"]
        x, y = int(x), int(y)
        # 坐标越界校验（2026-08-18 修复：昨天实测鼠标点中屏幕角落触发 fail-safe）
        sw, sh = pg.size()
        if x < 0 or y < 0 or x >= sw or y >= sh:
            return ToolResult.err_result(
                f"点击坐标 ({x},{y}) 超出屏幕范围（屏幕 {sw}x{sh}）。"
                "请先用 screen_capture/screen_analyze 确认目标实际位置后再点击。")
        before_path = _verify_before(pg)
        pg.click(x=x, y=y, button=button, clicks=clicks)
        out = {"clicked": [x, y], "button": button, "clicks": clicks}
        if eid:
            out["element_id"] = eid
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "点击"))
            except Exception:
                pass
        text = json.dumps(out, ensure_ascii=False)
        return ToolResult.ok_result(text, brief=f"点击 ({x},{y})")
    except Exception as e:
        return ToolResult.err_result(f"点击失败: {e}")


def _set_clipboard_text(text: str) -> None:
    """把文本写入 Windows 剪贴板（CF_UNICODETEXT，纯标准库）。

    用于中文/特殊字符输入：先贴剪贴板再 Ctrl+V，避免 IME 与
    pyautogui.typewrite 无法输入非 ASCII 的问题（AIPC 已验证该路径）。

    注意：64 位 Python 下句柄/指针是 64 位，必须显式声明 restype，
    否则 ctypes 默认按 c_int(32 位) 解释返回值，指针被截断导致
    GlobalLock 返回无效地址、memmove 写 0 地址直接崩溃（已踩坑）。
    """
    import ctypes
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    CF_UNICODETEXT = 13
    # 64 位下句柄/指针是 64 位，restype 与 argtypes 都必须显式声明：
    #   - restype 不设：默认按 c_int(32 位) 解释返回值 → 指针截断 → 写 0 地址崩溃
    #   - argtypes 不设：句柄作为参数传入时按 c_int 转换 → int too long 溢出
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]

    if not user32.OpenClipboard(None):
        raise RuntimeError("无法打开剪贴板")
    try:
        user32.EmptyClipboard()
        data = text.encode("utf-16-le") + b"\x00\x00"
        h = kernel32.GlobalAlloc(0x0042, len(data))  # GMEM_MOVEABLE | GMEM_ZEROINIT
        if not h:
            raise RuntimeError("GlobalAlloc 分配失败")
        p = kernel32.GlobalLock(h)
        if not p:
            raise RuntimeError("GlobalLock 失败")
        ctypes.memmove(p, data, len(data))
        kernel32.GlobalUnlock(h)
        if not user32.SetClipboardData(CF_UNICODETEXT, h):
            raise RuntimeError("SetClipboardData 失败")
    finally:
        user32.CloseClipboard()


def _foreground_title() -> str:
    """当前前台窗口标题（读不到返回空串）。"""
    from .windows import _get_windows
    win = _get_windows()
    fg = win.user32.GetForegroundWindow()
    if not fg:
        return ""
    return win._title_of(fg)


# 助手自身窗口标题关键字：键盘输入落在这里必然错误（已踩坑：输入进聊天框）
_ASSISTANT_TITLE_HINTS = ("知识库桌面助手", "快速问答", "Lazaxa")


def _keyboard_type(text: str = "", window_title: str = "",
                   element_id: str = "") -> ToolResult:
    """向当前焦点窗口输入文字。纯 ASCII 直接敲键；中文走剪贴板粘贴。

    给 element_id 时先聚焦该控件再输入（定向输入，不依赖前台窗口猜测）。

    安全（防止输入落到错误窗口）：
      1. 给了 window_title → 输入前校验前台窗口标题包含它（支持中英别名）；
      2. 未给 → 若有最近激活的目标窗口（open_app/window_control），校验前台仍是它；
      3. 都没有 → 若前台是助手自己的窗口，拒绝输入（等模型先激活目标）。
    """
    try:
        text = str(text or "")
        if not text:
            return ToolResult.err_result("缺少参数 text（要输入的文字）")
        eid = str(element_id or "").strip()
        focused = ""
        if eid:
            # 定向输入：显式指定了控件 → 聚焦它即可，无需再做前台窗口启发式校验
            it, el = _ui_resolve_node(eid)
            el.set_focus()
            focused = it["name"]
        else:
            expected = str(window_title or "").strip()
            real = _foreground_title()
            if expected:
                from .windows import _title_keywords
                if not any(k.lower() in real.lower() for k in _title_keywords(expected)):
                    return ToolResult.err_result(
                        f"当前前台窗口是 '{real}'，与目标 '{expected}' 不匹配，已拒绝输入。"
                        "请先调用 window_control 激活目标窗口后再输入。")
            else:
                from .windows import _last_target_title
                target_hint = _last_target_title()
                if target_hint and target_hint.lower() not in real.lower():
                    return ToolResult.err_result(
                        f"最近目标窗口是 '{target_hint}'，但当前前台窗口是 '{real}'，已拒绝输入。"
                        "请先调用 window_control 激活目标窗口，或给 keyboard_type 传 window_title。")
                if not target_hint and any(h in real for h in _ASSISTANT_TITLE_HINTS):
                    return ToolResult.err_result(
                        f"当前焦点在助手窗口 '{real}'，拒绝输入。"
                        "请先调用 window_control 激活目标窗口（如记事本），再输入。")
        pg = _lazy_pyautogui()
        before_path = _verify_before(pg)
        if text.isascii():
            pg.typewrite(text, interval=0.02)
        else:
            _set_clipboard_text(text)
            pg.hotkey("ctrl", "v")
        out = {"input_chars": len(text)}
        if eid:
            out["element_id"] = eid
            out["element"] = focused
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "输入"))
            except Exception:
                pass
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"输入 {len(text)} 字符")
    except Exception as e:
        return ToolResult.err_result(f"输入失败: {e}")


def _normalize_keys(keys) -> str:
    """把快捷键统一成小写 '+' 连接，如 ['ctrl','c'] / 'ctrl+c' -> 'ctrl+c'。"""
    if isinstance(keys, str):
        return "+".join(k.strip().lower() for k in re.split(r"[+\s]+", keys) if k.strip())
    return "+".join(str(k).strip().lower() for k in (keys or []) if str(k).strip())


def _keyboard_press(keys=None, shortcut: str | None = None) -> ToolResult:
    """按键/快捷键，如 keys=['ctrl','c'] 或 shortcut='ctrl+c'。黑名单外才执行。"""
    try:
        shortcut = _normalize_keys(keys or shortcut)
        if not shortcut:
            return ToolResult.err_result("缺少参数 keys（按键列表）或 shortcut（如 ctrl+c）")
        if shortcut in _HOTKEY_BLACKLIST:
            return ToolResult.err_result(f"快捷键 '{shortcut}' 在黑名单中，已拒绝执行")
        pg = _lazy_pyautogui()
        before_path = _verify_before(pg)
        pg.hotkey(*shortcut.split("+"))
        out = {"pressed": shortcut}
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "按键"))
            except Exception:
                pass
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"按键 {shortcut}")
    except Exception as e:
        return ToolResult.err_result(f"按键失败: {e}")


# ============ 控件动作原语（2026-09-29 · 契约对标 P0-2） ============
# 对标上游 computer_use 的 scroll / drag / set_value / perform_action：
# 补上「结构化动作」这一层，减少纯坐标点的脆弱性与多行输入的剪贴板绕行。

_SCROLL_CLICKS_PER_PAGE = 100   # 一页滚动的滚轮刻度（pyautogui 1 刻度≈3 行）

# perform_action 支持的动作 → (依赖的 UIA 模式名, 实际调用)
# 模式名为空表示无前置模式要求。执行前会探测控件是否真支持该模式，
# 只用无障碍树实际暴露的动作（对齐上游契约），不猜测、不硬点。
_UI_ACTION_IMPL = {
    "invoke":           ("invoke",          lambda el: el.iface_invoke.Invoke()),
    "toggle":           ("toggle",          lambda el: el.iface_toggle.Toggle()),
    "select":           ("selection_item",  lambda el: el.iface_selection_item.Select()),
    "expand":           ("expand_collapse", lambda el: el.iface_expand_collapse.Expand()),
    "collapse":         ("expand_collapse", lambda el: el.iface_expand_collapse.Collapse()),
    "set_focus":        ("",                lambda el: el.set_focus()),
    "scroll_into_view": ("scroll_item",     lambda el: el.iface_scroll_item.ScrollIntoView()),
}


def _ui_pattern(el, name: str):
    """取控件的 UIA 模式接口（name 如 value/invoke）；不支持时返回 None。"""
    if not name:
        return True
    try:
        return getattr(el, f"iface_{name}")
    except Exception:
        return None


def _scroll(x: int | None = None, y: int | None = None,
            direction: str = "down", pages: int = 1) -> ToolResult:
    """滚动：direction=up/down/left/right，pages 为页数（默认 1）。

    可选 x/y 指定滚动发生的坐标（如滚到某个列表区域内）；缺省用当前鼠标位置。
    """
    try:
        d = str(direction or "down").strip().lower()
        if d not in ("up", "down", "left", "right"):
            return ToolResult.err_result(f"未知方向 '{direction}'，可用: up/down/left/right")
        n = max(1, int(pages or 1))
        clicks = _SCROLL_CLICKS_PER_PAGE * n
        px = int(x) if x is not None else None
        py = int(y) if y is not None else None
        pg = _lazy_pyautogui()
        before_path = _verify_before(pg)
        if d == "up":
            pg.scroll(clicks, x=px, y=py)
        elif d == "down":
            pg.scroll(-clicks, x=px, y=py)      # pyautogui：负值向下滚
        elif d == "left":
            pg.hscroll(-clicks, x=px, y=py)
        else:
            pg.hscroll(clicks, x=px, y=py)
        out = {"scrolled": d, "pages": n, "at": [px, py]}
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "滚动"))
            except Exception:
                pass
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"滚动 {d} {n} 页")
    except Exception as e:
        return ToolResult.err_result(f"滚动失败: {e}")


def _drag(fromX: int | None = None, fromY: int | None = None,
          toX: int | None = None, toY: int | None = None,
          duration: float = 0.5, button: str = "left") -> ToolResult:
    """拖拽：从 (fromX,fromY) 拖到 (toX,toY)。

    用于拖动滑块/滚动条、移动窗口、框选、拖文件到目标位置。
    """
    try:
        if None in (fromX, fromY, toX, toY):
            return ToolResult.err_result("缺少参数：需要 fromX/fromY/toX/toY 四个坐标")
        fx, fy, tx, ty = int(fromX), int(fromY), int(toX), int(toY)
        pg = _lazy_pyautogui()
        sw, sh = pg.size()
        for px, py in ((fx, fy), (tx, ty)):
            if px < 0 or py < 0 or px >= sw or py >= sh:
                return ToolResult.err_result(
                    f"拖拽坐标 ({px},{py}) 超出屏幕范围（屏幕 {sw}x{sh}），请先确认目标位置。")
        before_path = _verify_before(pg)
        pg.moveTo(fx, fy, duration=float(duration))
        pg.dragTo(tx, ty, duration=float(duration), button=str(button or "left"))
        out = {"dragged": [[fx, fy], [tx, ty]], "button": button}
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "拖拽"))
            except Exception:
                pass
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"拖拽 ({fx},{fy})→({tx},{ty})")
    except Exception as e:
        return ToolResult.err_result(f"拖拽失败: {e}")


def _set_value(element_id: str = "", value: str = "",
               window_title: str = "") -> ToolResult:
    """把文本直接写入控件（UIA ValuePattern）——多行文本/表单的首选。

    与 keyboard_type 的区别：不经键盘，不受焦点切换/输入法影响，可一次写入多行内容
    （上游契约明确：多行输入必须用 set_value，type_text 不支持换行）。
    """
    try:
        eid = str(element_id or "").strip()
        if not eid:
            return ToolResult.err_result("缺少参数 element_id（来自 ui_list/ui_find 的控件 id）")
        it, el = _ui_resolve_node(eid, window_title)
        iface = _ui_pattern(el, "value")
        if iface is None:
            return ToolResult.err_result(
                f"控件 '{it['name']}'（{it['type']}）不支持直接写值（无 ValuePattern）。"
                "可改用 keyboard_type 走键盘输入。")
        val = str(value if value is not None else "")
        iface.SetValue(val)
        return ToolResult.ok_result(
            json.dumps({"element_id": eid, "name": it["name"], "chars": len(val)},
                       ensure_ascii=False),
            brief=f"写入 {len(val)} 字符到 '{it['name']}'")
    except Exception as e:
        return ToolResult.err_result(f"写值失败: {e}")


def _perform_action(element_id: str = "", action: str = "",
                    window_title: str = "") -> ToolResult:
    """在控件上执行 UIA 动作（只用控件实际支持的动作）。

    常用：invoke（点按钮）、toggle（切换勾选）、select（选中列表/树项）、
    expand/collapse（展开/收起）、set_focus（聚焦）、scroll_into_view（滚入视野）。
    比按坐标点击更可靠；控件不支持该动作时会明确报错并列出它实际支持哪些动作。
    """
    try:
        eid = str(element_id or "").strip()
        if not eid:
            return ToolResult.err_result("缺少参数 element_id（来自 ui_list/ui_find 的控件 id）")
        act = str(action or "").strip().lower()
        if act not in _UI_ACTION_IMPL:
            return ToolResult.err_result(
                f"未知动作 '{action}'，可用: {sorted(_UI_ACTION_IMPL)}")
        it, el = _ui_resolve_node(eid, window_title)
        pattern, runner = _UI_ACTION_IMPL[act]
        if _ui_pattern(el, pattern) is None:
            avail = [a for a, (pt, _f) in _UI_ACTION_IMPL.items() if _ui_pattern(el, pt)]
            return ToolResult.err_result(
                f"控件 '{it['name']}'（{it['type']}）不支持动作 '{act}'；"
                f"该控件实际支持: {avail or ['（无）']}。可改用 mouse_click 按坐标点击。")
        runner(el)
        return ToolResult.ok_result(
            json.dumps({"element_id": eid, "name": it["name"], "action": act},
                       ensure_ascii=False),
            brief=f"{act} '{it['name']}'")
    except Exception as e:
        return ToolResult.err_result(f"控件动作失败: {e}")


# UIA 文本枚举值（text 选择用到；经核实 comtypes UIAutomationClient 同名常量取值）
_TEXT_ENDPOINT_START = 0      # TextPatternRangeEndpoint_Start
_TEXT_ENDPOINT_END = 1        # TextPatternRangeEndpoint_End
_TEXT_UNIT_CHARACTER = 0      # TextUnit_Character


def _text_find(doc, needle: str):
    """在文档文本范围内查找子串；未找到返回 None（不把「没找到」当异常抛）。"""
    try:
        return doc.FindText(needle, False, False)
    except Exception:
        return None


def _select_text(element_id: str = "", text: str = "", selection: str = "text",
                 prefix: str = "", suffix: str = "", window_title: str = "") -> ToolResult:
    """在控件内按文本内容定位并选中（UIA TextPattern）——不依赖鼠标/键盘/坐标。

    selection: text=选中该文本（默认）；cursor_before=光标落到其前；cursor_after=光标落到其后。
    prefix/suffix 可选：同一文本在控件中出现多次时用于消歧——先按「前缀+文本+后缀」整体
    定位，再收缩到文本本身。

    FindText 语义（已核实）：返回的范围本身就覆盖匹配到的字符串，非退化范围。
    """
    try:
        eid = str(element_id or "").strip()
        if not eid:
            return ToolResult.err_result("缺少参数 element_id（来自 ui_list/ui_find 的控件 id）")
        needle = str(text or "")
        if not needle:
            return ToolResult.err_result("缺少参数 text（要定位并选中的文本）")
        sel = str(selection or "text").strip().lower()
        if sel not in ("text", "cursor_before", "cursor_after"):
            return ToolResult.err_result(
                f"未知 selection '{selection}'，可用: text/cursor_before/cursor_after")
        it, el = _ui_resolve_node(eid, window_title)
        iface = _ui_pattern(el, "text")
        if iface is None:
            return ToolResult.err_result(
                f"控件 '{it['name']}'（{it['type']}）不支持文本选择（无 TextPattern）。"
                "可改用 set_value 整体写值，或 keyboard_type 走键盘输入。")
        doc = iface.DocumentRange
        pre, suf = str(prefix or ""), str(suffix or "")
        rng = None
        if pre or suf:
            rng = _text_find(doc, f"{pre}{needle}{suf}")
            if rng is not None:
                if pre:      # 收缩左端：跳过前缀
                    rng.MoveEndpointByUnit(_TEXT_ENDPOINT_START, _TEXT_UNIT_CHARACTER, len(pre))
                if suf:      # 收缩右端：跳过后缀
                    rng.MoveEndpointByUnit(_TEXT_ENDPOINT_END, _TEXT_UNIT_CHARACTER, -len(suf))
        if rng is None:
            rng = _text_find(doc, needle)
        if rng is None:
            return ToolResult.err_result(
                f"在控件 '{it['name']}' 中未找到文本 '{needle}'，请先用 ui_list 确认控件内容。")
        if sel == "cursor_before":       # 终点回撤到起点 → 退化为插入点（在文本之前）
            rng.MoveEndpointByUnit(_TEXT_ENDPOINT_END, _TEXT_UNIT_CHARACTER, -len(needle))
        elif sel == "cursor_after":      # 起点推进到终点 → 退化为插入点（在文本之后）
            rng.MoveEndpointByUnit(_TEXT_ENDPOINT_START, _TEXT_UNIT_CHARACTER, len(needle))
        rng.Select()
        return ToolResult.ok_result(
            json.dumps({"element_id": eid, "name": it["name"], "text": needle,
                        "selection": sel}, ensure_ascii=False),
            brief=(f"选中 '{needle}'" if sel == "text" else f"光标定位到 '{needle}'"))
    except Exception as e:
        return ToolResult.err_result(f"文本选择失败: {e}")


# ============ 阶段 3：模板匹配 / 宏序列 / 连续监测（视觉升级方案 §6） ============

def _find_image_on_screen(image: str = "", region=None, confidence: float = 0.85,
                          max_matches: int = 5) -> ToolResult:
    """模板匹配：按图标/按钮小图在屏幕上定位（pyautogui.locateOnScreen）。

    用于没有文字、OCR 找不到的场景（图标/Logo/色块按钮）。
    image 为模板图片路径——来源有二：用户提供，或先用 screen_capture(region=...)
    截取目标区域保存为模板。返回每个匹配的中心坐标/边界框/置信度。
    """
    try:
        image = str(image or "").strip()
        if not image:
            return ToolResult.err_result("缺少参数 image（模板图片路径）")
        if not os.path.isfile(image):
            return ToolResult.err_result(f"模板图片不存在: {image}")
        pg = _lazy_pyautogui()
        conf = float(confidence)
        kwargs = {}
        if 0.0 < conf < 1.0:
            try:
                import cv2  # noqa: F401  confidence 匹配依赖 OpenCV
                kwargs["confidence"] = conf
            except Exception:
                pass  # 无 OpenCV 时降级精确匹配
        region = [int(v) for v in region] if region else None
        boxes = list(pg.locateAllOnScreen(image, region=region, **kwargs))
        # 按置信度降序 + 去重叠（保留匹配最好的，跳过与之高度重叠的候选）
        scored = []
        for b in boxes:
            c = float(getattr(b, "confidence", 1.0) or 1.0)
            scored.append((b, c))
        scored.sort(key=lambda t: t[1], reverse=True)
        kept = []
        for b, c in scored:
            if any(_box_iou(b, kb) > 0.5 for kb, _ in kept):
                continue
            kept.append((b, c))
        if not kept:
            return ToolResult.ok_result(json.dumps(
                {"found": False,
                 "summary": "未在屏幕上找到与模板匹配的区域（可用 screen_capture 确认目标是否可见，或调整 confidence）"},
                ensure_ascii=False), brief="未找到模板")
        matches = []
        for b, c in kept[:max(1, int(max_matches))]:
            left, top, w, h = int(b.left), int(b.top), int(b.width), int(b.height)
            matches.append({"center": [left + w // 2, top + h // 2],
                            "bbox": [left, top, w, h],
                            "confidence": round(c, 3)})
        out = {"found": True, "matches": matches,
               "summary": f"找到 {len(matches)} 处匹配，最高置信度 {matches[0]['confidence']}"}
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=f"找到 {len(matches)} 处匹配")
    except Exception as e:
        return ToolResult.err_result(f"模板匹配失败: {e}")


def _box_iou(a, b) -> float:
    """两个定位框的交并比（模板匹配 NMS 用）。"""
    ax1, ay1, aw, ah = a.left, a.top, a.width, a.height
    bx1, by1, bw, bh = b.left, b.top, b.width, b.height
    ix = max(0, min(ax1 + aw, bx1 + bw) - max(ax1, bx1))
    iy = max(0, min(ay1 + ah, by1 + bh) - max(ay1, by1))
    inter = ix * iy
    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0.0


# 宏序列支持的动作类型（对齐 AIPC ActionExecutor）
_SEQ_TYPES = {"click", "double_click", "move_to", "type_text", "press_key",
              "hotkey", "scroll", "drag_to", "wait"}

# 里程碑段末期望类型（P3：GUI 里程碑断言，借微软 fara）
_MILESTONE_EXPECT_TYPES = ("text", "image", "vlm", "stable")

# VLM 软判据：描述含这些否定词 → 视为"目标未出现"（避免把模棱两可当成功）
_VLM_NEGATION_HINTS = ("没有", "未出现", "不存在", "尚未", "无法确认", "未找到",
                       "看不到", "并未出现")


def _validate_seq_actions(actions):
    """校验宏动作数组 → (plan, error)。plan 元素为 (动作类型, 原字典)。

    click 等动作的具体字段不在此校验（执行时缺参会抛 KeyError，由外层统一兜底）。
    """
    if not isinstance(actions, list) or not actions:
        return None, "缺少参数 actions（动作序列数组）"
    plan = []
    for i, act in enumerate(actions):
        if not isinstance(act, dict):
            return None, f"第 {i + 1} 个动作必须是对象"
        t = str(act.get("type", "")).strip()
        if t not in _SEQ_TYPES:
            return None, (f"第 {i + 1} 个动作未知类型 '{t}'，"
                          f"支持: {sorted(_SEQ_TYPES)}")
        if t == "hotkey":
            shortcut = _normalize_keys(act.get("keys"))
            if shortcut in _HOTKEY_BLACKLIST:
                return None, f"第 {i + 1} 步快捷键 '{shortcut}' 在黑名单，已拒绝"
        plan.append((t, act))
    return plan, ""


def _execute_seq_plan(pg, plan) -> list:
    """执行校验后的宏动作序列，返回 executed 摘要列表。"""
    import time as _time
    executed = []
    for t, act in plan:
        if t == "click":
            x, y = int(act["x"]), int(act["y"])
            pg.click(x, y, button=act.get("button", "left"),
                     clicks=int(act.get("clicks", 1)))
            executed.append({"type": t, "at": [x, y]})
        elif t == "double_click":
            x, y = int(act["x"]), int(act["y"])
            pg.doubleClick(x, y)
            executed.append({"type": t, "at": [x, y]})
        elif t == "move_to":
            x, y = int(act["x"]), int(act["y"])
            pg.moveTo(x, y, duration=float(act.get("duration", 0.2)))
            executed.append({"type": t, "at": [x, y]})
        elif t == "type_text":
            text = str(act.get("text", ""))
            if text.isascii():
                pg.typewrite(text, interval=float(act.get("interval", 0.02)))
            else:
                _set_clipboard_text(text)  # 中文走剪贴板粘贴
                pg.hotkey("ctrl", "v")
            executed.append({"type": t, "chars": len(text)})
        elif t == "press_key":
            pg.press(str(act.get("key", "")))
            executed.append({"type": t, "key": act.get("key")})
        elif t == "hotkey":
            shortcut = _normalize_keys(act.get("keys"))
            pg.hotkey(*shortcut.split("+"))
            executed.append({"type": t, "keys": shortcut})
        elif t == "scroll":
            pg.scroll(int(act.get("amount", 100)),
                      x=int(act["x"]) if act.get("x") is not None else None,
                      y=int(act["y"]) if act.get("y") is not None else None)
            executed.append({"type": t, "amount": act.get("amount", 100)})
        elif t == "drag_to":
            x, y = int(act["x"]), int(act["y"])
            pg.dragTo(x, y, duration=float(act.get("duration", 0.5)),
                      button=act.get("button", "left"))
            executed.append({"type": t, "to": [x, y]})
        elif t == "wait":
            _time.sleep(float(act.get("duration", 1.0)))
            executed.append({"type": t, "duration": act.get("duration", 1.0)})
    return executed


def _run_action_sequence(actions=None, name: str = "", verify: bool = True) -> ToolResult:
    """宏序列：把一组界面操作一次性批量执行（AIPC ActionExecutor 移植）。

    每个动作是 {"type": ..., 参数...} 字典。整段序列只做一次"行动-观察闭环"
    （操作前/后快照 + 差异摘要 + VLM 判断），避免每步都调 VLM 拖慢执行。
    """
    try:
        plan, err = _validate_seq_actions(actions)
        if err:
            return ToolResult.err_result(err)
        pg = _lazy_pyautogui()
        before_path = _verify_before(pg) if verify else ""
        executed = _execute_seq_plan(pg, plan)
        out = {"name": str(name or "").strip(), "executed": executed,
               "summary": f"宏序列执行完成，共 {len(executed)} 步"}
        if before_path:
            try:
                out["verify"] = json.loads(_verify_after(before_path, "宏序列"))
            except Exception:
                pass
        return ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                    brief=out["summary"])
    except KeyError as e:
        return ToolResult.err_result(f"动作缺少参数 {e}（如 click 需要 x/y）")
    except Exception as e:
        return ToolResult.err_result(f"宏序列执行失败: {e}")


def _wait_for_change(timeout: float = 30.0, interval: float = 2.0,
                     region=None) -> ToolResult:
    """连续监测：周期截图，等到屏幕出现显著变化（如弹窗/进度条/新内容）。

    用途："等通知弹出来"、"等加载完成"、"等安装进度"。复用闭环差异引擎
    （阈值/占比与写操作验证一致）。超时无变化返回 changed=false。
    """
    import time as _time
    try:
        pg = _lazy_pyautogui()
        region = [int(v) for v in region] if region else None
        timeout = float(timeout)
        interval = max(0.2, float(interval))
        baseline = _grab_screen(pg, region)
        deadline = _time.time() + timeout
        checked = 0
        while _time.time() < deadline:
            _time.sleep(interval)
            checked += 1
            res = _diff_blocks(baseline, _grab_screen(pg, region))
            if res is None:
                continue
            bbox, n = res
            cx, cy = bbox[0] + bbox[2] // 2, bbox[1] + bbox[3] // 2
            path = _save_screenshot(_grab_screen(pg, region))
            return ToolResult.ok_result(json.dumps(
                {"changed": True, "regions": n, "bbox": bbox, "center": [cx, cy],
                 "path": path,
                 "summary": f"屏幕出现 {n} 处变化，主变化中心 ({cx},{cy})，等待耗时约 "
                            f"{int(_time.time() + timeout - deadline)}s"},
                ensure_ascii=False), brief="屏幕发生变化")
        return ToolResult.ok_result(json.dumps(
            {"changed": False, "checked": checked,
             "summary": f"等待 {timeout:g}s（检查 {checked} 次）屏幕无显著变化"},
            ensure_ascii=False), brief="等待超时无变化")
    except Exception as e:
        return ToolResult.err_result(f"屏幕监测失败: {e}")


# ============ 里程碑断言（P3：借微软 fara，把"60 步耗死在最后"变成"卡在哪一段") ============

def _wait_stable(pg, region=None, timeout: float = 8.0, frames: int = 2,
                 interval: float = 0.6):
    """期望屏幕"静下来"：连续 frames 帧无显著变化即视为稳定。

    返回 (ok, 说明)。wait_for_change 等"变化出现"，这里反向等"变化停止"
    （如保存对话框关闭后界面安顿下来），避免立刻断言撞上动画/渲染尾巴。
    """
    import time as _time
    try:
        region = [int(v) for v in region] if region else None
        frames = max(1, int(frames))
        deadline = _time.time() + float(timeout)
        stable = 0
        prev = _grab_screen(pg, region)
        checked = 0
        while _time.time() < deadline and stable < frames:
            _time.sleep(max(0.2, float(interval)))
            checked += 1
            cur = _grab_screen(pg, region)
            if _diff_blocks(prev, cur) is None:
                stable += 1
            else:
                stable = 0  # 又动了 → 重新计数
            prev = cur
        if stable >= frames:
            return True, f"屏幕已静下来（连续 {stable} 帧无显著变化）"
        return False, f"等待 {timeout:g}s 屏幕仍在变化（检查 {checked} 次）"
    except Exception as e:
        return False, f"稳定检测失败: {e}"


def _check_milestone_expect(expect: dict, region=None):
    """段末期望谓词门禁 → (命中?, 说明)。

    text=OCR 定位命中 / image=模板匹配命中 / vlm=本地视觉描述（不可用时
    自动降级放行，不阻塞）/ stable=屏幕连续静默。期望类型非法 → 失败。
    """
    etype = str((expect or {}).get("type", "")).strip()
    if etype not in _MILESTONE_EXPECT_TYPES:
        return False, f"期望类型必须为 {'/'.join(_MILESTONE_EXPECT_TYPES)}，收到 '{etype}'"
    region = expect.get("region") or region
    value = expect.get("value")
    timeout = float(expect.get("timeout", 8.0))
    if etype == "text":
        r = _find_on_screen(text=str(value or ""))
        if r.ok:
            import json as _json
            try:
                info = _json.loads(r.text)
            except Exception:
                info = {}
            return True, (f"文字 '{value}' 命中"
                          + (f" @({info['x']},{info['y']})" if info.get("x") is not None else ""))
        # OCR 目标中文但读出乱码时，_find_on_screen 的错误文本已带引导；照实回传
        return False, (r.error or f"未命中文字 '{value}'")
    if etype == "image":
        r = _find_image_on_screen(image=str(value or ""), region=region)
        if r.ok:
            return True, f"模板匹配成功: {r.brief or '找到目标'}"
        return False, (r.error or f"未匹配模板 '{value}'")
    if etype == "vlm":
        reason = _vlm_available()
        if reason:
            # VLM 不可用 → 自动降级放行（不因感知件缺失卡死整条链路）
            return True, f"VLM 不可用自动跳过（{reason[:40]}…）"
        r = _screen_describe(region=region,
                             question=str(value or "画面是否已出现预期内容？"))
        if not r.ok:
            return True, "VLM 调用失败自动跳过，不阻塞本段"
        answer = (r.text or "")[:300]
        # 软判据：描述明确说"没有/未出现/尚未"等 → 未命中；其余视为已出现
        if any(kw in answer for kw in _VLM_NEGATION_HINTS):
            return False, f"VLM 判断目标尚未出现：{answer[:120]}"
        return True, f"VLM 判断目标已出现：{answer[:120]}"
    # stable
    return _wait_stable(_lazy_pyautogui(), region=region, timeout=timeout)


def _run_action_milestones(milestones=None, name: str = "") -> ToolResult:
    """里程碑宏序列（借微软 fara）：分段执行 GUI 动作，段末断言门禁。

    入参 milestones = [{name, actions:[...], expect:{type, value, timeout, region}}]：
    - actions 复用宏序列动作语法（click/type_text/hotkey/wait…），可省略（纯断言段）；
    - expect.type: text=OCR 命中该文字 / image=模板匹配 / vlm=本地视觉确认
      （不可用自动降级放行）/ stable=期望屏幕静下来（连续 2 帧无变化）。
    逐段执行 → 段末跑断言；断言失败重试本段（至多 2 次）仍失败 → 停在失败段，
    返回结构化结果（completed 前缀列表），模型据此换策略，不把 60 步耗死在最后一步。
    """
    try:
        if not isinstance(milestones, list) or not milestones:
            return ToolResult.err_result("缺少参数 milestones（里程碑数组）")
        pg = _lazy_pyautogui()
        completed: list[str] = []
        details: list[dict] = []
        failed = ""
        fail_note = ""
        total_retries = 0
        for i, ms in enumerate(milestones):
            if not isinstance(ms, dict):
                return ToolResult.err_result(f"第 {i + 1} 个里程碑必须是对象")
            mname = str(ms.get("name", "")).strip() or f"里程碑{i + 1}"
            expect = ms.get("expect")
            if not isinstance(expect, dict) or not isinstance(expect.get("type"), str) \
                    or expect["type"].strip() not in _MILESTONE_EXPECT_TYPES:
                return ToolResult.err_result(
                    f"里程碑 '{mname}' 的 expect.type 必须为 "
                    f"{'/'.join(_MILESTONE_EXPECT_TYPES)}")
            # 纯断言段允许省略/空 actions；有动作时复用宏序列校验
            raw_actions = ms.get("actions")
            plan: list = []
            if raw_actions:
                if not isinstance(raw_actions, list):
                    return ToolResult.err_result(
                        f"里程碑 '{mname}' 的 actions 必须为动作数组")
                plan, err = _validate_seq_actions(raw_actions)
                if err:
                    return ToolResult.err_result(f"里程碑 '{mname}': {err}")
            ok, note = False, ""
            for attempt in range(3):  # 原执行 + 至多 2 次重试
                try:
                    if plan:
                        _execute_seq_plan(pg, plan)
                        import time as _t
                        _t.sleep(config.UI_VERIFY_WAIT_MS / 1000.0)
                    ok, note = _check_milestone_expect(expect)
                except KeyError as e:
                    ok, note = False, f"动作缺少参数 {e}"
                except Exception as e:
                    ok, note = False, f"里程碑执行异常: {e}"
                if ok:
                    break
                if attempt < 2:
                    total_retries += 1
                    note += f"（第 {attempt + 1} 次断言未过，重试本段）"
            details.append({"name": mname, "ok": ok, "note": note,
                            "attempts": attempt + 1})
            if not ok:
                failed = mname
                fail_note = note
                break
            completed.append(mname)
        out = {"ok": not failed, "name": str(name or "").strip(),
               "completed": completed, "milestones": details,
               "retries": total_retries}
        if failed:
            out["failed_milestone"] = failed
            out["error"] = fail_note
            out["summary"] = (f"卡在里程碑 '{failed}'（已完成 {len(completed)}/"
                              f"{len(milestones)}）：{fail_note}。"
                              "请根据 completed 列表换策略，或让用户手动处理后继续。")
            payload = json.dumps(out, ensure_ascii=False)
            res = ToolResult(text=payload, error=f"里程碑 '{failed}' 断言未过",
                             brief=f"里程碑 '{failed}' 断言未过")
            res.meta = {"retries": total_retries}   # P2-2：重试次数落审计专列
            return res
        out["summary"] = f"{len(milestones)}/{len(milestones)} 里程碑全部通过"
        res = ToolResult.ok_result(json.dumps(out, ensure_ascii=False),
                                   brief=out["summary"])
        res.meta = {"retries": total_retries}       # P2-2：重试次数落审计专列
        return res
    except Exception as e:
        return ToolResult.err_result(f"里程碑序列执行失败: {e}")


# ============ 注册 ============

def register_all(r):
    """注册 GUI 自动化工具（批次 C + 视觉升级方案阶段 1+2 + computer_use 契约对标）。

    只读（safe）：screen_capture / screen_ocr / find_on_screen / screen_analyze
                 / ui_list / ui_find（UI 控件树，输出稳定 id）/ screen_describe（本地 VLM）
    写操作（sensitive）：mouse_click / keyboard_type / keyboard_press
                 / scroll / drag / set_value / perform_action / select_text
                 （已附加行动-观察闭环：操作前/后快照 + 差异摘要回填）

    computer_use 契约对标（2026-09-29）：控件稳定引用 element_id、结构化动作原语
    （scroll/drag/set_value/perform_action/select_text）、ui_list 增量观察与限深。
    """
    r.register(Tool(
        name="ui_list",
        description=("列出当前前台窗口（或 window_title 指定窗口）的可交互 UI 控件树，"
                     "返回每个控件的 id（稳定元素引用）、类型(type)、名称(name)和中心点(center)。"
                     "适合操作界面前先调用了解结构——比 OCR 更准确（文字不会看错）。"
                     "推荐工作流：ui_list 拿 id → 动作工具传 element_id 定向操作（比坐标稳）。"
                     "默认只返回「与上次观察相比的增量」（界面没变就回一句无变化，省上下文），"
                     "需要全量树时传 disable_diff=true。"
                     "读不到控件（自绘 UI）时请改用 screen_analyze 走 OCR 元素表。"),
        parameters={"type": "object", "properties": {
            "window_title": {"type": "string",
                             "description": "可选：窗口标题关键字；缺省用当前前台窗口"},
            "max_items": {"type": "integer", "description": "可选：返回元素条数上限"},
            "disable_diff": {"type": "boolean",
                             "description": "true=返回全量控件树；缺省/省略=只返回相对上次的变化"},
            "max_depths": {"type": "integer",
                           "description": "可选：控件树限深（超过该层级的控件不返回）"},
        }},
        risk="safe", timeout=20, fn=_ui_list,
    ))
    r.register(Tool(
        name="ui_find",
        description=("在 UI 控件树中按名称关键字(text)或控件类型(control_type)定位元素，"
                     "返回 id（稳定元素引用）、中心坐标(x,y)与边界框(bbox)。"
                     "优先把 id 传给 mouse_click/keyboard_type/set_value/perform_action 的 "
                     "element_id 做定向操作；也可用坐标传给 mouse_click。"
                     "比 find_on_screen（OCR 文字定位）更准确。"
                     "找不到时请先用 ui_list 查看全部控件，或改用 OCR 路径。"),
        parameters={"type": "object", "properties": {
            "text": {"type": "string", "description": "控件名称关键字（支持部分匹配）"},
            "control_type": {"type": "string",
                             "description": "控件类型，如 Button/Edit/ComboBox/CheckBox"},
            "window_title": {"type": "string", "description": "可选：窗口标题；缺省前台窗口"},
            "occurrence": {"type": "integer", "description": "第几次匹配，默认 1"},
        }},
        risk="safe", timeout=20, fn=_ui_find,
    ))
    r.register(Tool(
        name="screen_describe",
        description=("截图并用本地视觉模型「看懂」屏幕内容：返回简短中文语义结论——"
                     "这是什么类型的界面、有哪些主要元素（按钮/输入框/菜单/弹窗）、"
                     "有没有错误提示、验证操作后的界面状态。与 screen_ocr（只读文字）互补："
                     "适合理解图标/图片/整体布局/弹窗含义。"
                     "可选 region 指定区域；question 传单一具体问题（如「这张截图里有没有报错？」"
                     "「目标窗口是否在最上层？」），输出已做简洁化。"
                     "注意：本地视觉模型是 4B 小模型，结论偶有误差，涉及精确文字/数值/坐标判断时，"
                     "用 screen_ocr / find_on_screen / ui_find 交叉验证，不要只信本条描述。"
                     "视觉模型未安装时返回明确提示，可改用 screen_analyze。"),
        parameters={"type": "object", "properties": {
            "region": {"type": "array", "items": {"type": "integer"},
                       "description": "可选区域 [x, y, w, h]；缺省全屏"},
            "question": {"type": "string",
                         "description": "可选：单一具体问题，如'有没有报错'、'这是什么软件'、"
                                        "'窗口标题是什么'"},
        }},
        risk="safe", timeout=130, fn=_screen_describe,
    ))
    r.register(Tool(
        name="screen_capture",
        description=("对屏幕截图（全屏或指定区域），返回图片保存路径和尺寸。"
                     "用于查看当前屏幕状态；配合 find_on_screen / mouse_click 操作界面。"),
        parameters={"type": "object", "properties": {
            "region": {"type": "array", "items": {"type": "integer"},
                       "description": "可选区域 [x, y, w, h]；缺省全屏"},
        }},
        risk="safe", timeout=15, fn=_screen_capture,
    ))
    r.register(Tool(
        name="screen_ocr",
        description=("识别当前屏幕上的全部文字，返回每个文字块的内容、坐标和置信度。"
                     "用于了解屏幕上有什么内容、找输入框/按钮的文字。"),
        parameters={"type": "object", "properties": {
            "region": {"type": "array", "items": {"type": "integer"}, "description": "可选区域"},
            "min_confidence": {"type": "number", "description": "置信度下限 0-100，默认 30"},
        }},
        risk="safe", timeout=30, fn=_screen_ocr,
    ))
    r.register(Tool(
        name="find_on_screen",
        description=("在屏幕上按文字定位元素，返回中心坐标、边界框和置信度。"
                     "未找到时返回屏幕可见文字供调整。找到的坐标可直接传给 mouse_click。"),
        parameters={"type": "object", "properties": {
            "text": {"type": "string", "description": "要查找的文字（支持部分匹配）"},
            "occurrence": {"type": "integer", "description": "第几次出现，默认 1"},
        }, "required": ["text"]},
        risk="safe", timeout=30, fn=_find_on_screen,
    ))
    r.register(Tool(
        name="find_image_on_screen",
        description=("模板匹配：按图标/按钮的小图在屏幕上定位（无文字目标的首选）。"
                     "image 为模板图片路径——可先用 screen_capture(region=[x,y,w,h]) "
                     "截取目标区域保存为模板，或使用用户提供的图标文件。"
                     "返回每个匹配的中心坐标(center，可直接传给 mouse_click)、"
                     "边界框(bbox)与置信度。confidence 越低越宽松（0~1，默认 0.85）。"
                     "找不到时可用 screen_describe 让视觉模型描述屏幕确认目标是否可见。"),
        parameters={"type": "object", "properties": {
            "image": {"type": "string", "description": "模板图片文件路径（必填）"},
            "confidence": {"type": "number", "description": "匹配阈值 0~1，默认 0.85，越低越宽松"},
            "region": {"type": "array", "items": {"type": "integer"},
                       "description": "可选搜索区域 [x, y, w, h]；缺省全屏"},
            "max_matches": {"type": "integer", "description": "最多返回几处匹配，默认 5"},
        }, "required": ["image"]},
        risk="safe", timeout=30, fn=_find_image_on_screen,
    ))
    r.register(Tool(
        name="screen_analyze",
        description=("理解当前屏幕：截图+OCR 后生成精炼的「屏幕元素表」——自动去重、"
                     "把同一行相邻文字合并成元素，每个元素含文字、中心坐标(center)和边界框。"
                     "适合在操作界面前先调用，让模型看清屏幕布局后选择目标元素；"
                     "元素 center 坐标可直接传给 mouse_click。可选 focus 参数只返回含指定文字的元素。"),
        parameters={"type": "object", "properties": {
            "region": {"type": "array", "items": {"type": "integer"},
                       "description": "可选区域 [x, y, w, h]；缺省全屏"},
            "focus": {"type": "string",
                      "description": "可选：只返回文字含该关键字的元素"},
        }},
        risk="safe", timeout=30, fn=_screen_analyze,
    ))
    r.register(Tool(
        name="wait_for_change",
        description=("连续监测屏幕：周期性截图，等到出现显著变化才返回（如弹窗弹出、"
                     "加载完成、进度更新）。返回变化区域中心(center)/边界框(bbox)/"
                     "变化块数(regions)与最新截图路径(path)。"
                     "timeout 为最长等待秒数，interval 为轮询间隔秒数。"
                     "适合「等待通知/弹窗出现」「等待任务完成」等场景。"),
        parameters={"type": "object", "properties": {
            "timeout": {"type": "number", "description": "最长等待秒数，默认 30"},
            "interval": {"type": "number", "description": "轮询间隔秒数，默认 2，最小 0.2"},
            "region": {"type": "array", "items": {"type": "integer"},
                       "description": "可选监测区域 [x, y, w, h]；缺省全屏"},
        }},
        risk="safe", timeout=130, fn=_wait_for_change,
    ))
    r.register(Tool(
        name="mouse_click",
        description=("点击鼠标：传 element_id（控件引用，推荐）、坐标 (x, y)、或文字 text（先定位再点）。"
                     "优先级 element_id > 坐标 > 文字。支持 button=left/right、clicks=2 双击。"
                     "此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "element_id": {"type": "string",
                           "description": "可选：来自 ui_list/ui_find 的控件 id（推荐，比坐标稳）"},
            "x": {"type": "integer", "description": "横坐标"},
            "y": {"type": "integer", "description": "纵坐标"},
            "text": {"type": "string", "description": "要点击的文字（替代坐标）"},
            "button": {"type": "string", "description": "left/right，默认 left"},
            "clicks": {"type": "integer", "description": "点击次数，默认 1"},
            "occurrence": {"type": "integer", "description": "text 定位第几次出现"},
        }},
        risk="sensitive", timeout=15, fn=_mouse_click, screen_lock=True,
    ))
    r.register(Tool(
        name="keyboard_type",
        description=("向当前焦点窗口输入文字。中文自动走剪贴板粘贴。"
                     "给了 element_id 则先聚焦该控件再输入（定向输入，最稳）。"
                     "也可传 window_title（目标窗口标题关键字）做输入前校验，"
                     "防止应用抢焦点导致误输入。此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "text": {"type": "string", "description": "要输入的文字"},
            "element_id": {"type": "string",
                           "description": "可选：来自 ui_list/ui_find 的控件 id（推荐，定向输入）"},
            "window_title": {"type": "string", "description": "可选：目标窗口标题关键字，输入前校验前台窗口"},
        }, "required": ["text"]},
        risk="sensitive", timeout=15, fn=_keyboard_type, screen_lock=True,
    ))
    r.register(Tool(
        name="scroll",
        description=("滚动屏幕/控件区域：direction=up/down/left/right，pages 为页数（默认 1）。"
                     "可选 x/y 指定滚动发生的坐标（滚到某列表区域内）。"
                     "适合「翻页/看列表下方内容/滚动到目标」。会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "direction": {"type": "string", "description": "up/down/left/right，默认 down"},
            "pages": {"type": "integer", "description": "滚动页数，默认 1"},
            "x": {"type": "integer", "description": "可选：滚动发生的横坐标"},
            "y": {"type": "integer", "description": "可选：滚动发生的纵坐标"},
        }},
        risk="sensitive", timeout=15, fn=_scroll, screen_lock=True,
    ))
    r.register(Tool(
        name="drag",
        description=("拖拽：从 (fromX,fromY) 拖到 (toX,toY)。用于拖动滑块/滚动条、移动窗口、"
                     "框选、把文件拖到目标位置。会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "fromX": {"type": "integer", "description": "起点横坐标"},
            "fromY": {"type": "integer", "description": "起点纵坐标"},
            "toX": {"type": "integer", "description": "终点横坐标"},
            "toY": {"type": "integer", "description": "终点纵坐标"},
            "duration": {"type": "number", "description": "拖拽耗时秒数，默认 0.5"},
            "button": {"type": "string", "description": "left/right，默认 left"},
        }, "required": ["fromX", "fromY", "toX", "toY"]},
        risk="sensitive", timeout=20, fn=_drag, screen_lock=True,
    ))
    r.register(Tool(
        name="set_value",
        description=("把文本直接写入控件（UIA ValuePattern）——多行文本/表单输入的首选："
                     "不经键盘，不受焦点切换与输入法影响，一次写入多行内容。"
                     "element_id 来自 ui_list/ui_find。控件不支持写值时会明确提示改用 keyboard_type。"
                     "此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "element_id": {"type": "string", "description": "来自 ui_list/ui_find 的控件 id（必填）"},
            "value": {"type": "string", "description": "要写入控件的文本（可含换行）"},
            "window_title": {"type": "string", "description": "可选：窗口标题；缺省前台窗口"},
        }, "required": ["element_id", "value"]},
        risk="sensitive", timeout=20, fn=_set_value, screen_lock=True,
    ))
    r.register(Tool(
        name="perform_action",
        description=("在控件上执行 UIA 动作（只用控件实际支持的动作，比按坐标点击更可靠）："
                     "invoke（点按钮）/toggle（切换勾选）/select（选中列表或树项）/"
                     "expand/collapse（展开或收起）/set_focus（聚焦）/scroll_into_view（滚入视野）。"
                     "element_id 来自 ui_list/ui_find；控件不支持该动作时会报错并列出它实际支持哪些。"
                     "此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "element_id": {"type": "string", "description": "来自 ui_list/ui_find 的控件 id（必填）"},
            "action": {"type": "string",
                       "description": "invoke/toggle/select/expand/collapse/set_focus/scroll_into_view"},
            "window_title": {"type": "string", "description": "可选：窗口标题；缺省前台窗口"},
        }, "required": ["element_id", "action"]},
        risk="sensitive", timeout=20, fn=_perform_action, screen_lock=True,
    ))
    r.register(Tool(
        name="select_text",
        description=("在控件内按文本内容定位并选中（UIA TextPattern）——不依赖鼠标/键盘/坐标，"
                     "适合精确选中输入框/文档里的某段文字，再用 keyboard_press 替换或复制。"
                     "selection=text（默认，选中该文本）/cursor_before（光标落到其前）/"
                     "cursor_after（光标落到其后）。"
                     "同一文本出现多次时用 prefix/suffix 消歧（先按「前缀+文本+后缀」整体定位"
                     "再收缩到文本本身）。"
                     "element_id 来自 ui_list/ui_find；控件不支持文本选择时会明确提示改用 set_value。"
                     "此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "element_id": {"type": "string", "description": "来自 ui_list/ui_find 的控件 id（必填）"},
            "text": {"type": "string", "description": "要定位并选中的文本（必填）"},
            "selection": {"type": "string",
                          "description": "text/cursor_before/cursor_after，默认 text"},
            "prefix": {"type": "string", "description": "可选：目标文本前紧邻的内容（消歧用）"},
            "suffix": {"type": "string", "description": "可选：目标文本后紧邻的内容（消歧用）"},
            "window_title": {"type": "string", "description": "可选：窗口标题；缺省前台窗口"},
        }, "required": ["element_id", "text"]},
        risk="sensitive", timeout=20, fn=_select_text, screen_lock=True,
    ))
    r.register(Tool(
        name="keyboard_press",
        description=("按下按键或快捷键，如 keys=['ctrl','c'] 或 shortcut='ctrl+c'。"
                     "锁屏/任务管理器等危险快捷键已内置黑名单。此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "keys": {"type": "array", "items": {"type": "string"}, "description": "按键列表"},
            "shortcut": {"type": "string", "description": "快捷键字符串，如 'ctrl+c'"},
        }},
        risk="sensitive", timeout=15, fn=_keyboard_press, screen_lock=True,
    ))
    r.register(Tool(
        name="run_action_sequence",
        description=("⚠️ 已弃用（S1-9）：请改用 run_action_milestones —— 它支持分段执行 + "
                     "期望断言门禁 + 自动重试，能精确停在失败段，避免长链路到末尾才发现前面错了。"
                     "本工具仅保留以兼容旧任务，新调用请勿使用。"
                     "（旧语义：宏序列，把一组界面操作按顺序一次性批量执行，AIPC ActionExecutor 移植）。"
                     "actions 是动作数组，每个动作是 {\"type\": ...} 对象。支持的动作类型："
                     "click(需 x/y)、double_click(需 x/y)、move_to(需 x/y)、"
                     "type_text(需 text，中文自动粘贴)、press_key(需 key)、"
                     "hotkey(需 keys 数组，如 ['ctrl','s'])、scroll(需 amount，可选 x/y)、"
                     "drag_to(需 x/y)、wait(需 duration 秒)。"
                     "整段序列只做一次验证闭环（操作前后快照+差异摘要+VLM 判断），"
                     "不会每步都请求确认。危险快捷键已内置黑名单。此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "actions": {"type": "array",
                        "description": "动作序列数组（见描述中的动作类型）"},
            "name": {"type": "string", "description": "可选：宏名称"},
            "verify": {"type": "boolean", "description": "是否做操作前后验证闭环，默认 true"},
        }, "required": ["actions"]},
        risk="sensitive", timeout=120, fn=_run_action_sequence, screen_lock=True,
    ))
    r.register(Tool(
        name="run_action_milestones",
        description=("里程碑宏序列（GUI 长链路推荐）：把复杂界面操作拆成若干段，每段执行完"
                     "先跑一个「期望断言」门禁，过了才进下一段；某段断言失败会自动重试 2 次，"
                     "仍失败就精确停在失败段，返回 completed（已通过的段）列表，方便换策略，"
                     "避免一长串操作到末尾才发现前面早错了。"
                     "milestones 是数组，每项 {name, actions, expect}：actions 复用宏序列动作语法"
                     "（click/type_text/hotkey/wait…，可省略表示纯断言段）；"
                     "expect={type, value, timeout}，type 四选一："
                     "text=OCR 命中该文字；image=按模板小图匹配（value 为模板图片路径）；"
                     "vlm=本地视觉描述确认（value 为提问，模型不可用时自动放行不阻塞）；"
                     "stable=期望屏幕静下来（连续 2 帧无变化）。此操作会请求用户确认。"),
        parameters={"type": "object", "properties": {
            "milestones": {"type": "array",
                           "description": "里程碑数组（见描述结构）"},
            "name": {"type": "string", "description": "可选：链路名称"},
        }, "required": ["milestones"]},
        risk="sensitive", timeout=300, fn=_run_action_milestones, screen_lock=True,
    ))
