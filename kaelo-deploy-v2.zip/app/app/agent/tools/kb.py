# -*- coding: utf-8 -*-
"""知识库检索工具：kb_query（复用现有 RAG 检索能力）。

让 Lazaxa 在 agent 模式也能查用户的知识库（总库 master 或指定分支库），
检索结果同时包含本地知识库与 MySQL 内容（高亮/档案/对话历史）。
复用 app/state.py 的 store 缓存与自动建库，不重复初始化。
"""
from ..registry import Tool, ToolResult, ToolRegistry


def _kb_query(query: str, kb: str = "", top_k: int = 3) -> ToolResult:
    """检索知识库，返回结构化文本（带来源）。"""
    from ...state import _get_store, _get_mysql_store
    from ... import config, rag

    query = (query or "").strip()
    if not query:
        return ToolResult.err_result("query 不能为空")
    top_k = max(1, min(int(top_k or 3), 10))

    kb_key = kb or "master"
    # Obsidian 笔记同步库（obsidian_sync_kb 产生）：独立向量目录，不合并 MySQL
    if kb_key == "obsidian":
        try:
            store = rag.VecStore(config.OBSIDIAN_STORE_DIR).load()
            hits = store.search(query, top_k=top_k) if store.size else []
        except Exception as e:
            return ToolResult.err_result(f"Obsidian 笔记库检索失败: {type(e).__name__}: {e}")
        if not hits:
            return ToolResult.ok_result(
                "笔记知识库还没有同步过内容（或未命中）。可让用户在笔记里记录后，"
                "对 Lazaxa 说'把笔记同步到知识库'。", brief="0 条命中")
        lines = [f"检索到 {len(hits)} 条笔记相关内容："]
        for i, item in enumerate(hits, 1):
            src = item.get("source") or "未知"
            shown = (item.get("text") or "").strip()[:300]
            lines.append(f"{i}. 来源:{src}\n   {shown}")
        return ToolResult.ok_result("\n".join(lines), brief=f"{len(hits)} 条命中")

    if kb_key not in config.KNOWLEDGE_BASES:
        return ToolResult.err_result(
            f"未知知识库: {kb_key}（可选：{list(config.KNOWLEDGE_BASES)}）")

    # 本地知识库检索（store 缓存 + 首次自动建库，异常不影响主流程）
    try:
        store = _get_store(kb_key)
        hits = store.search(query, top_k=top_k) if store and store.size else []
    except Exception as e:
        return ToolResult.err_result(f"知识库检索失败: {type(e).__name__}: {e}")

    # MySQL 内容（高亮/档案/对话历史）合并检索
    mhits = []
    try:
        mstore = _get_mysql_store()
        if mstore is not None and mstore.size:
            mhits = mstore.search(query, top_k=top_k)
    except Exception:
        mhits = []

    if not hits and not mhits:
        return ToolResult.ok_result(
            f"知识库【{kb_key}】中未检索到与“{query}”相关的资料。", brief="0 条命中")

    lines = [f"检索到 {len(hits) + len(mhits)} 条相关资料："]
    seen = set()
    n = 0
    for item in hits + mhits:
        text = (item.get("text") or "").strip()
        src = item.get("source") or "未知"
        if not text or text in seen:
            continue
        seen.add(text)
        n += 1
        tag = "[MySQL]" if str(src).startswith(config.MYSQL_SRC_PREFIX) else "[知识库]"
        shown = text[:300] + ("…" if len(text) > 300 else "")
        lines.append(f"{n}. {tag} 来源:{src}\n   {shown}")
        if n >= top_k * 2:
            break
    return ToolResult.ok_result("\n".join(lines), brief=f"{n} 条命中")


def register_all(r: ToolRegistry):
    """注册知识库检索工具。risk=safe（只读检索，自动执行）。"""
    r.register(Tool(
        name="kb_query",
        description=(
            "检索用户的知识库（个人知识库系统：master总库/experience经验库/"
            "personal个人库/knowledge知识库，并包含 MySQL 中的高亮、档案、"
            "对话历史）。当用户问到知识库里的内容、要求基于资料回答、"
            "或需要回忆知识库里记录的东西时使用。kb 参数默认 master（全量）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "要检索的问题或关键词"},
                "kb": {"type": "string", "description": "知识库 key：master(默认)/experience/personal/knowledge"},
                "top_k": {"type": "integer", "description": "最多返回条数，默认 3，最大 10"},
            },
            "required": ["query"],
        },
        risk="safe",
        timeout=60,
        fn=_kb_query,
    ))
