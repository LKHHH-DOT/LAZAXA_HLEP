# -*- coding: utf-8 -*-
"""后台任务监督工具（"边聊边做"通话督导模式 · 2026-08-18）。

主对话（监工）视角的四个工具，真正干活的 worker 由 app/jobs.py 调度：
- delegate_job：把复杂指令派成后台任务（worker 独立上下文跑完整 agent 循环），
  立即返回 job_id，主对话不被阻塞，可继续陪用户聊天；
- check_jobs：查看自己派出的后台任务进度（前端面板数据同源）；
- call_worker：把老板中途的新指令传进正在干活的 worker（每轮循环读取照办）；
- cancel_job：取消后台任务（执行中立即中断 / 排队中直接移除）。

设计要点：本组工具只对"主对话"可见（worker 的工具过滤表在 jobs.py
_MANAGEMENT_TOOLS 中排除它们），防止 worker 再开 worker / 误用管理工具。
"""
from ... import config  # noqa: F401（保留：与其它工具模块一致导入 app 配置）
from ..registry import Tool, ToolResult


def _delegate_job(task: str) -> ToolResult:
    """派一个后台任务，立即返回 job_id（不等待执行结果）。"""
    from ...jobs import manager
    try:
        job_id = manager.launch(task)
    except Exception as e:
        return ToolResult.err_result(f"启动后台任务失败：{type(e).__name__}: {e}")
    return ToolResult.ok_result(
        f"后台任务已派出：{job_id}（状态：工作中或排队）。你继续陪用户聊天，"
        "任务进展用户问起就用 check_jobs / 系统注入的状态汇报，完成后向用户总结。",
        brief=f"🧩 后台任务已派出 {job_id}")


def _check_jobs() -> ToolResult:
    """查看后台任务进度（含最近动态与审批等待）。"""
    from ...jobs import manager
    jobs = manager.list_jobs()
    if not jobs:
        return ToolResult.ok_result("当前没有后台任务。", brief="无后台任务")
    lines = ["当前后台任务："]
    for j in jobs:
        st = {"queued": "⏳ 排队", "running": "⏳ 工作中",
              "awaiting_approval": "⚠️ 等你审批",
              "done": "✅ 已完成", "failed": "❌ 失败",
              "cancelled": "✋ 已取消"}.get(j["state"], j["state"])
        lines.append(f"[{j['id']}] {st} | 指令：{j['task']}")
        for a in j.get("activity", [])[-3:]:
            lines.append(f"   · {a['text']}")
        if j.get("reply"):
            lines.append(f"   结果：{j['reply'][:200]}")
        if j.get("error"):
            lines.append(f"   错误：{j['error'][:200]}")
        if j.get("pending_approval"):
            pa = j["pending_approval"]
            lines.append(f"   等待审批：{pa.get('tool', '')} {pa.get('args', '')}")
    return ToolResult.ok_result("\n".join(lines), brief=f"{len(jobs)} 个后台任务")


def _call_worker(job_id: str, instruction: str) -> ToolResult:
    """把老板的新指令传进正在执行的后台任务。"""
    from ...jobs import manager
    if not job_id or not str(instruction).strip():
        return ToolResult.err_result("call_worker 需要 job_id 与 instruction（要传达的指令）")
    if manager.send_instruction(job_id, str(instruction).strip()):
        return ToolResult.ok_result(
            f"指令已传给后台任务 {job_id}：{instruction}",
            brief=f"已向 {job_id} 传话")
    return ToolResult.err_result(
        f"任务 {job_id} 不存在或已不在执行中（只可给工作中/等你审批的任务传话）")


def _cancel_job(job_id: str) -> ToolResult:
    """取消一个后台任务。"""
    from ...jobs import manager
    if not job_id:
        return ToolResult.err_result("cancel_job 需要 job_id")
    if manager.cancel(job_id):
        return ToolResult.ok_result(f"后台任务 {job_id} 已取消。",
                                    brief=f"已取消 {job_id}")
    return ToolResult.err_result(f"任务 {job_id} 无法取消（不存在，或已处于终态）")


def register_all(r):
    """注册后台任务监督工具（仅主对话 schema 可见；worker 侧由 jobs 过滤）。"""
    r.register(Tool(
        name="delegate_job",
        display_name="🧩 派后台任务",
        description=(
            "把一个需要多步骤操作电脑/耗时的任务委派成**后台任务**：后台 worker 会"
            "独立执行完整流程（可操作文件/屏幕/键鼠，危险操作仍会弹审批），"
            "本工具**立即返回** job_id，你不必等它跑完。"
            "适用：用户在'边聊边做'模式下说'你去干 X'、你判断任务步骤多或耗时长；"
            "委派后立即回复用户'已开工'并继续陪聊，之后用 check_jobs / 系统注入的"
            "任务状态向用户汇报进度。若用户明确表示'等我做完'或任务很短，则不用本工具，"
            "自己直接执行。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "要委派给后台 worker 的完整任务指令（含所有背景与要求，独立可执行）",
                },
            },
            "required": ["task"],
        },
        risk="safe",
        timeout=30,
        fn=_delegate_job,
    ))
    r.register(Tool(
        name="check_jobs",
        display_name="📋 查后台任务",
        description=(
            "查看当前全部后台任务的状态（排队/工作中/等你审批/完成/失败）与最近动态。"
            "用户问'做到哪一步了/好了没/在干嘛'时用它查详情后向用户汇报。"
        ),
        parameters={"type": "object", "properties": {}},
        risk="safe",
        timeout=15,
        fn=_check_jobs,
    ))
    r.register(Tool(
        name="call_worker",
        display_name="📣 向任务传话",
        description=(
            "把老板中途说的新指令/修改意见传给正在执行的后台任务：worker 在下一步"
            "行动前会先读到这条指令并照办（有冲突按新指令优先）。"
            "适用：用户看了进展后说'停一下，那个别做/改成 XX/加上 YY'，且任务还在执行中。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "要传话的后台任务 job_id（如 job-1724000000000）",
                },
                "instruction": {
                    "type": "string",
                    "description": "要传达给 worker 的新指令（具体、明确，worker 会照办）",
                },
            },
            "required": ["job_id", "instruction"],
        },
        risk="safe",
        timeout=15,
        fn=_call_worker,
    ))
    r.register(Tool(
        name="cancel_job",
        display_name="🛑 取消任务",
        description=(
            "取消一个后台任务：执行中立即中断，排队中直接移除。"
            "适用：用户说'别做了/停/算了'，或你判断该任务不该继续。取消后向用户确认并"
            "询问是否需要按新方式重开（可再 delegate_job）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "要取消的后台任务 job_id",
                },
            },
            "required": ["job_id"],
        },
        risk="safe",
        timeout=15,
        fn=_cancel_job,
    ))
