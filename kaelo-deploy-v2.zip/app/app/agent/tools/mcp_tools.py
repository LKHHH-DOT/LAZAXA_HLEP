# -*- coding: utf-8 -*-
"""外部 MCP Server 桥接工具（2026-08-17 · MCP 集成调研落地）。

把 Lazaxa 变成 MCP 客户端：模型可直接调用外部 MCP server（Blender 等）
暴露的工具。通用三件套，server 在 config.MCP_SERVERS 注册，新软件加配置即可。

工具：
  - mcp_list_tools：列出某 server 可用工具（safe，自动执行）
  - mcp_tool_schema：查看某工具的参数说明（safe）
  - mcp_call_tool：调用某工具（sensitive，写操作走审批；只读工具也在此执行）

模型使用引导（写在 description 里）：
  遇到"用 Blender/3D 建模/渲染"类任务 → mcp_list_tools("blender")
  → 不确定参数就 mcp_tool_schema → mcp_call_tool 执行。
"""
import json
import os
import socket
import subprocess
import time

from ... import config
from .. import mcp_bridge
from ..registry import Tool, ToolResult

# ---- Blender 按需拉起配置（2026-08-18：不再由服务守护自动拉起） ----
# 用户要求："让他干对应的活的时候才拉取 Blender"。故 mcp_call_tool 真正要
# 调用 blender 工具时才检测 9876，未监听则自动启动 Blender + MCP 插件。
BLENDER_MCP_PORT = 9876
BLENDER_EXE = r"D:\Allapp\blender\blender.exe"
BLENDER_START_SCRIPT = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "..", "..", "scripts", "blender_mcp_start.py"))
BLENDER_START_MAX_WAIT = 45  # Blender 冷启动较慢，最多等 45 秒


def _port_alive(port: int, timeout: float = 0.8) -> bool:
    """探测本地端口是否被监听（对应 MCP 服务是否在线）。"""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


def _ensure_blender_up(max_wait: int = BLENDER_START_MAX_WAIT):
    """按需拉起 Blender MCP：9876 未监听时自动启动 Blender。

    仅当任务真正要调用 blender 工具时才执行（"干对应的活才拉取"）。
    返回 (是否就绪, 提示消息)；启动超时给出明确指引。
    """
    if _port_alive(BLENDER_MCP_PORT):
        return True, "Blender MCP 已在运行"
    if not os.path.exists(BLENDER_EXE) or not os.path.exists(BLENDER_START_SCRIPT):
        return False, (f"未找到 Blender（{BLENDER_EXE}）或启动脚本，无法自动拉起。"
                       f"请手动启动 Blender 后重试。")
    try:
        # Blender 必须 GUI 模式（background 模式 timers 不 tick）
        subprocess.Popen([BLENDER_EXE, "--python", BLENDER_START_SCRIPT],
                         close_fds=True)
    except Exception as e:
        return False, (f"启动 Blender 失败：{e}。可手动运行："
                       f"{BLENDER_EXE} --python {BLENDER_START_SCRIPT}")
    deadline = time.time() + max_wait
    while time.time() < deadline:
        time.sleep(2)
        if _port_alive(BLENDER_MCP_PORT):
            return True, "Blender 已自动启动，MCP 服务就绪"
    return False, (f"已启动 Blender，但等待 {max_wait} 秒 MCP 端口（9876）仍未就绪。"
                   f"请查看 Blender 窗口内的 MCP 插件面板是否启动服务，稍后重试。")


def _server_spec(name: str) -> dict:
    """按名字取 server 配置；未注册/未启用给出明确提示。"""
    spec = (config.MCP_SERVERS or {}).get(name)
    if spec is None:
        raise ValueError(
            f"未知 MCP server: {name}。可用: {', '.join(config.MCP_SERVERS.keys()) or '（无）'}")
    if not spec.get("enabled", True):
        raise ValueError(f"MCP server '{name}'（{spec.get('display_name', name)}）已禁用，"
                         f"无法调用。可在 config.py MCP_SERVERS 里启用。")
    return spec


def _mcp_list_tools(server: str) -> ToolResult:
    """列出某个外部 MCP server（如 blender）暴露的全部工具。"""
    server = str(server or "").strip()
    try:
        spec = _server_spec(server)
        client = mcp_bridge.get_client(server, spec)
        tools = client.list_tools()
    except Exception as e:
        return ToolResult.err_result(str(e))
    if not tools:
        return ToolResult.ok_result("（该 server 没有暴露任何工具）", brief="0 工具")
    brief = f"{len(tools)} 个工具"
    head = (f"MCP server '{server}'（{spec.get('display_name', server)}）共 {len(tools)} 个工具。\n"
            f"需要某个工具的详细参数时用 mcp_tool_schema 查询。\n\n")
    return ToolResult.ok_result(head + mcp_bridge.format_tools_brief(tools), brief=brief)


def _mcp_tool_schema(server: str, tool: str) -> ToolResult:
    """查看某个外部 MCP 工具的参数说明（JSON Schema）。"""
    server = str(server or "").strip()
    tool = str(tool or "").strip()
    if not server or not tool:
        return ToolResult.err_result("参数缺失：server 与 tool（如 blender / blender_object_create）")
    try:
        spec = _server_spec(server)
        client = mcp_bridge.get_client(server, spec)
        tools = client.list_tools()
    except Exception as e:
        return ToolResult.err_result(str(e))
    for t in tools:
        if t.get("name") == tool:
            desc = t.get("description") or ""
            schema = t.get("inputSchema") or {}
            props = (schema.get("properties") or {})
            req = schema.get("required") or []
            lines = [f"工具 {tool}：", "", desc.strip()[:1500], "", "参数："]
            if not props:
                lines.append("  （无参数）")
            for pname, pinfo in props.items():
                ptype = pinfo.get("type", "?")
                pdesc = str(pinfo.get("description", ""))[:120]
                mark = "（必填）" if pname in req else "（可选）"
                default = pinfo.get("default", "")
                dstr = f"，默认 {default}" if default not in (None, "") else ""
                lines.append(f"  · {pname}: {ptype} {mark}{dstr} — {pdesc}")
            return ToolResult.ok_result("\n".join(lines), brief=f"{tool} 参数说明")
    return ToolResult.err_result(f"server '{server}' 没有找到工具 {tool}。"
                                 f"可用工具见 mcp_list_tools。")


def _mcp_call_tool(server: str, tool: str, arguments: str = "{}") -> ToolResult:
    """调用外部 MCP 工具（如 Blender 的 blender_object_create）。"""
    server = str(server or "").strip()
    tool = str(tool or "").strip()
    if not server or not tool:
        return ToolResult.err_result("参数缺失：server 与 tool（如 blender / blender_object_create）")
    # arguments 允许传 JSON 字符串或字典
    if isinstance(arguments, str):
        try:
            args = json.loads(arguments) if arguments.strip() else {}
        except json.JSONDecodeError as e:
            return ToolResult.err_result(f"arguments 不是合法 JSON: {e}")
    else:
        args = dict(arguments or {})
    try:
        spec = _server_spec(server)
        # 按需拉起：Blender 等本地软件未启动时自动启动（"干对应的活才拉取"）
        if server == "blender":
            ok, msg = _ensure_blender_up()
            if not ok:
                return ToolResult.err_result(msg)
        client = mcp_bridge.get_client(server, spec)
        text = client.call_tool(tool, args)
    except Exception as e:
        return ToolResult.err_result(str(e))
    return ToolResult.ok_result(text, brief=f"{server}.{tool} 已执行")


def register_all(r):
    """注册 MCP 桥接三件套。"""
    r.register(Tool(
        name="mcp_list_tools",
        display_name="🧩 列出外部工具",
        description=(
            "列出某个外部 MCP server 暴露的工具。MCP server 是已接入 Lazaxa 的"
            "专业软件接口（当前：blender=Blender 3D，建模/材质/动画/渲染 38 个工具）。"
            "遇到'用 Blender/3D 建模/渲染/加材质'类任务，先调用本工具（server='blender'）"
            "看有哪些可用工具，再决定下一步。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "server": {"type": "string", "description": "MCP server 名（当前支持：blender）"},
            },
            "required": ["server"],
        },
        risk="safe", timeout=60, fn=_mcp_list_tools,
    ))
    r.register(Tool(
        name="mcp_tool_schema",
        display_name="📋 工具参数说明",
        description=(
            "查看某个外部 MCP 工具的详细参数说明（JSON Schema），"
            "调用前不确定参数格式时用。如 mcp_tool_schema('blender', 'blender_object_create')。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "server": {"type": "string", "description": "MCP server 名"},
                "tool": {"type": "string", "description": "工具名（如 blender_object_create）"},
            },
            "required": ["server", "tool"],
        },
        risk="safe", timeout=60, fn=_mcp_tool_schema,
    ))
    r.register(Tool(
        name="mcp_call_tool",
        display_name="⚡ 调用外部工具",
        description=(
            "调用某个外部 MCP 工具执行实际操作（如 Blender 建模/渲染）。"
            "先 mcp_list_tools 确认工具名、mcp_tool_schema 确认参数格式，再调用本工具。"
            "arguments 传 JSON 字符串。⚠️ 关键：blender 等 MCP 工具的参数必须用 'params' "
            "键包装（工具本身只收一个 params 字段），示例：{\"params\": {\"type\": \"CUBE\", "
            "\"name\": \"方块\"}}；不要直接写扁平参数。"
            "写操作（创建/修改/渲染）会走审批；只读查询自动执行。"
            "若 Blender 未启动会自动拉起（冷启动需等约 10-45 秒，MCP 就绪前重试会提示等待）；"
            "自动拉起失败才需要手动运行 run_command 执行 "
            "\"D:\\Allapp\\blender\\blender.exe\" --python \"D:\\Users\\Hasee\\Desktop\\Kaelo\\"
            "SelfIterate\\scripts\\blender_mcp_start.py\" 一键启动。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "server": {"type": "string", "description": "MCP server 名"},
                "tool": {"type": "string", "description": "要调用的工具名"},
                "arguments": {"type": "string", "description": "工具参数（JSON 字符串，需用 params 键包装）"},
            },
            "required": ["server", "tool"],
        },
        risk="sensitive", timeout=180, fn=_mcp_call_tool,
    ))
