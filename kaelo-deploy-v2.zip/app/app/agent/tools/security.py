# -*- coding: utf-8 -*-
"""电脑安全体检工具（防御向"安全管家"，2026-08-18）。

能力：
  - security_check：一键体检本机安全（12 项：Defender/防火墙/监听端口/管理员账户/
    账户锁定/共享目录/RDP/补丁/启动项/外部连接），返回分级报告
    （✅ 正常 / ⚠️ 注意 / 🔴 紧急）+ 加固建议。

触发场景：用户说"体检一下电脑""检查电脑安全""有没有被攻击""看看电脑有没有风险"等。

实现要点：
  - 复用 SelfIterate/scripts/security_check.py 为唯一实现源（本工具是薄壳）
  - 只读检查，risk="safe"，不弹审批
  - 子进程隐藏窗口（CREATE_NO_WINDOW），后台/守护运行时也不闪窗
"""
import os
import subprocess
import sys

from ..registry import Tool, ToolResult

# SelfIterate/（本文件位于 app/agent/tools/security.py，上溯 4 级：tools→agent→app→SelfIterate）
BASE_DIR = os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
SCRIPT = os.path.join(BASE_DIR, "scripts", "security_check.py")
CREATE_NO_WINDOW = 0x08000000  # Windows：隐藏子进程窗口


def _security_check(check: str = "") -> ToolResult:
    """执行安全体检，返回分级报告。"""
    if not os.path.exists(SCRIPT):
        return ToolResult.err_result(f"体检脚本缺失: {SCRIPT}")
    argv = [sys.executable, SCRIPT]
    if check:
        argv += ["--check", check]
    try:
        r = subprocess.run(
            argv, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=90, creationflags=CREATE_NO_WINDOW,
        )
    except subprocess.TimeoutExpired:
        return ToolResult.err_result("安全体检执行超时（>90s）")
    except Exception as e:
        return ToolResult.err_result(f"安全体检执行异常: {type(e).__name__}: {e}")

    out = (r.stdout or "").strip()
    if r.stderr and r.stderr.strip():
        out = f"{out}\n[stderr] {r.stderr.strip()}"
    if not out:
        return ToolResult.err_result("安全体检无输出")
    # 提取汇总行做 brief（给前端一行摘要）
    summary = next((ln for ln in out.splitlines() if ln.startswith("汇总")), "")
    return ToolResult(text=out, brief=summary or "体检完成")


def register_all(r):
    """注册安全体检工具。"""
    r.register(Tool(
        name="security_check",
        display_name="安全体检",
        description=("一键体检本机电脑安全（12 项：Defender 实时防护/防火墙/监听端口/"
                     "管理员账户/账户锁定/共享目录/RDP/补丁/启动项/外部连接）。"
                     "返回分级报告（✅正常/⚠️注意/🔴紧急）与加固建议。"
                     "当用户说'体检一下电脑''检查电脑安全''有没有被攻击'"
                     "'看看电脑有没有风险'时调用。可选 check 参数只查单项。"),
        parameters={"type": "object", "properties": {
            "check": {"type": "string",
                      "description": ("只查某一项（可选：system/defender/firewall/ports/"
                                       "admins/users/lockout/shares/rdp/patch/startup/"
                                       "connections），空则全量体检")},
        }, "required": []},
        risk="safe", timeout=90, fn=_security_check,
    ))
