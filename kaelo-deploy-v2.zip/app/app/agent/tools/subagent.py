# -*- coding: utf-8 -*-
"""子代理工具（批次 E2 · 借鉴 harness subagent 一次性委派设计，Python 重写）。

核心思路（对齐 docs/subsystems/subagent.zh.md 的最小集）：
  - 一次性委派：subagent_spawn(task) → 子代理独立上下文跑一轮 agent 循环
    → 返回 {output, stop_reason}；非 completed 视为失败，回填主任务换方式。
  - 工具过滤（"可见性而非权限"）：tool_filter 限定子代理可见工具，
    不传则继承父级可见集。
  - 深度限制：父循环 depth >= config.AGENT_MAX_SUBAGENT_DEPTH 时，
    schema 中移除 subagent_spawn（防无限递归）。
  - 真实执行由循环层接管（loop.py 识别工具名特殊处理，同事件循环递归，
    审批/事件/审计全复用）；本模块仅提供 schema 与防御性占位实现，
    避免工具被 registry.execute 裸调时静默出错。
"""
from ..registry import Tool, ToolResult


def _subagent_spawn(task: str, tool_filter: list | None = None) -> ToolResult:
    """占位实现：真实执行在 loop.py（_execute_subagent）中接管。

    正常情况下本函数不会被调用（循环层对 subagent_spawn 特判）；
    兜底返回错误，防止被当作普通工具静默执行。
    """
    return ToolResult.err_result(
        "subagent_spawn 需在 agent 循环上下文中执行（由循环层接管），不能作为普通工具直接调用。")


def _subagent_parallel(tasks: list) -> ToolResult:
    """占位实现：真实执行在 loop.py（_execute_subagent_parallel）中接管。

    正常情况下本函数不会被调用（循环层对 subagent_parallel 特判）；
    兜底返回错误，防止被当作普通工具静默执行。
    """
    return ToolResult.err_result(
        "subagent_parallel 需在 agent 循环上下文中执行（由循环层接管），不能作为普通工具直接调用。")


def register_all(r):
    """注册子代理工具（批次 E2 · spawn 单次委派 + parallel 并行编排）。"""
    r.register(Tool(
        name="subagent_spawn",
        display_name="🧩 委派子代理",
        description=(
            "把一个独立子任务委派给子代理执行：子代理拥有独立上下文（不共享当前对话历史），"
            "只会使用 tool_filter 限定的工具（不传则继承当前可见工具集），"
            "完成后返回其最终输出。适合需要独立处理、相互解耦的子任务；"
            "子代理内再次委派会受全局深度上限限制。"
            "可选传角色卡（role/goal/backstory，B批1）：给子代理明确人设与成功标准，"
            "输出更专业定向（如 role=资深 Python 代码审查员 + goal=找出 3 类缺陷）。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "委派给子代理的子任务指令（要具体、可独立完成，含所需背景）",
                },
                "tool_filter": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "限定子代理可用的工具名列表（可选；缺省继承当前可见工具集）",
                },
                "role": {
                    "type": "string",
                    "description": "角色卡·扮演身份（可选）：子代理充当的角色人设，如「资深 Python 代码审查员」",
                },
                "goal": {
                    "type": "string",
                    "description": "角色卡·目标（可选）：子代理要达成的成功标准，一句话说清验收口径",
                },
                "backstory": {
                    "type": "string",
                    "description": "角色卡·背景（可选）：领域上下文/约束/期望语气，帮子代理进入角色",
                },
            },
            "required": ["task"],
        },
        risk="sensitive",
        timeout=30,
        fn=_subagent_spawn,
    ))
    r.register(Tool(
        name="subagent_parallel",
        display_name="🧩 并行委派子代理",
        description=(
            "一次性委派多个独立子代理**并行**执行（tasks 数组，每项含 task、可选 tool_filter 与"
            "可选角色卡 role/goal/backstory（B批1））："
            "各子代理拥有独立上下文、同时运行，全部完成后返回每个任务的输出与状态。"
            "适合可同时推进、互不依赖的多个子任务（一次审批即可，不会逐个弹窗）。"
            "数量上限 5 个；子代理内再次委派受全局深度上限限制。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "task": {"type": "string", "description": "子任务指令（独立可完成）"},
                            "tool_filter": {
                                "type": "array", "items": {"type": "string"},
                                "description": "该子代理可用工具白名单（可选）",
                            },
                            "role": {
                                "type": "string",
                                "description": "角色卡·扮演身份（可选）：子代理角色人设，如「资深代码审查员」",
                            },
                            "goal": {
                                "type": "string",
                                "description": "角色卡·目标（可选）：该子代理的成功标准，一句话说清验收口径",
                            },
                            "backstory": {
                                "type": "string",
                                "description": "角色卡·背景（可选）：领域上下文/约束/期望语气",
                            },
                        },
                        "required": ["task"],
                    },
                    "description": "要并行执行的子任务数组（2~5 个）",
                },
            },
            "required": ["tasks"],
        },
        risk="sensitive",
        timeout=30,
        fn=_subagent_parallel,
    ))
