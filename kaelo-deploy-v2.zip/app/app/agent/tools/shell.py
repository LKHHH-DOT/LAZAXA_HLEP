# -*- coding: utf-8 -*-
"""第一批基础工具：shell（命令执行）+ files（文件操作）+ web（联网搜索）。

注册方式：模块底部调用 register_all(registry) 统一注册。
"""

import os
import re
import glob as glob_mod
import subprocess

from ..registry import Tool, ToolResult, ToolRegistry


# ============ 安全护栏（借鉴 harness 的设计思想，简化版） ============

# 危险命令模式黑名单：命中直接拒绝（宁可错杀，不可放行）
DANGEROUS_PATTERNS = [
    r"\bformat\b\s+[a-zA-Z]:",
    r"del\s+/[fspqa]+\s+[a-zA-Z]:\\",
    r"rmdir\s+/s",
    r"\brm\s+-rf\s+/",
    r"shutdown\s",
    r"reg\s+delete",
    r"taskkill\s+/f\s+/im\s+explorer",
]


def _is_safe_command(command: str) -> str | None:
    """命令安全检查。返回 None=通过；否则返回拒绝原因。"""
    low = command.lower()
    for pat in DANGEROUS_PATTERNS:
        if re.search(pat, low):
            return f"命令被安全策略拦截（命中黑名单模式: {pat}）"
    return None


# ============ run_command ============

def _run_command(command: str, timeout: int = 60, cwd: str = "") -> ToolResult:
    """在 PowerShell 中执行命令。

    借鉴 harness pwsh-local 的关键设计（简化版）：
    - 强制 UTF-8 输出，避免中文乱码
    - 超时杀死整个进程树
    - stdout/stderr 各限 64KB，保留尾部（错误信息通常在尾部）
    """
    blocked = _is_safe_command(command)
    if blocked:
        return ToolResult.err_result(blocked)

    workdir = cwd or None
    # chcp 65001 保证中文不乱码；-NoProfile 不加载用户配置，输出干净
    ps_cmd = f"chcp 65001 > $null; {command}"
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=workdir,
            creationflags=0x08000000 if os.name == "nt" else 0,  # CREATE_NO_WINDOW
        )
    except subprocess.TimeoutExpired as e:
        return ToolResult.err_result(f"命令执行超时（>{timeout}s）\n已输出: {_tail(e.stdout or '')}")
    except Exception as e:
        return ToolResult.err_result(f"命令启动失败: {type(e).__name__}: {e}")

    out = _tail((proc.stdout or "") + ("\n[stderr]\n" + proc.stderr if proc.stderr else ""), 64000)
    exit_code = proc.returncode
    status = "成功" if exit_code == 0 else f"失败(exit={exit_code})"
    brief = f"exit={exit_code}"
    if exit_code == 0:
        return ToolResult.ok_result(out, brief=f"执行成功，exit=0")
    return ToolResult.err_result(f"命令返回码 {exit_code}\n{out}")


def _tail(text: str, limit: int) -> str:
    """保留末尾 limit 字符（错误信息通常在尾部），并标记截断。"""
    if len(text) <= limit:
        return text
    return f"...[已截断 {len(text) - limit} 字符]...\n" + text[-limit:]


# ============ files 工具 ============

def _read_file(path: str, limit: int = 8000) -> ToolResult:
    """读取文本文件内容（自动探测编码，超大文件截断保留尾部）。"""
    if not os.path.isfile(path):
        return ToolResult.err_result(f"文件不存在: {path}")
    size = os.path.getsize(path)
    try:
        for enc in ("utf-8", "gbk", "utf-8-sig", "latin-1"):
            try:
                with open(path, "r", encoding=enc) as f:
                    if size > 200_000:  # 太大则只读尾部
                        f.seek(max(0, size - 200_000))
                        text = f.read()
                    else:
                        text = f.read()
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        else:
            return ToolResult.err_result(f"无法识别文件编码: {path}")
    except Exception as e:
        return ToolResult.err_result(f"读取失败: {type(e).__name__}: {e}")
    return ToolResult.ok_result(_tail(text, limit), brief=f"{os.path.basename(path)}（{size} 字节）")


def _write_file(path: str, content: str) -> ToolResult:
    """写入文件（先备份 .bak）。"""
    directory = os.path.dirname(path) or "."
    if not os.path.isdir(directory):
        return ToolResult.err_result(f"目录不存在: {directory}（不自动创建）")
    try:
        if os.path.isfile(path):
            backup = path + ".bak"
            with open(path, "rb") as src, open(backup, "wb") as dst:
                dst.write(src.read())
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        return ToolResult.err_result(f"写入失败: {type(e).__name__}: {e}")
    return ToolResult.ok_result(f"已写入 {path}（{len(content)} 字符）", brief=f"已写入 {os.path.basename(path)}")


def _list_dir(path: str = ".") -> ToolResult:
    """列出目录内容（名称/类型/大小/修改时间）。"""
    if not os.path.isdir(path):
        return ToolResult.err_result(f"目录不存在: {path}")
    try:
        entries = sorted(os.listdir(path))
    except Exception as e:
        return ToolResult.err_result(f"读取目录失败: {type(e).__name__}: {e}")
    lines = []
    for name in entries:
        full = os.path.join(path, name)
        try:
            if os.path.isdir(full):
                lines.append(f"[目录]  {name}/")
            else:
                size = os.path.getsize(full)
                mtime = os.path.getmtime(full)
                lines.append(f"[文件]  {name}  ({size:,} B, {_fmt_time(mtime)})")
        except OSError:
            lines.append(f"[?]     {name}")
    text = "\n".join(lines) if lines else "（空目录）"
    return ToolResult.ok_result(text, brief=f"{len(entries)} 项")


def _fmt_time(ts: float) -> str:
    import datetime
    return datetime.datetime.fromtimestamp(ts).strftime("%m-%d %H:%M")


def _search_files(pattern: str, path: str = ".", max_results: int = 50) -> ToolResult:
    """按名称 glob 搜索文件。pattern 支持通配符（*.py）。"""
    try:
        matches = glob_mod.glob(os.path.join(path, pattern), recursive=True)
    except Exception as e:
        return ToolResult.err_result(f"搜索失败: {type(e).__name__}: {e}")
    matches = [m for m in matches if os.path.isfile(m)][:max_results]
    if not matches:
        return ToolResult.ok_result(f"未找到匹配 {pattern} 的文件", brief="0 个匹配")
    text = "\n".join(matches)
    return ToolResult.ok_result(text, brief=f"{len(matches)} 个匹配")


# ============ web 工具（复用现有 Tavily） ============

def _web_search(query: str, max_results: int = 5) -> ToolResult:
    """联网搜索（Tavily API）。返回标题/摘要/链接。"""
    from .. import config as _cfg
    if not _cfg.TAVILY_API_KEY:
        return ToolResult.err_result("未配置 TAVILY_API_KEY，联网搜索不可用")
    try:
        import requests
        r = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": _cfg.TAVILY_API_KEY,
                "query": query,
                "max_results": max_results,
                "search_depth": "basic",
            },
            timeout=15,
        )
        if r.status_code != 200:
            return ToolResult.err_result(f"Tavily 返回 {r.status_code}")
        data = r.json()
        results = (data.get("results") or [])[:max_results]
        if not results:
            return ToolResult.ok_result("无搜索结果", brief="0 条结果")
        lines = []
        for i, item in enumerate(results, 1):
            lines.append(f"{i}. {item.get('title', '')}\n   {item.get('content', '')[:150]}\n   {item.get('url', '')}")
        text = "\n".join(lines)
        return ToolResult.ok_result(text, brief=f"{len(results)} 条结果")
    except Exception as e:
        return ToolResult.err_result(f"联网搜索失败: {type(e).__name__}: {e}")


# ============ 注册 ============

def register_all(r: ToolRegistry):
    """注册第一批基础工具。"""
    r.register(Tool(
        name="run_command",
        description=(
            "在 Windows PowerShell 中执行命令并返回输出。"
            "适合：查看系统信息、运行脚本、安装软件、执行文件操作等。"
            "注意：危险命令（格式化、删系统盘、关机、改注册表）会被拦截。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "要执行的 PowerShell 命令"},
                "timeout": {"type": "integer", "description": "超时秒数，默认 60", "default": 60},
                "cwd": {"type": "string", "description": "工作目录，默认当前目录"},
            },
            "required": ["command"],
        },
        risk="dangerous",
        timeout=120,
        fn=_run_command,
    ))
    r.register(Tool(
        name="read_file",
        description="读取文本文件内容（自动识别编码，超大文件截断保留尾部）。用于查看代码、配置、文档。",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件绝对路径"},
                "limit": {"type": "integer", "description": "最多返回字符数，默认 8000"},
            },
            "required": ["path"],
        },
        risk="safe",
        timeout=30,
        fn=_read_file,
    ))
    r.register(Tool(
        name="write_file",
        description="写入文本文件（UTF-8）。如果文件已存在会先备份为 .bak。注意：目录不存在时拒绝，不会自动创建。",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件绝对路径"},
                "content": {"type": "string", "description": "要写入的内容"},
            },
            "required": ["path", "content"],
        },
        risk="sensitive",
        timeout=30,
        fn=_write_file,
    ))
    r.register(Tool(
        name="list_dir",
        description="列出目录内容（名称/类型/大小/修改时间）。用于查看文件夹里有什么。",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "目录路径，默认当前目录"},
            },
            "required": [],
        },
        risk="safe",
        timeout=30,
        fn=_list_dir,
    ))
    r.register(Tool(
        name="search_files",
        description="按文件名模式搜索文件（支持通配符如 *.py、report*）。",
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "文件名通配模式"},
                "path": {"type": "string", "description": "搜索根目录，默认当前目录"},
                "max_results": {"type": "integer", "description": "最多返回条数，默认 50"},
            },
            "required": ["pattern"],
        },
        risk="safe",
        timeout=30,
        fn=_search_files,
    ))
    r.register(Tool(
        name="web_search",
        description="联网搜索（Tavily）。当用户需要最新信息、实时资讯、不知道答案的内容时使用。返回标题/摘要/链接。",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词"},
                "max_results": {"type": "integer", "description": "最多返回条数，默认 5"},
            },
            "required": ["query"],
        },
        risk="safe",
        timeout=20,
        fn=_web_search,
    ))
