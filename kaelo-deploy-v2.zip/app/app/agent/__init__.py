# -*- coding: utf-8 -*-
"""Lazaxa智能体 agent 包：工具调用循环（ReAct）实现。

设计见 docs/Lazaxa智能体设计书.md。
核心思想：一个工具调用循环 + 可插拔工具注册表，纯 Python 实现。
"""

from .loop import run_agent_task, make_emitter
from .registry import ToolRegistry, ToolResult, registry
from . import tools as _tools
from . import skills as _skills
from . import pipeline as _pipeline

# 启动时注册全部工具（幂等：重复导入不重复注册）
_tools.register_all(registry)
_skills.register_all(registry)
# M5：注册默认工具流水线钩子（审批 gate + 审计/修剪 post）
_pipeline.register_default_hooks(registry)

__all__ = ["run_agent_task", "make_emitter", "ToolRegistry", "ToolResult", "registry"]
