# -*- coding: utf-8 -*-
"""任务上下文（ContextVar · M4b 规划层基建，M5 通用）。

工具函数 `fn(**args)` 的参数只来自模型，天然拿不到"当前是哪一轮 / 谁在调我"。
这里提供进程内 contextvar，由 run_agent_task 在根任务（depth==0）开头 set，
工具经 registry 线程池执行时用 contextvars.copy_context() 传播进来读取。

- 根任务 / worker 各自独立 asyncio Task → ContextVar 天然隔离，互不串台；
- 子代理（depth>0）不 set，沿用父轮 round_id（与 M3"子代理事件并入父轮"一致），
  且子代理是在父 asyncio Task 内 await 的，天然继承父上下文；
- 未 set 时 getter 返回默认值 ""，调用方自行降级（绝不抛错）。
"""
from contextvars import ContextVar

current_round_id: ContextVar[str] = ContextVar("current_round_id", default="")


def get_round_id() -> str:
    """读取当前任务轮次 id；未设置（测试/裸调/子代理继承父值）时返回 ""。"""
    return current_round_id.get()
