# -*- coding: utf-8 -*-
"""知识库校验模块：专门用来搜索和校验知识库准确度。

为什么必要：知识库如果装了错误内容，检索越准，'把错误答案递给用户'就越是确定发生。
本模块让一个独立的'校验 AI'定期检查知识库，三层递进：

  第1层 · 规则校验（免费、全量）—— 每个知识块的硬伤检查
      · 过短 / 过长 / 纯符号 / 乱码 / 编码异常 / 内容重复
  第2层 · AI 事实核查（DeepSeek、抽样）—— 让大模型审核知识块
      · 逻辑矛盾 / 明显错误 / 事实存疑 / 人设冲突
  第3层 · 金标问题检索测试 —— 用标准问题测检索能否命中正确知识
      · 回答"检索质量还行不行"，发现知识缺口与检索失效

设计原则：
  · 免费优先：规则校验全量跑不花钱；AI 核查只抽样（可配比例），控制成本
  · 只报告不改：校验只输出报告，不自动改知识库，人工确认后才动
  · 可独立运行：app/validate.py 不依赖前端，可部署到更强服务器定时跑
"""
import json
import os
import re
from datetime import datetime
from typing import List

from . import config, rag

# ============ 第1层 · 规则校验（免费、全量） ============

# 常见乱码特征（UTF-8 被 GBK 误读等）
_GARBLED_PATTERNS = [
    re.compile(r"Ã[\x80-\xbf]"),          # 常见 UTF-8->Latin-1 乱码
    re.compile(r"æ[\x80-\xbf]"),
    re.compile(r"鈥|鈥|鈈|鐨|浣|鏄|涓"),    # UTF-8 被 GBK 误读的典型字
]
# 纯符号
_SYMBOL_ONLY = re.compile(r"^[\W_]{1,30}$")

# 编码异常检测：尝试按 UTF-8 严格的再次解码
def _looks_garbled(text: str) -> bool:
    for pat in _GARBLED_PATTERNS:
        if pat.search(text):
            return True
    return False


def _rule_check_block(i: int, m: dict) -> dict | None:
    """对单个块做规则检查，返回问题描述；无问题返回 None。"""
    text = m.get("text", "")
    src = m.get("source", "")
    problems = []

    t = text.strip()
    if len(t) < 10:
        problems.append(f"过短({len(t)}字)")
    if len(t) > 500:
        problems.append(f"过长({len(t)}字，建议切分)")
    if _SYMBOL_ONLY.match(t):
        problems.append("纯符号")
    if _looks_garbled(t):
        problems.append("疑似乱码(编码异常)")
    # 重复：与库内其他块完全相同的文本
    if m.get("_dup_count", 0) > 1:
        problems.append(f"内容重复x{m.get('_dup_count')}")

    if not problems:
        return None
    return {"index": i, "source": src, "text": text[:60], "problems": problems}


def rule_check_all(store: rag.VecStore) -> dict:
    """全量规则校验。返回问题列表与统计。"""
    # 先统计重复计数
    from collections import Counter
    text_counts = Counter(m["text"] for m in store.meta)

    issues = []
    for i, m in enumerate(store.meta):
        m2 = {**m, "_dup_count": text_counts[m["text"]]}
        issue = _rule_check_block(i, m2)
        if issue:
            issues.append(issue)

    return {
        "checked": store.size,
        "issues_count": len(issues),
        "issues": issues,
    }


# ============ 第2层 · AI 事实核查（DeepSeek、抽样） ============

def _call_deepseek(system: str, user: str) -> str:
    """调用 LLM 获取审核意见（非流式，复用 app/llm.py 统一客户端）。

    统一客户端已内置超时/重试/退避/错误分类/token 统计；失败返回占位文本，
    由上层按"存疑"处理（不中断校验流程）。
    """
    from .llm import _llm_complete
    reply = _llm_complete(system, user, timeout=120, max_tokens=500, temperature=0.2)
    if reply is None:
        return "[AI调用失败]"
    return reply


def _sample_blocks(store: rag.VecStore, sample_ratio: float, max_sample: int) -> List[int]:
    """按比例+上限抽样块索引。"""
    import random
    n = store.size
    if n == 0:
        return []
    k = max(1, min(int(n * sample_ratio), max_sample, n))
    idxs = list(range(n))
    random.seed(42)  # 固定种子，可复现
    return random.sample(idxs, k)


def ai_fact_check(store: rag.VecStore, sample_ratio: float = 0.1, max_sample: int = 20) -> dict:
    """AI 事实核查（抽样）：让 DeepSeek 审核知识块的逻辑/事实/人设一致性。

    返回每条审核： verdict(ok/suspect/error) + 说明。
    """
    if config.CHAT_BACKEND != "deepseek":
        return {"skipped": True, "reason": "当前后端不是 DeepSeek，AI 核查不可用"}

    idxs = _sample_blocks(store, sample_ratio, max_sample)
    system = (
        "你是一名知识库质检员。你会收到一条知识库片段。"
        "请判断它是否存在：1)逻辑矛盾 2)明显的史实/事实错误 3)与人设背景冲突 4)无意义内容。"
        "只输出 JSON，格式：{\"verdict\":\"ok\"|\"suspect\"|\"error\",\"reason\":\"简短说明\"}。"
        "verdict=ok 表示无问题；suspect 表示存疑需人工确认；error 表示明显错误。"
    )
    results = []
    for i in idxs:
        text = store.meta[i]["text"]
        user = f"知识库片段（来源:{store.meta[i].get('source','')}）：\n{text[:400]}"
        reply = _call_deepseek(system, user)
        # 尝试解析 JSON
        verdict, reason = "suspect", reply[:120]
        try:
            m = re.search(r'\{.*\}', reply, re.S)
            if m:
                obj = json.loads(m.group(0))
                verdict = obj.get("verdict", "suspect")
                reason = obj.get("reason", "") or reply[:120]
        except Exception:
            pass
        results.append({
            "index": i,
            "source": store.meta[i].get("source", ""),
            "verdict": verdict,
            "reason": reason,
            "text": text[:60],
        })
    ok_count = sum(1 for r in results if r["verdict"] == "ok")
    return {
        "sampled": len(results),
        "ok_count": ok_count,
        "suspect_count": len(results) - ok_count,
        "results": results,
    }


# ============ 第3层 · 金标问题检索测试 ============

GOLDEN_QUESTIONS: List[dict] = [
    # 通用金标问题（换知识库时按实际内容替换）
    {"q": "爱奇艺防盗链怎么处理？", "expect": "签名|播放器|UA", "topics": ["爱奇艺"]},
    {"q": "大学四年规划是什么？", "expect": "规划|学习|路线", "topics": ["大学规划"]},
    {"q": "AI学习路线有哪些？", "expect": "底层|模型|训练", "topics": ["AI学习"]},
    {"q": "Linux学习路线是什么？", "expect": "Shell|命令|脚本", "topics": ["Linux"]},
    {"q": "机械与CAM软件怎么学？", "expect": "加工|刀路|G代码", "topics": ["机械"]},
    {"q": "自我认知与价值分析？", "expect": "热爱|价值|成长", "topics": ["自我认知"]},
]


def golden_question_test(store: rag.VecStore, top_k: int = 5) -> dict:
    """金标问题检索测试：检查每个问题能否检索到含'期望关键词'的知识块。

    命中率 = 检索到的候选块中包含期望内容的比例 —— 衡量检索质量 + 知识完整性。
    """
    results = []
    for item in GOLDEN_QUESTIONS:
        q = item["q"]
        expect = item["expect"]
        hits = store.search(q, top_k=top_k)
        # 命中判断：期望关键词（| 分隔任中其一）出现在检索结果的文本里
        expects = [e.strip() for e in expect.split("|") if e.strip()]
        hit_texts = [h["text"] for h in hits]
        hit = any(any(ex in t for ex in expects) for t in hit_texts)
        results.append({
            "question": q,
            "expect": expect,
            "hit": hit,
            "top_hit": hits[0]["text"][:50] if hits else "",
            "source": hits[0]["source"] if hits else "",
        })
    hit_count = sum(1 for r in results if r["hit"])
    return {
        "total": len(results),
        "hit_count": hit_count,
        "hit_rate": round(hit_count / len(results), 3) if results else 0,
        "results": results,
    }


# ============ 总入口 ============

def run_validation(store: rag.VecStore,
                   ai_sample_ratio: float = 0.1,
                   golden_top_k: int = 5) -> dict:
    """一键校验：规则全量 + AI抽样核查 + 金标检索测试。"""
    report = {
        "run_at": datetime.now().isoformat(),
        "kb_size": store.size,
        "backend": config.CHAT_BACKEND,
    }
    # 第1层
    report["rule_check"] = rule_check_all(store)
    # 第2层
    report["ai_fact_check"] = ai_fact_check(store, sample_ratio=ai_sample_ratio)
    # 第3层
    report["golden_test"] = golden_question_test(store, top_k=golden_top_k)
    # 汇总
    rule_issues = report["rule_check"]["issues_count"]
    ai_suspect = report["ai_fact_check"].get("suspect_count", 0)
    golden_miss = report["golden_test"]["total"] - report["golden_test"]["hit_count"]
    report["summary"] = {
        "overall_status": "PASS" if (rule_issues == 0 and ai_suspect == 0 and golden_miss == 0)
                           else "REVIEW",
        "rule_issues": rule_issues,
        "ai_suspect": ai_suspect,
        "golden_miss": golden_miss,
        "advice": _build_advice(rule_issues, ai_suspect, golden_miss),
    }
    return report


def _build_advice(rule_issues: int, ai_suspect: int, golden_miss: int) -> str:
    tips = []
    if rule_issues:
        tips.append(f"发现 {rule_issues} 个规则问题（过短/乱码/重复），建议先跑知识库维护（python -m app.maint）清理")
    if ai_suspect:
        tips.append(f"AI 核查发现 {ai_suspect} 条存疑内容，请人工复核报告中的 reason")
    if golden_miss:
        tips.append(f"金标问题有 {golden_miss} 个未命中，说明知识库有缺口或检索失效，建议补充对应文档")
    if not tips:
        tips.append("知识库状态良好，无需处理")
    return "；".join(tips)


# ============ 上传时即时检查 ============

def _char_overlap(a: str, b: str) -> float:
    """字符级重叠率（Jaccard-like）：交集 token 数 / 并集 token 数。

    中文按单字、英文/数字按整词切分，过滤纯主题词相同导致的相似度误报。
    例如两段都讲同一主题但内容完全不同 → 重叠率低 → 不算冲突。
    """
    def tokens(s):
        cjk = set(re.findall(r"[\u4e00-\u9fff]", s))
        words = set(re.findall(r"[a-zA-Z0-9_]+", s.lower()))
        return cjk | words
    ta, tb = tokens(a), tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def check_upload(store: rag.VecStore, source: str) -> dict:
    """文档入库后即时检查：冲突检测 + 规则校验 + AI核查。

    只检查刚入库的指定 source 的块，不影响已有知识库。
    返回 {rule_issues, conflicts, ai_warnings, summary}。
    """
    # 找到新入库的块索引
    new_idxs = [i for i, m in enumerate(store.meta) if m.get("source") == source]
    if not new_idxs:
        return {"rule_issues": [], "conflicts": [], "ai_warnings": [], "summary": "未找到该来源的块"}

    # ---- 1. 规则校验（对新块全量）----
    from collections import Counter
    text_counts = Counter(m["text"] for m in store.meta)
    rule_issues = []
    for i in new_idxs:
        m2 = {**store.meta[i], "_dup_count": text_counts[store.meta[i]["text"]]}
        issue = _rule_check_block(i, m2)
        if issue:
            rule_issues.append(issue)

    # ---- 2. 相似/冲突预检：每个新块检索已有库，找不同来源中语义高度相近的块 ----
    # 注意：此阶段检测的是"内容高度相似"（可能重复/冲突），不是"事实矛盾"。
    # 阈值提高 + 字符重叠校验，避免同主题不同文档被误报。
    SIM_THRESHOLD = 0.62      # dmeta 中文向量：0.62+ 才算内容相近（同主题正常 0.3-0.5）
    TOKEN_OVERLAP = 0.30      # 字符重叠率下限，进一步过滤仅主题词相同的情况
    conflicts = []
    seen_pairs = set()
    for i in new_idxs:
        text = store.meta[i]["text"]
        # 用新块文本做 query 检索已有库 top_k=8
        hits = store.search(text, top_k=8)
        for h in hits:
            h_src = h.get("source", "")
            if h_src == source:
                continue
            if h.get("score", 0) < SIM_THRESHOLD:
                continue
            pair_key = (text[:40], h["text"][:40])
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)
            if _char_overlap(text, h["text"]) < TOKEN_OVERLAP:
                continue
            conflicts.append({
                "new_chunk": text[:80],
                "existing_source": h_src,
                "existing_chunk": h["text"][:80],
                "score": round(h.get("score", 0), 3),
            })
    # 数量太多时只保留最高分的前 20 条（报告仍给 total）
    conflicts_total = len(conflicts)
    conflicts.sort(key=lambda c: -c["score"])
    conflicts = conflicts[:20]

    # ---- 3. AI 核查：只检查有冲突的块（省 token）----
    ai_warnings = []
    if conflicts and config.CHAT_BACKEND == "deepseek":
        system = (
            "你是一名知识库冲突检测员。你会收到两段可能关于同一主题的知识库片段。"
            "请判断它们是否存在事实矛盾（如同一人物的不同身份、同一事件的不同说法）。"
            "只输出 JSON：{\"conflict\": true/false, \"reason\": \"简短说明矛盾点\"}。"
            "如果只是补充信息而非矛盾，conflict=false。"
        )
        checked_pairs = set()
        for c in conflicts[:15]:  # 过滤后数量可控，最多检查15对
            pair_key = (c["new_chunk"][:30], c["existing_chunk"][:30])
            if pair_key in checked_pairs:
                continue
            checked_pairs.add(pair_key)
            user = (
                f"片段A（新上传，来源{source}）：\n{c['new_chunk']}\n\n"
                f"片段B（已有，来源{c['existing_source']}）：\n{c['existing_chunk']}"
            )
            reply = _call_deepseek(system, user)
            verdict = False
            reason = reply[:100]
            try:
                m = re.search(r'\{.*\}', reply, re.S)
                if m:
                    obj = json.loads(m.group(0))
                    verdict = obj.get("conflict", False)
                    reason = obj.get("reason", "") or reply[:100]
            except Exception:
                pass
            if verdict:
                ai_warnings.append({
                    "new_chunk": c["new_chunk"],
                    "existing_source": c["existing_source"],
                    "existing_chunk": c["existing_chunk"],
                    "reason": reason,
                })

    # ---- 汇总 ----
    parts = []
    if rule_issues:
        parts.append(f"规则问题 {len(rule_issues)} 个")
    if conflicts:
        parts.append(f"高度相似 {conflicts_total} 处")
    if ai_warnings:
        parts.append(f"AI确认矛盾 {len(ai_warnings)} 处")
    summary = "；".join(parts) if parts else "未发现问题"

    return {
        "rule_issues": rule_issues,
        "conflicts": conflicts,
        "conflicts_total": conflicts_total,
        "ai_warnings": ai_warnings,
        "summary": summary,
    }


# ============ 独立运行入口 ============

if __name__ == "__main__":
    from .log_util import setup_logging, get_logger
    setup_logging()
    _log = get_logger("validate")
    _log.info("=" * 50)
    _log.info("知识库校验 · 独立运行")
    _log.info("=" * 50)
    store = rag.get_store()
    _log.info("知识库规模: %d 块", store.size)
    rep = run_validation(store)
    _log.info(json.dumps(rep, ensure_ascii=False, indent=2, default=str))