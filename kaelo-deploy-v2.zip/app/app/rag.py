# -*- coding: utf-8 -*-
"""轻量本地向量库：切块 -> 嵌入 -> 检索，全部走本机 Ollama。
不依赖 chromadb 等重型库，保证在任意 Python 版本可跑（最小闭环）。

检索采用业界标准混合检索（Hybrid Search）：
  1. 向量检索（语义）：调用 Ollama 中文 embedding，余弦相似度 + 长度归一化
  2. BM25 关键词检索（字面）：中文按 unigram+bigram 切分，经典 BM25 公式
  3. RRF（Reciprocal Rank Fusion）融合两路结果，提升召回准确率
"""
import json
import logging
import math
import os
import re
import time
from collections import Counter, defaultdict
from datetime import datetime
from typing import List

import numpy as np

logger = logging.getLogger("rag")
import requests

from . import config

# ============ 检索统计（阶段 3：/api/metrics 用） ============
_SEARCH_STATS = {"calls": 0, "total_ms": 0.0, "max_ms": 0.0}


def search_stats() -> dict:
    """返回检索耗时统计快照。"""
    calls = _SEARCH_STATS["calls"]
    return {
        "calls": calls,
        "avg_ms": round(_SEARCH_STATS["total_ms"] / calls, 1) if calls else 0.0,
        "total_ms": round(_SEARCH_STATS["total_ms"], 1),
        "max_ms": round(_SEARCH_STATS["max_ms"], 1),
    }


def reset_search_stats():
    _SEARCH_STATS["calls"] = 0
    _SEARCH_STATS["total_ms"] = 0.0
    _SEARCH_STATS["max_ms"] = 0.0


def _split_text(text: str, max_len: int = 150, overlap: int = 30) -> List[str]:
    """按自然段落/句号切分成带重叠的块。中文友好。"""
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    # 先按常见分隔切
    parts = re.split(r"(?<=[。！？!?；;])", text)
    parts = [p.strip() for p in parts if p.strip()]
    # 再按长度合并（重叠 = 上一块尾部 overlap 字，接上当前剩余内容）
    chunks = []
    buf = ""
    for p in parts:
        if len(buf) + len(p) > max_len and buf:
            chunks.append(buf)
            buf = buf[-overlap:] + p
        else:
            buf += p
    if buf:
        chunks.append(buf)
    # 单块超长则硬切
    final = []
    for c in chunks:
        while len(c) > max_len:
            final.append(c[:max_len])
            c = c[max_len - overlap:]
        final.append(c)
    return [c for c in final if c.strip()]


def _embed(texts: List[str], batch_size: int = 32) -> np.ndarray:
    """调用 Ollama embedding 接口，返回 (n, dim) 向量数组。

    自动分批（默认每批 32 条）再合并：bge-m3 上下文有限（8192 token），
    MySQL 同步等场景一次传入数百条文本会触发 400；分批后保证任意规模可嵌入。
    """
    if not texts:
        return np.zeros((0, 0), dtype=np.float32)
    parts = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        resp = requests.post(
            f"{config.OLLAMA_HOST}/api/embed",
            json={"model": config.EMBED_MODEL, "input": batch},
            timeout=180,
        )
        resp.raise_for_status()
        data = resp.json()
        if "embeddings" in data:
            parts.append(np.array(data["embeddings"], dtype=np.float32))
        else:
            # 兼容旧版返回结构
            parts.append(np.array([data["embedding"]], dtype=np.float32))
    return np.vstack(parts)


# ============ BM25 关键词检索（字面匹配，弥补向量检索对专有名词的不足） ============

# 中文空白/标点分隔单位（中文无空格分词，这里按字符做 unigram+bigram，避免引入重型分词库）
_PUNCT = set("，。！？；：、（）《》「」\"'，.!,?;:()[]{}「」～~  \t\n\r")


def _tokenize(text: str) -> List[str]:
    """中文轻量切词：过滤标点后生成 unigram（单字）+ bigram（相邻双字）。"""
    cleaned = [c for c in text if c not in _PUNCT and not c.isspace()]
    if not cleaned:
        return []
    toks = list(cleaned)  # unigram
    for i in range(len(cleaned) - 1):
        toks.append(cleaned[i] + cleaned[i + 1])  # bigram
    return toks


class BM25Index:
    """经典 BM25 检索器（面向短文档块）。"""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.docs: List[str] = []
        self.doc_tf: List[Counter] = []
        self.df: Counter = Counter()
        self.doc_lens: List[int] = []
        self.avgdl = 0.0
        self.N = 0

    def build(self, docs: List[str]):
        self.docs = docs
        self.doc_tf = []
        self.df = Counter()
        self.doc_lens = []
        for d in docs:
            toks = _tokenize(d)
            tf = Counter(toks)
            self.doc_tf.append(tf)
            self.df.update(set(toks))
            self.doc_lens.append(len(toks))
        self.N = len(docs)
        self.avgdl = sum(self.doc_lens) / self.N if self.N else 0.0

    def search(self, query: str, top_k: int = 10) -> List[tuple]:
        """返回 [(doc_index, bm25_score), ...] 降序。"""
        qtoks = set(_tokenize(query))
        if not qtoks or self.N == 0:
            return []
        scores = []
        for i in range(self.N):
            tf = self.doc_tf[i]
            dl = self.doc_lens[i]
            s = 0.0
            for t in qtoks:
                f = tf.get(t, 0)
                if f == 0:
                    continue
                idf = math.log(1 + (self.N - self.df.get(t, 0) + 0.5) / (self.df.get(t, 0) + 0.5))
                denom = f + self.k1 * (1 - self.b + self.b * dl / self.avgdl) if self.avgdl else f + self.k1
                s += idf * f * (self.k1 + 1) / denom
            if s > 0:
                scores.append((i, s))
        scores.sort(key=lambda x: -x[1])
        return scores[:top_k]


def _rrf_fuse(vec_ranked: List[int], bm25_ranked: List[int], k: int = 60) -> List[int]:
    """RRF（倒数排名融合）：score(d) = Σ 1/(k + rank_i(d))。返回融合后的 doc 索引降序。"""
    rrf: dict[int, float] = defaultdict(float)
    for rank, doc_i in enumerate(vec_ranked, start=1):
        rrf[doc_i] += 1.0 / (k + rank)
    for rank, doc_i in enumerate(bm25_ranked, start=1):
        rrf[doc_i] += 1.0 / (k + rank)
    return [i for i, _ in sorted(rrf.items(), key=lambda x: -x[1])]


class VecStore:
    """自研向量库：vectors.npy 存向量，meta.json 存文本/来源，外加 BM25 关键词索引。

    支持知识库管理：增(add)、删(delete_source)、改(update_source)、查(list_sources/search)。
    meta 中每个块记录 created_at 时间戳，为版本/时效过滤打基础。
    """

    def __init__(self, path: str):
        self.path = path
        os.makedirs(path, exist_ok=True)
        self._vec_path = os.path.join(path, "vectors.npy")
        self._meta_path = os.path.join(path, "meta.json")
        self.vectors = None
        self.meta: List[dict] = []
        self.bm25: BM25Index | None = None

    def load(self):
        if os.path.exists(self._vec_path):
            self.vectors = np.load(self._vec_path)
            with open(self._meta_path, "r", encoding="utf-8") as f:
                self.meta = json.load(f)
            self._build_bm25()
        return self

    def _build_bm25(self):
        self.bm25 = BM25Index()
        self.bm25.build([m["text"] for m in self.meta])

    @property
    def size(self) -> int:
        return len(self.meta)

    def add(self, chunks: List[str], source: str = "unknown", embed: bool = True):
        """追加入库（按文本去重）。

        embed=False：只追加 meta + 标记 BM25 待重建，不算向量（向量交给
        scripts/embed_increment.py 增量补齐）——批量加书时省一次全量嵌入，
        是"不清空重建"的关键（借 kada 经验）。
        """
        if not chunks:
            return
        # 防重复：已存在的相同内容跳过（同批内也去重，保持顺序）
        existing = {m["text"] for m in self.meta}
        new_meta = []
        now = datetime.now().isoformat()
        for text in chunks:
            if text in existing:
                continue
            existing.add(text)
            new_meta.append({"text": text, "source": source, "created_at": now})
        if not new_meta:
            return
        if embed:
            vecs = _embed([m["text"] for m in new_meta])
            arr = np.asarray(vecs, dtype=np.float32)
            self.vectors = arr if self.vectors is None else np.vstack([self.vectors, arr])
        self.meta.extend(new_meta)
        self.bm25 = None  # 索引已失效：下次检索时懒重建（含新块）
        self.save()

    def add_with_sources(self, texts: List[str], sources: List[str]):
        """批量添加：texts[i] 与 sources[i] 一一对应（MySQL 内容同步用，一次嵌入）。"""
        if not texts:
            return
        vecs = _embed(texts)
        existing = {m["text"] for m in self.meta}
        new_meta, new_vecs = [], []
        now = datetime.now().isoformat()
        for t, v, s in zip(texts, vecs, sources):
            if t not in existing:
                new_meta.append({"text": t, "source": s, "created_at": now})
                new_vecs.append(v)
        if not new_meta:
            return
        if self.vectors is None:
            self.vectors = np.array(new_vecs, dtype=np.float32)
        else:
            self.vectors = np.vstack([self.vectors, np.array(new_vecs)])
        self.meta.extend(new_meta)
        self.bm25 = None  # 索引已失效：下次检索时懒重建（含新块）
        self.save()

    def save(self):
        """原子写：先写 .tmp 临时文件，再 os.replace 原子覆盖。

        防止写一半断电/进程崩溃导致 vectors.npy 与 meta.json 损坏
        （阶段 2 可靠性：数据不丢）。临时文件残留会在下次保存时被覆盖。
        """
        vec_tmp = self._vec_path + ".tmp.npy"  # 以 .npy 结尾，避免 np.save 自动追加后缀
        meta_tmp = self._meta_path + ".tmp"
        np.save(vec_tmp, self.vectors)
        with open(meta_tmp, "w", encoding="utf-8") as f:
            json.dump(self.meta, f, ensure_ascii=False, indent=1)
        os.replace(vec_tmp, self._vec_path)
        os.replace(meta_tmp, self._meta_path)

    def _rebuild_by_index(self, keep_idx: List[int]):
        """按保留索引重建 vectors/meta/BM25 并保存（删除/合并后调用）。"""
        if not keep_idx:
            self.vectors = np.empty((0, self.vectors.shape[1]), dtype=np.float32) if self.vectors is not None else None
            self.meta = []
        else:
            self.vectors = self.vectors[keep_idx]
            self.meta = [self.meta[i] for i in keep_idx]
        self.save()
        self._build_bm25()

    def list_sources(self) -> List[dict]:
        """按来源分组统计：{source, count, first_at, last_at}。"""
        by_src = defaultdict(list)
        for m in self.meta:
            by_src[m.get("source", "unknown")].append(m.get("created_at", ""))
        out = []
        for src, times in sorted(by_src.items(), key=lambda x: -len(x[1])):
            times = [t for t in times if t]
            out.append({
                "source": src,
                "count": len(times) if times else len(by_src[src]),
                "first_at": min(times) if times else "",
                "last_at": max(times) if times else "",
            })
        return out

    def delete_source(self, source: str) -> int:
        """删除某个来源的全部块（同名文档重新上传前先调用）。返回删除块数。"""
        keep_idx = [i for i, m in enumerate(self.meta) if m.get("source") != source]
        removed = len(self.meta) - len(keep_idx)
        if removed:
            self._rebuild_by_index(keep_idx)
        return removed

    def update_source(self, source: str, chunks: List[str]) -> dict:
        """用新内容整体替换某来源：先删旧块，再入库新块。返回 {removed, added}。"""
        removed = self.delete_source(source)
        before = self.size
        self.add(chunks, source=source)
        return {"removed": removed, "added": self.size - before}

    def search(self, query: str, top_k: int = config.TOP_K,
               vec_weight: float = 0.6, bm25_weight: float = 0.4) -> List[dict]:
        """混合检索：向量（语义）+ BM25（关键词）→ RRF 融合。

        vec_weight/bm25_weight 是可选的加权系数（加权 RRF），默认 0.6/0.4。
        """
        if not self.meta:
            return []
        _t0 = time.perf_counter()
        # ---- 路 1：向量语义检索 ----
        # 注意：向量数可能少于块数（增量加书后尚未补向量，见 scripts/embed_increment.py）。
        # 此时只对"已有向量"的前 n_vec 块算语义分，其余块交给 BM25 兜底——
        # 既不让形状不匹配把检索打崩，也不会丢掉关键词召回（kada 经验）。
        _n_vec = 0 if self.vectors is None else len(self.vectors)
        q = _embed([query])[0]
        qnorm = np.linalg.norm(q)
        sims = None
        if qnorm == 0 or _n_vec == 0:
            vec_ranked = []
        else:
            _v = self.vectors[:_n_vec]
            sims = (_v @ q) / (np.linalg.norm(_v, axis=1) * qnorm + 1e-9)
            # 标题 boost：块首行是 Markdown 标题且与查询字面共现 ≥2 词时，相似度加权。
            # 解决"标题字面命中" vs "正文语义接近"的竞争（如查询"大学四年规划"时，
            # 标题为"# 大学四年完整规划"的文档块应胜过其他文档中泛泛谈规划的正文块）。
            _qtoks = set(_tokenize(query))
            _boost = np.ones(_n_vec)
            for _i in range(_n_vec):
                _first = (self.meta[_i].get("text") or "").splitlines()[0] or ""
                if _first.lstrip().startswith("#"):
                    _ov = len(_qtoks & set(_tokenize(_first)))
                    if _ov >= 3:
                        _boost[_i] = 1.35
                    elif _ov >= 2:
                        _boost[_i] = 1.2
            # 长度归一化：惩罚过长的"泛化开场块"，让短而具体的问答块胜出
            lens = np.array([len(self.meta[_i]["text"]) for _i in range(_n_vec)], dtype=np.float32)
            len_penalty = np.exp(-((lens - 120) / 90) ** 2)
            sims = sims * _boost * (0.6 + 0.4 * len_penalty)
            vec_ranked = np.argsort(-sims).tolist()

        # ---- 路 2：BM25 关键词检索 ----
        if self.bm25 is None:
            self._build_bm25()
        bm25_ranked = [i for i, _ in self.bm25.search(query, top_k=max(top_k * 3, 10))]

        # ---- RRF 融合 ----
        fused = _rrf_fuse(vec_ranked, bm25_ranked, k=60)

        # ---- 同源去重：同一来源文档最多保留 MAX_PER_SOURCE 块，防止一个文档霸屏 ----
        max_per_src = config.MAX_PER_SOURCE
        fused_dedup = []
        src_count: dict[str, int] = defaultdict(int)
        for i in fused:
            src = self.meta[i].get("source", "")
            if src_count[src] >= max_per_src:
                continue
            src_count[src] += 1
            fused_dedup.append(i)
            if len(fused_dedup) >= top_k:
                break
        fused = fused_dedup[:top_k]

        # 附上各路的原始分数做证据
        out = []
        for i in fused:
            item = {
                "text": self.meta[i]["text"],
                "source": self.meta[i].get("source", ""),
                # 只有 BM25 命中的新增块（尚未补向量）无语义分，记 0 分
                "score": float(sims[i]) if (sims is not None and i < len(sims)) else 0.0,
                "rank": len(out) + 1,
            }
            out.append(item)
        # 记录检索耗时（阶段 3 指标）
        _ms = (time.perf_counter() - _t0) * 1000
        _SEARCH_STATS["calls"] += 1
        _SEARCH_STATS["total_ms"] += _ms
        _SEARCH_STATS["max_ms"] = max(_SEARCH_STATS["max_ms"], _ms)
        return out


def build_from_dir(knowledge_dir: str, store: VecStore, embed: bool = True):
    """扫描知识目录下的 md/txt 文件，全部切块入库（按文本去重，可重复执行）。

    embed=False：只建 meta/BM25，不算向量（批量增量加书用，见 scripts/add_books.py）。
    """
    if not os.path.isdir(knowledge_dir):
        logger.warning("知识目录不存在：%s", knowledge_dir)
        return
    added = 0
    for name in os.listdir(knowledge_dir):
        path = os.path.join(knowledge_dir, name)
        if os.path.isfile(path) and name.lower().endswith((".md", ".txt")):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
            chunks = _split_text(text)
            store.add(chunks, source=name, embed=embed)
            added += len(chunks)
            logger.info("建库: %s -> %d 块", name, len(chunks))
    logger.info("建库完成，共 %d 块", store.size)
    return added


def get_store(kb: str | None = None) -> VecStore:
    """获取指定知识库的向量库；kb 为空则用默认库。"""
    kb = kb or config.DEFAULT_KB
    cfg = config.KNOWLEDGE_BASES.get(kb, config.KNOWLEDGE_BASES[config.DEFAULT_KB])
    return VecStore(cfg["vector_dir"]).load()


# ==================== 总库自动同步（分支库 -> master） ====================

def sync_master_from_branches(force: bool = False) -> dict:
    """把 master 配置的分支库源文档同步到总库目录（软拷贝，分支库为真实源）。

    - 分支库的文档 -> data/master 下对应子目录（english/ knowledge/ experience/）
    - 总库目录里的旧文件如已被删掉则清理
    - 返回 {added, removed, total} 统计
    """
    master_cfg = config.KNOWLEDGE_BASES.get("master")
    branches = (master_cfg or {}).get("branches", [])
    master_dir = (master_cfg or {}).get("knowledge_dir", "data/master")
    if not master_cfg or not branches:
        return {"added": 0, "removed": 0, "total": 0}

    seen = set()
    added = removed = 0
    # master 目录子结构：english/ knowledge/ experience/
    for bkey in branches:
        bcfg = config.KNOWLEDGE_BASES.get(bkey)
        if not bcfg:
            continue
        src_dir = bcfg["knowledge_dir"]  # 分支库真实源目录
        sub_dir = os.path.join(master_dir, bkey)  # 总库下按分支分目录
        os.makedirs(sub_dir, exist_ok=True)
        if not os.path.isdir(src_dir):
            continue
        for fname in os.listdir(src_dir):
            fpath = os.path.join(src_dir, fname)
            if not os.path.isfile(fpath) or not fname.lower().endswith((".md", ".txt")):
                continue
            dst = os.path.join(sub_dir, fname)
            # 软拷贝：内容不同才写（避免反复重建向量）
            if not os.path.exists(dst) or open(dst, "r", encoding="utf-8", errors="ignore").read() != \
                    open(fpath, "r", encoding="utf-8", errors="ignore").read():
                with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                    data = fh.read()
                with open(dst, "w", encoding="utf-8") as fh:
                    fh.write(data)
                added += 1
            seen.add(os.path.join(bkey, fname))
    # 清理总库目录中已不存在的（源分支删除的文档）
    if os.path.isdir(master_dir):
        for sub in os.listdir(master_dir):
            if sub not in branches:
                continue  # 不误删非分支目录（如 .gitkeep）
            sub_path = os.path.join(master_dir, sub)
            if os.path.isdir(sub_path):
                for fname in os.listdir(sub_path):
                    rel = os.path.join(sub, fname)
                    if rel not in seen and fname.lower().endswith((".md", ".txt")):
                        os.remove(os.path.join(sub_path, fname))
                        removed += 1
    # 统计总库当前文档数
    total = 0
    if os.path.isdir(master_dir):
        for sub in os.listdir(master_dir):
            sp = os.path.join(master_dir, sub)
            if os.path.isdir(sp):
                total += len([f for f in os.listdir(sp) if f.lower().endswith((".md", ".txt"))])
    return {"added": added, "removed": removed, "total": total}


def build_from_dir_multi(dirs: dict, store: VecStore, embed: bool = True) -> int:
    """从多个目录建库（总库专用）：dirs: {分支key: 目录路径}。"""
    total = 0
    for bkey, d in dirs.items():
        if not os.path.isdir(d):
            continue
        for name in os.listdir(d):
            path = os.path.join(d, name)
            if os.path.isfile(path) and name.lower().endswith((".md", ".txt")):
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
                chunks = _split_text(text)
                # source 前缀带分支名，便于追溯来源
                store.add(chunks, source=f"[{bkey}] {name}", embed=embed)
                total += len(chunks)
    return total


# ==================== MySQL 内容同步到向量库（高亮/档案/对话历史） ====================

def _delete_mysql_sources(store: VecStore, keyword: str) -> int:
    """删除 source 以 [mysql] 开头且包含 keyword 的块（重建对应来源前调用）。"""
    keep = [
        i for i, m in enumerate(store.meta)
        if not (m.get("source", "").startswith(config.MYSQL_SRC_PREFIX) and keyword in m.get("source", ""))
    ]
    removed = len(store.meta) - len(keep)
    if removed:
        store._rebuild_by_index(keep)
    return removed


def _mysql_fp(rows: List[dict], id_key: str = "id", time_key: str = "updated_at") -> list:
    """内容指纹：[条数, 最大 id, 最大更新时间]。用于判断 MySQL 内容是否有变化。"""
    if not rows:
        return [0, 0, ""]
    return [
        len(rows),
        max(r.get(id_key) or 0 for r in rows),
        max(str(r.get(time_key) or "") for r in rows),
    ]


def sync_from_mysql(store: VecStore, state_path: str, chat_limit: int = 200) -> dict:
    """把 MySQL 内容（高亮/个人档案/对话历史）增量同步到向量库。

    - 高亮 / 档案：量小，指纹变化（增删改）时整类重建
    - 对话历史：只增量添加新消息（id 大于上次同步位置），不重建旧块
    状态文件记录各表的指纹，内容无变化时零开销。来源统一带 [mysql] 前缀。
    """
    from . import db as _db

    if not _db.ping():
        return {"ok": False, "error": "MySQL 不可用，跳过同步"}

    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            state = {}

    changed = False
    added = removed = 0

    # ---- 1. 高亮条目：指纹变化则整类重建 ----
    try:
        hl_rows = _db.list_highlights()
    except Exception:
        hl_rows = []
    fp = _mysql_fp(hl_rows)
    if state.get("hl_fp") != fp:
        removed += _delete_mysql_sources(store, "高亮")
        texts, sources = [], []
        for r in hl_rows:
            text = f"[高亮·{r.get('category', '通用')}] {r.get('title', '')}：{r.get('content', '')}"
            if r.get("tags"):
                text += f"（标签：{r['tags']}）"
            if r.get("source"):
                text += f"（来源：{r['source']}）"
            for c in _split_text(text):
                texts.append(c)
                sources.append(f"{config.MYSQL_SRC_PREFIX} 高亮:{r.get('title', '')}")
        store.add_with_sources(texts, sources)
        added += len(texts)
        state["hl_fp"] = fp
        changed = True

    # ---- 2. 个人档案：指纹变化则整类重建 ----
    try:
        pf_rows = _db.list_profile()
    except Exception:
        pf_rows = []
    fp = _mysql_fp(pf_rows)
    if state.get("pf_fp") != fp:
        removed += _delete_mysql_sources(store, "档案")
        texts, sources = [], []
        for r in pf_rows:
            text = f"[档案·{r.get('field', '')}] {r.get('content', '')}"
            for c in _split_text(text):
                texts.append(c)
                sources.append(f"{config.MYSQL_SRC_PREFIX} 档案:{r.get('field', '')}")
        store.add_with_sources(texts, sources)
        added += len(texts)
        state["pf_fp"] = fp
        changed = True

    # ---- 3. 对话历史：增量添加（只加 id 大于上次同步位置的新消息） ----
    try:
        msgs = _db.get_recent_messages(chat_limit)
    except Exception:
        msgs = []
    last_max = state.get("chat_max", 0)
    cur_max = max((r["id"] for r in msgs), default=0)
    new_msgs = [r for r in msgs if r["id"] > last_max]
    if new_msgs:
        texts, sources = [], []
        for r in new_msgs:
            role = "用户" if r.get("role") == "user" else "助手"
            text = f"[{role}] {r.get('content', '')}"
            for c in _split_text(text):
                texts.append(c)
                sources.append(f"{config.MYSQL_SRC_PREFIX} 对话:{r.get('session_id', '')}-{r.get('id', '')}")
        store.add_with_sources(texts, sources)
        added += len(texts)
        state["chat_max"] = cur_max
        changed = True

    # 指纹/进度落盘
    if changed:
        os.makedirs(os.path.dirname(state_path), exist_ok=True)
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    return {"ok": True, "changed": changed, "added": added, "removed": removed}