# 本地语音 RAG 对话系统配置
# 修改这里即可切换模型、路径、知识库

import os
import re


def _load_dotenv(path: str = ".env"):
    """轻量读取 .env 文件（不引入 python-dotenv 依赖）。

    仅当对应键尚未存在于真实环境变量时才写入，真实环境变量优先级最高。
    支持 # 注释、KEY=VALUE 与带引号的值。
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v
    except FileNotFoundError:
        pass


# 项目根目录（config.py 在 app/ 下，根目录为上一级）
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_load_dotenv(os.path.join(_BASE_DIR, ".env"))

# Ollama 服务地址（自动补全协议前缀；0.0.0.0 是服务端监听地址，客户端要连 127.0.0.1）
_OLLAMA_RAW = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
if not _OLLAMA_RAW.startswith(("http://", "https://")):
    _OLLAMA_RAW = "http://" + _OLLAMA_RAW
OLLAMA_HOST = _OLLAMA_RAW.replace("http://0.0.0.0", "http://127.0.0.1").replace("https://0.0.0.0", "https://127.0.0.1")

# 生成模型（回答用）
# 方案A：本地 Ollama 模型（需本地跑得动，如 qwen3.5:9b）
# 方案B：DeepSeek 云端 API（最便宜模型 deepseek-chat）
CHAT_MODEL = "deepseek-chat"
CHAT_BACKEND = "deepseek"          # "ollama" 或 "deepseek"
# 密钥只从环境变量 / .env 读取，代码里不再保留明文。
# 设置方法：把密钥写入项目根目录 .env（参考 .env.example），或设置系统环境变量。
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

# 管理令牌（保护上传/删除/设置/档案/历史等管理接口；空则管理接口全部拒绝访问）
# 前端访问管理接口时通过 X-Admin-Token 请求头携带；从环境变量 / .env 读取。
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")

# 向量化模型（RAG 检索用）——bge-m3：中文检索质量优于 dmeta-embedding-zh（CMTEB ~70），GPU/CPU 均可跑
EMBED_MODEL = "bge-m3"

# ============ 多知识库配置（三分支 + 一总库） ============
# 架构：experience / personal / knowledge 三个分支库 + master 总库（同步三个分支全部文档）
# master 用于问答时全量检索，让回答更全面、更精准。
# 每个库：name(展示名) / avatar(图标) / desc(描述) /
#         knowledge_dir(源文档目录) / vector_dir(向量库目录) / persona(人设key) /
#         is_master(是否总库) / branches(总库对应的分支库 key 列表)
KNOWLEDGE_BASES = {
    "master": {
        "name": "总知识库",
        "avatar": "🧠",
        "desc": "全库检索 · 经验/个人/知识全方位",
        "knowledge_dir": "data/master",
        "vector_dir": "data/vector_store_master",
        "persona": "assistant",
        "is_master": True,
        "branches": ["experience", "personal", "knowledge"],
    },
    "experience": {
        "name": "经验库",
        "avatar": "💼",
        "desc": "工作项目经验 · 技术/总结/方案",
        "knowledge_dir": "data/experience",
        "vector_dir": "data/vector_store_experience",
        "persona": "assistant",
        "is_master": False,
    },
    "personal": {
        "name": "个人库",
        "avatar": "👤",
        "desc": "个人 · 性格/想法/私密资料",
        "knowledge_dir": "data/personal",
        "vector_dir": "data/vector_store_personal",
        "persona": "assistant",
        "is_master": False,
    },
    "knowledge": {
        "name": "知识库",
        "avatar": "📚",
        "desc": "通用知识 · 领域知识/参考",
        "knowledge_dir": "data/knowledge",
        "vector_dir": "data/vector_store_knowledge",
        "persona": "assistant",
        "is_master": False,
    },
}

# ============ MySQL 内容纳入 RAG 检索（本地知识库为主，MySQL 为补充） ============
# 把 MySQL 里的重要内容（高亮条目 / 个人档案 / 对话历史）也切块嵌入到独立的向量库，
# 提问时与本地知识库同时检索、合并去重。个人使用场景，不涉及隐私顾虑。
MYSQL_RAG_ENABLED = True          # 是否启用 MySQL 检索
MYSQL_STORE_DIR = "data/vector_store_mysql"   # MySQL 内容的向量库目录
# 同步状态文件：记录上次同步时各表的 max(id)/count，用于判断内容是否变化、避免每次都重建
MYSQL_SYNC_STATE = "data/vector_store_mysql/.sync_state.json"
# 对话历史最多纳入多少条（防止向量库无限膨胀；只取最近 N 条）
MYSQL_CHAT_LIMIT = 200
# MySQL 内容检索后最多进入上下文的块数（把名额留给知识库资料；借 kada 经验）
MYSQL_HITS_LIMIT = 6
# MySQL 检索结果的来源前缀（前端可据此识别是 MySQL 内容）
MYSQL_SRC_PREFIX = "[mysql]"

# 默认知识库（总库）
DEFAULT_KB = "master"

# 总库是否随分支库内容自动同步（上传/删除分支文档时同步更新总库）
MASTER_AUTO_SYNC = True

# ============ MySQL 持久化配置（对话历史/文档台账/高亮条目） ============
# 本机 PHPStudy MySQL 8.0.12，root 空密码；可用环境变量覆盖
MYSQL_HOST = os.environ.get("MYSQL_HOST", "127.0.0.1")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")   # PHPStudy 默认 root 空密码
MYSQL_DB = os.environ.get("MYSQL_DB", "personal_kb")
# MySQL 不可用时是否降级：True=对话照常，只是历史不落库（推荐）
# False=MySQL 连不上时报错启动失败
MYSQL_REQUIRED = False

# 检索时返回的上下文块数（影响 RAG 召回率；块数越多输入越全，但开销略增）
# 经验（kada）：原值 8 偏小，候选池太小会让"病/主题分散在多篇资料"的内容漏召；
# 单块约 150 字，15 块 ≈ 2.3K 字，DeepSeek 上下文完全够用（kada 在 96 万块库用 30，
# 40 会超时；我们库小取 15）。若出现"回答慢/超时"第一反应是调小它。
TOP_K = 15

# 同源去重：单个来源文档最多进入上下文 N 块（防止一个文档霸屏）
# 借 kada 经验 3 -> 5：长文档（如个人档案）同一主题会分散在多块，3 块易被截断。
MAX_PER_SOURCE = 5

# ============ 多车道检索（借 kada 医学库经验） ============
# 单路检索时，某一类内容（如"学习路线"）因字面/语义更贴近提问而占满名额，把
# 同样有用的另一类资料（如"项目经验""自我认知"）挤出上下文——资料不缺，是没开渠。
# 这里按本库实际内容分三条车道（见 state.py::RETRIEVAL_LANES），各留名额，
# 跨车道去重后补位，再按车道分组拼进提示词。
LANES_ENABLED = True
# 每条车道最终进入上下文的块数（3 车道 × 5 = 15 = TOP_K，总预算不超）
LANE_PER_LANE_K = 5
# 每条车道的候选池大小：先取大候选，再用车道特征词稳定重排（kada 用 36）
LANE_CANDIDATES = 20

# ============ 联网搜索兜底（知识库 + MySQL 都搜不到时） ============
# 触发条件：合并检索结果为空，或最高分 < WEB_SEARCH_MIN_SCORE
# 搜索引擎：Tavily（专为 AI 优化的搜索 API，免费 1000 次/月，api.tavily.com 国内可直连）
#   注册拿 Key：https://tavily.com  →  dashboard 复制 API Key（tvly-xxx）
#   Key 可填到下方、或环境变量 TAVILY_API_KEY、或网页后台动态设置覆盖
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "")   # 没填则联网搜索自动跳过
WEB_SEARCH_ENABLED = True
WEB_SEARCH_MIN_SCORE = 0.35      # 低于此分数视为"没找到"（自研库 0.3 左右多为噪声）
WEB_SEARCH_MAX_RESULTS = 3       # 最多取几条搜索结果
WEB_SEARCH_SNIPPET_LEN = 200     # 每条摘要最大字数

# 启动时是否自动建库（知识目录有变化时自动重建）
AUTO_REBUILD = True

# ============ 动态设置（来自 MySQL app_settings 表，网页可改） ============
# 优先读数据库里的设置覆盖默认值；数据库不可用则用默认/环境变量。
# 可配置项：deepseek_api_key / deepseek_base_url / chat_model / ollama_host / embed_model
def load_db_settings():
    """启动时把 MySQL 里的设置叠加到模块级常量（覆盖默认值）。"""
    try:
        from . import db as _db
        s = _db.all_settings()
    except Exception:
        s = {}
    # 应用设置覆盖（优先级：环境变量/.env → 数据库设置 → 代码默认值）
    # 数据库存的密钥只在对应环境变量未设置时才生效，保证改 .env 即换 Key
    global DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, CHAT_MODEL, OLLAMA_HOST, EMBED_MODEL, CHAT_BACKEND, TAVILY_API_KEY
    _env_field = {
        "deepseek_api_key": "DEEPSEEK_API_KEY",
        "deepseek_base_url": "DEEPSEEK_BASE_URL",
        "chat_model": "CHAT_MODEL",
        "ollama_host": "OLLAMA_HOST",
        "embed_model": "EMBED_MODEL",
        "chat_backend": "CHAT_BACKEND",
        "tavily_api_key": "TAVILY_API_KEY",
    }
    for field, env_name in _env_field.items():
        if not s.get(field) or os.environ.get(env_name):
            continue
        if field == "deepseek_api_key":
            DEEPSEEK_API_KEY = s[field]
        elif field == "deepseek_base_url":
            DEEPSEEK_BASE_URL = s[field]
        elif field == "chat_model":
            CHAT_MODEL = s[field]
        elif field == "ollama_host":
            OLLAMA_HOST = s[field]
        elif field == "embed_model":
            EMBED_MODEL = s[field]
        elif field == "chat_backend":
            CHAT_BACKEND = s[field]
        elif field == "tavily_api_key":
            TAVILY_API_KEY = s[field]
    return s


# ============ Lazaxa 智能体（agent 工具调用循环）配置 ============
# 设计见 docs/Lazaxa智能体设计书.md
AGENT_ENABLED = True                     # 是否启用 agent 模式
AGENT_MAX_STEPS = 20                     # 单次任务工具调用步数上限（防死循环）
AGENT_HISTORY_LIMIT = 20                 # 多轮上下文最多携带的历史消息条数
AGENT_LLM_TIMEOUT = 300                  # 单次模型调用超时（秒）
AGENT_MAX_INPUT_CHARS = 50000            # 单条用户输入长度护栏（S1-5，中英混合按字符计）
AGENT_EVENTS_ENABLED = True              # M3：全生命周期事件账本开关（agent_events 表，异常/回退时一键关）
# ---- 超长上下文与压缩工程（2026-08-17 · 四层方案）----
# 设计见 docs/Lazaxa超长上下文与压缩工程方案.md；关闭总开关即完全回退旧行为（硬截断）
CONTEXT_COMPACT_ENABLED = True           # 总开关
CONTEXT_COMPACT_THRESHOLD = 30000        # 触发压缩的估算字符阈值（约 15-20K token）
CONTEXT_COMPACT_KEEP_RECENT = 3          # 压缩时保留的最近完整轮数（S1-8：2→3，多留一轮当前工作上下文）
CONTEXT_COMPACT_MAX_PER_TASK = 2         # 单任务最多自动压缩次数（防抖动）
# ---- M4a: old tool-result clearing (Observation Masking), before LLM compaction ----
CONTEXT_TOOL_CLEAR_ENABLED = True
CONTEXT_TOOL_CLEAR_THRESHOLD = 18000
CONTEXT_TOOL_CLEAR_KEEP_N = 10
CONTEXT_TOOL_CLEAR_EXCLUDE = (
    "memory_recall", "memory_search", "note_task_done", "remember",
    "approval_status", "plan_get",
)
TOOL_RESULT_TRIM_CHARS = 2000            # 工具结果修剪阈值（超长截断+占位符+原文归档）
CONTEXT_ARCHIVE_DIR = os.path.join(_BASE_DIR, "data", "agent", "archives")  # 压缩/修剪原文归档（JSONL）
# 工作区白名单根目录 = 仓库根（"两者合一"沙箱：文件类工具只能在此目录内操作）
# 默认取仓库根（config.py 位于 app/ 下，仓库根 = 再往上一级）；可用环境变量 AGENT_WORKSPACE 覆盖
AGENT_WORKSPACE = os.environ.get("AGENT_WORKSPACE", os.path.dirname(_BASE_DIR))

# 桌面临时目录（行为守则"临时文件纪律"）：智能体任务中的中间产物
# （草稿/测试文件/缓存/中间数据）一律写这里，不污染工作区（仓库根）。
# 任务结束后由 loop.cleanup_temp_dir() 自动清空（保留目录本身）。
# 默认桌面 LazaxaTemp；可用环境变量 AGENT_TEMP_DIR 覆盖。
AGENT_TEMP_DIR = os.environ.get(
    "AGENT_TEMP_DIR", os.path.join(os.path.expanduser("~"), "Desktop", "LazaxaTemp"))
os.makedirs(AGENT_TEMP_DIR, exist_ok=True)

# ============ 技能体系（批次 E1 · 借鉴 harness skills seam） ============
# skills/ 目录下每个 <name>.md 一个技能（frontmatter name/description/when_to_use + 正文）。
# 目录只注入 name+description（省 token），正文由 use_skill 按需加载。
# 技能目录（项目根下 skills/；config.py 位于 app/ 下，项目根 = _BASE_DIR 的上一级）
SKILLS_DIR = os.path.join(os.path.dirname(_BASE_DIR), "skills")

# ============ 子代理（批次 E2 · 借鉴 harness subagent/jobs） ============
# 子代理委派深度上限（0=主任务；>= 该值后 schema 中移除委派工具，防无限递归）
AGENT_MAX_SUBAGENT_DEPTH = 2
# 单次并行委派（subagent_parallel）的子代理数量上限（防刷爆事件流/上下文）
AGENT_MAX_PARALLEL_SUBAGENTS = 5

# ============ 反思机制（2026-08-18 · 修复复杂任务链"踩坑不换思路"） ============
# 连续工具执行失败达该次数 → 在下一轮模型调用前注入强制反思提示
# （要求换完全不同的策略；卡住时用 web_search 联网找解法）
AGENT_REFLECT_STREAK = 2
# 单个任务内反思提示最大注入次数（防止持续失败时无限刷屏干扰）
AGENT_REFLECT_MAX_INJECTIONS = 2

# ============ 后台任务（"边聊边做"通话督导模式 · 2026-08-18） ============
# 主对话（监工）把复杂指令 delegate 成后台 worker 执行，自己继续陪聊；
# 期3（多任务并行）起最多 AGENT_JOB_PARALLEL 个 worker 同时跑，
# 会操作同一屏幕/键鼠的工具（screen_lock=True）执行前申请全局互斥锁，
# 谁先申请到谁用，防止并行任务点错窗口/输入串台。
AGENT_JOB_TIMEOUT = 1800               # 单个后台任务整体超时（秒）：30 分钟强制结束
AGENT_JOB_ACTIVITY_LIMIT = 20          # Job 进度事件环形缓冲保留条数（前端面板/上下文用）
# 期3 多任务并行（电话模式升级方案 §四）：任务随便并行，动屏幕/键鼠的工具全局一把锁。
AGENT_JOB_PARALLEL = 3                 # 最多同时执行的后台 worker 数（超出的进 FIFO 排队）
AGENT_JOB_SCREEN_WAIT = 60             # 工具等屏幕互斥锁的最长秒数；超时提示稍后再试


# ============ GUI 自动化（批次 C · 移植 AIPC ui_controller + 视觉升级方案阶段 1） ============
# 能力：截图/OCR/定位/点击/输入/窗口控制，见 docs/AIPC整合方案.md 与 docs/Lazaxa视觉升级方案.md
# 截图保存目录：走桌面临时目录（行为守则"临时文件纪律"），主任务结束自动清理，不落工作区
AGENT_SCREENSHOT_DIR = os.path.join(AGENT_TEMP_DIR, "screenshots")
OCR_LANG = "chi_sim+eng"                 # Tesseract 识别语言（中文简体+英文）
OCR_MIN_CONFIDENCE = 30.0                # screen_ocr 默认置信度下限（0-100）
SCREEN_ANALYZE_MAX_ITEMS = 40            # screen_analyze 单次返回的元素上限（防刷爆上下文）
# 行动-观察闭环（视觉升级方案 §4.2）：写操作（点击/输入/按键）自动附带
# 操作前/后快照 + 变化摘要，让模型获得"操作后发生了什么"的反馈
UI_VERIFY_ENABLED = True                 # 写操作自动验证闭环总开关
UI_VERIFY_WAIT_MS = 600                  # 操作后等待界面响应再截图（毫秒）
UI_DIFF_THRESHOLD = 30                   # 像素差异阈值 0-255（超过才计入变化）
UI_DIFF_MIN_RATIO = 0.02                 # 分块内变化像素占比下限（低于视为噪声）
# UI 控件树（视觉升级方案 §4.1，pywinauto UIAutomation）
UI_LIST_MAX_ITEMS = 60                   # ui_list 单次返回元素上限（防刷爆上下文）
# 视觉语言模型（视觉升级方案 §5，语义层：screen_describe 看懂截图）
VLM_MODEL = os.environ.get("VLM_MODEL", "gemma3:4b")   # Ollama 视觉模型（qwen2.5-vl 官方未收录，故用 gemma3）
VLM_TIMEOUT = 120                        # VLM 单次推理超时（秒）
UI_VERIFY_VLM = True                     # 写操作闭环自动附加 VLM 结果判断（用户决定开启：更智能，但每次写操作多花几秒；VLM 不可用时自动跳过）

# ============ 手机事件反连（C批1 · adb 轮询设备通知/电量 → 桌面提醒） ============
# 桌面侧后台线程定时轮询 adb 设备（见 app/phone.py），把"手机上的事"主动
# 推到桌面提醒（phone_events 表 → kb_gui 弹窗）。设备没连/adb 不可用时静默跳过。
PHONE_MONITOR_ENABLED = os.environ.get("PHONE_MONITOR_ENABLED", "1") == "1"  # 总开关
PHONE_MONITOR_SECONDS = int(os.environ.get("PHONE_MONITOR_SECONDS", "60"))   # 轮询间隔（秒）
PHONE_BATTERY_LOW_PCT = int(os.environ.get("PHONE_BATTERY_LOW_PCT", "20"))   # 低电量告警阈值

# ============ 三级权限体系（借鉴 Claude Code 权限模式 + 企业审批审计） ============
# 设计见 docs/Lazaxa智能体设计书.md §7；决策引擎 app/agent/permissions.py
PERMISSION_DEFAULT_MODE = "relaxed"     # 默认权限模式：locked/standard/relaxed
# 说明：默认省心（relaxed）——sensitive 写操作自动放行；run_command 内容分级
# （删文件/清空内容等删除类操作任何模式都人工确认，普通命令自动）；rm -rf 级走硬断路器。
# 硬性断路器：命中即强制人工确认（任何模式不可绕过，借鉴 Claude Code 的 rm -rf 硬拦截）
PERMISSION_HARD_BLOCK = [
    re.compile(r"remove-item[^;]{0,80}\s-recurse", re.IGNORECASE),  # PowerShell rm -rf 级
    re.compile(r"rm\s+-rf", re.IGNORECASE),
    re.compile(r"\bformat\s+[a-z]:", re.IGNORECASE),
    re.compile(r"\bshutdown\b", re.IGNORECASE),
    re.compile(r"\bstop-computer\b", re.IGNORECASE),
    re.compile(r"\brestart-computer\b", re.IGNORECASE),
    re.compile(r"\bdiskpart\b", re.IGNORECASE),
    re.compile(r"\bdel\s+/f\s+/s\s+/q", re.IGNORECASE),
    re.compile(r"\brd\s+/s", re.IGNORECASE),
]
# 受保护目录：文件类工具（read_file/write_file/list_dir）默认拒绝访问（借鉴 Claude 受保护目录）
PERMISSION_PROTECTED_DIRS = [
    "c:/windows", "c:/program files", "c:/program files (x86)",
    "c:/programdata", "c:/$recycle.bin",
    "c:/users/hasee/appdata", "c:/users/hasee/.ssh",
    "c:/users/hasee/.git", "c:/users/hasee/.aws", "c:/users/hasee/.gnupg",
]
# 敏感文件黑名单（行为守则禁区 A，相对仓库根，小写/正斜杠）：工作区内也不可读写（读+写都 deny）
# 含密钥：.env / keys / kb-gui-assistant/config.json / history；个人隐私：SelfIterate/data；整机快照：version
PERMISSION_BLOCKED_PATHS = [
    "selfiterate/.env",
    "selfiterate/keys",
    "kb-gui-assistant/config.json",
    "kb-gui-assistant/history",
    "selfiterate/data",
    "version",
]

# ============ Sanctum 长期记忆（Qdrant 底座 · M3 记忆系统-长层） ============
# 定位与设计见 Sanctum/Sanctum定位与技术方案.md（2026-08-16 讨论沉淀）
# 原则：嵌入（fastembed 离线）与检索（本机 Qdrant）全程本地，向量数据不出网
SANCTUM_QDRANT_URL = os.environ.get("SANCTUM_QDRANT_URL", "http://127.0.0.1:6333")
SANCTUM_COLLECTION = os.environ.get("SANCTUM_COLLECTION", "assistant_memory")
SANCTUM_EMBED_MODEL = os.environ.get("SANCTUM_EMBED_MODEL", "BAAI/bge-small-zh-v1.5")
SANCTUM_EMBED_DIM = int(os.environ.get("SANCTUM_EMBED_DIM", "512"))
# 本地模型缓存目录（与 Sanctum/demo_rag.py 共用，避免重复下载）
SANCTUM_MODEL_DIR = os.path.join(_BASE_DIR, "..", "Sanctum", "models")
# 记忆检索默认返回条数
SANCTUM_MEMORY_TOP_K = 5
# 规则式自动沉淀开关：识别"记住/别忘了"等意图后自动写入记忆库（阶段 3）
MEMORY_AUTO_SINK_ENABLED = os.environ.get("MEMORY_AUTO_SINK_ENABLED", "1") == "1"
# M4c 失败教训沉淀开关：loop_capped/max_steps 行为类失败自动提炼教训入记忆（独立于自动沉淀）
MEMORY_LESSON_SINK_ENABLED = os.environ.get("MEMORY_LESSON_SINK_ENABLED", "1") == "1"

# ============ Obsidian 笔记（Local REST API 插件 · 方案 C） ============
# 依赖 Obsidian 社区插件 "Local REST API"（默认 HTTPS 端口 27124，自签名证书）。
# apiKey / port 从插件配置 data.json 自动读取，无需写进 .env。
OBSIDIAN_VAULT_PATH = "D:/Users/Hasee/Documents/Obsidian Vault"   # 用户 Obsidian 库目录
OBSIDIAN_PLUGIN_DATA = os.path.join(
    OBSIDIAN_VAULT_PATH, ".obsidian", "plugins", "obsidian-local-rest-api", "data.json")
OBSIDIAN_BASE_URL = "https://127.0.0.1"   # 本机 Obsidian Local REST API（自签证书，工具内跳过校验）
OBSIDIAN_DEFAULT_PORT = 27124             # data.json 缺省端口
# Obsidian 笔记手动同步进知识库时的独立向量目录（kb='obsidian'，与自研 RAG 库隔离）
OBSIDIAN_STORE_DIR = os.path.join(_BASE_DIR, "data", "vector_store_obsidian")

# ============ 外部 MCP Server 接入（2026-08-17 · MCP 集成调研落地） ============
# Lazaxa 作为 MCP 客户端（stdio，见 app/agent/mcp_bridge.py），启动外部 MCP server
# 子进程，模型可调用其暴露的工具——相当于"标准插座"，有 MCP 的软件（Blender/
# Krita/VLC/FFmpeg…）都能插上。工具注册见 app/agent/tools/mcp_tools.py。
# 每个 server 需配置：command/args/cwd（启动方式）+ enabled（开关）。
MCP_SERVERS = {
    # Blender 3D：blender-mcp（harveyxiacn，359 工具）。源码在 TRAEpj/blender-mcp，
    # Blender 内需安装并启用 addon（Blender 偏好设置 → 插件 → 安装 dist/blender_mcp_addon.zip），
    # 并在 3D 视图侧边栏 MCP 面板启动插件服务（监听 127.0.0.1:9876）。
    "blender": {
        "display_name": "Blender 3D",
        "enabled": os.environ.get("MCP_BLENDER_ENABLED", "1") == "1",
        "command": "uv",
        "args": ["run", "--directory", r"D:\Users\Hasee\Desktop\other_work\TRAEpj\blender-mcp", "blender-mcp"],
        "cwd": r"D:\Users\Hasee\Desktop\other_work\TRAEpj\blender-mcp",
    },
}
