# -*- coding: utf-8 -*-
"""统一日志：控制台 + 文件轮转（阶段 1 工程地基）。

用法：
    from .log_util import setup_logging, get_logger
    setup_logging()              # 在应用入口（main.py）启动时调用一次
    logger = get_logger("rag")   # 各模块获取命名 logger
"""
import logging
import os
from logging.handlers import RotatingFileHandler

_LOG_FORMAT = "%(asctime)s %(levelname)s [%(name)s] %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(level: int = logging.INFO, log_dir: str | None = None) -> logging.Logger:
    """初始化根日志（幂等）：控制台 + logs/app.log 轮转（5MB × 3 份）。"""
    root = logging.getLogger()
    if root.handlers:  # 已初始化过则直接返回
        return root
    if log_dir is None:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
        )
    os.makedirs(log_dir, exist_ok=True)

    fmt = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)
    fh = RotatingFileHandler(
        os.path.join(log_dir, "app.log"),
        maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8",
    )
    fh.setFormatter(fmt)
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)

    root.setLevel(level)
    root.addHandler(fh)
    root.addHandler(ch)
    return root


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
