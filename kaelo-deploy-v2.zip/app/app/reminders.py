# -*- coding: utf-8 -*-
"""Lazaxa 笔记到期提醒：定时扫描 Obsidian vault，提取含"今天/明天"的提醒类内容入库。

定位（用户定）：Obsidian 是面向日常工作的笔记库 + 提醒源。
AI 不需要记住笔记全文，而是发现笔记里有"明天下午3点去拿体检报告"这类
提醒内容时，主动提醒用户。

规则式提取（免费、快、可控）：
  - 触发词：提醒 / 记得 / 截止 / 到期 / 待办 / 别忘了 / 要做 / 得去
  - 日期词：今天/今日 → 当天；明天/明日 → 次日；N月N日 → 当年对应日期
  - 只对"有明确日期 + 触发词"的行生成提醒，避免误报
扫描入库按 (笔记, 内容, 日期) 去重，幂等可重复执行。
"""
import logging
import re
from datetime import date, timedelta

from . import db

logger = logging.getLogger("reminders")

# 提醒意图触发词
_TRIGGER = re.compile(r"提醒|记得|截止|到期|待办|别忘了|别忘|要做|得去|需要去|记得去|该去|要交|要拿|要买|要办|去拿|去取|去交|去办")
# 日期词
_TODAY = re.compile(r"今天|今日")
_TOMORROW = re.compile(r"明天|明日")
_DAY = re.compile(r"(?<![\d])(\d{1,2})\s*月\s*(\d{1,2})\s*日(?!\d)")
# 时段词（识别是否真提醒，非硬性条件）
# _TIME = re.compile(r"(\d{1,2})\s*[点:：时]|上午|下午|晚上|中午|早上")


def _resolve_date(line: str, today: date) -> date | None:
    """从一行文本解析提醒日期：今天→today、明天→today+1、N月N日→当年。
    解析不出明确日期返回 None（不生成提醒，避免误报）。
    """
    if _TODAY.search(line):
        return today
    if _TOMORROW.search(line):
        return today + timedelta(days=1)
    m = _DAY.search(line)
    if m:
        month, day = int(m.group(1)), int(m.group(2))
        try:
            d = date(today.year, month, day)
        except ValueError:
            return None
        # 已过去的今年日期 → 视为明年（如 12月31日 在 1 月看到）
        if d < today:
            d = date(today.year + 1, month, day)
        return d
    return None


def scan_note(full_path: str, note_rel: str, today: date) -> list:
    """扫描单篇笔记，返回 [(remind_date, content)]。"""
    rows = []
    try:
        with open(full_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except Exception:
        return rows
    in_code = False
    for raw in lines:
        line = raw.strip()
        # 跳过空行 / 标题
        if not line or line.startswith("#"):
            continue
        # 代码块整体跳过（围栏内内容不算笔记正文）
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if not _TRIGGER.search(line):
            continue
        d = _resolve_date(line, today)
        if d is None:
            continue
        # 截断超长行，去掉多余空白
        content = re.sub(r"\s+", " ", line)[:200]
        rows.append((d, content))
    return rows


def scan_vault_for_reminders() -> int:
    """扫描整个笔记库并入库到期提醒（幂等）。返回新增条数。

    安静契约（B批3 · 借 LoopX quiet_noop 哲学）：无新增时静默返回 0、不刷
    日志（正常扫描不出噪音，只有真发现新提醒才 info 一行）；按 (笔记,内容,日期)
    去重，可重复执行不产生重复提醒。
    """
    try:
        from .agent.tools.obsidian import _walk_vault_md
    except Exception as e:
        logger.warning("扫描笔记库失败（工具导入错误）: %s", e)
        return 0
    today = date.today()
    added = 0
    for rel, full in _walk_vault_md():
        for remind_at, content in scan_note(full, rel, today):
            if db.add_reminder(content, rel, remind_at):
                added += 1
    if added:
        logger.info("[reminders] 扫描到 %d 条新提醒", added)
    return added
