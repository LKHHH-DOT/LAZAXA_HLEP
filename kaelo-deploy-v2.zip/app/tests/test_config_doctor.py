# -*- coding: utf-8 -*-
"""config doctor 单元测试（B批2 · SelfIterate/scripts/config_doctor.py）。

覆盖：dotenv 解析、模板对照分级、--fix 一键补齐（保已有键）、
技能目录校验（validate_skills 的 tmp 目录行为）。
"""
import os
import sys

SCRIPTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)
import config_doctor as cd  # noqa: E402


# ---------- dotenv 解析 ----------

def test_parse_dotenv_basic():
    text = ("# 注释\nKEY=value\nEMPTY=\nQUOTED=\"a b\"\n# 另一注释\n"
            "URL=http://127.0.0.1:6333\n")
    out = cd.parse_dotenv(text)
    assert out == {"KEY": "value", "EMPTY": "", "QUOTED": "a b",
                   "URL": "http://127.0.0.1:6333"}


def test_parse_dotenv_empty():
    assert cd.parse_dotenv("") == {}
    assert cd.parse_dotenv("# 只有注释\n\n") == {}
    assert cd.parse_dotenv("没有等号的行") == {}


# ---------- 模板对照分级 ----------

def test_diff_env_levels():
    example = {"SECRET": "", "URL": "http://a:1", "OK_KEY": "x"}
    actual = {"URL": "", "OK_KEY": "x"}
    issues = {i["key"]: i for i in cd.diff_env(example, actual)}
    assert issues["SECRET"]["level"] == "error"      # 缺失行 → error
    assert issues["URL"]["level"] == "warning"       # 配置类空值 → warning
    assert "OK_KEY" not in issues                    # 正常键不入列


def test_diff_env_secret_present_but_empty_is_info():
    example = {"TAVILY_API_KEY": ""}
    actual = {"TAVILY_API_KEY": ""}
    issues = cd.diff_env(example, actual)
    assert len(issues) == 1 and issues[0]["level"] == "info"


def test_load_env_file_missing_returns_empty(tmp_path):
    assert cd.load_env_file(str(tmp_path / "ghost.env")) == {}


# ---------- --fix 一键补齐 ----------

def test_fix_env_appends_missing_keeps_existing(tmp_path):
    ex = tmp_path / "example.env"
    ex.write_text("SECRET=\nURL=http://x:1\n", encoding="utf-8")
    env = tmp_path / ".env"
    env.write_text("# 用户已有内容\nURL=http://y:2\n", encoding="utf-8")
    fixed = cd.fix_env(str(ex), str(env))
    assert fixed == ["SECRET"]
    text = env.read_text(encoding="utf-8")
    assert "URL=http://y:2" in text          # 已有键不覆盖
    assert "SECRET=" in text                 # 缺失键补上（模板空值留空待填）
    assert "config doctor" in text


def test_fix_env_no_missing_no_write(tmp_path):
    ex = tmp_path / "example.env"
    ex.write_text("A=1\n", encoding="utf-8")
    env = tmp_path / ".env"
    env.write_text("A=1\n", encoding="utf-8")
    assert cd.fix_env(str(ex), str(env)) == []
    assert env.read_text(encoding="utf-8") == "A=1\n"


def test_fix_env_missing_dir_created(tmp_path):
    ex = tmp_path / "example.env"
    ex.write_text("A=1\n", encoding="utf-8")
    env = tmp_path / "sub" / ".env"          # 目录不存在
    fixed = cd.fix_env(str(ex), str(env))
    assert fixed == ["A"]
    assert "A=1" in env.read_text(encoding="utf-8")


# ---------- 技能目录校验（validate_skills tmp 目录） ----------

def test_validate_skills_healthy(tmp_path):
    from app.agent import skills
    (tmp_path / "good-skill.md").write_text(
        "---\ndescription: 正常技能\nversion: 1.0.0\n---\n正文内容\n",
        encoding="utf-8")
    rep = skills.validate_skills(str(tmp_path))
    assert rep["ok"] is True and rep["total"] == 1 and rep["issues"] == []


def test_validate_skills_error_levels(tmp_path):
    from app.agent import skills
    # 缺 description → error；无 frontmatter → error
    (tmp_path / "no-desc.md").write_text("---\nversion: 1.0.0\n---\n正文\n",
                                         encoding="utf-8")
    (tmp_path / "no-front.md").write_text("# 没有 frontmatter\n", encoding="utf-8")
    (tmp_path / "bad name.md").write_text("---\ndescription: x\n---\n正文\n",
                                          encoding="utf-8")
    rep = skills.validate_skills(str(tmp_path))
    errors = [i for i in rep["issues"] if i["level"] == "error"]
    assert rep["ok"] is False
    kinds = " ".join(i["msg"] for i in errors)
    assert "description" in kinds and "frontmatter" in kinds and "不合法" in kinds


def test_validate_skills_warning_levels(tmp_path):
    from app.agent import skills
    # version 格式非法 + frontmatter name 与文件名不一致
    (tmp_path / "real-name.md").write_text(
        "---\nname: other-name\ndescription: x\nversion: 2.0\n---\n正文\n",
        encoding="utf-8")
    rep = skills.validate_skills(str(tmp_path))
    warns = [i for i in rep["issues"] if i["level"] == "warning"]
    msgs = " ".join(i["msg"] for i in warns)
    assert "格式非法" in msgs and "不一致" in msgs


def test_validate_skills_reference_marked_info(tmp_path):
    from app.agent import skills
    (tmp_path / "ref-doc.md").write_text(
        "---\ndescription: 附属规范\nreference: main-skill\n"
        "version: 1.0.0\n---\n长正文…\n", encoding="utf-8")
    rep = skills.validate_skills(str(tmp_path))
    infos = [i for i in rep["issues"] if i["level"] == "info"]
    assert rep["ok"] is True
    assert len(infos) == 1 and "reference" in infos[0]["msg"] and "main-skill" in infos[0]["msg"]
