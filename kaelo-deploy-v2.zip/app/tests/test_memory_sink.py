# -*- coding: utf-8 -*-
"""P1 记忆防污染 + 分层测试（借 Agent-Memory）。

覆盖（方案 §四 测试项）：
  1. 污染文本剥离：auto_sink_message 收到夹带记忆注入段的消息 → 只存干净原文
  2. 纯注入段（无用户正文）不沉淀（防自增强反馈环）
  3. 无注入段的正常消息行为不变（原文入库）
  4. 画像稳定段注入：get_profile_block 返回最近 profile 条目
  5. 记忆检索段排除画像（profile 不重复出现在动态段）
  6. 写入防重：memory_add 同文本同来源不重复写入

全部 mock 掉 registry.execute / retrieve / qdrant 客户端，纯测规则逻辑。
"""
import types

import pytest

from app import memory as mem


@pytest.fixture(autouse=True)
def _fake_execute(monkeypatch):
    """把 registry.execute 换成记录器，隔离 Qdrant/嵌入。"""
    from app.agent.registry import registry as _reg

    calls = []

    def fake_execute(name, args):
        calls.append((name, args))
        return types.SimpleNamespace(ok=True)

    monkeypatch.setattr(_reg, "execute", fake_execute)
    return calls


# ============ 1. 污染文本剥离（防自增强反馈环） ============

def test_sink_strips_injected_memory_block(monkeypatch, _fake_execute):
    """消息夹带【长期记忆】注入段 → 只存剥离后的干净原文。"""
    calls = _fake_execute
    polluted = (
        "请记住：我以后的代码注释都用中文。\n"
        f"{mem.MEM_CTX_HEADER}：\n"
        "- 主人偏好深色主题 [preference]\n"
        "- 主人常用 Python [profile]"
    )
    assert mem.auto_sink_message(polluted)
    assert len(calls) == 1
    assert calls[0][0] == "memory_add"
    stored = calls[0][1]["text"]
    assert "注释都用中文" in stored
    assert "深色主题" not in stored          # 注入的记忆片段不得写回
    assert "【长期记忆】" not in stored
    assert "[profile]" not in stored


def test_sink_strips_profile_and_loop_headers(monkeypatch):
    """画像节头与 agent 循环节头（【相关长期记忆】）同样被剥离。"""
    text = (
        f"{mem.MEM_PROFILE_HEADER}：\n"
        "- 主人是自由职业者 [profile]\n"
        "\n"
        "以后都用这个方案帮我写周报\n"
        "\n"
        "【相关长期记忆】（仅供参考）：\n"
        "- 周报模板用表格 [memory]"
    )
    clean = mem._strip_injected_memory(text)
    assert "自由职业者" not in clean
    assert "周报模板" not in clean
    assert "写周报" in clean


def test_sink_pure_injected_segment_no_user_words(_fake_execute):
    """消息只有注入段、没有用户正文 → 剥离后为空，不沉淀。"""
    calls = _fake_execute
    polluted = (
        f"{mem.MEM_CTX_HEADER}：\n"
        "- 主人偏好深色主题 [preference]\n"
        "- 主人常用 Python [profile]"
    )
    assert not mem.auto_sink_message(polluted)
    assert len(calls) == 0


def test_sink_normal_message_unchanged(monkeypatch, _fake_execute):
    """无注入段消息：干净原文原样入库（行为与改造前一致）。"""
    calls = _fake_execute
    msg = "请记住，我以后每周五下午三点都要开会"
    assert mem.auto_sink_message(msg)
    assert calls[0][1]["text"] == msg
    assert calls[0][1]["tags"] == ["自动沉淀"]


def test_sink_source_msg_overrides_user_msg(monkeypatch, _fake_execute):
    """路由传 source_msg（原文快照）时，以它为准剥离入库。

    user_msg 很短（"记住"不足门槛），但路由带 source_msg 完整原文 → 按原文沉淀。
    """
    calls = _fake_execute
    assert mem.auto_sink_message("记住", source_msg="记住：以后都用 Notion 管理待办")
    assert calls[0][1]["text"] == "记住：以后都用 Notion 管理待办"


# ============ 2. 画像稳定段注入（profile 分层） ============

def test_get_profile_block_recent_profiles(monkeypatch):
    """get_profile_block 取最近 type=profile 条目并格式化为注入行。"""
    monkeypatch.setattr(
        mem, "retrieve_recent",
        lambda type="", limit=3: [
            {"id": "p1", "text": "主人是自由职业者", "type": "profile",
             "tags": [], "created_iso": "2026-09-01", "score": 0.0},
            {"id": "p2", "text": "主人主要用 Windows", "type": "profile",
             "tags": [], "created_iso": "2026-09-02", "score": 0.0},
        ],
    )
    block = mem.get_profile_block(top_k=2)
    assert "主人是自由职业者" in block
    assert "主人主要用 Windows" in block
    assert "[profile]" in block


def test_get_profile_block_empty(monkeypatch):
    """画像库为空/不可用 → 返回空串（稳定段静默降级）。"""
    monkeypatch.setattr(mem, "retrieve_recent", lambda **k: [])
    assert mem.get_profile_block() == ""
    assert mem.get_profile_block(top_k=0) == ""


def test_get_memory_context_excludes_profile(monkeypatch):
    """动态检索段排除 profile：画像只在稳定段注入，不重复出现。"""
    fake_items = (
        {"id": "1", "text": "上周整理了项目文档", "type": "memory",
         "tags": [], "created_iso": "", "score": 0.5},
        {"id": "2", "text": "主人是自由职业者", "type": "profile",
         "tags": [], "created_iso": "", "score": 0.9},
        {"id": "3", "text": "写周报用表格模板", "type": "experience",
         "tags": [], "created_iso": "", "score": 0.4},
    )
    monkeypatch.setattr(mem, "_cached_retrieve", lambda q, k: fake_items)
    ctx = mem.get_memory_context("周报怎么写")
    assert "- 上周整理了项目文档 [memory]" in ctx
    assert "- 写周报用表格模板 [experience]" in ctx
    assert "自由职业者" not in ctx


# ============ 3. 写入防重（tools/memory._memory_add） ============

class _FakeClient:
    """假 Qdrant 客户端：按"文本是否已存在"查重，upsert 记录并累积。"""

    def __init__(self):
        self._stored = set()
        self.upserted = 0
        self.payloads = []          # 每次 upsert 的完整 payload（供溯源字段断言）

    def count(self, **kw):
        cf = kw.get("count_filter")
        texts = [
            c.match.value for c in (cf.must if cf is not None else [])
            if getattr(c, "key", None) == "text" and getattr(c, "match", None)
        ]
        if texts:
            # 查重：该文本是否已入库（其余条件在测试里恒定，可忽略）
            return types.SimpleNamespace(
                count=1 if texts[0] in self._stored else 0)
        return types.SimpleNamespace(count=len(self._stored))

    def upsert(self, **kw):
        for p in kw["points"]:
            self._stored.add(p.payload["text"])
            self.payloads.append(p.payload)
        self.upserted += len(kw["points"])


def test_memory_add_dedup_same_text_same_source(monkeypatch):
    """同文本同来源重复写入 → 第二次跳过，不产生重复点。"""
    from app.agent import tools  # noqa: F401  确保包可导入
    from app.agent.tools import memory as tmem

    fake = _FakeClient()
    monkeypatch.setattr(tmem, "_ensure_collection", lambda: None)
    monkeypatch.setattr(tmem, "_get_client", lambda: fake)
    monkeypatch.setattr(tmem, "_embed", lambda texts: [[0.1] * 8])

    r1 = tmem._memory_add("我以后都用中文注释", type="preference",
                          source="[自动记忆] 对话")
    assert r1.ok and fake.upserted == 1
    # 第二次完全相同内容 → 防重跳过
    r2 = tmem._memory_add("我以后都用中文注释", type="preference",
                          source="[自动记忆] 对话")
    assert r2.ok and fake.upserted == 1
    assert "未重复" in r2.text


def test_memory_add_different_text_writes(monkeypatch):
    """不同文本（同来源）正常写入，防重不误伤。"""
    from app.agent.tools import memory as tmem

    fake = _FakeClient()
    monkeypatch.setattr(tmem, "_ensure_collection", lambda: None)
    monkeypatch.setattr(tmem, "_get_client", lambda: fake)
    monkeypatch.setattr(tmem, "_embed", lambda texts: [[0.1] * 8])

    tmem._memory_add("第一偏好", type="preference", source="S")
    tmem._memory_add("第二偏好", type="preference", source="S")
    assert fake.upserted == 2


# ============ 4. round_id 溯源（A批2 记忆防污染反馈环） ============

def test_sink_carries_given_round_id(_fake_execute):
    """auto_sink 收到 round_id → memory_add 参数原样带上，落库可溯源。"""
    calls = _fake_execute
    assert mem.auto_sink_message("请记住，我以后周三开例会", round_id="r-123")
    assert calls[0][1]["round_id"] == "r-123"


def test_sink_fallback_round_when_missing(_fake_execute):
    """chat 路径未传 round_id → 自动补一个 chat- 前缀溯源 id（保证必填）。"""
    calls = _fake_execute
    assert mem.auto_sink_message("请记住，我以后周三开例会")
    rid = calls[0][1]["round_id"]
    assert isinstance(rid, str) and rid.startswith("chat-")


def test_memory_add_stores_round_in_payload(monkeypatch):
    """memory_add 落库时 round_id 写入 payload；未传则不出现该键。"""
    from app.agent.tools import memory as tmem

    fake = _FakeClient()
    monkeypatch.setattr(tmem, "_ensure_collection", lambda: None)
    monkeypatch.setattr(tmem, "_get_client", lambda: fake)
    monkeypatch.setattr(tmem, "_embed", lambda texts: [[0.1] * 8])

    tmem._memory_add("带轮次写入", type="memory", source="S", round_id="r-9")
    assert fake.payloads[0]["round_id"] == "r-9"
    tmem._memory_add("不带轮次写入", type="memory", source="S")
    assert "round_id" not in fake.payloads[1]


def test_build_filter_round_id_condition():
    """_build_filter 显式传 round_id → 过滤条件含轮次等值匹配；不传则无。"""
    from qdrant_client.models import MatchValue
    from app.agent.tools.memory import _build_filter

    f_with = _build_filter(source="S", round_id="r-42")
    keys_with = {c.key for c in f_with.must}
    assert "round_id" in keys_with
    assert "source" in keys_with
    # 轮次匹配为等值条件
    cond = next(c for c in f_with.must if c.key == "round_id")
    assert isinstance(cond.match, MatchValue) and cond.match.value == "r-42"
    # 不传 round_id → 轮次不作为过滤维度
    f_without = _build_filter(source="S")
    keys_without = {c.key for c in f_without.must}
    assert "round_id" not in keys_without
