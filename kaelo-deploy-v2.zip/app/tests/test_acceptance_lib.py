# -*- coding: utf-8 -*-
"""acceptance_lib（C批3 · GUI 验收基准集 VLM judge 工具库）单元测试。

覆盖：vlm_ask 缺图/模型不可用/非 200/空响应/正常响应清洗、
ollama_alive 在线判定、vlm_judge 是/否题命中与 fail-open 降级。
全部通过 monkeypatch _post_json 断网模拟，不触真实 Ollama。
"""
import os
import sys

SCRIPTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)
import acceptance_lib as al  # noqa: E402


class _FakeResp:
    """伪 requests.Response：只带测试关心的 status_code/json。"""

    def __init__(self, status_code=200, data=None):
        self.status_code = status_code
        self._data = data or {}

    def json(self):
        return self._data


def _make_img(tmp_path, name="shot.png", content=b"PNG-FAKE"):
    p = tmp_path / name
    p.write_bytes(content)
    return str(p)


# ---------- ollama_alive ----------

def test_ollama_alive_ok(monkeypatch):
    monkeypatch.setattr(al, "_post_json", lambda url, payload, timeout: _FakeResp(200))
    assert al.ollama_alive() is True


def test_ollama_alive_non200(monkeypatch):
    monkeypatch.setattr(al, "_post_json", lambda url, payload, timeout: _FakeResp(500))
    assert al.ollama_alive() is False


def test_ollama_alive_exception(monkeypatch):
    def boom(*a, **k):
        raise ConnectionError("refused")
    monkeypatch.setattr(al, "_post_json", boom)
    assert al.ollama_alive() is False


def test_ollama_host_from_config_or_default():
    host = al._ollama_host()
    assert host.startswith("http")


# ---------- vlm_ask ----------

def test_vlm_ask_missing_image_returns_none(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setattr(al, "_post_json",
                        lambda url, payload, timeout: calls.append((url, payload)) or _FakeResp())
    assert al.vlm_ask(str(tmp_path / "ghost.png"), "这是什么窗口？") is None
    assert calls == []          # 缺图：根本不发请求


def test_vlm_ask_post_raises_returns_none(tmp_path, monkeypatch):
    img = _make_img(tmp_path)

    def boom(*a, **k):
        raise RuntimeError("offline")
    monkeypatch.setattr(al, "_post_json", boom)
    assert al.vlm_ask(img, "看这张图") is None


def test_vlm_ask_non200_returns_none(tmp_path, monkeypatch):
    img = _make_img(tmp_path)
    monkeypatch.setattr(al, "_post_json", lambda url, payload, timeout: _FakeResp(404))
    assert al.vlm_ask(img, "看这张图") is None


def test_vlm_ask_clean_whitespace(tmp_path, monkeypatch):
    img = _make_img(tmp_path)
    monkeypatch.setattr(al, "_post_json",
                        lambda url, payload, timeout: _FakeResp(
                            data={"response": "  这是一个  \n\n  记事本窗口  "}))
    out = al.vlm_ask(img, "这是什么窗口？")
    assert out == "这是一个 记事本窗口"


def test_vlm_ask_empty_response_returns_none(tmp_path, monkeypatch):
    img = _make_img(tmp_path)
    monkeypatch.setattr(al, "_post_json", lambda url, payload, timeout: _FakeResp(data={}))
    assert al.vlm_ask(img, "看这张图") is None


def test_vlm_ask_payload_options_low_temp(tmp_path, monkeypatch):
    """纪律：低温采样 + 图片 base64 + 限长——与 screen_describe 同口径。"""
    img = _make_img(tmp_path)
    captured = {}

    def fake(url, payload, timeout):
        captured["url"] = url
        captured["payload"] = payload
        return _FakeResp(data={"response": "是"})

    monkeypatch.setattr(al, "_post_json", fake)
    out = al.vlm_ask(img, "这是记事本吗？", model="gemma3:4b")
    assert out == "是"
    assert "/api/generate" in captured["url"]
    p = captured["payload"]
    assert p["model"] == "gemma3:4b"
    assert p["stream"] is False
    assert p["options"]["temperature"] == 0.2
    assert p["options"]["top_p"] == 0.9
    assert p["options"]["num_predict"] <= 200
    assert p["images"] and isinstance(p["images"][0], str)     # base64
    assert "无法确认" in p["prompt"]                            # 防编造纪律注入


def test_vlm_ask_default_model_from_config(tmp_path, monkeypatch):
    """model=None 时取 app.config.VLM_MODEL（默认 gemma3:4b）。"""
    img = _make_img(tmp_path)
    captured = {}

    def fake(url, payload, timeout):
        captured["model"] = payload["model"]
        return _FakeResp(data={"response": "结论"})

    monkeypatch.setattr(al, "_post_json", fake)
    assert al.vlm_ask(img, "看这张图") == "结论"
    assert captured["model"]  # 非空即通过（由 config/env 解析而来）


# ---------- vlm_judge ----------

def test_vlm_judge_unavailable_when_ask_none(tmp_path, monkeypatch):
    monkeypatch.setattr(al, "vlm_ask", lambda *a, **k: None)
    j = al.vlm_judge(_make_img(tmp_path), "看这张图", must_contain="记事本")
    assert j == {"available": False, "verdict": None, "passed": False}


def test_vlm_judge_hit_keyword(monkeypatch):
    monkeypatch.setattr(al, "vlm_ask", lambda *a, **k: "这是一个记事本窗口")
    j = al.vlm_judge("img.png", "这是什么窗口？", must_contain="记事本")
    assert j["available"] is True
    assert j["passed"] is True
    assert j["verdict"] == "这是一个记事本窗口"


def test_vlm_judge_miss_keyword_still_available(monkeypatch):
    monkeypatch.setattr(al, "vlm_ask", lambda *a, **k: "看不清内容")
    j = al.vlm_judge("img.png", "这是什么窗口？", must_contain="微信")
    assert j["available"] is True
    assert j["passed"] is False


def test_vlm_judge_case_insensitive(monkeypatch):
    monkeypatch.setattr(al, "vlm_ask", lambda *a, **k: "This is NOTEPAD window")
    j = al.vlm_judge("img.png", "what window", must_contain="notepad")
    assert j["passed"] is True


def test_vlm_judge_empty_must_contain_never_passes(monkeypatch):
    monkeypatch.setattr(al, "vlm_ask", lambda *a, **k: "记事本窗口")
    j = al.vlm_judge("img.png", "看这张图", must_contain="")
    assert j["available"] is True
    assert j["passed"] is False
