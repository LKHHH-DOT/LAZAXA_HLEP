# -*- coding: utf-8 -*-
"""Obsidian 工具单元测试（app/agent/tools/obsidian.py）。

不依赖真实 Obsidian：覆盖工具注册/风险分级、vault 路径规范化、
插件配置读取（缺文件返回 None）、未装插件的友好错误。
"""
import json

from app.agent.registry import registry
from app.agent import permissions as p
from app.agent.tools import obsidian as ob


# ---------- 工具注册与风险分级 ----------

def test_obsidian_tools_registered():
    for name in ("obsidian_list", "obsidian_read", "obsidian_write",
                 "obsidian_append", "obsidian_search", "obsidian_delete"):
        assert registry.get(name) is not None, name


def test_obsidian_risk_levels():
    """读/搜/列 safe；写/追加 sensitive；删 dangerous。"""
    assert registry.get("obsidian_list").risk == "safe"
    assert registry.get("obsidian_read").risk == "safe"
    assert registry.get("obsidian_search").risk == "safe"
    assert registry.get("obsidian_write").risk == "sensitive"
    assert registry.get("obsidian_append").risk == "sensitive"
    assert registry.get("obsidian_delete").risk == "dangerous"


def test_obsidian_delete_ask_all_modes():
    """删笔记不可逆 → 任何非锁定模式都 ask（删文件要通过）。"""
    for mode in ("standard", "relaxed"):
        d, _ = p.decide(mode, "dangerous", "obsidian_delete", {"note": "x.md"})
        assert d == p.DECISION_ASK, mode


def test_obsidian_write_relaxed_allow():
    d, _ = p.decide("relaxed", "sensitive", "obsidian_write", {"note": "x.md"})
    assert d == p.DECISION_ALLOW


def test_obsidian_read_safe_allow():
    d, _ = p.decide("relaxed", "safe", "obsidian_read", {"note": "x.md"})
    assert d == p.DECISION_ALLOW


def test_obsidian_tools_deny_locked():
    """锁定模式：obsidian 工具不在白名单 → deny。"""
    d, _ = p.decide("locked", "safe", "obsidian_read", {"note": "x.md"})
    assert d == p.DECISION_DENY


# ---------- vault 路径规范化 ----------

def test_vault_path_adds_md():
    # URL 编码后的相对路径（HTTP 传输需要，服务器自动解码）
    import urllib.parse
    assert ob._vault_path("日记/2026-08-16") == urllib.parse.quote("日记/2026-08-16") + ".md"


def test_vault_path_strips_slashes():
    assert ob._vault_path("/项目/周报.md/") == ob._vault_path("项目/周报.md")


def test_vault_path_quotes_spaces():
    assert ob._vault_path("my note") == "my%20note.md"


def test_vault_path_empty():
    assert ob._vault_path("   ") == ""


# ---------- 插件配置读取 ----------

def test_plugin_config_missing_returns_none(monkeypatch, tmp_path):
    monkeypatch.setattr(ob.config, "OBSIDIAN_PLUGIN_DATA",
                        str(tmp_path / "no_such" / "data.json"))
    assert ob._plugin_config() is None


def test_plugin_config_reads_key_and_port(monkeypatch, tmp_path):
    cfg = tmp_path / "data.json"
    cfg.write_text(json.dumps({"apiKey": "secret123", "port": 27777}),
                   encoding="utf-8")
    monkeypatch.setattr(ob.config, "OBSIDIAN_PLUGIN_DATA", str(cfg))
    got = ob._plugin_config()
    assert got["apiKey"] == "secret123"
    assert got["port"] == 27777


def test_list_without_plugin_returns_friendly_error(monkeypatch, tmp_path):
    monkeypatch.setattr(ob.config, "OBSIDIAN_PLUGIN_DATA",
                        str(tmp_path / "no_such" / "data.json"))
    res = ob._obsidian_list()
    assert not res.ok
    assert "Local REST API" in res.error
