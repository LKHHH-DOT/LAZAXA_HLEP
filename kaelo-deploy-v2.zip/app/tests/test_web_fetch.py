# -*- coding: utf-8 -*-
"""注入防御版 web_fetch 测试（C批2 · app/agent/tools/web.py）。

覆盖：HTML→Markdown 净化（剥 script/style/整段容器）、隐藏文本剥离
（hidden/aria-hidden/display:none/visibility/opacity:0/font-size:0/负缩进，
并验证 opacity:0.5 这类可见半透明不被误伤）、实体解码、标题提取；
fetch 层：非 HTML 拒绝、超长截断、注册与 risk。
"""
from app.agent.registry import ToolRegistry
from app.agent.tools import web
from app.agent.tools.web import (_decode_body, fetch_page_text, html_to_markdown,
                                 register_all)

# ---------- 净化核心 ----------

_HTML = """<html><head><title>示例页</title></head><body>
<p>正文第一段。</p>
<div style="display:none">display:none 藏字别出</div>
<div hidden>hidden 藏字别出</div>
<div aria-hidden="true">aria 藏字别出</div>
<span style="font-size:0">字号0藏字</span>
<p style="text-indent:-9999px">负缩进藏字</p>
<script>alert('xss')</script>
<style>.x{color:red}</style>
<h2>小节标题</h2>
<ul><li>条目一</li><li>条目二</li></ul>
<p>结束 &amp; 语</p>
</body></html>"""


def test_strips_scripts_styles_and_hidden_text():
    title, md = html_to_markdown(_HTML)
    assert title == "示例页"
    assert "正文第一段" in md
    assert "小节标题" in md and "## 小节标题" in md
    assert "- 条目一" in md and "- 条目二" in md
    assert "结束 & 语" in md          # &amp; 已解码
    # 全部藏字/脚本/样式都不该进入正文
    for bad in ("藏字", "xss", "color:red", "display:none"):
        assert bad not in md, f"藏字未剥离: {bad!r}"
    # 净化后不应残留任何 HTML 标签
    assert "<" not in md and ">" not in md


def test_opacity_half_visible_not_stripped():
    html = ('<p style="opacity:0.5">半透明可见文字</p>'
            '<p style="opacity: 0;">完全透明藏字</p>')
    _, md = html_to_markdown(html)
    assert "半透明可见文字" in md
    assert "完全透明藏字" not in md


def test_nested_script_inside_body_removed():
    html = "<p>可见</p><div><script>var s='x'</script><p>内层可见</p></div>"
    _, md = html_to_markdown(html)
    assert "var s" not in md
    assert "可见" in md and "内层可见" in md


def test_garbage_and_empty_html():
    assert html_to_markdown("") == ("", "")
    assert html_to_markdown("纯文本没有标签")[1].replace(" ", "") == "纯文本没有标签"


def test_code_block_keeps_newlines():
    html = "<pre>line1\nline2\n</pre><p>后文</p>"
    _, md = html_to_markdown(html)
    assert "line1\nline2" in md


# ---------- 解码 ----------

def test_decode_body_respects_meta_charset():
    # 服务器头误标 ISO-8859-1，但页面 <meta> 声明 utf-8
    content = '<meta charset="utf-8"><p>中文内容</p>'.encode("utf-8")
    out = _decode_body(content, "ISO-8859-1", "text/html")
    assert "中文内容" in out


def test_decode_body_uses_header_charset():
    content = "héllo".encode("latin-1")
    out = _decode_body(content, None, "text/html; charset=iso-8859-1")
    assert out == "héllo"


# ---------- fetch 层 ----------

class _Resp:
    def __init__(self, content, ctype="text/html", encoding=None):
        self.content = content
        self.headers = {"Content-Type": ctype}
        self.encoding = encoding


def test_fetch_page_text_non_html_rejected(monkeypatch):
    monkeypatch.setattr(web, "_http_get", lambda url, timeout=15: _Resp(
        b'{"a":1}', ctype="application/json"))
    title, err = fetch_page_text("https://example.com/api")
    assert title is None and "不是可解析的 HTML" in err


def test_fetch_page_text_invalid_url():
    title, err = fetch_page_text("ftp://x")
    assert title is None and "http://" in err


def test_fetch_page_text_truncates_long(monkeypatch):
    body = ("<p>%s</p>" % ("长" * 9000)).encode("utf-8")
    monkeypatch.setattr(web, "_http_get", lambda url, timeout=15: _Resp(body))
    title, md = fetch_page_text("https://example.com", max_chars=2000)
    assert title == ""
    assert md and "已截断" in md and len(md) <= 2600


def test_tool_registered_safe():
    reg = ToolRegistry()
    register_all(reg)
    tool = reg.get("web_fetch")
    assert tool is not None
    assert tool.risk == "safe"
    schemas = {s["function"]["name"] for s in reg.openai_schemas()}
    assert "web_fetch" in schemas
