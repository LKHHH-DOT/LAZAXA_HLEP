# -*- coding: utf-8 -*-
"""GUI 视觉工具测试（视觉升级方案阶段 1）。

覆盖：行动-观察闭环差异引擎（_diff_blocks）、验证快照开关（_verify_before）、
新工具注册（ui_list / ui_find）。真实桌面窗口/截图的交互行为不做单测（环境依赖）。
"""
from PIL import Image, ImageDraw

from app import config
from app.agent import permissions as p
from app.agent.registry import ToolRegistry
from app.agent.tools import gui


def _solid(size, color=(255, 255, 255)):
    return Image.new("RGB", size, color)


# ---------- 行动-观察闭环：差异引擎 ----------

def test_diff_blocks_detects_change():
    # 在 (100,100)~(300,200) 画黑块，应被网格分块检出并给出并集 bbox
    before = _solid((800, 600))
    after = _solid((800, 600))
    ImageDraw.Draw(after).rectangle([100, 100, 299, 199], fill=(0, 0, 0))
    res = gui._diff_blocks(before, after, grid=(8, 8))
    assert res is not None
    bbox, n = res
    assert n >= 1
    assert bbox[0] <= 100 and bbox[1] <= 100
    assert bbox[0] + bbox[2] >= 300 and bbox[1] + bbox[3] >= 200


def test_diff_blocks_no_change():
    before = _solid((800, 600))
    after = _solid((800, 600))
    assert gui._diff_blocks(before, after) is None


def test_diff_blocks_size_mismatch_resized():
    # 前后分辨率不一致时自动对齐（防止截图尺寸抖动导致误报）
    before = _solid((800, 600))
    after = _solid((1600, 1200))
    ImageDraw.Draw(after).rectangle([200, 200, 599, 399], fill=(0, 0, 0))
    res = gui._diff_blocks(before, after, grid=(8, 8))
    assert res is not None
    bbox, _ = res
    assert bbox[0] <= 200 and bbox[1] <= 200
    assert bbox[0] + bbox[2] >= 300 and bbox[1] + bbox[3] >= 200


def test_verify_before_disabled(tmp_path, monkeypatch):
    # 总开关关闭时不做操作前快照（返回空串，闭环静默关闭）
    monkeypatch.setattr(config, "UI_VERIFY_ENABLED", False)
    assert gui._verify_before(None) == ""


# ---------- 新工具注册 ----------

def _fresh_registry():
    r = ToolRegistry()
    from app.agent.tools import register_all
    register_all(r)
    return r


def test_ui_tools_registered():
    r = _fresh_registry()
    names = r.names()
    assert "ui_list" in names and "ui_find" in names


def test_ui_tools_risk_safe():
    # 只读工具必须 safe 自动执行（不弹审批），对齐 screen_analyze
    r = _fresh_registry()
    assert r.get("ui_list").risk == "safe"
    assert r.get("ui_find").risk == "safe"


# ---------- 语义层：screen_describe（本地 VLM） ----------

def test_screen_describe_registered():
    r = _fresh_registry()
    assert "screen_describe" in r.names()
    assert r.get("screen_describe").risk == "safe"
    assert r.get("screen_describe").timeout >= 120  # VLM 推理耗时长，超时要给足


def test_screen_describe_vlm_missing(monkeypatch):
    # VLM 不可用（Ollama 未运行/模型未拉取）→ 明确错误提示，不崩溃
    monkeypatch.setattr(gui, "_vlm_available", lambda: "本地视觉模型 gemma3:4b 不可用")
    res = gui._screen_describe()
    assert not res.ok and "视觉模型" in res.error


# ---------- VLM 输出稳定性加固（2026-09-04，小模型乱输出调研） ----------

def test_clean_vlm_output_strips_fences_and_whitespace():
    # 去 Markdown 代码围栏 + 压多余空行/行尾空格（主模型直接可用的纯净文本）
    raw = ("```json\n好的，根据截图：\n  目标窗口在最上层。\n\n\n"
           "没有报错。\n```\n")
    out = gui._clean_vlm_output(raw)
    assert "```" not in out and "json" not in out
    assert "\n\n" not in out and "\n\n\n" not in out
    assert out.strip() == out
    assert "目标窗口在最上层" in out


def test_clean_vlm_output_truncates_long():
    # 限长截断（防止小 VLM 分点废话/英文冗长撑爆主模型上下文）
    out = gui._clean_vlm_output("很" * 2000, max_len=100)
    assert len(out) <= 101 and out.endswith("…")


def test_clean_vlm_output_empty():
    assert gui._clean_vlm_output("") == ""
    assert gui._clean_vlm_output(None) == ""


def test_verify_after_vlm_judge_flag_off(tmp_path, monkeypatch):
    # 显式关闭 UI_VERIFY_VLM（默认开，此处关掉验证开关分支）：闭环只回传差异摘要，不调用 VLM（不额外耗时）
    monkeypatch.setattr(config, "UI_VERIFY_VLM", False)
    monkeypatch.setattr(config, "UI_VERIFY_WAIT_MS", 0)
    before = _solid((800, 600))
    before_path = str(tmp_path / "before.png")
    before.save(before_path)
    calls = {"n": 0}

    def _fake_describe(img, q):
        calls["n"] += 1
        return "fake judge"
    monkeypatch.setattr(gui, "_vlm_describe_image", _fake_describe)
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: type("PG", (), {})())
    monkeypatch.setattr(gui, "_grab_screen",
                        lambda pg, region=None: _solid((800, 600)))
    monkeypatch.setattr(gui, "_save_screenshot", lambda img: str(tmp_path / "after.png"))
    import json as _json
    out = _json.loads(gui._verify_after(before_path, "点击"))
    assert calls["n"] == 0  # 未调用 VLM
    assert "judge" not in out


def test_ui_find_missing_params():
    # 缺 text 和 control_type → 明确错误提示（不裸抛）
    res = gui._ui_find(text="", control_type="")
    assert not res.ok and "text" in res.error


# ---------- 权限：UI 工具不受工作区限制（只读、不落文件） ----------

def test_ui_list_perm_safe_allow():
    # ui_list 不操作文件、只读屏幕 → relaxed/standard 均自动放行
    d, r = p.decide("standard", "safe", "ui_list", {"window_title": "记事本"})
    assert d == p.DECISION_ALLOW and r == "standard:safe"


# ---------- 阶段 3：模板匹配 / 宏序列 / 连续监测 ----------

class _FakePG:
    """最小化 pyautogui 替身（只实现被测路径用到的方法）。"""

    def __init__(self):
        self.calls = []
        self._boxes = []

    def locateAllOnScreen(self, image, region=None, **kw):
        self.calls.append(("locateAllOnScreen", image, region, kw))
        return list(self._boxes)

    def click(self, *a, **kw):
        self.calls.append(("click", a, kw))

    def typewrite(self, text, **kw):
        self.calls.append(("typewrite", text, kw))

    def press(self, key):
        self.calls.append(("press", key))

    def hotkey(self, *keys):
        self.calls.append(("hotkey", keys))


def test_find_image_missing_params():
    # 缺 image → 明确错误
    res = gui._find_image_on_screen(image="")
    assert not res.ok and "image" in res.error


def test_find_image_template_missing(monkeypatch):
    # 模板文件不存在 → 明确错误（不崩溃、不截图）
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: _FakePG())
    res = gui._find_image_on_screen(image=r"D:\no_such_template.png")
    assert not res.ok and "模板图片不存在" in res.error


def test_find_image_no_match(monkeypatch, tmp_path):
    # 模板存在但屏幕上找不到 → found=false 提示，不报错
    tpl = tmp_path / "tpl.png"
    Image.new("RGB", (20, 20), (10, 10, 10)).save(tpl)
    fake = _FakePG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: fake)
    res = gui._find_image_on_screen(image=str(tpl))
    assert res.ok
    import json
    out = json.loads(res.text)
    assert out["found"] is False


def test_action_sequence_validation():
    # 空序列 / 未知动作类型 → 明确错误
    res = gui._run_action_sequence(actions=[])
    assert not res.ok and "actions" in res.error
    res = gui._run_action_sequence(actions=[{"type": "fly"}])
    assert not res.ok and "未知类型" in res.error


def test_action_sequence_hotkey_blacklist():
    # 黑名单快捷键（win+l 锁屏）在任何序列里都必须被拒绝
    res = gui._run_action_sequence(actions=[{"type": "wait", "duration": 0},
                                            {"type": "hotkey", "keys": ["win", "l"]}])
    assert not res.ok and "黑名单" in res.error


def test_action_sequence_executes(monkeypatch):
    # 正常序列按顺序执行：click + type_text + wait（verify 关闭免截图）
    import time as _t
    fake = _FakePG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: fake)
    monkeypatch.setattr(gui, "_verify_before", lambda pg: "")
    monkeypatch.setattr(gui, "_set_clipboard_text", lambda t: None)
    monkeypatch.setattr(_t, "sleep", lambda s: None)
    res = gui._run_action_sequence(actions=[
        {"type": "click", "x": 10, "y": 20},
        {"type": "type_text", "text": "hello"},
        {"type": "wait", "duration": 0},
    ], verify=False)
    assert res.ok
    import json
    out = json.loads(res.text)
    assert len(out["executed"]) == 3
    assert fake.calls[0][0] == "click" and fake.calls[0][1][:2] == (10, 20)


def test_action_sequence_missing_param():
    # click 缺 x/y → 明确错误（KeyError 转错误提示）
    res = gui._run_action_sequence(actions=[{"type": "click", "x": 1}])
    assert not res.ok and "缺少参数" in res.error


def test_wait_for_change_timeout(monkeypatch):
    # 屏幕始终无变化 → 超时返回 changed=false（不报错）
    import time as _t
    fake = _FakePG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: fake)
    monkeypatch.setattr(gui, "_grab_screen",
                        lambda pg, region=None: _solid((200, 200)))
    monkeypatch.setattr(_t, "sleep", lambda s: None)
    res = gui._wait_for_change(timeout=0.2, interval=0.2)
    assert res.ok
    import json
    out = json.loads(res.text)
    assert out["changed"] is False


def test_wait_for_change_detects(monkeypatch, tmp_path):
    # 第二次截图出现变化 → changed=true 且给出变化中心
    import time as _t
    shots = [iter([_solid((200, 200)),          # 基线（第一次截图）
                   _solid((200, 200), color=(0, 0, 0)),  # 变化（第二次截图）
                   _solid((200, 200), color=(0, 0, 0))])]  # 保存变化快照（第三次）
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: _FakePG())
    monkeypatch.setattr(_t, "sleep", lambda s: None)

    def _grab(pg, region=None):
        return next(shots[0])
    monkeypatch.setattr(gui, "_grab_screen", _grab)
    monkeypatch.setattr(gui, "_save_screenshot",
                        lambda img: str(tmp_path / "after.png"))
    res = gui._wait_for_change(timeout=0.2, interval=0.2)
    assert res.ok
    import json
    out = json.loads(res.text)
    assert out["changed"] is True and "center" in out


def test_phase3_tools_registered_and_risk():
    r = _fresh_registry()
    assert "find_image_on_screen" in r.names()
    assert "run_action_sequence" in r.names()
    assert "wait_for_change" in r.names()
    assert r.get("find_image_on_screen").risk == "safe"
    assert r.get("wait_for_change").risk == "safe"
    assert r.get("run_action_sequence").risk == "sensitive"
    assert r.get("run_action_sequence").timeout >= 60


# ---------- 另存为对话框保存原语（P3 真屏验收第五版沉淀） ----------

def test_save_dialog_registered_and_risk():
    # 已注册为 sensitive：写操作（保存文件到指定路径）需人工确认
    r = _fresh_registry()
    assert "save_dialog" in r.names()
    t = r.get("save_dialog")
    assert t.risk == "sensitive"
    assert t.timeout >= 30
    props = t.to_openai_schema()["function"]["parameters"]["properties"]
    assert "path" in props and "window_title" in props
    assert t.to_openai_schema()["function"]["parameters"]["required"] == ["path"]


def test_save_dialog_missing_path():
    # 缺 path → 明确错误（不碰真实 GUI）
    from app.agent.tools.gui_dialogs import _save_dialog
    res = _save_dialog(path="")
    assert not res.ok and "path" in res.error


def test_save_dialog_path_needs_dir_and_name():
    # 只给文件名没有目录 → 拒绝（必须完整路径）
    from app.agent.tools.gui_dialogs import _save_dialog
    res = _save_dialog(path="onlyfilename.txt")
    assert not res.ok and "完整路径" in res.error


# ---------- computer_use 契约对标（2026-09-29 · P0/P1） ----------
# 稳定元素引用 element_id / 结构化动作原语 / 增量观察 / list_apps。
# 全部用替身，不碰真实桌面（环境依赖）。

class _FakeRect:
    def __init__(self, l, t, r, b):
        self.left, self.top, self.right, self.bottom = l, t, r, b


class _FakeInfo:
    def __init__(self, ctype, auto_id):
        self.control_type = ctype
        self.automation_id = auto_id


class _FakeEl:
    """pywinauto 控件替身：只实现 _ui_collect_nodes/_ui_depth 用到的接口。"""

    def __init__(self, ctype, name, auto_id="", rect=(0, 0, 10, 10),
                 parent=None, handle=0):
        self.element_info = _FakeInfo(ctype, auto_id)
        self._name = name
        self._rect = rect
        self._parent = parent
        self.handle = handle

    def window_text(self):
        return self._name

    def rectangle(self):
        return _FakeRect(*self._rect)

    def parent(self):
        return self._parent


class _FakeWin:
    def __init__(self, els, handle=100):
        self._els = els
        self.handle = handle

    def wait(self, *a, **kw):
        pass

    def descendants(self):
        return list(self._els)


class _FakeDesktop:
    def __init__(self, win):
        self._win = win

    def window(self, handle=None):
        return self._win


def _fake_uia_env(monkeypatch, els, handle=100):
    win = _FakeWin(els, handle)
    monkeypatch.setattr(gui, "_ui_available", lambda: "")
    monkeypatch.setattr(gui, "_uia", _FakeDesktop(win))
    monkeypatch.setattr(gui, "_foreground_hwnd", lambda: handle)
    return win


def test_ui_collect_nodes_stable_ids(monkeypatch):
    # AutomationId 优先；缺失退化「类型:名称#序号」（同名递增）；
    # 同 AutomationId 重复 → 追加 ' 去重。id 必须跨轮稳定（增量/引用都靠它）。
    els = [
        _FakeEl("Button", "确定", auto_id="btnOk", rect=(10, 10, 60, 40)),
        _FakeEl("Edit", "姓名", rect=(10, 50, 110, 80)),
        _FakeEl("Edit", "姓名", rect=(10, 90, 110, 120)),
        _FakeEl("Button", "复制", auto_id="btnOk", rect=(70, 10, 120, 40)),
    ]
    _fake_uia_env(monkeypatch, els)
    items, hwnd = gui._ui_collect_nodes()
    assert hwnd == 100
    ids = [it["id"] for it in items]
    assert ids == ["Button:btnOk", "Edit:姓名#0", "Edit:姓名#1", "Button:btnOk'"]
    assert items[0]["center"] == [35, 25]


def test_ui_collect_nodes_max_depths(monkeypatch):
    # max_depths 限深：深一层的控件被过滤（自绘深层树收窄输出）
    mid = _FakeEl("Custom", "容器", handle=500)
    deep = _FakeEl("Button", "深层按钮", auto_id="deep", parent=mid, handle=501)
    els = [_FakeEl("Button", "浅层", auto_id="top"), deep]
    _fake_uia_env(monkeypatch, els)
    full, _ = gui._ui_collect_nodes()
    assert {it["id"] for it in full} == {"Button:top", "Button:deep"}
    assert "depth" not in full[1]        # 未限深时不带 depth（省输出）
    limited, _ = gui._ui_collect_nodes(max_depths=0)
    assert [it["id"] for it in limited] == ["Button:top"]
    kept, _ = gui._ui_collect_nodes(max_depths=1)
    assert [it["id"] for it in kept] == ["Button:top", "Button:deep"]
    assert kept[1]["depth"] == 1


def test_ui_collect_nodes_max_items_semantics(monkeypatch):
    # None=配置上限（给模型看的输出限长）；0=不限（ui_find / element_id 解析用）
    from app import config as _c
    els = [_FakeEl("Button", f"按钮{i}", auto_id=f"b{i}") for i in range(5)]
    _fake_uia_env(monkeypatch, els)
    monkeypatch.setattr(_c, "UI_LIST_MAX_ITEMS", 2)
    assert len(gui._ui_collect_nodes()[0]) == 2
    assert len(gui._ui_collect_nodes(max_items=3)[0]) == 3
    assert len(gui._ui_collect_nodes(max_items=0)[0]) == 5


def test_ui_find_and_resolve_beyond_list_cap(monkeypatch):
    # 回归护栏：控件排在第 N 个（超出 UI_LIST_MAX_ITEMS）也必须能找到/定向，
    # 否则 element_id 定向会误报"已失效"
    import json
    from app import config as _c
    els = [_FakeEl("Button", f"按钮{i}", auto_id=f"b{i}", rect=(0, i, 10, i + 10))
           for i in range(70)]
    _fake_uia_env(monkeypatch, els)
    monkeypatch.setattr(_c, "UI_LIST_MAX_ITEMS", 10)
    res = gui._ui_find(text="按钮69")
    assert res.ok and json.loads(res.text)["id"] == "Button:b69"
    it, _el = gui._ui_resolve_node("Button:b69")
    assert it["name"] == "按钮69" and it["center"] == [5, 74]


def _pub_item(eid, name="控件", x=0, y=0):
    return {"id": eid, "type": "Button", "name": name,
            "x": x, "y": y, "width": 10, "height": 10,
            "center": [x + 5, y + 5], "_el": None}


def test_ui_list_first_full_then_diff(monkeypatch):
    # 首次观察一律全量（让模型先看清结构）；未变回 changed=false；有变只回增量。
    import json
    monkeypatch.setattr(gui, "_ui_tree_cache", {})
    cur = {"items": [_pub_item("Button:ok", "确定"), _pub_item("Edit:name", "姓名")]}
    monkeypatch.setattr(gui, "_ui_collect_nodes",
                        lambda wt="", mi=0, md=None: (cur["items"], 100))

    first = json.loads(gui._ui_list().text)
    assert first["full"] is True and first["count"] == 2

    same = json.loads(gui._ui_list().text)
    assert same["changed"] is False and "无变化" in same["summary"]

    cur["items"] = [_pub_item("Button:ok", "确定"),
                    _pub_item("Edit:name", "姓名", x=99)]
    diff = json.loads(gui._ui_list().text)
    assert diff["changed"] is True and diff["changed_count"] == 1
    assert diff["items"][0]["id"] == "Edit:name" and "移除" in diff["summary"]

    removed = json.loads(gui._ui_list().text)
    assert removed["changed"] is False  # 变化已入库，再观察又是无变化


def test_ui_list_disable_diff_and_max_depths_passthrough(monkeypatch):
    # disable_diff=true 强制全量；max_depths 透传给 _ui_collect_nodes
    import json
    monkeypatch.setattr(gui, "_ui_tree_cache", {})
    seen = {}

    def _collect(wt="", mi=0, md=None):
        seen["md"] = md
        return [_pub_item("Button:ok", "确定")], 100

    monkeypatch.setattr(gui, "_ui_collect_nodes", _collect)
    gui._ui_list()                       # 首次全量
    out = json.loads(gui._ui_list(disable_diff=True, max_depths=3).text)
    assert out["full"] is True and out["changed"] is True
    assert seen["md"] == 3


def test_ui_list_no_items(monkeypatch):
    # 窗口读不到可交互控件 → 明确错误并指向 OCR 兜底路径
    monkeypatch.setattr(gui, "_ui_collect_nodes", lambda wt="", mi=0, md=None: ([], 100))
    res = gui._ui_list(window_title="记事本")
    assert not res.ok and "screen_analyze" in res.error


def test_ui_resolve_node_missing_and_stale(monkeypatch):
    # 缺 element_id / 引用失效 → 明确报错（要求重新观察，绝不猜坐标硬点）
    import pytest
    with pytest.raises(RuntimeError) as e1:
        gui._ui_resolve_node("")
    assert "缺少 element_id" in str(e1.value)
    monkeypatch.setattr(gui, "_ui_collect_nodes",
                        lambda wt="", mi=0, md=None: ([_pub_item("Button:ok")], 100))
    with pytest.raises(RuntimeError) as e2:
        gui._ui_resolve_node("Button:gone")
    assert "已失效" in str(e2.value) and "重新调用 ui_list" in str(e2.value)


def test_mouse_click_element_id_prefers_ref(monkeypatch):
    # element_id 优先于坐标：点击落在控件中心，回传 element_id
    import json

    class _PG:
        def __init__(self):
            self.clicks = []

        def size(self):
            return (1920, 1080)

        def click(self, **kw):
            self.clicks.append(kw)

    pg = _PG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: pg)
    monkeypatch.setattr(gui, "_verify_before", lambda _pg: "")
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "type": "Button",
                                             "name": "确定", "center": [35, 25]}, None))
    res = gui._mouse_click(element_id="Button:ok", x=1, y=1)
    assert res.ok
    out = json.loads(res.text)
    assert out["clicked"] == [35, 25] and out["element_id"] == "Button:ok"
    assert pg.clicks[0]["x"] == 35 and pg.clicks[0]["y"] == 25


def test_mouse_click_needs_target(monkeypatch):
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: object())
    res = gui._mouse_click()
    assert not res.ok and "element_id" in res.error


def test_scroll_direction_and_pages(monkeypatch):
    # 方向白名单 + pages 换算滚轮刻度；down 在 pyautogui 里是负值
    import json

    class _PG:
        def __init__(self):
            self.calls = []

        def scroll(self, clicks, **kw):
            self.calls.append(("scroll", clicks, kw))

        def hscroll(self, clicks, **kw):
            self.calls.append(("hscroll", clicks, kw))

    pg = _PG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: pg)
    monkeypatch.setattr(gui, "_verify_before", lambda _pg: "")
    bad = gui._scroll(direction="sideways")
    assert not bad.ok and "up/down/left/right" in bad.error
    res = gui._scroll(direction="down", pages=2, x=5, y=6)
    assert res.ok and json.loads(res.text)["pages"] == 2
    assert pg.calls[-1][0] == "scroll"
    assert pg.calls[-1][1] == -gui._SCROLL_CLICKS_PER_PAGE * 2
    assert pg.calls[-1][2] == {"x": 5, "y": 6}


def test_drag_param_validation(monkeypatch):
    # 缺任一坐标 → 明确错误；越界 → 拒绝（防止拖到屏幕外触发 fail-safe）
    res = gui._drag(fromX=1, fromY=2, toX=3)
    assert not res.ok and "fromX/fromY/toX/toY" in res.error

    class _PG:
        def size(self):
            return (100, 100)

    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: _PG())
    res = gui._drag(fromX=1, fromY=2, toX=3, toY=500)
    assert not res.ok and "超出屏幕范围" in res.error


def test_set_value_writes_via_pattern(monkeypatch):
    # ValuePattern 可用 → 直接写值（多行原样写入，不经键盘）
    import json

    class _Iface:
        def __init__(self):
            self.vals = []

        def SetValue(self, v):
            self.vals.append(v)

    iface = _Iface()
    el = type("El", (), {"iface_value": iface})()
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "name": "备注", "type": "Edit"}, el))
    res = gui._set_value(element_id="Edit:remark", value="第一行\n第二行")
    assert res.ok and iface.vals == ["第一行\n第二行"]
    assert json.loads(res.text)["chars"] == 7

    missing = gui._set_value(element_id="")
    assert not missing.ok and "element_id" in missing.error


def test_set_value_no_value_pattern(monkeypatch):
    # 控件不支持 ValuePattern → 明确报错并指向 keyboard_type
    el = type("El", (), {})()          # 无 iface_value
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "name": "列表", "type": "List"}, el))
    res = gui._set_value(element_id="List:1", value="x")
    assert not res.ok and "ValuePattern" in res.error and "keyboard_type" in res.error


def test_perform_action_only_exposed_patterns(monkeypatch):
    # 只用控件实际暴露的模式：不支持的动作要报错并列出可用动作
    import json

    class _Iface:
        def __init__(self):
            self.n = 0

        def Invoke(self):
            self.n += 1

    iface = _Iface()
    el = type("El", (), {"iface_invoke": iface})()
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "name": "确定", "type": "Button"}, el))

    unknown = gui._perform_action(element_id="Button:ok", action="fly")
    assert not unknown.ok and "未知动作" in unknown.error

    unsupported = gui._perform_action(element_id="Button:ok", action="toggle")
    assert not unsupported.ok and "不支持动作" in unsupported.error
    assert "invoke" in unsupported.error          # 列出实际可用动作

    res = gui._perform_action(element_id="Button:ok", action="invoke")
    assert res.ok and iface.n == 1
    assert json.loads(res.text)["action"] == "invoke"

    missing = gui._perform_action(element_id="")
    assert not missing.ok and "element_id" in missing.error


def test_ui_action_patterns_match_pywinauto_api():
    # 回归护栏：_UI_ACTION_IMPL 里的模式名必须是 pywinauto UIAWrapper 真实属性
    # （曾用 el.toggle()/el.scroll_into_view() —— 这两个方法在包装器上并不存在）
    import pytest
    uiawrapper = pytest.importorskip("pywinauto.controls.uiawrapper")
    for act, (pattern, _runner) in gui._UI_ACTION_IMPL.items():
        if not pattern:
            continue
        assert hasattr(uiawrapper.UIAWrapper, f"iface_{pattern}"), \
            f"动作 {act} 引用了不存在的模式 iface_{pattern}"


# ---------- select_text 原语（Trae 契约对标 · 文本定位选择） ----------

class _SelTextRange:
    """IUIAutomationTextRange 替身：记录端点移动与选中区间。"""

    def __init__(self, doc, start, length):
        self._doc = doc
        self.start = start
        self.end = start + length

    def MoveEndpointByUnit(self, endpoint, unit, count):
        assert unit == gui._TEXT_UNIT_CHARACTER
        if endpoint == gui._TEXT_ENDPOINT_START:
            self.start += count
        else:
            self.end += count
        return abs(count)

    def Select(self):
        self._doc.selected = (self.start, self.end)


class _SelTextDoc:
    """DocumentRange 替身：FindText 返回覆盖匹配串的范围（对齐 UIA 实际语义）。"""

    def __init__(self, content):
        self.content = content
        self.selected = None
        self.finds = []

    def FindText(self, needle, backward, ignoreCase):
        self.finds.append(needle)
        idx = self.content.find(needle)
        if idx < 0:
            return None
        return _SelTextRange(self, idx, len(needle))


def _bind_text_el(monkeypatch, content, name="编辑框"):
    """把 _ui_resolve_node 绑到一个带 TextPattern 的替身控件上，返回其 DocumentRange。"""
    tp = type("TP", (), {"DocumentRange": _SelTextDoc(content)})()
    el = type("El", (), {"iface_text": tp})()
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "name": name, "type": "Edit"}, el))
    return tp.DocumentRange


def test_select_text_selects_matched_range(monkeypatch):
    # 默认 selection=text → 选中匹配到的整段文本
    import json
    doc = _bind_text_el(monkeypatch, "hello world")
    res = gui._select_text(element_id="Edit:box", text="world")
    assert res.ok and doc.selected == (6, 11) and doc.finds == ["world"]
    assert json.loads(res.text)["selection"] == "text"


def test_select_text_cursor_before_and_after(monkeypatch):
    # cursor_before/after → 退化为插入点（不选中任何文字）
    doc = _bind_text_el(monkeypatch, "hello world")
    assert gui._select_text(element_id="Edit:box", text="world",
                            selection="cursor_before").ok
    assert doc.selected == (6, 6)
    doc.selected = None
    assert gui._select_text(element_id="Edit:box", text="world",
                            selection="cursor_after").ok
    assert doc.selected == (11, 11)


def test_select_text_prefix_suffix_disambiguation(monkeypatch):
    # 同一文本多处出现 → 按「前缀+文本+后缀」整体定位，再收缩到文本本身
    doc = _bind_text_el(monkeypatch, "aa TARGET bb TARGET cc")
    res = gui._select_text(element_id="Edit:box", text="TARGET",
                           prefix="aa ", suffix=" bb")
    assert res.ok and doc.finds == ["aa TARGET bb"]     # 一次命中，未回退
    assert doc.selected == (3, 9)


def test_select_text_fallback_and_not_found(monkeypatch):
    doc = _bind_text_el(monkeypatch, "alpha beta")
    # 前缀/后缀组合未命中 → 回退到纯文本查找
    res = gui._select_text(element_id="Edit:box", text="beta", prefix="XX")
    assert res.ok and doc.finds == ["XXbeta", "beta"]
    assert doc.selected == (6, 10)
    miss = gui._select_text(element_id="Edit:box", text="zzz")
    assert not miss.ok and "未找到" in miss.error


def test_select_text_no_text_pattern(monkeypatch):
    # 控件不支持 TextPattern → 明确报错并指向 set_value
    el = type("El", (), {})()
    monkeypatch.setattr(gui, "_ui_resolve_node",
                        lambda eid, wt="": ({"id": eid, "name": "列表", "type": "List"}, el))
    res = gui._select_text(element_id="List:1", text="x")
    assert not res.ok and "TextPattern" in res.error and "set_value" in res.error


def test_select_text_validation():
    assert not gui._select_text(element_id="", text="x").ok
    assert not gui._select_text(element_id="Edit:box", text="").ok
    bad = gui._select_text(element_id="Edit:box", text="x", selection="whatever")
    assert not bad.ok and "selection" in bad.error


def test_select_text_enum_constants_match_uia():
    # 回归护栏：端点/单位常量须与 comtypes UIAutomationClient 枚举取值一致
    import pytest
    pytest.importorskip("pywinauto.uia_defines")
    from pywinauto.uia_defines import IUIA
    client = IUIA().ui_automation_client
    assert gui._TEXT_ENDPOINT_START == client.TextPatternRangeEndpoint_Start
    assert gui._TEXT_ENDPOINT_END == client.TextPatternRangeEndpoint_End
    assert gui._TEXT_UNIT_CHARACTER == client.TextUnit_Character


def test_contract_tools_registered_and_risk():
    # 新原语全部 sensitive + screen_lock（独占屏幕资源，需确认）
    r = _fresh_registry()
    for name in ("scroll", "drag", "set_value", "perform_action", "select_text"):
        t = r.get(name)
        assert t is not None, f"{name} 未注册"
        assert t.risk == "sensitive"
        assert t.screen_lock is True
    assert r.get("ui_list").risk == "safe"
    props = r.get("mouse_click").to_openai_schema()["function"]["parameters"]["properties"]
    assert "element_id" in props
    props = r.get("ui_list").to_openai_schema()["function"]["parameters"]["properties"]
    assert "disable_diff" in props and "max_depths" in props


def test_list_apps_tool(monkeypatch):
    # list_apps：只读枚举可见窗口；返回标题/句柄/进程号
    import json
    from app.agent.tools import windows as win

    class _FakeW:
        def enum_visible(self, only_titled=True):
            assert only_titled is True
            return [{"hwnd": 11, "title": "记事本", "pid": 999},
                    {"hwnd": 22, "title": "", "pid": 888}]

    monkeypatch.setattr(win, "_get_windows", lambda: _FakeW())
    res = win._list_apps()
    assert res.ok
    out = json.loads(res.text)
    assert out["count"] == 2 and out["items"][0]["hwnd"] == 11

    r = _fresh_registry()
    assert "list_apps" in r.names()
    assert r.get("list_apps").risk == "safe"
