# -*- coding: utf-8 -*-
"""MCP 桥接工具单元测试（app/agent/tools/mcp_tools.py）。

不真正启动外部 MCP 进程，用 fake client 验证工具逻辑与错误分支。
"""
import pytest

from app.agent import mcp_bridge
from app.agent.tools import mcp_tools
from app import config


class FakeClient:
    """假 MCP 客户端：只记录调用，不启动进程。"""

    def __init__(self, tools):
        self._tools = tools
        self.calls = []

    def list_tools(self):
        return self._tools

    def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        return f"执行结果:{name}"


def _patch_client(monkeypatch, tools):
    monkeypatch.setattr(mcp_bridge, "get_client", lambda name, spec: FakeClient(tools))
    # 按需拉起已 mock（真实逻辑由 test_ensure_blender_* 覆盖）
    monkeypatch.setattr(mcp_tools, "_ensure_blender_up", lambda: (True, ""))
    # 保证 config 有 blender server 且启用
    monkeypatch.setattr(
        config, "MCP_SERVERS",
        {"blender": {"display_name": "Blender 3D", "enabled": True,
                     "command": "uv", "args": [], "cwd": None}},
    )


SAMPLE_TOOLS = [
    {"name": "blender_object_create", "description": "Create a new object in Blender.",
     "inputSchema": {"type": "object",
                     "properties": {"name": {"type": "string", "description": "物体名"}},
                     "required": ["name"]}},
    {"name": "blender_scene_list", "description": "List all scenes.",
     "inputSchema": {"type": "object", "properties": {}, "required": []}},
]


# ---------- mcp_list_tools ----------

def test_list_tools_returns_brief(monkeypatch):
    _patch_client(monkeypatch, SAMPLE_TOOLS)
    res = mcp_tools._mcp_list_tools(server="blender")
    assert res.ok
    assert "blender_object_create" in res.text
    assert "2 个工具" in res.brief


def test_list_tools_unknown_server(monkeypatch):
    monkeypatch.setattr(config, "MCP_SERVERS", {"blender": {"enabled": True}})
    res = mcp_tools._mcp_list_tools(server="krita")
    assert not res.ok
    assert "未知 MCP server" in res.error


def test_list_tools_disabled_server(monkeypatch):
    monkeypatch.setattr(
        config, "MCP_SERVERS",
        {"blender": {"display_name": "Blender", "enabled": False}})
    res = mcp_tools._mcp_list_tools(server="blender")
    assert not res.ok
    assert "已禁用" in res.error


# ---------- mcp_tool_schema ----------

def test_tool_schema_found(monkeypatch):
    _patch_client(monkeypatch, SAMPLE_TOOLS)
    res = mcp_tools._mcp_tool_schema(server="blender", tool="blender_object_create")
    assert res.ok
    assert "name" in res.text
    assert "必填" in res.text


def test_tool_schema_missing_params():
    res = mcp_tools._mcp_tool_schema(server="", tool="")
    assert not res.ok
    assert "参数缺失" in res.error


def test_tool_schema_not_found(monkeypatch):
    _patch_client(monkeypatch, SAMPLE_TOOLS)
    res = mcp_tools._mcp_tool_schema(server="blender", tool="no_such_tool")
    assert not res.ok
    assert "没有找到" in res.error


# ---------- mcp_call_tool ----------

def test_call_tool_ok(monkeypatch):
    _patch_client(monkeypatch, SAMPLE_TOOLS)
    res = mcp_tools._mcp_call_tool(
        server="blender", tool="blender_object_create",
        arguments='{"name": "Cube"}')
    assert res.ok
    assert "执行结果" in res.text


def test_call_tool_bad_json(monkeypatch):
    _patch_client(monkeypatch, SAMPLE_TOOLS)
    res = mcp_tools._mcp_call_tool(
        server="blender", tool="blender_object_create", arguments="{bad json")
    assert not res.ok
    assert "JSON" in res.error


def test_call_tool_missing_name():
    res = mcp_tools._mcp_call_tool(server="", tool="")
    assert not res.ok
    assert "参数缺失" in res.error


# ---------- Blender 按需拉起（_ensure_blender_up） ----------

def test_ensure_blender_port_open_no_spawn(monkeypatch):
    """端口已在监听 → 不启动 Blender。"""
    spawned = []
    monkeypatch.setattr(mcp_tools, "_port_alive", lambda *a, **k: True)
    monkeypatch.setattr(mcp_tools.subprocess, "Popen",
                        lambda *a, **k: spawned.append(a))
    ok, msg = mcp_tools._ensure_blender_up()
    assert ok
    assert "已在运行" in msg
    assert not spawned


def test_ensure_blender_spawns_when_closed(monkeypatch):
    """端口未监听 → 自动启动 Blender，等端口就绪后返回成功。"""
    spawned = []
    seq = iter([False, False, True])  # 首次探测 + 轮询两次后端口起来
    monkeypatch.setattr(mcp_tools, "_port_alive", lambda *a, **k: next(seq))
    monkeypatch.setattr(mcp_tools.time, "sleep", lambda *a, **k: None)
    monkeypatch.setattr(mcp_tools.subprocess, "Popen",
                        lambda *a, **k: spawned.append(a))
    ok, msg = mcp_tools._ensure_blender_up()
    assert ok
    assert "自动启动" in msg
    assert len(spawned) == 1
    assert "blender.exe" in spawned[0][0][0].lower()


def test_ensure_blender_timeout_when_never_ready(monkeypatch):
    """启动后端口一直不起 → 超时给明确指引。

    注意：必须 mock subprocess.Popen——否则会真实 Popen 拉起 Blender GUI 窗口
    （历史 bug：本用例漏 mock，每次全量 pytest 都莫名弹出 Blender）。
    """
    spawned = []
    monkeypatch.setattr(mcp_tools, "_port_alive", lambda *a, **k: False)
    monkeypatch.setattr(mcp_tools.time, "sleep", lambda *a, **k: None)
    monkeypatch.setattr(mcp_tools.subprocess, "Popen",
                        lambda *a, **k: spawned.append(a))
    ok, msg = mcp_tools._ensure_blender_up(max_wait=0)
    assert not ok
    assert "仍未就绪" in msg
    # 确实尝试启动过一次，但 Popen 被 mock 拦截，不会出现真实 Blender 窗口
    assert len(spawned) == 1
    assert "blender.exe" in spawned[0][0][0].lower()


def test_ensure_blender_missing_exe(monkeypatch):
    """找不到 Blender 可执行文件 → 不尝试启动，提示手动。"""
    monkeypatch.setattr(mcp_tools, "_port_alive", lambda *a, **k: False)
    monkeypatch.setattr(mcp_tools, "BLENDER_EXE", r"Z:\no\such\blender.exe")
    ok, msg = mcp_tools._ensure_blender_up()
    assert not ok
    assert "未找到 Blender" in msg


def test_conftest_guard_blocks_real_blender_popen():
    """全局守卫（conftest autouse）：测试期若漏 mock 真实 Popen blender.exe，
    必须 fail-loud 抛错，而不是在桌面上弹出 Blender 窗口。"""
    import subprocess

    with pytest.raises(RuntimeError, match="禁止真实启动"):
        subprocess.Popen([r"D:\Allapp\blender\blender.exe", "--python", "x.py"])
