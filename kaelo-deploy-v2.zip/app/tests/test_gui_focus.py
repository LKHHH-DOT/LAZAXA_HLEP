# -*- coding: utf-8 -*-
"""GUI 焦点安全单元测试（app/agent/tools/gui.py + windows.py）。

回归 Bug：打开应用后窗口未置前 → 键盘输入/截图落到助手窗口（聊天框）。
覆盖 keyboard_type 三种前台校验 + open_app 自动置前。
"""
import os

from app.agent.tools import gui
from app.agent.tools import windows as w


class _FakePG:
    """假 pyautogui：拦截真实键盘/剪贴板操作。"""

    def typewrite(self, *a, **k):
        pass

    def hotkey(self, *a, **k):
        pass


def _mock_pg(monkeypatch):
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: _FakePG())
    monkeypatch.setattr(gui, "_set_clipboard_text", lambda t: None)


# ---------- keyboard_type：给了 window_title 的前台校验 ----------

def test_type_rejects_foreground_mismatch(monkeypatch):
    monkeypatch.setattr(gui, "_foreground_title", lambda: "知识库桌面助手")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="hi", window_title="记事本")
    assert not res.ok
    assert "不匹配" in res.error


def test_type_accepts_foreground_match(monkeypatch):
    monkeypatch.setattr(gui, "_foreground_title", lambda: "无标题 - 记事本")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="hi", window_title="记事本")
    assert res.ok


def test_type_alias_notepad_matches_english_title(monkeypatch):
    """window_title=记事本 应匹配英文系统标题 'Notepad'（中英别名）。"""
    monkeypatch.setattr(gui, "_foreground_title", lambda: "*今天是周六 - Notepad")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="hi", window_title="记事本")
    assert res.ok


def test_window_control_alias_finds_english_title(monkeypatch):
    """window_control title=记事本 应能找到英文标题窗口并激活。"""

    class FakeWin:
        def find(self, title):
            if "notepad" in title.lower():
                return 1, "无标题 - Notepad"
            return None, ""

        def activate(self, hwnd):
            return True

        def minimize(self, hwnd):
            return True

        def maximize(self, hwnd):
            return True

        def restore(self, hwnd):
            return True

        def close(self, hwnd):
            return True

    monkeypatch.setattr(w, "_get_windows", lambda: FakeWin())
    monkeypatch.setattr(w, "_last_target", "")
    res = w._window_control(title="记事本", action="activate")
    assert res.ok
    assert w._last_target == "无标题 - Notepad"


# ---------- keyboard_type：未给 window_title 的兜底校验 ----------

def test_type_blocks_assistant_window_without_target(monkeypatch):
    """没有最近目标、前台又是助手窗口 → 拒绝，防止输入进聊天框。"""
    monkeypatch.setattr(gui, "_foreground_title", lambda: "知识库桌面助手")
    monkeypatch.setattr(w, "_last_target", "")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="今天是周六")
    assert not res.ok
    assert "助手窗口" in res.error


def test_type_blocks_after_target_moved_away(monkeypatch):
    """最近目标是记事本，但前台已切到别处 → 拒绝。"""
    monkeypatch.setattr(gui, "_foreground_title", lambda: "知识库桌面助手")
    monkeypatch.setattr(w, "_last_target", "无标题 - 记事本")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="今天是周六")
    assert not res.ok
    assert "最近目标窗口" in res.error


def test_type_allows_when_last_target_is_foreground(monkeypatch):
    monkeypatch.setattr(gui, "_foreground_title", lambda: "无标题 - 记事本")
    monkeypatch.setattr(w, "_last_target", "无标题 - 记事本")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="hi")
    assert res.ok


def test_type_blocks_quickbar_window(monkeypatch):
    monkeypatch.setattr(gui, "_foreground_title", lambda: "知识库  ⌘ 快速问答")
    monkeypatch.setattr(w, "_last_target", "")
    _mock_pg(monkeypatch)
    res = gui._keyboard_type(text="hi")
    assert not res.ok


# ---------- open_app：启动已知应用后自动置前窗口 ----------

def test_open_app_activates_known_app(monkeypatch):
    """打开记事本 → 自动找到窗口并置前，记录 _last_target。"""
    launched = {}
    monkeypatch.setattr(w.subprocess, "Popen",
                        lambda exe, **k: launched.setdefault("exe", exe))

    class FakeWin:
        def find(self, title):
            return 123, "无标题 - 记事本"

        def activate(self, hwnd):
            return True

    monkeypatch.setattr(w, "_get_windows", lambda: FakeWin())
    monkeypatch.setattr(w, "_last_target", "")
    res = w._open_app(target="记事本")
    assert res.ok
    assert "置前" in res.text
    assert w._last_target == "无标题 - 记事本"


def test_open_app_unknown_app_no_activation(monkeypatch):
    """未知应用不自动置前（提示可用 window_control）。"""
    monkeypatch.setattr(w.subprocess, "Popen", lambda exe, **k: None)
    monkeypatch.setattr(w, "_get_windows", lambda: (_ for _ in ()).throw(
        AssertionError("未知应用不应调用窗口 API")))
    monkeypatch.setattr(w, "_last_target", "")
    res = w._open_app(target="微信")
    assert res.ok
    assert w._last_target == ""


def test_open_app_file_path(monkeypatch, tmp_path):
    """open_app 支持打开本地文件（回归：盘符路径误入协议分支的 bug）。"""
    f = tmp_path / "a.png"
    f.write_bytes(b"\x89PNG\r\n\x1a\n")
    opened = {}
    monkeypatch.setattr(w.os, "startfile", lambda p: opened.setdefault("p", p))
    monkeypatch.setattr(w, "_get_windows", lambda: (_ for _ in ()).throw(
        AssertionError("文件打开不应调用窗口 API")))
    res = w._open_app(target=str(f))
    assert res.ok
    assert opened["p"] == str(f)


def test_open_app_protocol_uri(monkeypatch):
    """协议 URI（ms-settings:）仍走 startfile，不被文件分支干扰。"""
    opened = {}
    monkeypatch.setattr(w.os, "startfile", lambda p: opened.setdefault("p", p))
    res = w._open_app(target="ms-settings:")
    assert res.ok
    assert opened["p"] == "ms-settings:"


# ---------- 用户工具表（computer-tools 技能接入，docs/工具.txt） ----------

def test_user_tools_all_paths_exist():
    """工具.txt 登记的 13 个工具路径必须真实存在，否则 open_app 会打开失败。"""
    assert len(w._USER_TOOLS) >= 13
    for name, path in w._USER_TOOLS.items():
        assert os.path.exists(path), f"工具 '{name}' 路径不存在: {path}"


def test_open_app_user_tool_exe(monkeypatch):
    """open_app("blender") 命中用户工具表 → Popen 拉起完整路径。"""
    launched = {}
    monkeypatch.setattr(w.subprocess, "Popen",
                        lambda exe, **k: launched.setdefault("exe", exe))
    monkeypatch.setattr(w, "_get_windows", lambda: type("W", (), {
        "find": lambda self, t: (None, ""), "activate": lambda self, h: True})())
    res = w._open_app(target="blender")
    assert res.ok
    assert launched["exe"] == w._USER_TOOLS["blender"]


def test_open_app_user_tool_dir(monkeypatch):
    """映射目标是目录（超智工具项目）→ 走 startfile 打开资源管理器。"""
    opened = {}
    monkeypatch.setattr(w.os, "startfile", lambda p: opened.setdefault("p", p))
    res = w._open_app(target="超智工具")
    assert res.ok
    assert "已打开目录" in res.text
    assert opened["p"] == w._USER_TOOLS["超智工具"]


def test_open_app_unknown_lists_user_tools(monkeypatch):
    """未知应用的错误提示应引导用户工具表与 computer-tools 技能。"""
    monkeypatch.setattr(w.subprocess, "Popen", lambda exe, **k: None)
    res = w._open_app(target="不存在的软件xyz")
    assert not res.ok
    assert "blender" in res.error and "computer-tools" in res.error
