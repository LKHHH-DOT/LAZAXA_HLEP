# -*- coding: utf-8 -*-
"""循环可靠性测试（2026-09-04 · P2：借 DeerFlow loop_detection 轻量版）。

覆盖 loop.py 新增的可靠性护栏：
  1. 工具指纹归一化：长参数截断/键序无关 → 同语义调用判为同指纹
  2. 同指纹循环熔断：窗口内重复 ≥3 次 → 软警告注入一次；连续命中
     达硬停阈值 → loop_capped 强制终止，partial output 保留
  3. 软警告注入次数上限：不会超过 _LOOP_MAX_WARNS 次刷屏
  4. 空回复兜底：第一次注入补救提示重试；重试仍空 → empty_response 收尾
  5. stop_reason 透传：done 事件 / 汇总 dict 携带枚举取值
  6. _resolve_subagent_stop 兼容推导（缺省字段按 error/steps 回退）
"""
import asyncio
import types

from app.agent import loop
from app.agent.loop import _resolve_subagent_stop, _tool_fingerprint
from app.agent.registry import ToolResult


def _call(name="run_command", cid="c1", args=None):
    return types.SimpleNamespace(name=name, id=cid,
                                 args=args or {"command": "echo hi"})


def _resp(content, tool_calls):
    tc = tool_calls or []
    return types.SimpleNamespace(
        has_tool_calls=bool(tc),
        content=content,
        tool_calls=tc,
        to_assistant_message=lambda: {"role": "assistant",
                                      "content": content or "",
                                      "tool_calls": []},
    )


def _run(monkeypatch, responses, exec_fn, max_steps=20, user_message="测试任务"):
    """mock llm.chat / registry.get / registry.execute，跑一次任务。"""
    from app.agent import llm as llm_mod
    from app.agent.registry import registry as reg

    seen = []
    it = iter(responses)

    def fake_chat(messages, tools, *a, **k):
        seen.append(messages)
        return next(it)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)
    monkeypatch.setattr(reg, "get",
                        lambda name: types.SimpleNamespace(risk="safe",
                                                           display_name=name))
    monkeypatch.setattr(reg, "execute", exec_fn)

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        return await loop.run_agent_task(user_message, emit=emit, max_steps=max_steps)

    result = asyncio.run(go())
    return seen, events, result


def _done(events):
    """返回最后一个 done 事件的 payload。"""
    ds = [p for t, p in events if t == "done"]
    return ds[-1] if ds else None


def _warn_notes(events):
    return [p.get("note", "") for t, p in events
            if t == "thinking" and "已警告" in p.get("note", "")]


# ---------- 1. 指纹归一化 ----------

def test_fingerprint_normalizes_long_args_and_key_order():
    """长参数截断 + 键序无关：同长同内容不同键序 → 指纹一致。

    截断后缀带原长度标记（…<lenN>），长度不同往往代表内容实质
    变化，指纹保持可区分；名字/参数不同指纹亦不同。
    """
    long1 = {"command": "x" * 500, "z": 1}
    long2 = {"z": 1, "command": "x" * 500}  # 键序不同、内容与长度一致
    assert _tool_fingerprint("run_command", long1) == \
        _tool_fingerprint("run_command", long2)
    # 长度不同 → 指纹不同（长度标记参与判定）
    assert _tool_fingerprint("run_command", {"command": "x" * 500}) != \
        _tool_fingerprint("run_command", {"command": "x" * 300})
    assert _tool_fingerprint("run_command", {"a": 1}) != \
        _tool_fingerprint("read_file", {"a": 1})
    # 不同参数 → 不同指纹（防循环检测把不同工作误判成空转）
    assert _tool_fingerprint("run_command", {"command": "a"}) != \
        _tool_fingerprint("run_command", {"command": "b"})


# ---------- 2. 循环熔断：软警告 → 硬停 loop_capped ----------

def test_loop_warn_then_cap_identical_calls(monkeypatch):
    """同指纹反复调用：第 1 次命中注入软警告，第 2 次连续命中 → loop_capped。"""
    exec_calls = []

    def exec_fn(name, args):
        exec_calls.append(args.get("command"))
        return ToolResult.ok_result("ok")

    same = _call(args={"command": "echo x"})
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [same]), _resp("", [same]), _resp("", [same]),
         _resp("已有部分进展", [same])],  # 第 4 轮指纹命中达硬停阈值
        exec_fn,
    )
    # 软警告恰好 1 次（第 1 次命中）；硬停前工具实际执行 3 次
    assert len(_warn_notes(events)) == 1
    assert len(exec_calls) == 3
    # done 事件与汇总都带 loop_capped，partial output 保留
    d = _done(events)
    assert d is not None and d["stop_reason"] == "loop_capped"
    assert "已有部分进展" in d["reply"]
    assert result["stop_reason"] == "loop_capped"
    assert result["error"] and "重复" in result["error"]


def test_loop_warns_capped_no_spam(monkeypatch):
    """软警告不超过上限：到 _LOOP_MAX_WARNS 次后，再命中也不刷警告。"""
    ok = lambda name, args: ToolResult.ok_result("ok")  # noqa: E731
    a = _call(args={"command": "echo 1"})
    b = _call(args={"command": "echo 2"})
    c = _call(args={"command": "echo 3"})
    # A×3 命中→警告1；B×3 命中→警告2（达上限）；C 换指纹打断连续命中；
    # 再 A（窗口内仍 ≥3）→ 命中但警告已被上限拦截，且不触发硬停
    resp_seq = ([_resp("", [a])] * 3 + [_resp("", [b])] * 3
                + [_resp("", [c]), _resp("", [a]), _resp("收工", None)])
    seen, events, result = _run(monkeypatch, resp_seq, ok)
    warns = _warn_notes(events)
    assert len(warns) == loop._LOOP_MAX_WARNS  # 到顶即不再注入
    assert result["stop_reason"] == "completed"  # 未误触发 loop_capped
    assert result["reply"] == "收工"


# ---------- 3. 空回复兜底 ----------

def test_empty_response_retry_then_recover(monkeypatch):
    """空回复第一次注入补救提示重试，第二次给出正常回答 → completed。"""
    seen, events, result = _run(
        monkeypatch,
        [_resp("", None), _resp("好的，答案是 42", None)],
        lambda name, args: ToolResult.ok_result("ok"),
    )
    notes = [p.get("note", "") for t, p in events
             if t == "thinking" and "空回复" in p.get("note", "")]
    assert len(notes) == 1  # 只补救一次
    assert result["reply"] == "好的，答案是 42"
    assert result["stop_reason"] == "completed"
    assert _done(events)["stop_reason"] == "completed"


def test_empty_response_give_up_after_retry(monkeypatch):
    """重试后仍空 → 以 empty_response 收尾（done/汇总一致）。"""
    seen, events, result = _run(
        monkeypatch,
        [_resp("", None), _resp("", None), _resp("", None)],  # 用不完第 3 个
        lambda name, args: ToolResult.ok_result("ok"),
    )
    d = _done(events)
    assert d is not None and d["stop_reason"] == "empty_response"
    assert d["error"] == "empty_response"
    assert result["stop_reason"] == "empty_response"
    assert "没能生成有效回答" in result["reply"]


# ---------- 4. 正常完成的 stop_reason 透传 ----------

def test_completed_stop_reason_in_done(monkeypatch):
    """普通任务正常结束 → done/汇总 stop_reason = completed。"""
    seen, events, result = _run(
        monkeypatch,
        [_resp("搞定", None)],
        lambda name, args: ToolResult.ok_result("ok"),
    )
    assert result["stop_reason"] == "completed"
    assert result["error"] == ""
    assert _done(events)["stop_reason"] == "completed"


# ---------- 5. 子代理停因兼容推导 ----------

def test_resolve_subagent_stop_fallback():
    """内层 stop_reason 优先；缺省按 error / steps 兼容推导。"""
    assert _resolve_subagent_stop({"stop_reason": "loop_capped"}) == "loop_capped"
    assert _resolve_subagent_stop({"stop_reason": "completed",
                                   "error": "boom"}) == "error"
    assert _resolve_subagent_stop({"error": "boom"}) == "error"
    assert _resolve_subagent_stop({"steps": 9, "limit": 5}) == "max_steps"
    assert _resolve_subagent_stop({}) == "completed"


# ---------- 6. B批4：软警告 wrap 注入点（不落进 tool_call 配对区段） ----------

def test_loop_warn_injected_outside_tool_pair_section(monkeypatch):
    """软警告应推迟到下一轮模型调用前注入（wrap 点）：警告 system 消息必须
    位于上一轮全部 tool responses 之后、且是当前请求最后一条消息——绝不夹在
    assistant(tool_call) 与其 tool responses 配对区段中间（DeerFlow 教训：
    警告注入 wrap_model_call 而非 after_model）。"""
    def exec_fn(name, args):
        return ToolResult.ok_result("ok")

    same = _call(args={"command": "echo x"})
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [same]), _resp("", [same]), _resp("", [same]),
         _resp("", [same])],  # 第 4 轮连续命中 → 硬停（警告已在其请求前注入）
        exec_fn,
    )
    assert len(_warn_notes(events)) == 1  # 第 1 次命中触发一次软警告事件
    assert result["stop_reason"] == "loop_capped"

    # 第 4 轮模型请求（seen[3]）的 messages 末尾应携带循环警告 system，
    # 且它在最后一条 role="tool"（上轮全部 tool responses）之后
    msgs = seen[3]
    warn_idxs = [i for i, m in enumerate(msgs)
                 if m.get("role") == "system" and "循环警告" in m.get("content", "")]
    assert warn_idxs, "第 4 轮请求前应已注入循环警告"
    warn_idx = warn_idxs[-1]
    assert warn_idx == len(msgs) - 1  # 位于请求末尾（工具配对区段之外）
    # 警告之前紧跟最后一条 tool 响应（说明在上一轮工具结果全部落定后才注入）
    assert msgs[warn_idx - 1].get("role") == "tool"


# ---------- 7. M4a/Bug1：显式重复授权识别（纯函数） ----------

def test_detect_explicit_repeat_arabic():
    n = loop._detect_explicit_repeat("请连续调用 run_command 5 次，每次参数完全相同 echo hi")
    assert n == 5


def test_detect_explicit_repeat_chinese_numeral():
    assert loop._detect_explicit_repeat("连续调用同一个工具五次") == 5
    assert loop._detect_explicit_repeat("重复执行三遍") == 3


def test_detect_explicit_repeat_requires_intent_and_count():
    assert loop._detect_explicit_repeat("调用一下 run_command") == 0       # 无意图词
    assert loop._detect_explicit_repeat("请重复调用这个工具") == 0          # 无次数
    assert loop._detect_explicit_repeat("") == 0


def test_detect_explicit_repeat_hard_cap():
    assert loop._detect_explicit_repeat("连续重复 100 次") == loop._EXPLICIT_REPEAT_CAP
    assert loop._detect_explicit_repeat("连续重复 8 次") == 8


def test_detect_explicit_repeat_negation_not_authorized():
    assert loop._detect_explicit_repeat("不要重复调用 5 次") == 0
    assert loop._detect_explicit_repeat("禁止连续执行 3 次") == 0


# ---------- 8. M4a/Bug1：显式授权时豁免循环熔断（集成） ----------

def test_explicit_repeat_exempts_loop_cap(monkeypatch):
    """用户明确要求连续 5 次相同调用：5 轮同指纹不被熔断，第 6 轮正常收工。"""
    exec_calls = []

    def exec_fn(name, args):
        exec_calls.append(args.get("command"))
        return ToolResult.ok_result("ok")

    same = _call(args={"command": "echo hi"})
    umsg = "请连续调用 run_command 5 次，每次参数完全相同 echo hi"
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [same])] * 5 + [_resp("全部完成", None)],
        exec_fn, user_message=umsg)
    assert len(exec_calls) == 5                    # 5 次全部实际执行
    assert result["stop_reason"] == "completed"    # 未被 loop_capped 误杀
    assert result["reply"] == "全部完成"
    # 豁免期间不注入"循环警告"
    assert _warn_notes(events) == []


def test_explicit_repeat_allowance_exhausted_then_cap(monkeypatch):
    """授权 3 次：第 3/4/5 轮命中被豁免，授权耗尽后连续命中 2 轮恢复硬停。"""
    same = _call(args={"command": "echo hi"})
    umsg = "连续调用 run_command 3 次，参数相同"
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [same])] * 7,   # 轮1-5执行，轮6软警告执行，轮7连续命中→硬停
        lambda n, a: ToolResult.ok_result("ok"),
        user_message=umsg)
    assert result["stop_reason"] == "loop_capped"  # 授权耗尽后熔断逻辑恢复


def test_no_explicit_repeat_keeps_original_cap(monkeypatch):
    """无重复授权（普通任务）回归：同指纹 4 轮仍按原逻辑 loop_capped。"""
    same = _call(args={"command": "echo x"})
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [same]), _resp("", [same]), _resp("", [same]),
         _resp("部分进展", [same])],
        lambda n, a: ToolResult.ok_result("ok"))
    assert result["stop_reason"] == "loop_capped"


# ---------- 9. M4a/Bug2：工具被拒绝后禁止编造结果 ----------

def _deny_tool_text(monkeypatch, decide_ret, ask_ret=None):
    """跑一轮被拒绝的工具调用，返回下一轮请求里携带的 tool 消息文本。"""
    from app.agent import permissions
    monkeypatch.setattr(loop.permissions, "decide",
                        lambda *a, **k: decide_ret)
    if ask_ret is not None:
        async def fake_ask(*a, **k):
            return ask_ret
        monkeypatch.setattr(loop.approval, "ask", fake_ask)
    call = _call(name="list_dir", args={"path": "D:/demo"})
    seen, events, result = _run(
        monkeypatch, [_resp("", [call]), _resp("收工", None)],
        lambda n, a: ToolResult.ok_result("ok"))
    # seen[1] = 第二轮请求，其中携带第一轮被拒绝后生成的 tool 消息
    tool_msgs = [m for m in seen[1] if m.get("role") == "tool"]
    assert tool_msgs, "被拒绝后应向模型回一条 tool 消息"
    return tool_msgs[-1]["content"]


def test_deny_message_forbids_fabrication(monkeypatch):
    txt = _deny_tool_text(monkeypatch, ("deny", "locked-mode"))
    assert "未实际执行" in txt
    assert "严禁" in txt and "编造" in txt
    assert "如实告知" in txt


def test_user_reject_message_forbids_fabrication(monkeypatch):
    txt = _deny_tool_text(monkeypatch, ("ask", "sensitive"), ask_ret=False)
    assert "未实际执行" in txt
    assert "严禁" in txt and "编造" in txt
    assert "如实告知" in txt


# ---------- 10. M4c：行为类失败终态携带工具轨迹（供失败教训提炼） ----------

def test_loop_capped_payload_carries_tool_path(monkeypatch):
    """loop_capped 的 done payload 带 tool_path，且保留重复工具名（体现空转）。"""
    same = _call(name="screenshot", args={"target": "screen"})
    seen, events, result = _run(
        monkeypatch, [_resp("", [same])] * 4,
        lambda n, a: ToolResult.ok_result("img"))
    d = _done(events)
    assert d["stop_reason"] == "loop_capped"
    path = d.get("tool_path")
    assert isinstance(path, list) and path
    assert "screenshot" in path
    assert len(path) >= 2  # 保留重复，反映"反复截图"特征


def test_max_steps_payload_carries_tool_path(monkeypatch):
    """max_steps 终态同样带 tool_path。"""
    a = _call(name="run_command", cid="a", args={"command": "echo 1"})
    # 每轮换不同参数避免触发循环熔断，走到步数上限（max_steps=3）
    resps = [_resp("", [_call(name="run_command", cid=f"c{i}",
                              args={"command": f"echo {i}"})]) for i in range(5)]
    seen, events, result = _run(monkeypatch, resps,
                                lambda n, a: ToolResult.ok_result("ok"),
                                max_steps=3)
    d = _done(events)
    assert d["stop_reason"] == "max_steps"
    assert d.get("tool_path") and "run_command" in d["tool_path"]

