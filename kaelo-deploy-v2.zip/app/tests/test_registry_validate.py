# -*- coding: utf-8 -*-
"""工具参数强校验测试（2026-09-05 · A批4 registry 执行前 Schema 校验）。

覆盖：
  1. 必填参数缺失 → 明确报缺哪个参数，且 fn 不被调用
  2. 类型明显不符 → 报期望/实收类型（string 收到容器、integer 收到字符串等）
  3. 宽松放行：integer 收整值 float；string 收数字（工具内可 str 化）
  4. boolean / array（含元素抽查）/ object 类型判定
  5. 未声明键放行（保持历史行为，交由 fn 兜底）
  6. args=None 视为 {}（无必填工具可正常执行）
  7. args 非对象 → 明确报错
"""
import pytest

from app.agent.registry import Tool, ToolRegistry, ToolResult


@pytest.fixture()
def _env():
    calls = []

    def fn(**kw):
        calls.append(kw)
        return ToolResult.ok_result("执行成功")

    reg = ToolRegistry()
    reg.register(Tool(
        name="demo_write",
        display_name="示例写入",
        description="测试用",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "目标路径"},
                "lines": {"type": "integer", "description": "行数"},
                "ratio": {"type": "number", "description": "比例"},
                "tags": {"type": "array", "items": {"type": "string"},
                         "description": "标签"},
                "force": {"type": "boolean", "description": "是否强制"},
                "meta": {"type": "object", "description": "元数据"},
            },
            "required": ["path"],
        },
        risk="safe", timeout=5, fn=fn,
    ))
    return reg, calls


def test_required_missing_blocked(_env):
    reg, calls = _env
    r = reg.execute("demo_write", {"lines": 3})
    assert not r.ok
    assert "参数校验失败" in r.error and "缺少必填参数 path" in r.error
    assert calls == []            # fn 未被调用


def test_type_mismatch_rejected(_env):
    reg, calls = _env
    # string 收到 dict
    r = reg.execute("demo_write", {"path": {"d": 1}})
    assert not r.ok and "path 应为 string" in r.error
    assert calls == []
    # integer 收到 str
    r = reg.execute("demo_write", {"path": "a", "lines": "3"})
    assert not r.ok and "lines 应为 integer" in r.error
    # boolean 收到 int
    r = reg.execute("demo_write", {"path": "a", "force": 1})
    assert not r.ok and "force 应为 boolean" in r.error
    # array 收到 dict
    r = reg.execute("demo_write", {"path": "a", "tags": {"x": 1}})
    assert not r.ok and "tags 应为 array" in r.error
    # object 收到 list
    r = reg.execute("demo_write", {"path": "a", "meta": [1]})
    assert not r.ok and "meta 应为 object" in r.error


def test_array_item_type_spot_check(_env):
    reg, calls = _env
    # 容器元素（dict）不符合 string 元素声明 → 拦截
    r = reg.execute("demo_write", {"path": "a", "tags": ["ok", {"x": 1}]})
    assert not r.ok and "数组元素应为 string" in r.error
    assert calls == []


def test_lenient_scalars_allowed(_env):
    """宽松放行：integer 收整值 float；string 收纯数字（工具内可 str 化）。"""
    reg, calls = _env
    r = reg.execute("demo_write", {"path": "a", "lines": 3.0})
    assert r.ok and calls[0]["lines"] == 3.0
    r2 = reg.execute("demo_write", {"path": 2026})
    assert r2.ok and calls[1]["path"] == 2026


def test_valid_full_args_passes(_env):
    reg, calls = _env
    r = reg.execute("demo_write", {
        "path": "C:/x.txt", "lines": 10, "tags": ["a", "b"],
        "force": True, "meta": {"k": "v"},
    })
    assert r.ok
    assert calls == [{"path": "C:/x.txt", "lines": 10, "tags": ["a", "b"],
                      "force": True, "meta": {"k": "v"}}]


def test_undeclared_keys_passthrough(_env):
    """未在 schema 声明的多余键放行（交由 fn 兜底/TypeError，与历史一致）。"""
    reg, calls = _env
    r = reg.execute("demo_write", {"path": "a", "extra_key": 1})
    assert r.ok and calls[0]["extra_key"] == 1


def test_args_none_treated_empty():
    """无必填参数工具：args=None 视为 {}，正常执行不误伤。"""
    reg = ToolRegistry()
    reg.register(Tool(
        name="demo_empty", display_name="", description="",
        parameters={"type": "object", "properties": {}},
        risk="safe", timeout=5,
        fn=lambda **kw: ToolResult.ok_result("ok"),
    ))
    r = reg.execute("demo_empty", None)
    assert r.ok


def test_args_not_object_rejected():
    reg = ToolRegistry()
    reg.register(Tool(
        name="demo2", display_name="", description="",
        parameters={"type": "object", "properties": {}},
        risk="safe", timeout=5,
        fn=lambda **kw: ToolResult.ok_result("ok"),
    ))
    r = reg.execute("demo2", ["不是对象"])
    assert not r.ok and "参数必须是 JSON 对象" in r.error
