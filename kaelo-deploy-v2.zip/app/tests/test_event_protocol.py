# -*- coding: utf-8 -*-
"""M5-2 协议契约 + 审批协议化测试。

覆盖（对应《M5-架构化-细化方案》M5-2 验收口径）：
  1. EventType 枚举 + EVENT_SCHEMA 覆盖完整，StrEnum 与旧字符串字面量等价
  2. sse_payload 统一出口带协议版本号 v（EventType / 字符串均可）
  3. missing_fields 必填字段校验（未知事件不约束）
  4. loop 全流程 wire 事件与 agent_events 落账行都满足协议契约
  5. approval_request payload 结构化（display_name / context_summary）
  6. 编辑参数后批准：以编辑后参数执行，approval_resolved 记 edited=True + 生效参数
  7. 同意不编辑 → 用原参数；拒绝 → 不执行且无编辑参数；过期应答 → resolve=False
  8. approve 接口 body 接受 edited_args

约定：纯机制用例用独立 new ToolRegistry()（不挂默认钩子）；loop 集成用例
换 FakeDb 抓 log_agent_event 行、桩 llm.chat/registry，离线跑真实 run_agent_task。
跟随仓库既有风格，用 asyncio.run 跑协程，不引入 pytest-asyncio。
"""

import asyncio
import copy
import json
import sys
import types

import pytest

from app.agent import approval as approval_mod
from app.agent import loop
from app.agent import llm as llm_mod
from app.agent import permissions
from app.agent.events import (
    EVENT_PROTOCOL_VERSION, EVENT_SCHEMA, EventType, missing_fields, sse_payload)
from app.agent.loop import run_agent_task
from app.agent.registry import (
    ExecContext, Tool, ToolRegistry, ToolResult, registry as global_registry)
from app import config as app_config

DECISION_ALLOW = permissions.DECISION_ALLOW
DECISION_ASK = permissions.DECISION_ASK


# --------------------------------------------------------------------- #
# 辅助
# --------------------------------------------------------------------- #
class _FakeDb:
    """离线替换 app.db：抓 log_agent_event 行，其余审计no-op。"""

    def __init__(self):
        self.rows = []

    def log_agent_event(self, event_type, payload=None, *, round_id="",
                        task_id="", parent_task_id="", step=0):
        self.rows.append({"id": len(self.rows) + 1, "type": event_type,
                          "payload": copy.deepcopy(payload or {}),
                          "round_id": round_id, "task_id": task_id,
                          "parent_task_id": parent_task_id, "step": step})
        return len(self.rows)

    def log_agent_task(self, *a, **k):
        return True

    def bump_audit_failure(self, *a, **k):
        pass


@pytest.fixture(autouse=True)
def _clean_approval():
    """每个用例前后清空全局审批单例，防跨用例残留。"""
    mgr = approval_mod.approval
    with mgr._lock:
        mgr._pending.clear()
        mgr._resolved_edits.clear()
    yield
    with mgr._lock:
        mgr._pending.clear()
        mgr._resolved_edits.clear()


def _collector(events):
    async def emit(t, p):
        events.append((t, p))
    return emit


def _ctx(**kw):
    base = dict(mode="standard", round_id="", parent_task_id="",
                user_message="u", task_id="tid", compact_name="c",
                emit=_collector([]))
    base.update(kw)
    return ExecContext(**base)


def _drive(reg, name, args, ctx, resolve_kwargs):
    """跑 arun，并在 gate 挂起后从"另一个协程"应答审批（模拟前端 /approve）。"""
    async def scenario():
        task = asyncio.create_task(reg.arun(name, args, ctx))
        for _ in range(50):
            await asyncio.sleep(0)
            if approval_mod.approval.pending_count():
                break
        assert approval_mod.approval.pending_count() == 1, "gate 未挂起"
        approval_mod.approval.resolve(ctx.task_id, **resolve_kwargs)
        return await task
    return asyncio.run(scenario())


def _sensitive_registry():
    """含单工具 t_demo、挂审批 gate 的干净注册表。"""
    reg = ToolRegistry()
    seen = {}

    def _fn(**kw):
        seen.update(kw)
        return ToolResult.ok_result("ok", brief="ok")

    reg.register(Tool("t_demo", "演示", {"type": "object", "properties": {}},
                      "sensitive", 30, _fn))
    reg.add_gate_hook(approval_mod.approval_gate_hook)
    return reg, seen


# --------------------------------------------------------------------- #
# 1. 枚举与 schema 完整性
# --------------------------------------------------------------------- #
def test_event_enum_and_schema_complete():
    assert set(EVENT_SCHEMA.keys()) == set(EventType)
    assert EventType.THINKING == "thinking"            # 与旧字符串字面量等价
    assert isinstance(EventType.THINKING, str)
    assert str(EventType.THINKING) == "thinking"
    assert json.loads(sse_payload(EventType.THINKING, step=1)[6:].strip())["type"] \
        == "thinking"


# --------------------------------------------------------------------- #
# 2. sse_payload 带版本号
# --------------------------------------------------------------------- #
def test_sse_payload_type_and_version():
    line = sse_payload(EventType.TOKEN, text="hi")
    assert line.startswith("data: ") and line.endswith("\n\n")
    obj = json.loads(line[len("data: "):].strip())
    assert obj == {"type": "token", "v": EVENT_PROTOCOL_VERSION, "text": "hi"}
    # 字符串事件类型同样可用（chat 路由的 meta/meta_web 等非枚举事件）
    obj2 = json.loads(sse_payload("thinking", step=1)[len("data: "):].strip())
    assert obj2["type"] == "thinking" and obj2["v"] == EVENT_PROTOCOL_VERSION


# --------------------------------------------------------------------- #
# 3. missing_fields 校验
# --------------------------------------------------------------------- #
def test_missing_fields():
    assert missing_fields(EventType.TOOL_RESULT, {"name": "x"}) == ["ok"]
    assert missing_fields(EventType.TOOL_RESULT, {"name": "x", "ok": False}) == []
    assert missing_fields("unknown-event", {}) == []    # 未知类型不约束


# --------------------------------------------------------------------- #
# 4. loop 全流程事件满足协议契约
# --------------------------------------------------------------------- #
def _resp(content="", tool_calls=None):
    tc = tool_calls or []
    return types.SimpleNamespace(
        has_tool_calls=bool(tc), content=content, tool_calls=tc,
        usage={"prompt_tokens": 5, "completion_tokens": 3},
        finish_reason="stop",
        to_assistant_message=lambda: {"role": "assistant",
                                      "content": content or "", "tool_calls": []})


def _tool(name="run_command", cid="c1", args=None):
    return types.SimpleNamespace(name=name, id=cid, args=args or {"cmd": "echo hi"})


def test_loop_events_match_protocol(monkeypatch):
    db = _FakeDb()
    monkeypatch.setitem(sys.modules, "app.db", db)
    reg = global_registry
    monkeypatch.setattr(reg, "get",
                        lambda name: types.SimpleNamespace(
                            risk="sensitive", display_name=name))
    monkeypatch.setattr(reg, "execute",
                        lambda name, args: ToolResult.ok_result("ok"))
    monkeypatch.setattr(reg, "openai_schemas", lambda: [])
    monkeypatch.setattr(loop.permissions, "decide",
                        lambda *a, **k: (DECISION_ALLOW, "test"))
    responses = [_resp(tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="完成")]
    it = iter(responses)
    monkeypatch.setattr(llm_mod, "chat",
                        lambda messages, tools, *a, **k: next(it))

    events = []
    async def go():
        return await run_agent_task("做", emit=_collector(events), max_steps=4,
                                    round_id="r-proto-1")
    asyncio.run(go())

    assert events, "loop 必须发出事件"
    for t, p in events:                                  # wire 事件契约
        assert t in set(EventType)
        assert missing_fields(t, p) == [], f"{t} 缺必填字段：{p}"
    known = {e.value for e in EventType}
    assert db.rows, "事件账本必须有落账行"
    for row in db.rows:                                  # 落账行契约
        assert row["type"] in known
        assert missing_fields(EventType(row["type"]), row["payload"]) == []


# --------------------------------------------------------------------- #
# 5. approval_request payload 结构化
# --------------------------------------------------------------------- #
def test_approval_request_payload_structured(monkeypatch):
    monkeypatch.setattr(global_registry, "get",
                        lambda name: types.SimpleNamespace(display_name="演示工具"))
    mgr = approval_mod.ApprovalManager()
    events = []
    emit = _collector(events)

    async def scenario():
        task = asyncio.create_task(
            mgr.ask("tid-x", "t_demo", {"a": 1}, "sensitive", emit))
        for _ in range(50):
            await asyncio.sleep(0)
            if mgr.pending_count():
                break
        mgr.resolve("tid-x", True)
        await task
    asyncio.run(scenario())

    assert len(events) == 1
    t, p = events[0]
    assert t == "approval_request"
    assert p["display_name"] == "演示工具"
    assert "演示工具" in p["context_summary"] and '"a"' in p["context_summary"]
    assert p["task_id"] == "tid-x" and p["tool"] == "t_demo"
    assert p["risk"] == "sensitive" and p["args"] == {"a": 1}
    assert missing_fields(EventType.APPROVAL_REQUEST, p) == []
    assert p["guidance"] == ""      # 普通动作无场景话术（不打扰）


# --------------------------------------------------------------------- #
# 5b. P2-1 安全场景话术（Hand-Off / Pre-Approval / Always-Confirm）
# --------------------------------------------------------------------- #
def test_guidance_classifies_scenarios():
    """三类场景各自命中对应话术；无关动作返回空串。"""
    g = approval_mod.guidance_for
    assert "须由你本人完成" in g("keyboard_type", {"text": "新密码 123"})
    assert "向外传输数据" in g("run_command", {"command": "scp a.txt u@h:/tmp"})
    assert "即使事先授权也要在执行前确认" in g(
        "run_command", {"command": "Remove-Item -Recurse D:\\x"})
    assert g("ui_list", {"window_title": "记事本"}) == ""


def test_guidance_orders_handoff_first_and_combines():
    """多类命中按 handoff → pre-approval → always-confirm 拼接，最该先看的在前。"""
    text = approval_mod.guidance_for(
        "run_command", {"command": "改密码后 scp secret.txt u@h:/tmp"})
    assert text.index("须由你本人完成") < text.index("向外传输数据")


def test_approval_request_carries_guidance(monkeypatch):
    """传输数据类动作：guidance 单列下发，且已拼进 context_summary 供旧前端兜底展示。"""
    monkeypatch.setattr(global_registry, "get",
                        lambda name: types.SimpleNamespace(display_name="命令"))
    mgr = approval_mod.ApprovalManager()
    events = []
    emit = _collector(events)

    async def scenario():
        task = asyncio.create_task(mgr.ask(
            "tid-g", "run_command",
            {"command": "scp secret.txt user@host:/tmp"}, "dangerous", emit))
        for _ in range(50):
            await asyncio.sleep(0)
            if mgr.pending_count():
                break
        mgr.resolve("tid-g", False)
        await task
    asyncio.run(scenario())

    t, p = events[0]
    assert t == "approval_request"
    assert "向外传输数据" in p["guidance"]
    assert "向外传输数据" in p["context_summary"]
    assert missing_fields(EventType.APPROVAL_REQUEST, p) == []


# --------------------------------------------------------------------- #
# 6. 编辑参数后批准 → 以编辑后参数执行
# --------------------------------------------------------------------- #
def test_edited_args_applied_to_execution(monkeypatch):
    reg, seen = _sensitive_registry()
    monkeypatch.setattr(permissions, "decide",
                        lambda *a, **k: (DECISION_ASK, "需确认"))
    monkeypatch.setattr(app_config, "AGENT_EVENTS_ENABLED", False)
    ctx = _ctx(task_id="tid-edit")
    result = _drive(reg, "t_demo", {"text": "ORIG"}, ctx,
                    {"approved": True, "edited_args": {"text": "EDITED"}})
    assert result.ok
    assert seen == {"text": "EDITED"}          # 执行用的是编辑后参数
    assert ctx.edited_args == {"text": "EDITED"}
    assert ctx.approved is True and ctx.decision == "ask"


# --------------------------------------------------------------------- #
# 7. 同意不编辑 / 拒绝 / 过期
# --------------------------------------------------------------------- #
def test_approve_without_edit_uses_original_args(monkeypatch):
    reg, seen = _sensitive_registry()
    monkeypatch.setattr(permissions, "decide",
                        lambda *a, **k: (DECISION_ASK, "需确认"))
    monkeypatch.setattr(app_config, "AGENT_EVENTS_ENABLED", False)
    ctx = _ctx(task_id="tid-noedit")
    result = _drive(reg, "t_demo", {"text": "ORIG"}, ctx, {"approved": True})
    assert result.ok and seen == {"text": "ORIG"}
    assert ctx.edited_args is None


def test_reject_blocks_and_keeps_no_edited_args(monkeypatch):
    reg, seen = _sensitive_registry()
    monkeypatch.setattr(permissions, "decide",
                        lambda *a, **k: (DECISION_ASK, "需确认"))
    monkeypatch.setattr(app_config, "AGENT_EVENTS_ENABLED", False)
    ctx = _ctx(task_id="tid-reject")
    result = _drive(reg, "t_demo", {"text": "ORIG"}, ctx,
                    {"approved": False, "edited_args": {"text": "EDITED"}})
    assert seen == {}                          # 拒绝：未执行
    assert result.gate_blocked and not result.ok
    assert result.error == approval_mod.REJECTED_MODEL_TEXT
    assert ctx.approved is False and ctx.edited_args is None


def test_resolve_unknown_task_returns_false():
    mgr = approval_mod.ApprovalManager()
    assert mgr.resolve("nope", True, edited_args={"a": 1}) is False
    assert mgr.take_edited_args("nope") is None


# --------------------------------------------------------------------- #
# 8. approval_resolved 落账带 edited 标记与生效参数
# --------------------------------------------------------------------- #
def test_approval_resolved_logs_edited_flag(monkeypatch):
    db = _FakeDb()
    monkeypatch.setitem(sys.modules, "app.db", db)
    reg, seen = _sensitive_registry()
    monkeypatch.setattr(permissions, "decide",
                        lambda *a, **k: (DECISION_ASK, "需确认"))
    monkeypatch.setattr(app_config, "AGENT_EVENTS_ENABLED", True)
    ctx = _ctx(task_id="tid-log", round_id="r-edit-1")
    result = _drive(reg, "t_demo", {"text": "ORIG"}, ctx,
                    {"approved": True, "edited_args": {"text": "EDITED"}})
    assert result.ok
    rows = [r for r in db.rows if r["type"] == "approval_resolved"]
    assert len(rows) == 1
    assert rows[0]["round_id"] == "r-edit-1"
    payload = rows[0]["payload"]
    assert payload["edited"] is True
    assert payload["approved"] is True
    assert payload["args"] == {"text": "EDITED"}     # 记生效（编辑后）参数
    assert missing_fields(EventType.APPROVAL_RESOLVED, payload) == []


# --------------------------------------------------------------------- #
# 9. approve 接口 body 契约
# --------------------------------------------------------------------- #
def test_approve_body_accepts_edited_args():
    from app.routers.agent import AgentApproveBody
    body = AgentApproveBody(task_id="t", approved=True,
                            edited_args={"a": 1})
    assert body.edited_args == {"a": 1}
    assert AgentApproveBody(task_id="t", approved=False).edited_args is None
