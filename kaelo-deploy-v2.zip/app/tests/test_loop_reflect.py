# -*- coding: utf-8 -*-
"""反思机制测试（2026-08-18 · 修复复杂任务链"踩坑不换思路"）。

验证 loop.py 的失败反思机制：
  1. 连续 2 次执行失败 → 第 3 次模型调用前注入反思提示（system 段 + thinking note）
  2. 失败后成功 → 计数清零，不误注入
  3. 注入次数上限：持续失败也只注入 AGENT_REFLECT_MAX_INJECTIONS 次
  4. 有工具调用时模型输出文本（如规划说明）也推送给前端
"""
import asyncio
import types

from app.agent import loop
from app.agent.registry import ToolResult


def _call(name="run_command", cid="c1", args=None):
    return types.SimpleNamespace(name=name, id=cid,
                                 args=args or {"command": "echo hi"})


def _resp(content, tool_calls):
    tc = tool_calls or []
    return types.SimpleNamespace(
        has_tool_calls=bool(tc),
        content=content,
        tool_calls=tc,
        to_assistant_message=lambda: {"role": "assistant",
                                      "content": content or "",
                                      "tool_calls": []},
    )


def _run(monkeypatch, responses, exec_fn, max_steps=10):
    """mock llm.chat / registry.get / registry.execute，跑一次任务。"""
    from app.agent import llm as llm_mod
    from app.agent.registry import registry as reg

    seen = []
    it = iter(responses)

    def fake_chat(messages, tools, *a, **k):
        seen.append(messages)
        return next(it)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)
    monkeypatch.setattr(reg, "get",
                        lambda name: types.SimpleNamespace(risk="safe",
                                                           display_name=name))
    monkeypatch.setattr(reg, "execute", exec_fn)

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        return await loop.run_agent_task("测试任务", emit=emit, max_steps=max_steps)

    result = asyncio.run(go())
    return seen, events, result


def _has_reflect(messages):
    return any(m["role"] == "system" and "反思提示" in m["content"]
               for m in messages)


def test_reflect_injected_after_two_failures(monkeypatch):
    """连续 2 次失败 → 第 3 次模型调用前注入反思提示。"""
    seen, events, result = _run(
        monkeypatch,
        [_resp("计划", [_call()]), _resp("", [_call()]),
         _resp("", [_call()]), _resp("完成", None)],
        lambda name, args: ToolResult.err_result("执行失败: boom"),
    )
    # 第 3 次调用的 messages 含反思 system 段
    assert _has_reflect(seen[2])
    # thinking 事件带反思 note
    assert any(t == "thinking" and "反思" in p.get("note", "")
               for t, p in events)
    assert result["reply"] == "完成"


def test_reflect_success_resets_streak(monkeypatch):
    """失败后成功 → 计数清零，后续不再误注入。"""
    calls = [0]

    def exec_fn(name, args):
        calls[0] += 1
        return (ToolResult.err_result("boom") if calls[0] in (1, 3)
                else ToolResult.ok_result("ok"))

    seen, events, result = _run(
        monkeypatch,
        [_resp("", [_call()]), _resp("", [_call()]),
         _resp("", [_call()]), _resp("", [_call()]), _resp("完成", None)],
        exec_fn,
    )
    # 失败→成功→失败：连续失败从不超过 1，不注入
    assert not _has_reflect(seen[3])


def test_reflect_injection_capped(monkeypatch):
    """持续失败也只注入 AGENT_REFLECT_MAX_INJECTIONS 次。

    注：每次工具调用传不同参数——若同指纹反复调用会被循环熔断
    （loop_capped，2026-09-03 新增）提前截停，本测试只验证
    "反思提示注入次数上限"这一件事，故刻意避开熔断判定。
    """
    max_inj = loop.config.AGENT_REFLECT_MAX_INJECTIONS
    seen, events, result = _run(
        monkeypatch,
        [_resp("", [_call(args={"command": f"step{i}"})]) for i in range(8)]
        + [_resp("放弃", None)],
        lambda name, args: ToolResult.err_result("boom"),
    )
    notes = [p.get("note", "") for t, p in events
             if t == "thinking" and "反思" in p.get("note", "")]
    assert len(notes) == max_inj


def test_plan_text_pushed_as_token(monkeypatch):
    """有工具调用时，模型输出的规划文本也推送给前端。"""
    seen, events, result = _run(
        monkeypatch,
        [_resp("执行计划：1.创建文件 2.打开微信 3.发送", [_call()]),
         _resp("完成", None)],
        lambda name, args: ToolResult.ok_result("ok"),
    )
    tokens = "".join(p["text"] for t, p in events if t == "token")
    assert "执行计划" in tokens
    assert "1.创建文件" in tokens
