# -*- coding: utf-8 -*-
"""FastAPI 冒烟测试（阶段 1）：鉴权、路径穿越防护、公开接口。

依赖本机环境：MySQL（PHPStudy）在运行 + 项目根目录存在 .env（含 ADMIN_TOKEN）。
不依赖 Ollama（所选用例均不触发 embedding）。
"""
from fastapi.testclient import TestClient
import pytest

from app import config
from app.main import app

TOKEN = config.ADMIN_TOKEN


@pytest.fixture(autouse=True)
def disable_autorebuild(monkeypatch):
    """关闭启动时自动重建向量库：避免测试触发 Ollama embedding 或写入真实数据目录。"""
    monkeypatch.setattr(config, "AUTO_REBUILD", False)


def test_public_kbs_no_token():
    with TestClient(app) as c:
        assert c.get("/api/kbs").status_code == 200


def test_public_models_no_token():
    with TestClient(app) as c:
        assert c.get("/api/models").status_code == 200


def test_admin_requires_token():
    with TestClient(app) as c:
        assert c.get("/api/settings").status_code == 401
        assert c.get("/api/settings", headers={"X-Admin-Token": "wrong-token"}).status_code == 401


def test_admin_with_token():
    with TestClient(app) as c:
        r = c.get("/api/settings", headers={"X-Admin-Token": TOKEN})
        assert r.status_code == 200


def test_agent_endpoint_requires_token():
    # agent 接口可执行 shell，必须被令牌保护
    with TestClient(app) as c:
        r = c.post("/api/v1/agent", json={"message": "hi"})
        assert r.status_code == 401


def test_agent_settings_requires_token():
    # 运行参数接口同样受令牌保护
    with TestClient(app) as c:
        assert c.get("/api/v1/agent/settings").status_code == 401


def test_agent_settings_roundtrip():
    # 用户自定义最大工具调用步数：GET 默认 20 → PUT 调大 → GET 生效；越界 400
    with TestClient(app) as c:
        h = {"X-Admin-Token": TOKEN}
        try:
            assert c.get("/api/v1/agent/settings", headers=h).json()["max_steps"] == 20
            r = c.put("/api/v1/agent/settings", headers=h, json={"max_steps": 50})
            assert r.status_code == 200
            assert r.json()["max_steps"] == 50
            assert c.get("/api/v1/agent/settings", headers=h).json()["max_steps"] == 50
            assert c.put("/api/v1/agent/settings", headers=h, json={"max_steps": 0}).status_code == 400
            assert c.put("/api/v1/agent/settings", headers=h, json={"max_steps": 101}).status_code == 400
            assert c.put("/api/v1/agent/settings", headers=h, json={"max_steps": "abc"}).status_code == 422
        finally:
            # 恢复默认，避免影响其他测试
            c.put("/api/v1/agent/settings", headers=h, json={"max_steps": 20})


def test_delete_path_traversal_rejected():
    with TestClient(app) as c:
        headers = {"X-Admin-Token": TOKEN}
        for src in ["..\\..\\evil.md", "../evil.md", ".."]:
            r = c.post("/api/delete", headers=headers, json={"source": src, "kb": "personal"})
            assert r.status_code == 200
            assert r.json().get("error") == "非法来源名"


def test_upload_invalid_filename_rejected():
    # 纯路径成分在 embedding 之前即被拒
    with TestClient(app) as c:
        headers = {"X-Admin-Token": TOKEN}
        r = c.post("/api/upload?kb=personal", headers=headers,
                   files={"file": ("..", b"# x", "text/markdown")})
        assert r.status_code == 200
        assert r.json().get("error") == "非法文件名"
