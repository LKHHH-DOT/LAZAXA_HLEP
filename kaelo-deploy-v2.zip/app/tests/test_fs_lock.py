# -*- coding: utf-8 -*-
"""B批3 · fs_lock 可移植跨进程文件锁（app/fs_lock.py）。

覆盖：with 获取/释放、同路径二次获取超时、释放后可重获、
不同路径互不阻塞、异常退出自动释放。
"""
import pytest

from app import fs_lock


def test_acquire_release_roundtrip(tmp_path):
    p = tmp_path / "x.lock"
    with fs_lock.acquire_lock(p, timeout=1):
        pass
    # 释放后可再次获取（同进程、同路径）
    with fs_lock.acquire_lock(p, timeout=1):
        pass


def test_same_path_second_acquire_times_out(tmp_path):
    """同一路径被持锁期间，二次获取轮询到 timeout 抛 TimeoutError。"""
    p = tmp_path / "x.lock"
    with fs_lock.acquire_lock(p, timeout=1):
        with pytest.raises(TimeoutError):
            with fs_lock.acquire_lock(p, timeout=0.3):
                pass  # 不应执行到
    # 释放后恢复可获取
    with fs_lock.acquire_lock(p, timeout=1):
        pass


def test_different_paths_not_blocked(tmp_path):
    a = tmp_path / "a.lock"
    b = tmp_path / "b.lock"
    with fs_lock.acquire_lock(a, timeout=1):
        with fs_lock.acquire_lock(b, timeout=0.2):  # 不同路径不受影响
            pass


def test_context_exception_releases_lock(tmp_path):
    """with 块内抛异常 → 锁被自动释放（不泄漏句柄）。"""
    p = tmp_path / "x.lock"
    lock = fs_lock.FileLock(p, timeout=1)
    with pytest.raises(RuntimeError):
        with lock:
            raise RuntimeError("boom")
    assert lock._handle is None  # 已释放
    with fs_lock.acquire_lock(p, timeout=0.2):  # 能立刻再拿 → 确实释放了
        pass


def test_acquire_creates_lock_file(tmp_path):
    p = tmp_path / "sub" / "y.lock"
    with fs_lock.acquire_lock(p, timeout=1):
        assert p.exists()  # 目录自动创建 + 锁文件落盘
