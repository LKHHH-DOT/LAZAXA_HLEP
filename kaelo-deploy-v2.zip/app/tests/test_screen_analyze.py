# -*- coding: utf-8 -*-
"""screen_analyze 屏幕理解单元测试（app/agent/tools/gui.py）。

覆盖：重叠去重、文字合并（中英混排）、行/元素分组、端到端元素表生成与 focus 过滤。
"""
import json

from app.agent.tools import gui


# ---------- 重叠去重 ----------

def test_dedupe_keeps_higher_confidence_overlap():
    blocks = [
        {"text": "确定", "confidence": 95, "x": 100, "y": 100, "width": 40, "height": 30},
        # 与上面几乎完全重叠但置信度低 → 应被丢弃
        {"text": "确定", "confidence": 60, "x": 102, "y": 101, "width": 40, "height": 30},
        {"text": "取消", "confidence": 90, "x": 300, "y": 100, "width": 40, "height": 30},
    ]
    out = gui._dedupe_overlaps(blocks)
    assert len(out) == 2
    texts = {b["text"] for b in out}
    assert texts == {"确定", "取消"}
    assert out[0]["confidence"] == 95


def test_dedupe_keeps_non_overlapping():
    blocks = [
        {"text": "确定", "confidence": 95, "x": 100, "y": 100, "width": 40, "height": 30},
        {"text": "取消", "confidence": 90, "x": 300, "y": 100, "width": 40, "height": 30},
    ]
    assert len(gui._dedupe_overlaps(blocks)) == 2


# ---------- 文字合并 ----------

def test_join_text_chinese_tight():
    assert gui._join_text("打", "开") == "打开"


def test_join_text_english_space():
    assert gui._join_text("Open", "File") == "Open File"


def test_join_text_mixed():
    assert gui._join_text("确定", "OK") == "确定OK"


# ---------- 元素分组 ----------

def test_group_merges_same_line_nearby():
    blocks = [
        {"text": "打开", "confidence": 95, "x": 100, "y": 100, "width": 40, "height": 30},
        {"text": "文件", "confidence": 90, "x": 142, "y": 100, "width": 40, "height": 30},
        # 间隙 300-(142+40)=118 > gap_px → 单独元素
        {"text": "取消", "confidence": 90, "x": 300, "y": 100, "width": 40, "height": 30},
    ]
    els = gui._group_into_elements(blocks)
    assert len(els) == 2
    assert els[0]["text"] == "打开文件"
    assert els[1]["text"] == "取消"


def test_group_separates_different_lines():
    blocks = [
        {"text": "标题", "confidence": 95, "x": 100, "y": 100, "width": 40, "height": 30},
        {"text": "正文", "confidence": 90, "x": 100, "y": 250, "width": 40, "height": 30},
    ]
    els = gui._group_into_elements(blocks)
    assert len(els) == 2


# ---------- 端到端（假 OCR） ----------

class _FakeImg:
    def __init__(self, size):
        self._size = size

    @property
    def size(self):
        return self._size


class _FakeTS:
    class Output:
        DICT = 3

    DATA = {
        "text": ["确定", "", "取消", "Open", "File", "hello"],
        "conf": [95, 40, 90, 92, 90, 88],
        "left": [100, 0, 300, 50, 98, 0],
        "top": [100, 0, 100, 200, 200, 400],
        "width": [40, 0, 40, 40, 30, 50],
        "height": [30, 0, 30, 20, 20, 20],
    }

    def image_to_data(self, img, **kw):
        return self.DATA


def _mock_screen(monkeypatch):
    class FakePG:
        def screenshot(self, *a, **k):
            return _FakeImg((1920, 1080))

    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: FakePG())
    monkeypatch.setattr(gui, "_lazy_pytesseract", lambda: _FakeTS())
    monkeypatch.setattr(gui, "_ocr_available", lambda: "")


def test_screen_analyze_end_to_end(monkeypatch):
    _mock_screen(monkeypatch)
    res = gui._screen_analyze()
    assert res.ok
    data = json.loads(res.text)
    assert data["width"] == 1920
    assert data["total"] == 4
    texts = [e["text"] for e in data["elements"]]
    # 同行相邻合并：Open+File → "Open File"；不同行/远距元素各自独立
    assert texts == ["确定", "取消", "Open File", "hello"]
    # center 坐标正确
    assert data["elements"][0]["center"] == [120, 115]


def test_screen_analyze_focus_filter(monkeypatch):
    _mock_screen(monkeypatch)
    res = gui._screen_analyze(focus="open")
    assert res.ok
    data = json.loads(res.text)
    assert data["total"] == 1
    assert data["elements"][0]["text"] == "Open File"
