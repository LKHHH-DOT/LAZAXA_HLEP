# -*- coding: utf-8 -*-
"""结果独立验证闸门测试（2026-09-05 · A批3 verify_result 工具）。

覆盖：
  1. 工具注册与 schema（verify_result 在完整注册表中，checks 必填）
  2. file_exists：存在性断言（期望存在/不存在）
  3. file_newer_than：防"拿旧文件冒充新产物"
  4. file_contains / file_not_contains：内容断言
  5. dir_contains：目录 glob 匹配
  6. process：进程运行状态断言（mock tasklist）
  7. 边界：空 checks 报错；未知 kind 标 SKIP 且算失败；全通过 ok / 有失败 err

全部纯本地（tmp_path），不触碰 Qdrant / 网络。
"""
import os
import time

import pytest

from app.agent.tools import register_all
from app.agent.tools.verify import _run_check, verify_result
from app.agent.registry import ToolRegistry


@pytest.fixture()
def _reg():
    r = ToolRegistry()
    register_all(r)
    return r


def test_verify_tool_registered(_reg):
    tool = _reg.get("verify_result")
    assert tool is not None
    assert tool.risk == "safe"
    schema = tool.parameters
    assert schema["required"] == ["checks"]
    assert "checks" in schema["properties"]
    assert "description" in schema["properties"]


def test_file_exists_pass_and_fail(tmp_path):
    f = tmp_path / "out.txt"
    f.write_text("hi", encoding="utf-8")
    ok = verify_result([{"kind": "file_exists", "path": str(f)}])
    assert ok.ok and "验证通过" in ok.brief
    # 期望不存在但存在 → 失败
    bad = verify_result([{"kind": "file_exists", "path": str(f),
                          "expect": False}])
    assert not bad.ok and "FAIL" in bad.text


def test_file_newer_than_fresh_and_stale(tmp_path):
    f = tmp_path / "fresh.txt"
    f.write_text("x", encoding="utf-8")
    ok = verify_result([{"kind": "file_newer_than", "path": str(f),
                         "seconds": 300}])
    assert ok.ok
    # 改老 mtime → 视为旧文件，防冒充新产物
    old = f.stat().st_mtime - 3600
    os.utime(f, (old, old))
    stale = verify_result([{"kind": "file_newer_than", "path": str(f),
                            "seconds": 300}])
    assert not stale.ok and "修改于" in stale.text


def test_file_contains_and_not_contains(tmp_path):
    f = tmp_path / "report.md"
    f.write_text("本周完成 A/B 两项", encoding="utf-8")
    ok = verify_result([{"kind": "file_contains", "path": str(f),
                         "text": "完成 A/B"}])
    assert ok.ok
    bad = verify_result([{"kind": "file_contains", "path": str(f),
                          "text": "完成 C"}])
    assert not bad.ok
    not_ok = verify_result([{"kind": "file_not_contains", "path": str(f),
                             "text": "残留占位 TODO"}])
    assert not_ok.ok
    missing = verify_result([{"kind": "file_contains",
                              "path": str(tmp_path / "nope.txt"),
                              "text": "x"}])
    assert not missing.ok and "不存在" in missing.text


def test_dir_contains(tmp_path):
    (tmp_path / "a_2026.xlsx").write_text("", encoding="utf-8")
    (tmp_path / "b.txt").write_text("", encoding="utf-8")
    ok = verify_result([{"kind": "dir_contains", "dir": str(tmp_path),
                         "pattern": "*.xlsx"}])
    assert ok.ok
    bad = verify_result([{"kind": "dir_contains", "dir": str(tmp_path),
                          "pattern": "*.docx"}])
    assert not bad.ok


def test_process_assertion(monkeypatch, tmp_path):
    # mock 掉 tasklist 调用，纯测闸门逻辑
    from app.agent.tools import verify as vmod
    monkeypatch.setattr(vmod, "_tasklist_running", lambda name: True)
    ok = verify_result([{"kind": "process", "name": "notepad",
                         "running": True}])
    assert ok.ok
    bad = verify_result([{"kind": "process", "name": "notepad",
                          "running": False}])
    assert not bad.ok


def test_empty_checks_error():
    r = verify_result(checks=[])
    assert not r.ok and "不能为空" in r.text
    r2 = verify_result(checks=None)
    assert not r2.ok


def test_mixed_all_pass_and_one_fail(tmp_path):
    f = tmp_path / "ok.txt"
    f.write_text("目标内容就绪", encoding="utf-8")
    good = verify_result(
        checks=[
            {"kind": "file_exists", "path": str(f)},
            {"kind": "file_contains", "path": str(f), "text": "目标内容"},
        ],
        description="确认报告已生成且含预期内容")
    assert good.ok and "2/2" in good.text
    bad = verify_result(
        checks=[
            {"kind": "file_exists", "path": str(f)},
            {"kind": "file_newer_than", "path": str(tmp_path / "ghost.txt")},
        ])
    assert not bad.ok and "1/2" in bad.text


def test_unknown_kind_flagged_not_passed():
    out = _run_check({"kind": "magic", "whatever": 1})
    assert out.startswith("[SKIP]")
    r = verify_result([{"kind": "magic"}])
    assert not r.ok
