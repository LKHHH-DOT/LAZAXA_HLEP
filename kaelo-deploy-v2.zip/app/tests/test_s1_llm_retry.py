# -*- coding: utf-8 -*-
"""S1-1 llm.chat 瞬时错误指数退避重试测试（M1 止血第一批）。

覆盖：
  1. 429 后下一次成功：自动重试 1 次，返回内容正确且 payload 带 usage 请求
  2. 连续 5xx：重试满 _MAX_RETRIES 次后抛 RuntimeError
  3. 401（不可重试类 4xx）：立即抛，只请求 1 次
  4. 读流中途连接中断（RequestException）：退避后重试，缓冲重置，内容不含半截流
"""
import json

import pytest
import requests

from app.agent import llm


class _FakeResp:
    def __init__(self, status_code, chunks=None, text=""):
        self.status_code = status_code
        self._chunks = list(chunks or [])
        self.text = text or f"err {status_code}"

    def iter_lines(self, decode_unicode=True):
        return iter(self._chunks)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _data(obj) -> str:
    return f"data: {json.dumps(obj)}"


def _ok_resp(content="完整回答", usage=None):
    chunks = [_data({"choices": [{"delta": {"content": content}}]})]
    if usage:
        chunks.append(_data({"choices": [], "usage": usage}))
    chunks.append("data: [DONE]")
    return _FakeResp(200, chunks)


class _BrokenResp(_FakeResp):
    """iter_lines 读到一半抛连接异常（模拟流式中途断网）。"""

    def __init__(self, prefix="半截内容"):
        super().__init__(200)
        self._prefix = prefix

    def iter_lines(self, decode_unicode=True):
        yield f"data: {json.dumps({'choices': [{'delta': {'content': self._prefix}}]})}"
        raise requests.ConnectionError("connection reset by peer")


@pytest.fixture()
def _patch_sleep(monkeypatch):
    """重试退避的 time.sleep 立刻返回（不让测试空等 1s/2s）。"""
    monkeypatch.setattr(llm.time, "sleep", lambda s: None)


def _patch_post(monkeypatch, responses):
    """responses: 依调用顺序逐个返回（越界时重复最后一个）；记录调用次数。"""
    state = {"n": 0, "payloads": []}

    def fake_post(url, **kw):
        r = responses[min(state["n"], len(responses) - 1)]
        state["n"] += 1
        state["payloads"].append(kw.get("json") or {})
        if isinstance(r, Exception):
            raise r
        return r

    monkeypatch.setattr(llm.requests, "post", fake_post)
    return state


def test_retry_after_429_succeeds(_patch_sleep, monkeypatch):
    state = _patch_post(monkeypatch, [
        _FakeResp(429, text="rate limited"),
        _ok_resp("你好", usage={"prompt_tokens": 10, "completion_tokens": 5}),
    ])
    resp = llm.chat([{"role": "user", "content": "hi"}])
    assert state["n"] == 2                     # 重试 1 次
    assert resp.content == "你好"
    for p in state["payloads"]:                # payload 全程带 usage 请求（S1-2）
        assert p.get("stream_options") == {"include_usage": True}


def test_retry_exhausted_on_5xx(_patch_sleep, monkeypatch):
    state = _patch_post(monkeypatch, [_FakeResp(500, text="boom")] * 3)
    with pytest.raises(RuntimeError) as ei:
        llm.chat([{"role": "user", "content": "hi"}])
    assert "500" in str(ei.value)
    assert state["n"] == 3                     # 3 次全试完才抛


def test_no_retry_on_401(_patch_sleep, monkeypatch):
    state = _patch_post(monkeypatch, [_FakeResp(401, text="bad key")])
    with pytest.raises(RuntimeError) as ei:
        llm.chat([{"role": "user", "content": "hi"}])
    assert "401" in str(ei.value)
    assert state["n"] == 1                     # 不重试，只请求一次


def test_stream_interrupt_resets_buffer(_patch_sleep, monkeypatch):
    state = _patch_post(monkeypatch, [
        _BrokenResp(prefix="半截内容"),         # 第一次读一半断流
        _ok_resp("完整回答"),
    ])
    resp = llm.chat([{"role": "user", "content": "hi"}])
    assert state["n"] == 2
    assert resp.content == "完整回答"          # 不含半截拼串
    assert "半截" not in resp.content
