# -*- coding: utf-8 -*-
"""知识库维护算法单元测试：精确去重 / 语义去重 / 低价值判定（不依赖 Ollama embedding）。"""
import numpy as np

from app import maint, rag


def make_store(path, texts, vectors=None):
    """手工构造 VecStore（绕过 embedding）：meta 为文本列表，vectors 可自定或随机。"""
    s = rag.VecStore(str(path))
    s.meta = [
        {"text": t, "source": f"s{i}", "created_at": "2026-01-01T00:00:00"}
        for i, t in enumerate(texts)
    ]
    if vectors is not None:
        s.vectors = np.asarray(vectors, dtype=np.float32)
    else:
        s.vectors = np.random.RandomState(0).rand(len(texts), 8).astype(np.float32)
    s._build_bm25()
    return s


# ---------- 精确去重 ----------

def test_dedup_exact_removes_duplicates(tmp_path):
    store = make_store(tmp_path / "kb", ["完全相同的内容", "完全相同的内容", "不同的内容"])
    rep = maint.dedup_exact(store)
    assert rep["removed"] == 1
    assert rep["kept"] == 2
    assert rep["total_before"] == 3
    assert store.size == 2


def test_dedup_exact_no_dup(tmp_path):
    store = make_store(tmp_path / "kb", ["甲", "乙", "丙"])
    rep = maint.dedup_exact(store)
    assert rep["removed"] == 0
    assert store.size == 3


# ---------- 语义去重 ----------

def test_dedup_semantic_merges_similar(tmp_path):
    # v0 与 v1 高度相似（>0.9），v2 完全不同
    v0 = np.array([1.0, 0.0, 0.0, 0.0])
    v1 = np.array([1.0, 0.05, 0.0, 0.0])
    v2 = np.array([0.0, 0.0, 1.0, 0.0])
    store = make_store(tmp_path / "kb", ["苹果很好吃", "苹果很好吃哦", "今天下雨"],
                       vectors=[v0, v1, v2])
    rep = maint.dedup_semantic(store)
    assert rep["merged"] >= 1
    assert rep["kept"] <= 2


def test_dedup_semantic_small_store(tmp_path):
    store = make_store(tmp_path / "kb", ["只有一块"])
    rep = maint.dedup_semantic(store)
    assert rep["merged"] == 0
    assert rep["kept"] == 1


def test_semantic_similar_pairs_blocked_matches_full_matrix(tmp_path):
    """分块相似对与全矩阵结果一致（防分块重构回归）。

    构造 600 块（跨多个 block=256 批次），其中若干块高度相似；
    断言：分块实现找出的相似对集合 == 全矩阵实现找出的对集合。
    """
    rng = np.random.RandomState(42)
    v = rng.rand(600, 8).astype(np.float32)
    v[100] = v[101] * 0.99 + 0.01 * v[0]      # 高度相似对（>0.9）
    v[300] = v[299] * 0.995
    v[500] = v[501] * 0.99 + 0.02 * v[10]
    texts = [f"文本{i}" for i in range(600)]
    store = make_store(tmp_path / "kb", texts, vectors=v)

    pairs = maint._semantic_similar_pairs(store, threshold=0.90, block=256)

    # 参照：全矩阵实现（仅用于测试对照）
    norms = np.linalg.norm(v, axis=1, keepdims=True)
    full = (v @ v.T) / (norms @ norms.T + 1e-9)
    expected = {(i, j) for i in range(600) for j in range(i + 1, 600) if full[i][j] > 0.90}
    got = {(i, j) for _, i, j in pairs}
    assert got == expected
    # 结果降序、且覆盖到三个已知相似对
    assert len(pairs) == len(expected) >= 3
    assert all(pairs[k][0] >= pairs[k + 1][0] for k in range(len(pairs) - 1))


def test_save_is_atomic_no_tmp_leftover(tmp_path):
    """原子写：save 后无 .tmp 残留，且文件可正常 load（阶段 2 可靠性）。"""
    store = make_store(tmp_path / "kb", ["第一块", "第二块"])
    store.save()
    files = sorted(p.name for p in (tmp_path / "kb").glob("*"))
    assert "vectors.npy" in files and "meta.json" in files
    assert not any(f.endswith(".tmp") or f.endswith(".tmp.npy") for f in files)
    # 落盘后可重新加载，内容一致
    loaded = rag.VecStore(str(tmp_path / "kb")).load()
    assert loaded.size == 2
    assert [m["text"] for m in loaded.meta] == ["第一块", "第二块"]


# ---------- 低价值判定 ----------

def test_is_low_value_too_short():
    low, reason = maint._is_low_value("好的")
    assert low
    assert "过短" in reason


def test_is_low_value_valid_text():
    low, _ = maint._is_low_value("这是一段超过十二个字的正常有效文本内容说明")
    assert not low


def test_prune_low_value(tmp_path):
    texts = ["好的", "这是一段超过十二个字的正常有效文本内容说明"]
    store = make_store(tmp_path / "kb", texts)
    rep = maint.prune_low_value(store)
    assert rep["pruned"] == 1
    assert rep["kept"] == 1
    assert store.size == 1
    # 冷库文件已归档
    cold_path = tmp_path / "kb" / "cold_meta.json"
    assert cold_path.exists()


# ---------- 整合维护 ----------

def test_run_maintenance(tmp_path):
    texts = ["重复文本", "重复文本", "短", "这是一段超过十二个字的正常有效文本内容说明"]
    store = make_store(tmp_path / "kb", texts)
    rep = maint.run_maintenance(store)
    assert "exact_dedup" in rep["steps"] and "semantic_merge" in rep["steps"] and "low_value_prune" in rep["steps"]
