# -*- coding: utf-8 -*-
"""笔记到期提醒解析单元测试（app/reminders.py）。

纯函数测试：日期解析 / 单篇扫描 / vault 扫描汇总。
入库（db.add_reminder 去重）依赖 MySQL，留待 E2E 验证。
"""
from datetime import date

from app.reminders import _resolve_date, scan_note, scan_vault_for_reminders


# ---------- 日期解析 ----------

def test_resolve_today():
    assert _resolve_date("今天下午3点去拿体检报告", date(2026, 8, 16)) == date(2026, 8, 16)


def test_resolve_tomorrow():
    assert _resolve_date("明天记得交房租", date(2026, 8, 16)) == date(2026, 8, 17)


def test_resolve_specific_month_day():
    assert _resolve_date("9月1日截止交作业", date(2026, 8, 16)) == date(2026, 9, 1)


def test_resolve_past_date_rolls_next_year():
    # 8 月看到 3 月 15 日 → 视为明年
    assert _resolve_date("3月15日要做年报", date(2026, 8, 16)) == date(2027, 3, 15)


def test_resolve_no_date_returns_none():
    assert _resolve_date("记得喝水", date(2026, 8, 16)) is None


def test_resolve_invalid_date_returns_none():
    assert _resolve_date("13月40日要开会", date(2026, 8, 16)) is None


def test_resolve_priority_today_over_month_day():
    # 一行同时出现"今天"与其它日期 → 今天优先
    assert _resolve_date("今天(12月1日)截止", date(2026, 8, 16)) == date(2026, 8, 16)


# ---------- 单篇扫描 ----------

def test_scan_note_extracts_reminder(tmp_path):
    f = tmp_path / "note.md"
    f.write_text("# 待办\n\n明天下午3点去拿体检报告\n\n# 杂记\n只是普通记录\n",
                 encoding="utf-8")
    rows = scan_note(str(f), "待办/体检.md", date(2026, 8, 16))
    assert len(rows) == 1
    assert rows[0][0] == date(2026, 8, 17)
    assert "体检报告" in rows[0][1]


def test_scan_note_skips_trigger_without_date(tmp_path):
    f = tmp_path / "note.md"
    f.write_text("记得喝水\n", encoding="utf-8")
    assert scan_note(str(f), "x.md", date(2026, 8, 16)) == []


def test_scan_note_skips_headings_and_code(tmp_path):
    f = tmp_path / "note.md"
    f.write_text("# 明天交作业\n```\n明天记得改bug\n```\n", encoding="utf-8")
    rows = scan_note(str(f), "x.md", date(2026, 8, 16))
    # 标题行被跳过；代码块行被跳过
    assert rows == []


def test_scan_note_truncates_long_line(tmp_path):
    f = tmp_path / "note.md"
    f.write_text("明天要交的是一份特别特别特别长的报告" + "啊" * 500 + "\n", encoding="utf-8")
    rows = scan_note(str(f), "x.md", date(2026, 8, 16))
    assert len(rows[0][1]) <= 200


def test_scan_note_missing_file_ok(tmp_path):
    assert scan_note(str(tmp_path / "no.md"), "no.md", date(2026, 8, 16)) == []


# ---------- vault 扫描汇总 ----------

def test_scan_vault_counts_added(monkeypatch, tmp_path):
    """多条笔记 → 汇总数量正确；去重幂等由 db 层保证（这里只数行）。"""
    (tmp_path / "a.md").write_text("明天记得开会\n", encoding="utf-8")
    (tmp_path / "b.md").write_text("今天截止交表\n", encoding="utf-8")
    (tmp_path / ".obsidian").mkdir()

    added = []
    monkeypatch.setattr("app.agent.tools.obsidian._walk_vault_md",
                        lambda: [("a.md", str(tmp_path / "a.md")),
                                 ("b.md", str(tmp_path / "b.md"))])
    monkeypatch.setattr("app.reminders.db.add_reminder",
                        lambda content, rel, d: added.append((content, rel, d)) or True)

    assert scan_vault_for_reminders() == 2
    assert len(added) == 2
