# -*- coding: utf-8 -*-
"""S1-3 解析失败回灌 / S1-5 输入长度护栏测试（M1 止血第一批）。

S1-3 覆盖：
  1. 工具参数带 __parse_error__ 哨兵 → registry.execute 不执行 fn，返回明确错误
S1-5 覆盖：
  2. /api/v1/agent 超长指令 → HTTP 400（护栏在最前，不触发任务/记忆副作用）
  3. /api/chat 超长提问 → HTTP 400
"""
import pytest
from fastapi.testclient import TestClient

from app import config
from app.agent.registry import Tool, ToolRegistry, ToolResult


# ---------- S1-3：__parse_error__ 回灌后执行前拦截 ----------

def test_parse_error_args_not_executed():
    """模型侧 JSON 解析失败 → args 带 __parse_error__：fn 绝不执行。"""
    calls = []

    def fn(**kw):
        calls.append(kw)
        return ToolResult.ok_result("执行成功")

    reg = ToolRegistry()
    reg.register(Tool(
        name="demo_write",
        description="测试用",
        parameters={"type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"]},
        risk="safe", timeout=5, fn=fn,
    ))
    r = reg.execute("demo_write",
                    {"__parse_error__": "JSONDecodeError: Unterminated string", "path": "a"})
    assert not r.ok
    assert "参数解析失败" in r.error
    assert "未执行" in r.error
    assert calls == []                 # 拿残缺参数硬跑 = 放大漂移，必须拦


# ---------- S1-5：输入长度护栏 ----------

TOKEN = config.ADMIN_TOKEN
_LONG = "长" * (config.AGENT_MAX_INPUT_CHARS + 1)


@pytest.fixture(autouse=True)
def disable_autorebuild(monkeypatch):
    """关闭启动时自动重建向量库：避免测试触发 Ollama embedding 或写入真实数据目录。"""
    monkeypatch.setattr(config, "AUTO_REBUILD", False)


def test_agent_oversized_message_400():
    with TestClient(app_import()) as c:
        r = c.post("/api/v1/agent",
                   headers={"X-Admin-Token": TOKEN},
                   json={"message": _LONG})
        assert r.status_code == 400
        assert "指令过长" in r.json()["detail"]


def test_chat_oversized_message_400():
    with TestClient(app_import()) as c:
        r = c.post("/api/chat", json={"message": _LONG, "kb": "personal"})
        assert r.status_code == 400
        assert "提问过长" in r.json()["detail"]


def app_import():
    """延迟 import app.main（避免收集期副作用）。"""
    from app.main import app
    return app
