# -*- coding: utf-8 -*-
"""后台任务单元测试（"边聊边做"通话督导模式 · app/jobs.py + tools/supervise.py）。

覆盖：4 个监督工具注册与 schema、worker 系统提示、worker 工具白名单过滤、
JobManager 调度（互斥排队/自动衔接/取消/传话）、worker 事件适配器
（审批挂起→恢复）、后台 worker 每轮消费老板传话（inbox 注入）。
"""
import asyncio

import pytest

from app.agent import loop
from app.agent.loop import _filter_tools, _make_subagent_emitter, _system_prompt
from app.agent.registry import Tool, ToolRegistry, ToolResult
from app.agent.tools import supervise
from app.agent.llm import ChatResponse, ToolCall
from app import config
from app import jobs
from app.jobs import JobManager, _make_job_emitter


def _run(coro):
    return asyncio.run(coro)


# ---------- 监督工具注册 ----------

def test_supervise_tools_registered():
    reg = ToolRegistry()
    supervise.register_all(reg)
    for name in ("delegate_job", "check_jobs", "call_worker", "cancel_job"):
        tool = reg.get(name)
        assert tool is not None, name
        assert tool.risk == "safe", name  # 只是调度，真正危险操作由 worker 内部审批
    schemas = {s["function"]["name"]: s["function"] for s in reg.openai_schemas()}
    assert schemas["delegate_job"]["parameters"]["required"] == ["task"]
    assert schemas["call_worker"]["parameters"]["required"] == ["job_id", "instruction"]
    assert schemas["cancel_job"]["parameters"]["required"] == ["job_id"]


def test_supervise_tools_in_full_registry():
    from app.agent.tools import register_all
    reg = ToolRegistry()
    register_all(reg)
    names = reg.names()
    for name in ("delegate_job", "check_jobs", "call_worker", "cancel_job"):
        assert name in names


def test_worker_system_prompt():
    p = _system_prompt(role="worker", depth=1)
    assert "后台操作员" in p
    assert "老板新指令" in p
    p_main = _system_prompt()
    assert "后台操作员" not in p_main


# ---------- worker 工具白名单 ----------

def _fake_schemas_all():
    return [{"function": {"name": n}} for n in
            ("delegate_job", "check_jobs", "call_worker", "cancel_job",
             "subagent_spawn", "subagent_parallel", "run_command", "screen_analyze")]


def test_worker_filter_excludes_management_tools():
    # 模拟 jobs 的白名单：全量 - 管理/委派类
    names = [s["function"]["name"] for s in _fake_schemas_all()]
    allowed = [n for n in names if n not in jobs._MANAGEMENT_TOOLS]
    assert "delegate_job" not in allowed
    assert "cancel_job" not in allowed
    assert "subagent_spawn" not in allowed
    assert "run_command" in allowed
    out = _filter_tools(_fake_schemas_all(), allowed, depth=1)
    got = {s["function"]["name"] for s in out}
    assert got == set(allowed)


# ---------- JobManager 调度 ----------

def test_launch_runs_immediately(monkeypatch):
    async def _fake_runner(**kw):
        assert kw["role"] == "worker"
        # 管理/委派类工具必须在 worker 可见集之外
        for banned in jobs._MANAGEMENT_TOOLS:
            assert banned not in kw["tool_filter"]
        return {"reply": "干完了", "steps": 1, "ms": 5, "error": ""}

    mgr = JobManager()
    monkeypatch.setattr(jobs, "_TASK_RUNNER", _fake_runner)

    async def go():
        jid = await mgr._launch_async("把桌面截图发我", "relaxed")
        job = mgr.get(jid)
        assert job.state == jobs.STATE_QUEUED or job.state == jobs.STATE_RUNNING
        # 等终态
        for _ in range(100):
            if job.state in (jobs.STATE_DONE, jobs.STATE_FAILED, jobs.STATE_CANCELLED):
                break
            await asyncio.sleep(0.01)
        assert job.state == jobs.STATE_DONE
        assert job.reply == "干完了"
        assert mgr.list_jobs()[0]["state"] == "done"
    _run(go())


def test_second_launch_queued_until_first_done(monkeypatch):
    # 串行回归：把并行上限压到 1，验证"排队→前一个结束自动衔接"仍成立
    monkeypatch.setattr(config, "AGENT_JOB_PARALLEL", 1)
    started = []

    async def _slow_runner(**kw):
        started.append(kw.get("parent_task_id"))
        await asyncio.sleep(0.05)
        return {"reply": f"done {kw['parent_task_id']}", "steps": 1, "ms": 0, "error": ""}

    mgr = JobManager()
    monkeypatch.setattr(jobs, "_TASK_RUNNER", _slow_runner)

    async def go():
        jid_a = await mgr._launch_async("任务A", "relaxed")
        job_a = mgr.get(jid_a)
        assert job_a.state == jobs.STATE_RUNNING
        jid_b = await mgr._launch_async("任务B", "relaxed")
        job_b = mgr.get(jid_b)
        assert job_b.state == jobs.STATE_QUEUED  # 单槽已占：排队
        for _ in range(200):
            if (mgr.get(jid_a).state == jobs.STATE_DONE
                    and mgr.get(jid_b).state == jobs.STATE_DONE):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid_a).state == jobs.STATE_DONE
        assert mgr.get(jid_b).state == jobs.STATE_DONE  # 前一个结束自动衔接
        assert mgr._running == set()
        assert not mgr._queued
    _run(go())


def test_cancel_running(monkeypatch):
    release = asyncio.Event()

    async def _blocking_runner(**kw):
        await release.wait()  # 挂起直到被取消
        return {"reply": "", "steps": 0, "ms": 0, "error": ""}

    mgr = JobManager()
    monkeypatch.setattr(jobs, "_TASK_RUNNER", _blocking_runner)

    async def go():
        jid = await mgr._launch_async("长任务", "relaxed")
        assert mgr.get(jid).state == jobs.STATE_RUNNING
        assert await mgr._cancel_async(jid) is True
        for _ in range(100):
            if mgr.get(jid).state in (jobs.STATE_CANCELLED, jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid).state == jobs.STATE_CANCELLED
        assert mgr._running == set()
        assert await mgr._cancel_async(jid) is False  # 终态不可再取消
    _run(go())


def test_cancel_queued(monkeypatch):
    monkeypatch.setattr(config, "AGENT_JOB_PARALLEL", 1)  # 单槽使 B 必然排队

    async def _slow_runner(**kw):
        await asyncio.sleep(0.1)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    mgr = JobManager()
    monkeypatch.setattr(jobs, "_TASK_RUNNER", _slow_runner)

    async def go():
        jid_a = await mgr._launch_async("A", "relaxed")
        jid_b = await mgr._launch_async("B", "relaxed")
        assert mgr.get(jid_b).state == jobs.STATE_QUEUED
        assert await mgr._cancel_async(jid_b) is True
        assert mgr.get(jid_b).state == jobs.STATE_CANCELLED  # 排队中直接移除
        # 取消排队后应不再占用后续执行
        for _ in range(200):
            if mgr.get(jid_a).state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid_a).state == jobs.STATE_DONE
        assert mgr._running == set()  # B 已取消，不会误启动
    _run(go())


def test_send_instruction(monkeypatch):
    mgr = JobManager()

    async def _runner(**kw):
        await asyncio.sleep(0.05)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    async def go():
        monkeypatch.setattr(jobs, "_TASK_RUNNER", _runner)
        jid = await mgr._launch_async("A", "relaxed")
        assert mgr.send_instruction(jid, "先别做那步") is True
        assert mgr.send_instruction("job-none", "x") is False
        # 排队中的任务也能收话（等它启动后消费）
        jid2 = await mgr._launch_async("B", "relaxed")
        assert mgr.send_instruction(jid2, "改成做别的") is True
        # 收尾：等两个任务都跑完，避免事件循环关闭时残留挂起任务
        for _ in range(200):
            if (mgr.get(jid).state in (jobs.STATE_DONE, jobs.STATE_FAILED)
                    and mgr.get(jid2).state in (jobs.STATE_DONE, jobs.STATE_FAILED)):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid2).state == jobs.STATE_DONE
    _run(go())


# ---------- worker 事件适配器 ----------

def test_emitter_approval_flow():
    async def go():
        job = jobs.Job("job-test", "任务", "relaxed")
        emit = _make_job_emitter(job)
        await emit("approval_request", {"task_id": "t-1", "tool": "write_file",
                                        "args": {"path": "x"}, "risk": "sensitive"})
        assert job.state == jobs.STATE_AWAITING
        assert job.pending_approval and job.pending_approval["tool"] == "write_file"
        # 审批通过后 worker 恢复 → 下一个普通事件把状态切回 running 并清审批
        await emit("tool_result", {"name": "write_file", "ok": True, "brief": "成功"})
        assert job.state == jobs.STATE_RUNNING
        assert job.pending_approval is None
        assert any(a["kind"] == "tool_result" for a in job.activity)
        # done/error 事件不写入（终态由 _drive 处理）
        await emit("done", {"reply": "x"})
        await emit("tool_call", {"name": "x", "display_name": "调用 x"})
        assert any(a["kind"] == "tool_call" for a in job.activity)
    _run(go())


def test_job_to_dict_and_activity_limit(monkeypatch):
    async def go():
        job = jobs.Job("job-d", "任务", "relaxed")
        emit = _make_job_emitter(job)
        for i in range(config.AGENT_JOB_ACTIVITY_LIMIT + 10):
            await emit("thinking", {"step": i})
        d = job.to_dict()
        assert d["id"] == "job-d" and d["state"] == jobs.STATE_QUEUED
        assert len(d["activity"]) <= config.AGENT_JOB_ACTIVITY_LIMIT
        assert "pending_approval" in d
        # to_dict(detail=False) 不携带 activity（列表接口省流量）
        assert "activity" not in job.to_dict(detail=False)
    _run(go())


# ---------- 后台任务状态块（注入主对话） ----------

def test_context_block_empty_and_content():
    mgr = JobManager()
    assert mgr.context_block() == ""  # 无任务 → 空
    mgr._jobs["job-x"] = jobs.Job("job-x", "测试任务", "relaxed")
    mgr._order.append("job-x")
    block = mgr.context_block()
    assert "job-x" in block and "测试任务" in block


# ---------- 后台 worker 消费老板传话（run_agent_task + inbox） ----------

def test_run_agent_task_consumes_inbox(monkeypatch):
    """整链路：worker 任务跑两轮后，老板传话被注入为「老板新指令」user 消息。"""
    import sys

    class FakeDb:
        @staticmethod
        def log_agent_task(*a, **kw):
            return True

    # 隔离 db 副作用（_audit 落库静默）
    sys.modules["app.db"] = FakeDb
    try:
        # 自建注册表：仅一个 echo 工具（risk=safe 自动执行，不走审批）
        reg = ToolRegistry()
        reg.register(Tool(name="echo_job", description="echo",
                          parameters={"type": "object", "properties": {}},
                          risk="safe", timeout=5,
                          fn=lambda **kw: ToolResult.ok_result("回声")))
        monkeypatch.setattr(loop, "registry", reg)

        seen_user_contents: list[str] = []
        boss_put = {"done": False}

        def fake_chat(messages, tools=None, on_token=None, timeout=300):
            # 记录最近一条 user 消息（用于断言老板传话是否注入）
            for m in messages:
                if m["role"] == "user":
                    seen_user_contents.append(m["content"])
            n = len(seen_user_contents)
            if not boss_put["done"]:
                # 第一轮：模型要调 echo 工具（同时我们趁机把老板指令放进 inbox，
                # 下一轮循环开头 drain 时被读到）
                boss_put["done"] = True
                return ChatResponse("", [ToolCall("c1", "echo_job", {})], None)
            return ChatResponse("任务完成", [], None)

        monkeypatch.setattr(loop.llm, "chat", fake_chat)

        async def go():
            inbox = asyncio.Queue()
            inbox.put_nowait("老板：改成先做 B")
            summary = await loop.run_agent_task("干一个任务", role="worker",
                                                mode="relaxed", inbox=inbox)
            assert summary.get("error", "") == ""
        _run(go())
        # 老板指令应作为 user 消息注入过一次（含"老板新指令"标记）
        assert any("老板新指令" in c and "改成先做 B" in c for c in seen_user_contents)
    finally:
        del sys.modules["app.db"]


# ---------- supervisor 工具 fn 边界（无需事件循环） ----------

def test_call_worker_unknown_job():
    r = supervise._call_worker("job-nope", "别做了")
    assert not r.ok and "不存在" in r.error


def test_cancel_job_unknown_job():
    r = supervise._cancel_job("job-nope")
    assert not r.ok


def test_check_jobs_empty(monkeypatch):
    from app import jobs as _jobs
    mgr = _jobs.JobManager()
    monkeypatch.setattr(_jobs, "manager", mgr)
    r = supervise._check_jobs()
    assert r.ok and "没有后台任务" in r.text


def test_make_subagent_emitter_unchanged():
    # 兼容回归：子代理发射器仍只透传审批
    got = []

    async def emit(t, p):
        got.append(t)

    inner = _make_subagent_emitter(emit)

    async def go():
        await inner("token", {})
        await inner("approval_request", {"task_id": "t"})
    _run(go())
    assert got == ["approval_request"]


# ---------- 任务事务性（P4 · agent_jobs 落盘 / 重启恢复 / 指纹幂等） ----------

class _FakeJobStore:
    """内存假库：替换 jobs._db_save_job / _db_find_active / _db_load_pending /
    _db_close_interrupted 四个落盘钩子（不改一行生产代码）。"""

    def __init__(self, rows=None):
        self.rows = rows or []          # 形如 db.list_agent_job_pending 的行
        self.snapshots: list[dict] = []  # 每次 _db_save_job 时复制当时的快照
        self.closed: list[str] = []      # 被标记 interrupted 的 job_id

    def save_job(self, job):
        self.snapshots.append({
            "id": job.id, "state": job.state, "reply": job.reply,
            "error": job.error, "steps": job.steps, "ms": job.ms,
            "fingerprint": job.fingerprint, "round_id": job.round_id,
        })
        # upsert 到 rows（同真实 agent_jobs：按 job_id 幂等），find_active 可据此判活跃
        for r in self.rows:
            if r.get("job_id") == job.id:
                r.update(status=job.state, fingerprint=job.fingerprint,
                         round_id=job.round_id)
                return
        self.rows.append({"job_id": job.id, "fingerprint": job.fingerprint,
                          "task": job.task, "mode": job.mode,
                          "round_id": job.round_id, "status": job.state})

    def find_active(self, fingerprint):
        for r in self.rows:
            if (r.get("fingerprint") == fingerprint
                    and r.get("status") in ("queued", "running", "awaiting_approval")):
                return r.get("job_id", "")
        return ""

    def load_pending(self):
        return [dict(r) for r in self.rows
                if r.get("status") in ("queued", "running", "awaiting_approval")]

    def close_interrupted(self, job_id, ended_at=None):
        self.closed.append(job_id)
        for r in self.rows:
            if r.get("job_id") == job_id:
                r["status"] = "interrupted"


def _hook_store(monkeypatch, store):
    monkeypatch.setattr(jobs, "_db_save_job", store.save_job)
    monkeypatch.setattr(jobs, "_db_find_active", store.find_active)
    monkeypatch.setattr(jobs, "_db_load_pending", store.load_pending)
    monkeypatch.setattr(jobs, "_db_close_interrupted", store.close_interrupted)


@pytest.fixture(autouse=True)
def _persistence_hooks_inert(monkeypatch):
    """全文件默认不碰真实 MySQL：落盘四钩子替换为纯内存 no-op。

    既防止本机 MySQL 的残留 agent_jobs 行干扰调度语义（曾导致同指纹排队
    任务被误判为已存在而吞掉），也让用例不污染库；P4 落盘用例再各自用
    _FakeJobStore 换上带断言的实现。
    """
    _hook_store(monkeypatch, _FakeJobStore())


def test_p4_recover_queued_resumes_and_running_interrupted(monkeypatch):
    """重启恢复：queued 从未开跑 → 自动续跑至 done；running 正在执行 →
    标 interrupted 不重跑（内存记失败态可展示）。"""
    store = _FakeJobStore(rows=[
        {"job_id": "job-q", "fingerprint": "fp-q", "task": "排队整理桌面",
         "mode": "relaxed", "round_id": "r-q", "status": "queued"},
        {"job_id": "job-r", "fingerprint": "fp-r", "task": "正在整理照片",
         "mode": "relaxed", "round_id": "r-r", "status": "running"},
    ])
    _hook_store(monkeypatch, store)
    ran: list[str] = []

    async def _runner(**kw):
        ran.append(kw.get("parent_task_id", ""))
        return {"reply": f"done {kw.get('parent_task_id')}", "steps": 1,
                "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _runner)
    mgr = JobManager()

    async def go():
        n = await mgr.recover_pending()
        assert n == 2
        job_q, job_r = mgr.get("job-q"), mgr.get("job-r")
        assert job_q is not None and job_q.round_id == "r-q"
        for _ in range(200):
            if job_q.state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        # queued 续跑完成；running 被标 interrupted、绝不开跑
        assert job_q.state == jobs.STATE_DONE
        assert job_r.state == jobs.STATE_FAILED
        assert job_r.stop_reason == "interrupted"
        assert "（副作用不可重放" in job_r.error
        assert job_r.round_id == "r-r"
        assert store.closed == ["job-r"]
        assert "job-q" in ran and "job-r" not in ran
        # 续跑首行已落盘（running），后续 _drive 终态快照也在
        assert store.snapshots[0]["state"] == jobs.STATE_RUNNING
        assert store.snapshots[0]["id"] == "job-q"
        assert store.snapshots[-1]["state"] == jobs.STATE_DONE
    _run(go())


def test_p4_recover_idempotent_second_call_zero(monkeypatch):
    store = _FakeJobStore(rows=[
        {"job_id": "job-a", "fingerprint": "fp-a", "task": "A", "mode": "relaxed",
         "round_id": "", "status": "queued"},
    ])
    _hook_store(monkeypatch, store)

    async def _runner(**kw):
        return {"reply": "ok", "steps": 0, "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _runner)
    mgr = JobManager()

    async def go():
        assert await mgr.recover_pending() == 1
        assert await mgr.recover_pending() == 0  # 幂等闸
        job_a = mgr.get("job-a")
        for _ in range(200):
            if job_a.state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        assert job_a.state == jobs.STATE_DONE  # 只跑了一次
    _run(go())


def test_p4_duplicate_fingerprint_returns_existing(monkeypatch):
    """调度幂等：同 指令+模式+轮次 的非终态任务重复入队 → 返回既有 job_id。"""
    store = _FakeJobStore()
    _hook_store(monkeypatch, store)

    async def _slow_runner(**kw):
        await asyncio.sleep(0.1)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _slow_runner)
    mgr = JobManager()

    async def go():
        jid1 = await mgr._launch_async("把桌面截图发我", "relaxed")
        jid2 = await mgr._launch_async("把桌面截图发我", "relaxed")  # 内存去重命中
        assert jid2 == jid1
        assert len(mgr._jobs) == 1
        # 进程内没有但落盘有同指纹活跃行 → 直接返回落盘 job_id（重启竞态防御）
        fp = jobs._fingerprint("冷启动残留任务", "relaxed", "")
        store.rows.append({"job_id": "job-db", "fingerprint": fp,
                           "task": "冷启动残留任务", "mode": "relaxed",
                           "round_id": "", "status": "running"})
        jid3 = await mgr._launch_async("冷启动残留任务", "relaxed")
        assert jid3 == "job-db"
        # 收尾：等 jid1 跑完释放互斥槽，避免事件循环残留挂起任务
        for _ in range(200):
            if mgr.get(jid1).state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        assert mgr._running == set()
    _run(go())


def test_p4_terminal_snapshot_persisted_done_and_failed(monkeypatch):
    """job 级终态落库：done/failed 都应有末次快照可查（含 reply/error/steps）。"""
    store = _FakeJobStore()
    _hook_store(monkeypatch, store)
    results = iter([
        {"reply": "整理完了", "steps": 3, "ms": 12, "error": ""},  # 成功
        {"reply": "", "steps": 1, "ms": 5, "error": "目标应用崩溃"},  # 失败
    ])

    async def _runner(**kw):
        return next(results)

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _runner)
    mgr = JobManager()

    async def go():
        for i in range(2):
            before = len(store.snapshots)
            jid = await mgr._launch_async(f"P4 任务{i}", "relaxed", round_id=f"r-{i}")
            job = mgr.get(jid)
            for _ in range(200):
                if job.state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                    break
                await asyncio.sleep(0.01)
            assert store.snapshots[before]["id"] == jid  # 落盘首行（running）
            tail = store.snapshots[-1]
            assert tail["round_id"] == f"r-{i}"
        # 末次快照 = 第二个 job 的终态（失败）
        assert store.snapshots[-1]["state"] == jobs.STATE_FAILED
        assert "目标应用崩溃" in store.snapshots[-1]["error"]
        # 第一个 job 终态快照是 done
        snap_done = next(s for s in store.snapshots if s["id"].startswith("job-")
                         and s["state"] == jobs.STATE_DONE)
        assert snap_done["reply"] == "整理完了" and snap_done["steps"] == 3
        assert mgr._running == set()
    _run(go())


def test_p4_audit_dedupe_same_task_id_no_dup_row(monkeypatch):
    """审计幂等：同 task_id 重复落库只产生一行（B批3 起走唯一索引兜底的
    INSERT IGNORE 原子路径，冲突整行静默忽略，无"先查后插"竞态窗口）。"""
    from app import db
    inserted: set = set()

    def fake_execute(sql, args=None, fetch_one=False):
        sql = (sql or "").strip()
        if sql.startswith("SHOW COLUMNS"):
            return [{"Field": "task_id"}, {"Field": "parent_task_id"},
                    {"Field": "round_id"}]
        if sql.startswith("SHOW INDEX"):
            return [{"Key_name": "idx_task_uq", "Non_unique": 0},
                    {"Key_name": "idx_parent", "Non_unique": 1}]
        if sql.startswith("ALTER"):
            return None
        if sql.startswith("SELECT id FROM agent_tasks"):
            tid = (args or [None])[0]
            return {"id": 1} if tid in inserted else None
        if "INSERT IGNORE INTO agent_tasks" in sql:
            # 模拟唯一索引：task_id 已存在 → rowcount=0，不产生新行
            tid = (args or [""])[0]
            if tid not in inserted:
                inserted.add(tid)
            return None
        if sql.startswith("INSERT INTO agent_tasks"):
            inserted.add((args or [""])[0])
            return None
        return None

    monkeypatch.setattr(db, "_execute", fake_execute)
    # 迁移惰性闸复位：保证走一遍 SHOW/幂等分支（已置位也无碍，fake 兼容）
    db._MIGRATED_PARENT_COL = False
    db._MIGRATED_TASK_UNIQUE = False
    assert db.log_agent_task("t-dup", "write_file", {"path": "x"})
    assert db.log_agent_task("t-dup", "write_file", {"path": "x"})
    assert len(inserted) == 1  # 同 task_id 只落一行（IGNORE 静默去重）
    db.log_agent_task("t-other", "read_file")
    assert len(inserted) == 2  # 不同 task_id 正常写入


def test_p4_cancel_queued_persists_terminal(monkeypatch):
    """排队中取消必须落盘终态：否则 DB 留陈旧 queued 行，让同指纹新任务
    被误判已存在而吞掉（test_send_instruction 曾因此偶发失败）。"""
    monkeypatch.setattr(config, "AGENT_JOB_PARALLEL", 1)  # 单槽使 B 必然排队
    store = _FakeJobStore()
    _hook_store(monkeypatch, store)

    async def _slow_runner(**kw):
        await asyncio.sleep(0.1)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _slow_runner)
    mgr = JobManager()

    async def go():
        jid_a = await mgr._launch_async("排头任务", "relaxed")
        jid_b = await mgr._launch_async("排队被取消任务", "relaxed")
        assert mgr.get(jid_b).state == jobs.STATE_QUEUED
        assert await mgr._cancel_async(jid_b) is True
        # 内存终态 + 落盘终态：不再残留活跃 queued 行
        assert mgr.get(jid_b).state == jobs.STATE_CANCELLED
        fp_b = jobs._fingerprint("排队被取消任务", "relaxed", "")
        assert store.find_active(fp_b) == ""
        tail = store.snapshots[-1]
        assert tail["state"] == jobs.STATE_CANCELLED
        assert tail["id"] == jid_b
        # 收尾：等排头任务完成释放互斥槽
        for _ in range(200):
            if mgr.get(jid_a).state in (jobs.STATE_DONE, jobs.STATE_FAILED):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid_a).state == jobs.STATE_DONE
        assert mgr._running == set()
    _run(go())


# ---------- 安静契约（B批3 · 终态超窗不再反复注入主对话摘要） ----------

def test_context_block_quiet_for_old_terminal():
    import time

    mgr = JobManager()
    now = time.time()
    # 旧终态：结束时间已超过安静窗口（早就不该再打扰老板）
    old = jobs.Job("job-old", "昨天的任务", "relaxed")
    old.state = jobs.STATE_DONE
    old.ended_at = now - jobs._TERMINAL_QUIET_SECONDS - 60
    old.reply = "早已完成"
    # 新终态：窗口内刚结束（老板可能马上追问结果 → 照常注入）
    fresh = jobs.Job("job-fresh", "刚完成的任务", "relaxed")
    fresh.state = jobs.STATE_DONE
    fresh.ended_at = now - 10
    fresh.reply = "刚干完"
    # 活跃：始终注入（督导模式核心）
    active = jobs.Job("job-act", "正在跑的任务", "relaxed")
    active.state = jobs.STATE_RUNNING
    for j in (old, fresh, active):
        mgr._jobs[j.id] = j
        mgr._order.append(j.id)

    block = mgr.context_block()
    assert "job-old" not in block and "昨天的任务" not in block
    assert "job-fresh" in block
    assert "job-act" in block


def test_context_block_all_terminal_quiet_after_window():
    import time

    mgr = JobManager()
    now = time.time()
    # 全为超窗终态（旧失败/旧取消）→ 摘要为空，不为历史任务反复制造噪音
    for jid, st in (("job-f", jobs.STATE_FAILED), ("job-c", jobs.STATE_CANCELLED)):
        j = jobs.Job(jid, f"旧任务 {jid}", "relaxed")
        j.state = st
        j.ended_at = now - jobs._TERMINAL_QUIET_SECONDS - 600
        mgr._jobs[jid] = j
        mgr._order.append(jid)
    assert mgr.context_block() == ""

    # 排队中任务即使前面全是旧终态也照常注入
    q = jobs.Job("job-q", "新排队任务", "relaxed")
    q.state = jobs.STATE_QUEUED
    mgr._jobs["job-q"] = q
    mgr._order.append("job-q")
    assert "job-q" in mgr.context_block()


# ---------- 期3 多任务并行（AGENT_JOB_PARALLEL 槽位并发 + 排队补位） ----------

def test_parallel_capacity_and_auto_fill(monkeypatch):
    """期3：并行槽位同时跑多个 worker；超出上限者排队；结束自动补位开跑。"""
    monkeypatch.setattr(config, "AGENT_JOB_PARALLEL", 2)
    ran: list[str] = []

    async def _fast_runner(**kw):
        ran.append(kw.get("parent_task_id", ""))
        await asyncio.sleep(0.05)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _fast_runner)
    mgr = JobManager()

    async def go():
        jid_a = await mgr._launch_async("任务A", "relaxed")
        jid_b = await mgr._launch_async("任务B", "relaxed")
        jid_c = await mgr._launch_async("任务C", "relaxed")
        # 三个委派刚发完（三个 _launch_async 全程无挂起点）：
        # A/B 占满 2 个并行槽，C 排队等补位
        assert len(mgr._running) == 2
        assert {jid_a, jid_b} <= mgr._running
        assert mgr.get(jid_c).state == jobs.STATE_QUEUED
        assert len(mgr._queued) == 1
        # 让出事件循环 → A/B 先后结束、C 自动补位，最终全部完成
        for _ in range(300):
            if all(mgr.get(j).state == jobs.STATE_DONE
                   for j in (jid_a, jid_b, jid_c)):
                break
            await asyncio.sleep(0.01)
        for jid in (jid_a, jid_b, jid_c):
            assert mgr.get(jid).state == jobs.STATE_DONE, jid
        assert mgr._running == set()
        assert not mgr._queued
        assert set(ran) == {jid_a, jid_b, jid_c}  # 三个都真正开跑过
    _run(go())


def test_parallel_cancel_running_frees_slot(monkeypatch):
    """期3：取消一个正在跑的任务 → 让出的槽位自动补一个排队任务。"""
    monkeypatch.setattr(config, "AGENT_JOB_PARALLEL", 2)
    mgr = JobManager()
    holder: dict[str, str] = {}  # 容器传引用：go() 里赋值、_runner 晚绑定读取

    async def _runner(**kw):
        jid = kw.get("parent_task_id", "")
        if jid == holder.get("b"):  # B 需要"一直跑着"等被取消
            await asyncio.sleep(5)
        await asyncio.sleep(0.05)
        return {"reply": "ok", "steps": 1, "ms": 0, "error": ""}

    monkeypatch.setattr(jobs, "_TASK_RUNNER", _runner)

    async def go():
        jid_a = await mgr._launch_async("任务A", "relaxed")
        jid_b = await mgr._launch_async("任务B", "relaxed")
        holder["b"] = jid_b
        jid_c = await mgr._launch_async("任务C", "relaxed")
        assert len(mgr._running) == 2
        assert mgr.get(jid_c).state == jobs.STATE_QUEUED
        assert await mgr._cancel_async(jid_b) is True
        # 让出事件循环：B 收成 cancelled，C 顶上空槽开跑
        for _ in range(300):
            if (mgr.get(jid_b).state == jobs.STATE_CANCELLED
                    and mgr.get(jid_c).state in (jobs.STATE_RUNNING,
                                                 jobs.STATE_DONE)):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid_b).state == jobs.STATE_CANCELLED
        assert mgr.get(jid_c).state != jobs.STATE_QUEUED  # 补位成功，不再排队
        # 收尾：A/C 正常完成，槽位清空
        for _ in range(300):
            if (mgr.get(jid_a).state == jobs.STATE_DONE
                    and mgr.get(jid_c).state == jobs.STATE_DONE):
                break
            await asyncio.sleep(0.01)
        assert mgr.get(jid_a).state == jobs.STATE_DONE
        assert mgr.get(jid_c).state == jobs.STATE_DONE
        assert mgr._running == set()
    _run(go())


def test_screen_lock_flags_on_gui_tools():
    """期3：会操作屏幕/键鼠的工具应标 screen_lock；纯读取工具不标（可并行）。"""
    from app.agent.tools import gui, windows

    reg = ToolRegistry()
    gui.register_all(reg)
    windows.register_all(reg)
    for name in ("mouse_click", "keyboard_type", "keyboard_press",
                 "run_action_sequence", "run_action_milestones",
                 "window_control", "open_app"):
        tool = reg.get(name)
        assert tool is not None and tool.screen_lock, name
    for name in ("screen_capture", "screen_ocr", "find_on_screen",
                 "screen_analyze", "ui_list", "ui_find", "screen_describe",
                 "find_image_on_screen", "wait_for_change"):
        tool = reg.get(name)
        assert tool is not None and not tool.screen_lock, name


# ---------- 期3 · loop 层 screen_lock 工具门控（锁占用→提示；锁空闲→执行并释放） ----------

def _run_loop_with_screen_lock(monkeypatch, lock_ok: bool):
    """搭一次 run_agent_task：模型首轮调 echo_lock（screen_lock），次轮结束。
    返回 (工具返回内容列表, release 调用记录)。"""
    import sys

    class FakeDb:
        @staticmethod
        def log_agent_task(*a, **kw):
            return True

    sys.modules["app.db"] = FakeDb
    try:
        reg = ToolRegistry()
        reg.register(Tool(name="echo_lock", description="echo",
                          parameters={"type": "object", "properties": {}},
                          risk="safe", timeout=5, screen_lock=True,
                          fn=lambda **kw: ToolResult.ok_result("回声")))
        monkeypatch.setattr(loop, "registry", reg)

        releases: list[str] = []

        class _FakeSem:
            def __init__(self, ok):
                self.ok = ok

            async def try_acquire(self, timeout):
                return self.ok

            def release(self):
                releases.append("release")

        monkeypatch.setattr(loop, "_screen_sem", _FakeSem(lock_ok))
        tool_contents: list[str] = []

        def fake_chat(messages, tools=None, on_token=None, timeout=300):
            assistant_calls = sum(1 for m in messages if m["role"] == "assistant")
            if assistant_calls == 0:
                return ChatResponse("", [ToolCall("c1", "echo_lock", {})], None)
            for m in messages:
                if m["role"] == "tool":
                    tool_contents.append(m["content"])
            return ChatResponse("结束", [], None)

        monkeypatch.setattr(loop.llm, "chat", fake_chat)

        async def go():
            summary = await loop.run_agent_task("用一下锁工具", mode="relaxed")
            assert summary.get("error", "") == ""

        _run(go())
        return tool_contents, releases
    finally:
        del sys.modules["app.db"]


def test_loop_screen_lock_busy_returns_guidance(monkeypatch):
    """期3：屏幕锁被别的任务占用时，screen_lock 工具不执行，喂回稍后重试提示。"""
    tool_contents, releases = _run_loop_with_screen_lock(monkeypatch, lock_ok=False)
    assert any("屏幕/键鼠正被其他任务占用" in c for c in tool_contents)
    assert "回声" not in "".join(tool_contents)  # 工具本身没跑
    assert releases == []  # 没拿到锁，不释放


def test_loop_screen_lock_free_executes_and_releases(monkeypatch):
    """期3：屏幕锁空闲 → screen_lock 工具正常执行，结束后释放锁。"""
    tool_contents, releases = _run_loop_with_screen_lock(monkeypatch, lock_ok=True)
    assert any(c == "回声" for c in tool_contents)
    assert releases == ["release"]  # 执行完 finally 释放

