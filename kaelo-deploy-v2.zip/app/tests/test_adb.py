# -*- coding: utf-8 -*-
"""ADB / Linux 设备工具单元测试（app/agent/tools/adb.py）。

用 monkeypatch 替换 _run_adb，不真实执行 adb 命令。
"""
import os

from app.agent.tools import adb


def _mock_run(monkeypatch, ok_text="", err_text="", returncode=0):
    def fake(args, timeout=60, max_out=6000):
        if returncode != 0:
            return adb.ToolResult.err_result(err_text)
        return adb.ToolResult.ok_result(ok_text)
    monkeypatch.setattr(adb, "_run_adb", fake)


# ---------- adb_devices ----------

def test_devices_empty(monkeypatch):
    _mock_run(monkeypatch, ok_text="List of devices attached\n")
    res = adb._adb_devices()
    assert res.ok
    assert "没有已连接" in res.text


def test_devices_with_one(monkeypatch):
    _mock_run(monkeypatch, ok_text="List of devices attached\nABC123 device product:box\n")
    res = adb._adb_devices()
    assert res.ok
    assert "ABC123" in res.text
    assert "1 台设备" in res.brief


# ---------- adb_shell ----------

def test_shell_missing_command():
    res = adb._adb_shell(command="")
    assert not res.ok
    assert "参数缺失" in res.error


def test_shell_ok(monkeypatch):
    _mock_run(monkeypatch, ok_text="/sdcard\nsystem\n")
    res = adb._adb_shell(command="ls /")
    assert res.ok
    assert "/sdcard" in res.text


def test_shell_failure(monkeypatch):
    _mock_run(monkeypatch, err_text="device offline", returncode=1)
    res = adb._adb_shell(command="ls")
    assert not res.ok
    assert "device offline" in res.error


# ---------- adb_install ----------

def test_install_missing_path():
    res = adb._adb_install(apk_path="")
    assert not res.ok
    assert "参数缺失" in res.error


def test_install_file_not_exist(tmp_path):
    res = adb._adb_install(apk_path=str(tmp_path / "nope.apk"))
    assert not res.ok
    assert "不存在" in res.error


def test_install_ok(monkeypatch, tmp_path):
    apk = tmp_path / "app.apk"
    apk.write_bytes(b"PK")
    _mock_run(monkeypatch, ok_text="Success")
    res = adb._adb_install(apk_path=str(apk))
    assert res.ok
    assert "安装成功" in res.text


# ---------- adb_screenshot ----------

def test_screenshot_missing_file(monkeypatch):
    # screencap 成功但 pull 失败（文件没生成）
    real_run = adb._run_adb

    def fake(args, timeout=60, max_out=6000):
        if args[0] == "pull":
            return adb.ToolResult.err_result("pull failed")
        return adb.ToolResult.ok_result("ok")
    monkeypatch.setattr(adb, "_run_adb", fake)
    res = adb._adb_screenshot()
    assert not res.ok
    monkeypatch.setattr(adb, "_run_adb", real_run)


# ---------- adb_push_pull ----------

def test_transfer_bad_mode():
    res = adb._adb_push_pull(mode="sync", local="a", remote="b")
    assert not res.ok
    assert "mode" in res.error


def test_transfer_missing_path():
    res = adb._adb_push_pull(mode="pull", local="", remote="")
    assert not res.ok
    assert "参数缺失" in res.error


def test_push_source_missing(tmp_path):
    res = adb._adb_push_pull(mode="push", local=str(tmp_path / "nofile"), remote="/sdcard/x")
    assert not res.ok
    assert "不存在" in res.error


def test_pull_ok(monkeypatch, tmp_path):
    _mock_run(monkeypatch, ok_text="1 file pulled")
    local = str(tmp_path / "out" / "file.txt")
    res = adb._adb_push_pull(mode="pull", local=local, remote="/sdcard/file.txt")
    assert res.ok
    assert "已pull" in res.text
