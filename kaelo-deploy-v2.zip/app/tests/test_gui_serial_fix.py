# -*- coding: utf-8 -*-
"""GUI 定位三修测试（2026-08-18 · 微信发送文件链路的三个实锤）。

1. mouse_click 坐标越界校验：防 PyAutoGUI fail-safe（昨天鼠标点中屏幕角落）。
2. find_on_screen OCR 乱码引导：目标是中文但 OCR 读出全乱码 → 引导改用 VLM。
3. ui_find 失败返回候选控件列表：让模型看到真实控件再调整目标。
"""
from PIL import Image

from app import config
from app.agent.tools import gui


def _solid(size, color=(255, 255, 255)):
    return Image.new("RGB", size, color)


class FakePG:
    """最小 pyautogui 替身：有 size/click/screenshot。"""

    def __init__(self):
        self.clicked = []
        self.PAUSE = 0.1

    def size(self):
        return (800, 600)

    def click(self, *a, **k):
        self.clicked.append((a, k))

    def screenshot(self, *a, **k):
        return _solid((800, 600))


class FakeTS:
    """最小 pytesseract 替身：固定输出乱码 OCR 结果。"""

    class Output:
        DICT = "dict"

    def image_to_data(self, img, lang, config, output_type):
        return {"text": ["L", "T", "R", "x", "@", "eMv", "WP?"],
                "conf": ["30"] * 7, "left": [0] * 7, "top": [0] * 7,
                "width": [10] * 7, "height": [10] * 7}


def test_mouse_click_rejects_out_of_screen(monkeypatch):
    """坐标越界 → 明确报错且不触发点击（防 fail-safe 点到屏幕角落）。"""
    pg = FakePG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: pg)
    monkeypatch.setattr(config, "UI_VERIFY_ENABLED", False)
    res = gui._mouse_click(x=1000, y=500)
    assert not res.ok
    assert "超出屏幕范围" in res.error
    assert pg.clicked == []  # 未发生点击


def test_mouse_click_negative_coord_rejected(monkeypatch):
    """负坐标同样拦截。"""
    pg = FakePG()
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: pg)
    monkeypatch.setattr(config, "UI_VERIFY_ENABLED", False)
    res = gui._mouse_click(x=-5, y=10)
    assert not res.ok
    assert "超出屏幕范围" in res.error


def test_find_on_screen_gibberish_guides_vlm(monkeypatch):
    """目标是中文但 OCR 全读出乱码 → 错误信息引导改用 screen_describe（VLM）。"""
    monkeypatch.setattr(gui, "_ocr_available", lambda: "")
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: FakePG())
    monkeypatch.setattr(gui, "_lazy_pytesseract", lambda: FakeTS())
    res = gui._find_on_screen(text="打开")
    assert not res.ok
    assert "乱码" in res.error
    assert "screen_describe" in res.error


def test_find_on_screen_ascii_target_keeps_old_hint(monkeypatch):
    """目标是 ASCII（如 'File'）时，乱码判断不触发（保持原提示）。"""
    monkeypatch.setattr(gui, "_ocr_available", lambda: "")
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: FakePG())
    monkeypatch.setattr(gui, "_lazy_pytesseract", lambda: FakeTS())
    res = gui._find_on_screen(text="File")
    assert not res.ok
    assert "乱码" not in res.error
    assert "screen_ocr" in res.error


def test_find_on_screen_cjk_noise_guides_vlm(monkeypatch):
    """盲区修复（2026-09-06）：OCR 输出的是零散汉字噪声（微信自绘界面把中文
    读成"口 一 …"）——老判据"读出内容无中文"会漏网（噪声也含汉字），
    新判据"目标汉字零重合"必须触发 VLM 引导。"""

    class FakeTSNoise:
        class Output:
            DICT = "dict"

        def image_to_data(self, img, lang, config, output_type):
            # 含汉字但与目标"打开"无一字重合的自绘界面噪声
            return {"text": ["口", "一", "LT", "R", "的", "九"],
                    "conf": ["30"] * 6, "left": [0] * 6, "top": [0] * 6,
                    "width": [10] * 6, "height": [10] * 6}

    monkeypatch.setattr(gui, "_ocr_available", lambda: "")
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: FakePG())
    monkeypatch.setattr(gui, "_lazy_pytesseract", lambda: FakeTSNoise())
    res = gui._find_on_screen(text="打开")
    assert not res.ok
    assert "无一字重合" in res.error
    assert "乱码" in res.error
    assert "screen_describe" in res.error


def test_find_on_screen_partial_read_not_false_positive(monkeypatch):
    """OCR 把目标拆成碎片读出（"文件/传输/助手"）时不触发乱码引导——重叠字存在，
    说明 OCR 有效，把可见文字交给模型自行调整，避免误伤。"""

    class FakeTSPartial:
        class Output:
            DICT = "dict"

        def image_to_data(self, img, lang, config, output_type):
            return {"text": ["文件", "传输", "助手", "发送"],
                    "conf": ["70"] * 4, "left": [0] * 4, "top": [0] * 4,
                    "width": [10] * 4, "height": [10] * 4}

    monkeypatch.setattr(gui, "_ocr_available", lambda: "")
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: FakePG())
    monkeypatch.setattr(gui, "_lazy_pytesseract", lambda: FakeTSPartial())
    res = gui._find_on_screen(text="文件传输助手")
    assert not res.ok
    assert "乱码" not in res.error
    assert "screen_ocr" in res.error


def test_ui_find_returns_candidates(monkeypatch):
    """ui_find 无匹配 → 返回候选控件列表，模型可据此调整目标。"""
    items = [
        {"id": "Button:文件传输助手", "type": "Button", "name": "文件传输助手",
         "center": (100, 200), "x": 0, "y": 0, "width": 10, "height": 10},
        {"id": "Edit:搜索", "type": "Edit", "name": "搜索",
         "center": (300, 400), "x": 0, "y": 0, "width": 10, "height": 10},
    ]
    monkeypatch.setattr(gui, "_ui_collect_nodes", lambda *a, **k: (items, 100))
    res = gui._ui_find(text="不存在的控件")
    assert not res.ok
    assert "候选控件" in res.error
    assert "文件传输助手" in res.error
    assert "搜索" in res.error
