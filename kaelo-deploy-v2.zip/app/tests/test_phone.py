# -*- coding: utf-8 -*-
"""手机事件反连测试（C批1 · app/phone.py + db 落库）。

覆盖：dumpsys 文本解析（电量/通知/设备列表）、跨轮去重判定（同通知不重弹、
低电量每放电会话只提醒一次、充电状态变化事件、设备断开静默重置）、
fetch_device_state 注入 runner、scan_and_store 落库计数（monkeypatch db）。
"""
from app import db as db_mod
from app import phone
from app.phone import (KIND_BATTERY, KIND_CHARGE, PhoneMonitor,
                       fetch_device_state, has_device, parse_battery,
                       parse_notifications, scan_and_store)

# ---------- 解析：dumpsys battery ----------

_BAT_LOW = """Current Battery Service state:
  AC powered: false
  USB powered: false
  Wireless powered: false
  status: 3
  health: 2
  present: true
  level: 15
  scale: 100
  voltage: 3700
  technology: Li-ion
"""


def test_parse_battery_typical():
    bat = parse_battery(_BAT_LOW)
    assert bat["level"] == 15
    assert bat["status"] == phone._STATUS_DISCHARGING
    assert bat["plugged"] is False


def test_parse_battery_charging_usb():
    text = _BAT_LOW.replace("status: 3", "status: 2").replace(
        "USB powered: false", "USB powered: true")
    bat = parse_battery(text)
    assert bat["status"] == phone._STATUS_CHARGING
    assert bat["plugged"] is True


def test_parse_battery_empty_or_garbage():
    assert parse_battery("") == {}
    assert parse_battery("no level at all") == {}


# ---------- 解析：dumpsys notification ----------

_NOTIF = """Notification List (userId=0):
  NotificationRecord(0x0123 pkg=com.whatsapp user=UserHandle{0} id=0x5 tag=null ...)
    key=0|com.whatsapp|5|null|12345
    android.title=WhatsApp
    android.text=小明：晚上一起吃饭？
  NotificationRecord(0x0456 pkg=com.android.systemui user=UserHandle{0} id=0x1 tag=null ...)
    android.title=已连接 USB 调试
    tickerText=已连接 USB 调试
Some other top-level section:
  noise that must not be parsed
"""


def test_parse_notifications_extracts_records():
    notifs = parse_notifications(_NOTIF)
    assert len(notifs) == 2
    wa = notifs[0]
    assert wa["pkg"] == "com.whatsapp"
    assert wa["title"] == "WhatsApp"
    assert "小明" in wa["text"]
    sysui = notifs[1]
    assert sysui["pkg"] == "com.android.systemui"
    # 无 android.title/body 的用 tickerText 兜底当标题
    assert sysui["title"] == "已连接 USB 调试"
    # 主节之外的"噪声"未混入
    assert not any("top-level" in n["text"] for n in notifs)


def test_parse_notifications_garbage_is_empty():
    assert parse_notifications("") == []
    assert parse_notifications("garbage\nwithout records\n") == []


# ---------- vivo/OriginOS 厂商壳清洗（真机 PD2121C 实测坑） ----------

_VIVO_NOTIF = """Notification List (userId=0):
  NotificationRecord(0x1 pkg=com.tailscale.ipn user=UserHandle{0} id=0x2 tag=null ...)
    key=0|com.tailscale.ipn|2|null|7
    android.title=String (Connected)
    android.text=String (Secure)
  NotificationRecord(0x2 pkg=android user=UserHandle{0} id=0x3 tag=null ...)
    key=0|android|3|null|8
    android.title=null
    android.text=null
  NotificationRecord(0x3 pkg=com.termux user=UserHandle{0} id=0x4 tag=null ...)
    key=0|com.termux|4|null|9
    android.title=null
    android.text=String (1 session)
"""


def test_clean_text_strips_vendor_shell():
    # vivo "String (…)" 壳 → 内容；嵌套括号安全保留内层
    assert phone._clean_text("String (Connected)") == "Connected"
    assert phone._clean_text('String (正处在 "开发模式")') == '正处在 "开发模式"'
    assert phone._clean_text("String (a (b))") == "a (b)"
    assert phone._clean_text("String ()") == ""
    # null（大小写不敏感）/纯空白 → 空串
    assert phone._clean_text("null") == ""
    assert phone._clean_text("NULL") == ""
    assert phone._clean_text("Null") == ""
    assert phone._clean_text("   ") == ""
    assert phone._clean_text("正常文本") == "正常文本"
    assert phone._clean_text("") == ""


def test_parse_notifications_vivo_cleans_and_skips_null():
    notifs = parse_notifications(_VIVO_NOTIF)
    assert len(notifs) == 3
    ts = notifs[0]
    assert ts["pkg"] == "com.tailscale.ipn"
    assert ts["title"] == "Connected"          # String (...) 壳已剥
    assert ts["text"] == "Secure"
    assert notifs[1]["title"] == "" and notifs[1]["text"] == ""   # null → 空
    termux = notifs[2]
    assert termux["title"] == "" and termux["text"] == "1 session"
    # tick 判定：全空记录不弹，仅有正文的按 title→pkg 兜底弹一条
    m = PhoneMonitor()
    evs = m.tick_notifications(notifs)
    assert len(evs) == 2
    assert evs[1]["pkg"] == "com.termux" and evs[1]["content"] == "1 session"


def test_has_device():
    assert has_device("List of devices attached\nABC123 device product:x\n") is True
    assert has_device("List of devices attached\n\n") is False
    assert has_device("* daemon not running; starting now\n") is False


# ---------- 判定：PhoneMonitor 跨轮去重 ----------

def _notif(pkg="com.whatsapp", rid="5", title="WhatsApp", text="你好"):
    return {"key": f"0|{pkg}|{rid}|null|100", "pkg": pkg,
            "title": title, "text": text}


def test_low_battery_warned_once_per_discharge_session():
    m = PhoneMonitor(low_pct=20)
    dis_low = {"level": 12, "status": phone._STATUS_DISCHARGING, "plugged": False}
    # 首次跨入低电量 → 提醒一次
    evs = m.tick_battery(dis_low)
    assert len(evs) == 1 and evs[0]["kind"] == KIND_BATTERY and evs[0]["level"] == "warn"
    # 继续放电（更低）不重复提醒
    assert m.tick_battery({"level": 9, "status": 3, "plugged": False}) == []
    # 充上电 → 解除低电量告警态
    assert m.tick_battery({"level": 30, "status": phone._STATUS_CHARGING, "plugged": True})
    # 新一轮放电会话再跌回低电量 → 重新提醒
    evs = m.tick_battery({"level": 15, "status": 3, "plugged": False})
    assert len(evs) == 1 and evs[0]["kind"] == KIND_BATTERY


def test_charging_and_full_events_once():
    m = PhoneMonitor()
    # 开始充电 → 事件；同状态再扫 → 静默
    evs = m.tick_battery({"level": 55, "status": phone._STATUS_CHARGING, "plugged": True})
    assert [e["kind"] for e in evs] == [KIND_CHARGE]
    assert m.tick_battery({"level": 60, "status": phone._STATUS_CHARGING, "plugged": True}) == []
    # 充满 → 事件一次
    evs = m.tick_battery({"level": 100, "status": phone._STATUS_FULL, "plugged": True})
    assert [e["kind"] for e in evs] == [KIND_CHARGE]
    assert evs[0]["title"] == "手机已充满"


def test_same_notification_not_resent():
    m = PhoneMonitor()
    n = _notif()
    assert len(m.tick_notifications([n])) == 1
    assert m.tick_notifications([n]) == []          # 同 key 去重
    n2 = _notif(rid="6", text="新的一条")
    evs = m.tick_notifications([n2])
    assert len(evs) == 1 and evs[0]["content"] == "新的一条"


def test_empty_notification_skipped():
    m = PhoneMonitor()
    assert m.tick_notifications([{"key": "k", "pkg": "com.x", "title": "", "text": ""}]) == []


def test_device_offline_silent_and_resets():
    m = PhoneMonitor(low_pct=20)
    m.tick_battery({"level": 10, "status": 3, "plugged": False})   # 触发过低电量
    assert m.low_warned is True
    # 设备断开 → 静默 + 状态重置（重新连上后可再提醒）
    assert m.tick(device=False, bat={}, notifs=[]) == []
    assert m.low_warned is False


# ---------- fetch_device_state：注入 runner ----------

def _runner_map(table):
    def runner(args):
        key = tuple(args)
        return table.get(key, (False, ""))
    return runner


def test_fetch_device_state_parses_live_device(monkeypatch):
    table = {
        ("devices", "-l"): (True, "List of devices attached\nABC123 device product:k\n"),
        ("shell", "dumpsys", "battery"): (True, _BAT_LOW),
        ("shell", "dumpsys", "notification", "--noredact"): (True, _NOTIF),
    }
    device, bat, notifs = fetch_device_state(_runner_map(table))
    assert device is True
    assert bat["level"] == 15
    assert notifs and notifs[0]["pkg"] == "com.whatsapp"


def test_fetch_device_state_no_device_silent(monkeypatch):
    table = {("devices", "-l"): (True, "List of devices attached\n\n")}
    device, bat, notifs = fetch_device_state(_runner_map(table))
    assert device is False and bat == {} and notifs == []


# ---------- scan_and_store：落库计数（安静契约） ----------

def test_scan_and_store_new_events_stored_once(monkeypatch):
    calls = []

    def fake_add(ev_key, kind="notice", pkg="", title="", content="", level="info"):
        key = (ev_key, kind, title, level)
        if key in calls:
            return False
        calls.append(key)
        return True

    monkeypatch.setattr(phone, "fetch_device_state",
                        lambda: (True, {"level": 10, "status": 3, "plugged": False}, []))
    monkeypatch.setattr(db_mod, "add_phone_event", fake_add)
    m = PhoneMonitor(low_pct=20)
    assert scan_and_store(monitor=m) == 1    # 低电量
    assert scan_and_store(monitor=m) == 0    # 同状态静默（quiet_noop）
