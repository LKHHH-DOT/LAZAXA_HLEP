# -*- coding: utf-8 -*-
"""M4a 旧工具结果清理单元测试（app/agent/context.py::clear_old_tool_results）。

对齐 JetBrains Observation Masking：隐藏更早的工具"观察结果"，
但完整保留 assistant.tool_calls 行动记录（工具名+参数）。全部纯函数测试，
不调用模型、不触碰网络。
"""
import copy

from app.agent import context
from app.agent.context import _TOOL_CLEARED_PLACEHOLDER, clear_old_tool_results


def _round(i, tool="run_command", payload_len=100, cid=None):
    """构造一轮 assistant(tool_call) + tool(result) 配对消息。"""
    cid = cid or f"call-{i}"
    assistant = {"role": "assistant", "content": f"step{i}", "tool_calls": [
        {"id": cid, "type": "function",
         "function": {"name": tool, "arguments": '{"command":"echo hi"}'}}]}
    tool_msg = {"role": "tool", "tool_call_id": cid,
                "content": f"result-{i}-" + "R" * payload_len}
    return [assistant, tool_msg]


def _mk(n, tool="run_command"):
    msgs = [{"role": "user", "content": "开始"}]
    for i in range(n):
        msgs += _round(i, tool=tool)
    return msgs


# ---------- 1. 保留最近 N 条，更早的替换为占位符 ----------

def test_clear_keeps_recent_n_and_replaces_older():
    msgs = _mk(12)
    out, cleared = clear_old_tool_results(msgs, keep_n=10)
    assert cleared == 2                       # 最早 2 条被清理
    tool_msgs = [m for m in out if m.get("role") == "tool"]
    assert tool_msgs[0]["content"] == _TOOL_CLEARED_PLACEHOLDER
    assert tool_msgs[1]["content"] == _TOOL_CLEARED_PLACEHOLDER
    # 最近 10 条原文保留
    assert tool_msgs[2]["content"].startswith("result-2-")
    assert tool_msgs[-1]["content"].startswith("result-11-")


# ---------- 2. assistant 行动记录（tool_calls）完整保留 ----------

def test_clear_preserves_assistant_tool_call_records():
    msgs = _mk(12)
    out, _ = clear_old_tool_results(msgs, keep_n=10)
    before_calls = [m for m in msgs if m.get("role") == "assistant"]
    after_calls = [m for m in out if m.get("role") == "assistant"]
    assert len(after_calls) == len(before_calls) == 12
    for b, a in zip(before_calls, after_calls):
        assert a["tool_calls"] == b["tool_calls"]   # 工具名+参数不丢
        assert a["content"] == b["content"]


# ---------- 3. 保护清单工具结果不清理 ----------

def test_clear_excludes_protected_tools():
    # 第 0 轮用受保护的 memory_recall，第 1~11 轮用普通工具
    msgs = [{"role": "user", "content": "x"}]
    msgs += _round(0, tool="memory_recall")
    for i in range(1, 12):
        msgs += _round(i, tool="run_command")
    out, cleared = clear_old_tool_results(
        msgs, keep_n=10, exclude_tools=("memory_recall",))
    # 最早两条 tool 结果下标对应 round0(memory_recall) 与 round1(run_command)，
    # memory_recall 受保护保留原文，只有 run_command 被清
    tool_msgs = [m for m in out if m.get("role") == "tool"]
    assert tool_msgs[0]["content"].startswith("result-0-")   # 受保护，原文
    assert tool_msgs[1]["content"] == _TOOL_CLEARED_PLACEHOLDER
    assert cleared == 1


# ---------- 4. 工具消息不足 keep_n / 无工具消息 → 原样不动 ----------

def test_clear_noop_when_below_keep_n():
    msgs = _mk(3, )
    out, cleared = clear_old_tool_results(msgs, keep_n=10)
    assert cleared == 0
    assert out is msgs                  # 直接返回原列表
    only_user = [{"role": "user", "content": "hi"},
                 {"role": "assistant", "content": "纯文本回答"}]
    out2, c2 = clear_old_tool_results(only_user, keep_n=10)
    assert c2 == 0 and out2 is only_user


# ---------- 5. 不改原列表（浅拷贝） ----------

def test_clear_does_not_mutate_input():
    msgs = _mk(12)
    snapshot = copy.deepcopy(msgs)
    clear_old_tool_results(msgs, keep_n=10)
    assert msgs == snapshot


# ---------- 6. keep_n=0 全清（切片陷阱回归） ----------

def test_clear_keep_n_zero_clears_all():
    msgs = _mk(3)
    out, cleared = clear_old_tool_results(msgs, keep_n=0)
    assert cleared == 3
    assert all(m["content"] == _TOOL_CLEARED_PLACEHOLDER
               for m in out if m.get("role") == "tool")


# ---------- 7. 消息总量不变（结构无损，配对仍完整） ----------

def test_clear_preserves_message_count_and_pairing():
    msgs = _mk(12)
    out, _ = clear_old_tool_results(msgs, keep_n=10)
    assert len(out) == len(msgs)        # 只换内容，不删消息
    # 每条 tool 消息仍能找到其 tool_call_id 对应的 assistant 调用
    ids = {tc["id"] for m in out if m.get("role") == "assistant"
           for tc in m.get("tool_calls", [])}
    for m in out:
        if m.get("role") == "tool":
            assert m["tool_call_id"] in ids
