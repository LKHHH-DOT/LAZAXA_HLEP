# -*- coding: utf-8 -*-
"""三级权限决策引擎单元测试（app/agent/permissions.py）。

覆盖：模式规范化 / 三种模式×风险默认策略 / run_command 内容分级 /
硬性断路器 / 受保护目录 / 工作区白名单 / 锁定模式白名单 /
deny 优先于 allow 的评估序。
"""
import os

from app import config
from app.agent import permissions as p


def _ws(*parts: str) -> str:
    """工作区（仓库根）内路径。"""
    return os.path.join(config.AGENT_WORKSPACE, *parts)


# ---------- normalize_mode ----------

def test_normalize_mode_valid():
    assert p.normalize_mode("locked") == "locked"
    assert p.normalize_mode("standard") == "standard"
    assert p.normalize_mode("relaxed") == "relaxed"


def test_normalize_mode_invalid_fallback():
    assert p.normalize_mode(None) == "standard"
    assert p.normalize_mode("") == "standard"
    assert p.normalize_mode("hacker") == "standard"


# ---------- 标准模式：safe 自动 / sensitive ask ----------

def test_standard_safe_allow():
    d, r = p.decide("standard", "safe", "read_file", {"path": _ws("tmp", "a.txt")})
    assert d == p.DECISION_ALLOW and r == "standard:safe"


def test_standard_sensitive_ask():
    d, _ = p.decide("standard", "sensitive", "write_file", {"path": _ws("tmp", "b.txt")})
    assert d == p.DECISION_ASK


# ---------- 省心模式：sensitive 自动放行 ----------

def test_relaxed_safe_allow():
    d, _ = p.decide("relaxed", "safe", "read_file", {"path": _ws("tmp", "a.txt")})
    assert d == p.DECISION_ALLOW


def test_relaxed_sensitive_allow():
    d, _ = p.decide("relaxed", "sensitive", "write_file", {"path": _ws("tmp", "b.txt")})
    assert d == p.DECISION_ALLOW


# ---------- run_command 内容分级：删文件确认 / 普通命令自动 ----------

def test_run_command_plain_auto():
    # 普通命令：任何非锁定模式都自动执行（查看/复制/移动/安装等不误拦截）
    for cmd in ("Get-ChildItem D:/tmp", "Copy-Item a.txt b.txt",
                "Get-Date", "dir /b D:/tmp"):
        d, r = p.decide("standard", "dangerous", "run_command", {"command": cmd})
        assert d == p.DECISION_ALLOW, cmd
        assert r == "run-command-auto", cmd


def test_run_command_plain_auto_relaxed():
    d, _ = p.decide("relaxed", "dangerous", "run_command", {"command": "Get-Date"})
    assert d == p.DECISION_ALLOW


def test_run_command_delete_ask_standard():
    # 删除类命令：即使 standard 也人工确认
    for cmd in ("Remove-Item D:/tmp/a.txt", "del D:/tmp/a.txt",
                "rm D:/tmp/a.txt", "Remove-Item D:/tmp/x -Force"):
        d, r = p.decide("standard", "dangerous", "run_command", {"command": cmd})
        assert d == p.DECISION_ASK, cmd
        assert r == "deletion-command", cmd


def test_run_command_delete_ask_relaxed():
    # 删文件确认不随模式放宽（用户诉求：删文件要通过）
    for cmd in ("Remove-Item D:/tmp/a.txt", "del D:/tmp/a.txt",
                "rm D:/tmp/a.txt", "rmdir D:/tmp/old",
                "Remove-Item 'D:/my file.txt'", "Clear-Content D:/tmp/log.txt"):
        d, _ = p.decide("relaxed", "dangerous", "run_command", {"command": cmd})
        assert d == p.DECISION_ASK, cmd


def test_run_command_delete_alias_requires_space():
    # 短别名 del/rm 必须后跟空白才判定删除：Get-DeliveryOptimization 不应误伤
    cmd = "Get-DeliveryOptimization -Status"
    d, _ = p.decide("relaxed", "dangerous", "run_command", {"command": cmd})
    assert d == p.DECISION_ALLOW, cmd


def test_run_command_clear_content_ask():
    d, _ = p.decide("relaxed", "dangerous", "run_command",
                    {"command": "Set-Content -Path D:/tmp/x.txt -Value ''"})
    # Set-Content 不是删除，但清空内容…此处只断言不因误判崩溃
    assert d in (p.DECISION_ALLOW, p.DECISION_ASK)


# ---------- 硬性断路器：任何模式强制 ask（保留人工判断权） ----------

def test_hard_block_force_ask_even_relaxed():
    d, r = p.decide("relaxed", "dangerous", "run_command",
                    {"command": "rm -rf D:/data"})
    assert d == p.DECISION_ASK and r == "hard-block"


def test_hard_block_force_ask_even_locked():
    # 锁定模式先命中硬断路器 → 仍 ask（评估序：断路器 > 锁定白名单）
    d, _ = p.decide("locked", "dangerous", "run_command",
                    {"command": "Remove-Item -Recurse C:/x"})
    assert d == p.DECISION_ASK


def test_hard_block_powershell_variant():
    d, _ = p.decide("standard", "dangerous", "run_command",
                    {"command": "Remove-Item -Path C:/x -Recurse -Force"})
    assert d == p.DECISION_ASK


# ---------- 受保护目录：默认拒绝（deny 优先于 allow） ----------

def test_protected_path_deny_standard():
    d, r = p.decide("standard", "safe", "read_file", {"path": "C:/Windows/System32/a.ini"})
    assert d == p.DECISION_DENY and r == "protected-path"


def test_protected_path_deny_relaxed():
    # 省心模式敏感操作放行，但受保护目录仍拒绝（安全基线不随模式放宽）
    d, _ = p.decide("relaxed", "sensitive", "write_file",
                    {"path": "C:/Users/Hasee/.ssh/config"})
    assert d == p.DECISION_DENY


def test_protected_path_case_insensitive():
    d, _ = p.decide("standard", "safe", "read_file", {"path": "c:/PROGRAMDATA/x"})
    assert d == p.DECISION_DENY


def test_workspace_path_not_protected():
    # 工作区内路径不受"受保护目录"影响 → 走正常策略（safe 放行）
    d, _ = p.decide("standard", "safe", "read_file", {"path": _ws("a.txt")})
    assert d == p.DECISION_ALLOW


def test_run_command_not_subject_to_protected_path():
    # 受保护目录只约束文件类工具；run_command 普通命令自动执行
    d, _ = p.decide("relaxed", "dangerous", "run_command",
                    {"command": "type C:/Windows/win.ini"})
    assert d == p.DECISION_ALLOW


# ---------- 锁定模式：只放行只读核心白名单 ----------

def test_locked_allowlist_allow():
    for tool in ("kb_query", "memory_search", "screen_capture", "screen_ocr"):
        d, _ = p.decide("locked", "safe", tool, {})
        assert d == p.DECISION_ALLOW


def test_locked_others_deny():
    d, r = p.decide("locked", "safe", "read_file", {"path": _ws("a.txt")})
    assert d == p.DECISION_DENY and r == "locked-mode"


def test_locked_run_command_deny():
    # locked 下 run_command 不在白名单 → 直接 deny（先于内容分级）
    d, _ = p.decide("locked", "dangerous", "run_command", {"command": "Get-Date"})
    assert d == p.DECISION_DENY


# ---------- 工作区白名单（两者合一沙箱）：文件类工具只能操作仓库内路径 ----------

def test_workspace_outside_deny_all_modes():
    # 仓库外路径：任何模式一律 deny（安全基线不随模式放宽）
    outside = r"D:\Users\Hasee\Desktop\outside.txt"
    for mode in ("locked", "standard", "relaxed"):
        d, r = p.decide(mode, "safe", "read_file", {"path": outside})
        assert d == p.DECISION_DENY and r == "workspace-outside", (mode, r)
        d, _ = p.decide(mode, "sensitive", "write_file", {"path": outside})
        assert d == p.DECISION_DENY, mode


def test_workspace_outside_all_file_tools():
    # 全部文件类工具（含 office）仓库外路径都被拒
    outside = r"D:\Users\Hasee\Desktop\x"
    for tool in ("read_file", "write_file", "list_dir", "search_files",
                 "office_excel_read", "office_excel_write", "office_excel_summary",
                 "office_word_read", "office_word_write", "office_pdf_read"):
        d, r = p.decide("relaxed", "sensitive", tool, {"path": outside})
        assert d == p.DECISION_DENY and r == "workspace-outside", tool


def test_workspace_inside_flows_to_normal_logic():
    # 工作区内路径照常走模式×风险策略（relaxed 写放行 / standard 写 ask）
    d, _ = p.decide("relaxed", "sensitive", "write_file", {"path": _ws("a.txt")})
    assert d == p.DECISION_ALLOW
    d, _ = p.decide("standard", "sensitive", "write_file", {"path": _ws("a.txt")})
    assert d == p.DECISION_ASK


def test_workspace_case_insensitive():
    # Windows 路径大小写不敏感：同路径不同写法都应识别为工作区内
    ws_lower = config.AGENT_WORKSPACE.lower()
    d, _ = p.decide("standard", "safe", "read_file",
                    {"path": os.path.join(ws_lower, "a.txt")})
    assert d == p.DECISION_ALLOW


def test_workspace_prefix_not_confused():
    # 前缀相似但并非工作区子目录（如 Kaelo_evil）不得放行
    sibling = os.path.join(os.path.dirname(config.AGENT_WORKSPACE), "Kaelo_evil", "a.txt")
    d, _ = p.decide("standard", "safe", "read_file", {"path": sibling})
    assert d == p.DECISION_DENY


def test_workspace_relative_path():
    # 相对路径按进程 cwd 解析：仓库内相对路径放行
    d, _ = p.decide("standard", "safe", "read_file", {"path": "PROJECT.md"})
    assert d == p.DECISION_ALLOW


def test_workspace_office_inside_allow():
    # office 工具工作区内路径照常走策略
    d, _ = p.decide("relaxed", "sensitive", "office_excel_write",
                    {"path": _ws("报表.xlsx"), "data": "x"})
    assert d == p.DECISION_ALLOW
    d, _ = p.decide("standard", "sensitive", "office_excel_write",
                    {"path": _ws("报表.xlsx"), "data": "x"})
    assert d == p.DECISION_ASK


# ---------- 敏感文件黑名单（行为守则禁区 A）：工作区内含密钥/隐私路径 读+写都 deny ----------

def test_blocked_env_read_deny():
    # .env（DeepSeek/ADMIN_TOKEN 等密钥）读都不行，任何模式
    env_path = os.path.join(config.AGENT_WORKSPACE, "SelfIterate", ".env")
    for mode in ("locked", "standard", "relaxed"):
        d, r = p.decide(mode, "safe", "read_file", {"path": env_path})
        assert d == p.DECISION_DENY and r == "blocked-path", (mode, r)


# ---------- 工作区开关（前端"权限按钮"控制，默认限内=严格沙箱） ----------

def test_workspace_strict_default_deny_outside():
    # 默认开关开启（限内）：仓库外路径照旧 deny，基线安全不受影响
    from app.state import get_permission_flags, set_permission_flag
    try:
        set_permission_flag("workspace_strict", True)
        assert get_permission_flags()["workspace_strict"] is True
        d, r = p.decide("relaxed", "safe", "read_file",
                        {"path": r"D:\Users\Hasee\Desktop\outside.txt"})
        assert d == p.DECISION_DENY and r == "workspace-outside"
    finally:
        set_permission_flag("workspace_strict", True)


def test_workspace_unlocked_allow_outside():
    # 用户点开开关（放开工作区）：仓库外普通路径不再被沙箱拦截，
    # 改走模式×风险策略（relaxed 下 safe 读放行）
    from app.state import set_permission_flag
    try:
        set_permission_flag("workspace_strict", False)
        d, r = p.decide("relaxed", "safe", "read_file",
                        {"path": r"D:\Users\Hasee\Desktop\outside.txt"})
        assert d == p.DECISION_ALLOW and r == "relaxed:safe"
        d, _ = p.decide("standard", "safe", "read_file",
                        {"path": r"D:\Users\Hasee\Desktop\outside.txt"})
        assert d == p.DECISION_ALLOW
    finally:
        set_permission_flag("workspace_strict", True)


def test_workspace_unlocked_still_blocks_sensitive_paths():
    # 放开工作区后，全盘敏感文件黑名单仍拦：.env/keys/config.json/history 任一路径段
    from app.state import set_permission_flag
    try:
        set_permission_flag("workspace_strict", False)
        for bad in (r"D:\Users\Hasee\Desktop\proj\.env",
                    r"D:\Users\Hasee\Desktop\proj\keys\id_rsa",
                    r"D:\Users\Hasee\Desktop\proj\config.json",
                    r"D:\Users\Hasee\Desktop\proj\history"):
            d, r = p.decide("relaxed", "safe", "read_file", {"path": bad})
            assert d == p.DECISION_DENY and r == "blocked-path-global", bad
        # .env.example 是模板，不算敏感，放开后可读
        d, _ = p.decide("relaxed", "safe", "read_file",
                        {"path": r"D:\Users\Hasee\Desktop\proj\.env.example"})
        assert d == p.DECISION_ALLOW
    finally:
        set_permission_flag("workspace_strict", True)


def test_blocked_write_and_office():
    # 写也一样拦；office 工具（读 Excel）也拦
    env_path = os.path.join(config.AGENT_WORKSPACE, "SelfIterate", ".env")
    d, _ = p.decide("relaxed", "sensitive", "write_file", {"path": env_path})
    assert d == p.DECISION_DENY
    data_xlsx = os.path.join(config.AGENT_WORKSPACE, "SelfIterate", "data", "x.xlsx")
    d, _ = p.decide("relaxed", "sensitive", "office_excel_read", {"path": data_xlsx})
    assert d == p.DECISION_DENY


def test_blocked_all_sensitive_paths():
    # 黑名单逐项检查（relaxed + safe 读也要拦）
    ws = config.AGENT_WORKSPACE
    paths = [
        os.path.join(ws, "SelfIterate", ".env"),
        os.path.join(ws, "SelfIterate", "keys", "lazaxa_deploy"),
        os.path.join(ws, "kb-gui-assistant", "config.json"),
        os.path.join(ws, "kb-gui-assistant", "history", "v1", "config.json"),
        os.path.join(ws, "SelfIterate", "data", "personal", "01.md"),
        os.path.join(ws, "version", "Kaelo_V1_20260817", ".env"),
    ]
    for path in paths:
        d, r = p.decide("relaxed", "safe", "read_file", {"path": path})
        assert d == p.DECISION_DENY and r == "blocked-path", (path, r)


def test_blocked_prefix_not_confused():
    # 路径段边界：SelfIterate/data_backup 不应被 selfiterate/data 误伤
    sibling = os.path.join(config.AGENT_WORKSPACE, "SelfIterate", "data_backup", "a.txt")
    d, _ = p.decide("standard", "safe", "read_file", {"path": sibling})
    assert d == p.DECISION_ALLOW


# ---------- 桌面临时目录（守则"临时文件纪律"：中间产物落点） ----------

def test_temp_dir_allowed_like_workspace(tmp_path, monkeypatch):
    # 临时目录视为工作区同等权限：standard 下写文件=ask（sensitive），不是 deny
    monkeypatch.setattr(config, "AGENT_TEMP_DIR", str(tmp_path))
    d, r = p.decide("standard", "sensitive", "write_file",
                    {"path": os.path.join(str(tmp_path), "intermediate.txt")})
    assert d == p.DECISION_ASK, r
    # relaxed 下敏感写放行（与工作区一致）
    d, _ = p.decide("relaxed", "sensitive", "write_file",
                    {"path": os.path.join(str(tmp_path), "x.txt")})
    assert d == p.DECISION_ALLOW


def test_temp_dir_outside_still_denied(tmp_path, monkeypatch):
    # 临时目录之外（如桌面其他位置）在限内模式下仍 deny workspace-outside
    monkeypatch.setattr(config, "AGENT_TEMP_DIR", str(tmp_path))
    outside = os.path.join(os.path.dirname(str(tmp_path)), "OtherDir", "a.txt")
    d, r = p.decide("standard", "sensitive", "write_file", {"path": outside})
    assert d == p.DECISION_DENY and r == "workspace-outside"


def test_cleanup_temp_dir_empties_but_keeps_dir(tmp_path, monkeypatch):
    # cleanup_temp_dir：清空临时目录内容但保留目录本身（任务结束自动清理）
    from app.agent.loop import cleanup_temp_dir
    monkeypatch.setattr(config, "AGENT_TEMP_DIR", str(tmp_path))
    (tmp_path / "a.txt").write_text("x", encoding="utf-8")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "b.txt").write_text("y", encoding="utf-8")
    cleanup_temp_dir()
    assert tmp_path.exists()
    assert list(tmp_path.iterdir()) == []


# ---------- 智能体运行参数（最大工具调用步数，用户可自定义） ----------

def test_agent_settings_set_and_validate():
    from app.state import get_agent_settings, set_agent_setting
    try:
        assert get_agent_settings()["max_steps"] == 20  # 默认 = config.AGENT_MAX_STEPS
        assert set_agent_setting("max_steps", 50) is True
        assert get_agent_settings()["max_steps"] == 50
        # 非法键 / 越界 / 非整数一律拒绝
        assert set_agent_setting("unknown_key", 1) is False
        assert set_agent_setting("max_steps", 0) is False
        assert set_agent_setting("max_steps", 101) is False
        assert set_agent_setting("max_steps", "abc") is False
    finally:
        set_agent_setting("max_steps", 20)  # 恢复默认，避免影响其他测试

