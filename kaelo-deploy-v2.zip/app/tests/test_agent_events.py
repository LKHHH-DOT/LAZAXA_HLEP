# -*- coding: utf-8 -*-
"""M3 agent_events ledger invariant tests.

Covers the append-only full-lifecycle event ledger (app/db.py agent_events +
loop.py instrumentation). Runs fully offline: app.db is swapped for a
FakeDb that captures log_agent_event rows (no MySQL), llm.chat and the
tool registry are stubbed, real run_agent_task is executed under asyncio.

Invariants (see M3 detail plan section 4):
  1. for every llm call there is a `request` event whose payload.messages
     is structurally equal to the messages the stub chat actually saw
  2. main-round event order = turn_start -> request -> assistant ->
     (tool_call -> tool_result)* -> done, with correct round_id on every row
  3. approval: approval_request + approval_resolved come in pairs with the
     right approved value; deny: only tool_call + tool_result(ok=false),
     no approval rows at all
  4. sub-agent/parallel inner rounds log their own turn_start/request...,
     share the parent round_id and carry parent_task_id lineage; approval
     requests are NOT logged twice (the A3 regression point)
  5. empty round_id -> zero rows; AGENT_EVENTS_ENABLED=False -> zero rows
  6. router GET /api/v1/agent/events returns {events, next_after, count}
"""
import asyncio
import copy
import sys
import types

from app.agent import loop
from app.agent import llm as llm_mod
from app.agent.loop import run_agent_task, _execute_subagent, _execute_subagent_parallel
from app.agent.registry import ToolResult
from app.agent.permissions import DECISION_ALLOW, DECISION_ASK, DECISION_DENY


# ---------------------------------------------------------------------
# FakeDb: captures log_agent_event rows; no-ops audit / failure counters
# ---------------------------------------------------------------------

class FakeDb:
    def __init__(self):
        self.rows = []       # [{id,type,payload,round_id,task_id,parent_task_id,step}]

    def log_agent_event(self, event_type, payload=None, *, round_id="",
                        task_id="", parent_task_id="", step=0):
        self.rows.append({
            "id": len(self.rows) + 1,
            "type": event_type,
            "payload": copy.deepcopy(payload or {}),
            "round_id": round_id,
            "task_id": task_id,
            "parent_task_id": parent_task_id,
            "step": step,
        })
        return len(self.rows)

    def log_agent_task(self, *a, **k):
        return True

    def bump_audit_failure(self, *a, **k):
        pass


def _install_db(monkeypatch, db):
    """Swap sys.modules['app.db'] for FakeDb (same trick as test_task_history)."""
    monkeypatch.setitem(sys.modules, "app.db", db)


def _rows_of(db, event_type=None, round_id=None):
    out = []
    for r in db.rows:
        if event_type is not None and r["type"] != event_type:
            continue
        if round_id is not None and r["round_id"] != round_id:
            continue
        out.append(r)
    return out


# ---------------------------------------------------------------------
# Stub chat responses / tool registry helpers (mirror test_loop_reliability)
# ---------------------------------------------------------------------

def _tool(name="run_command", cid="c1", args=None):
    return types.SimpleNamespace(name=name, id=cid, args=args or {"cmd": "echo hi"})


def _resp(content="", tool_calls=None, usage=None):
    tc = tool_calls or []
    return types.SimpleNamespace(
        has_tool_calls=bool(tc),
        content=content,
        tool_calls=tc,
        usage=usage or {"prompt_tokens": 5, "completion_tokens": 3},
        finish_reason="stop",
        to_assistant_message=lambda: {"role": "assistant",
                                      "content": content or "",
                                      "tool_calls": []},
    )


def _stub_tools(monkeypatch):
    """registry.get -> sensitive tool; registry.execute -> ok; no schemas."""
    from app.agent.registry import registry as reg
    monkeypatch.setattr(reg, "get",
                        lambda name: types.SimpleNamespace(
                            risk="sensitive", display_name=name))
    monkeypatch.setattr(reg, "execute",
                        lambda name, args: ToolResult.ok_result("ok"))
    monkeypatch.setattr(reg, "openai_schemas", lambda: [])


def _make_chat_stub(monkeypatch, seen, responses):
    """llm.chat stub: append deepcopy of messages to `seen`, pop next response."""
    it = iter(responses)

    def fake_chat(messages, tools, *a, **k):
        seen.append(copy.deepcopy(messages))
        return next(it)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)


def _stub_decide(monkeypatch, result):
    """permissions.decide -> fixed (decision, reason)."""
    monkeypatch.setattr(loop.permissions, "decide",
                        lambda *a, **k: result)


def _stub_ask(monkeypatch, approved=True):
    """approval.ask stub: emit approval_request then return approved."""
    async def fake_ask(task_id, tool_name, args, risk, emit):
        await emit("approval_request", {"task_id": task_id, "tool": tool_name,
                                        "args": args, "risk": risk})
        return approved

    monkeypatch.setattr(loop.approval, "ask", fake_ask)


async def _collector(events):
    async def emit(event_type, payload):
        events.append((event_type, copy.deepcopy(payload)))
    return emit

# ---------------------------------------------------------------------
# 1. request event mirrors exactly what the model saw (invariant 1)
# ---------------------------------------------------------------------

def test_request_payload_matches_chat_input(monkeypatch):
    """For each llm call, a request row exists whose payload.messages is
    structurally identical (role+content) to what the stub chat received."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    # turn 1: tool call round -> turn 2: plain completion
    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="完成", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("帮我看看", emit=emit, max_steps=4,
                                    round_id="r-test-1")

    summary = asyncio.run(go())
    assert summary.get("reply") == "完成"

    reqs = _rows_of(db, "request")
    assert len(reqs) == 2, "one request row per llm call"
    # each request.messages snapshot equals the messages the stub saw
    assert len(seen) == 2
    for req, msgs in zip(reqs, seen):
        req_msgs = req["payload"]["messages"]
        assert [m["role"] for m in req_msgs] == [m["role"] for m in msgs]
        assert [m["content"] for m in req_msgs] == [m["content"] for m in msgs]
    # request carries step + round
    assert [r["step"] for r in reqs] == [1, 2]
    assert all(r["round_id"] == "r-test-1" for r in reqs)


def test_request_snapshots_messages_before_inline_mutation(monkeypatch):
    """request is recorded BEFORE llm.chat (list later appended in place) —
    so its messages must NOT contain the next assistant/tool replies."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="好了", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("干活", emit=emit, max_steps=4,
                                    round_id="r-test-2")

    asyncio.run(go())
    # second llm call in real code would have seen the appended tool result;
    # the logged snapshot must not be polluted by post-return appends
    req0 = _rows_of(db, "request")[0]["payload"]["messages"]
    assert all(m["role"] in ("system", "user") for m in req0)
    assert not any(m.get("tool_calls") for m in req0)
    # the stub-copied reference at call time equals what was logged
    assert [m["content"] for m in seen[0]] == [m["content"] for m in req0]


# ---------------------------------------------------------------------
# 2. main-round sequence + round filter (invariant 2)
# ---------------------------------------------------------------------

def test_main_round_event_sequence_and_round_filter(monkeypatch):
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="收尾", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("做一件事", emit=emit, max_steps=4,
                                    round_id="r-round-1")

    asyncio.run(go())

    # all rows belong to this round
    assert all(r["round_id"] == "r-round-1" for r in db.rows)
    types_order = [r["type"] for r in db.rows]
    assert types_order[0] == "turn_start"
    assert types_order[-1] == "done"
    # subsequence: turn_start -> request -> assistant -> tool_call ->
    # tool_result -> request -> assistant -> done
    seq = [t for t in types_order
           if t in ("turn_start", "request", "assistant",
                    "tool_call", "tool_result", "done")]
    assert seq == ["turn_start", "request", "assistant", "tool_call",
                   "tool_result", "request", "assistant", "done"]
    # done payload carries reply/stop_reason
    done = _rows_of(db, "done")[-1]["payload"]
    assert done.get("reply") == "收尾"
    assert done.get("stop_reason") == "completed"


def test_token_events_not_persisted(monkeypatch):
    """40-char incremental token chunks never reach the ledger (full text is
    carried by assistant/done rows)."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="长文本" * 30, tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("回答问题", emit=emit, max_steps=2,
                                    round_id="r-tok-1")

    asyncio.run(go())
    # wire stream carries tokens; ledger does not
    assert any(t == "token" for t, _ in events)
    assert "token" not in [r["type"] for r in db.rows]
    # assistant row still holds full text
    asst = _rows_of(db, "assistant")[0]["payload"]
    assert asst["content"] == "长文本" * 30


def test_empty_round_id_writes_nothing(monkeypatch):
    """round_id='' (unit/legacy callers) -> zero ledger rows."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="好", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("hi", emit=emit, max_steps=2, round_id="")

    asyncio.run(go())
    assert db.rows == []

# ---------------------------------------------------------------------
# 3. approval pairing + deny scenario (invariant 3)
# ---------------------------------------------------------------------

def test_approval_request_and_resolved_pair(monkeypatch):
    """ASK tool round -> approval_request (via wire) + approval_resolved
    rows both appear, approved=True matches execution."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ASK, "needs confirm"))
    _stub_ask(monkeypatch, approved=True)
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="已执行", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("跑一下", emit=emit, max_steps=4,
                                    round_id="r-appr-1")

    asyncio.run(go())
    req = _rows_of(db, "approval_request")
    res = _rows_of(db, "approval_resolved")
    assert len(req) == 1 and len(res) == 1
    # same tool/task context in both
    assert req[0]["payload"]["tool"] == "run_command"
    assert req[0]["payload"]["risk"] == "sensitive"
    assert req[0]["payload"]["task_id"] == res[0]["payload"]["task_id"]
    assert res[0]["payload"]["approved"] is True
    # resolved logged with same round + after the request in write order
    assert res[0]["round_id"] == "r-appr-1"
    assert req[0]["id"] < res[0]["id"]
    # tool_result ran with ok=True after approval
    tr = _rows_of(db, "tool_result")
    assert tr and tr[0]["payload"]["ok"] is True
    # wire also saw the approval_request (frontend prompt needs it)
    assert any(t == "approval_request" for t, _ in events)


def test_approval_resolved_false_when_user_rejects(monkeypatch):
    """Rejected approval -> approval_resolved approved=False, tool never ran,
    tool_result(ok=false) '用户拒绝' path."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ASK, "needs confirm"))
    _stub_ask(monkeypatch, approved=False)
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="那就换个方式", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("跑一下", emit=emit, max_steps=4,
                                    round_id="r-rej-1")

    asyncio.run(go())
    res = _rows_of(db, "approval_resolved")
    assert len(res) == 1 and res[0]["payload"]["approved"] is False
    # refusal is surfaced as failed tool_result with a brief, no execution
    tr = _rows_of(db, "tool_result")
    assert tr and tr[0]["payload"]["ok"] is False
    assert "拒绝" in (tr[0]["payload"].get("brief") or "")
    # sub-agent never spawned; registry.execute never ran for real tools
    # (loop handles refusal before dispatch) - covered by ok=False above


def test_deny_scenario_no_approval_rows(monkeypatch):
    """policy deny -> tool_call + tool_result(ok=false) only, zero approval
    rows (no pending request ever existed)."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_DENY, "policy blocks"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c1")]),
                 _resp(content="好吧", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("跑一下", emit=emit, max_steps=4,
                                    round_id="r-deny-1")

    asyncio.run(go())
    types_order = [r["type"] for r in db.rows]
    assert "approval_request" not in types_order
    assert "approval_resolved" not in types_order
    tr = _rows_of(db, "tool_result")
    assert tr and tr[0]["payload"]["ok"] is False
    assert "权限" in (tr[0]["payload"].get("brief") or "")


# ---------------------------------------------------------------------
# 5. kill switch (invariant 5)
# ---------------------------------------------------------------------

def test_events_disabled_writes_nothing(monkeypatch):
    """AGENT_EVENTS_ENABLED=False -> zero ledger rows even with a real round."""
    from app import config as cfg
    monkeypatch.setattr(cfg, "AGENT_EVENTS_ENABLED", False)
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="完成", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("hi", emit=emit, max_steps=2,
                                    round_id="r-off-1")

    asyncio.run(go())
    assert db.rows == []

# ---------------------------------------------------------------------
# 4. sub-agent / parallel: inner rounds share round_id, carry lineage,
#    approvals not double-logged (invariant 4 = A3 regression)
# ---------------------------------------------------------------------

def _role_marker(content: str) -> str:
    """Sub-agent system prompt contains the delegation-depth head line."""
    return "委派深度" if "你是 Lazaxa 委派的子代理" in content else "main"


def _run_with_subagent(monkeypatch, db, main_responses, inner_responses,
                       round_id, ask_spawn=False):
    """Top-level run whose first main llm reply delegates to a sub-agent.
    Chat stub routes each call to main/inner by system-prompt role marker.
    ask_spawn=True makes the delegation itself require user approval."""
    from app.agent import llm as llm_mod
    seen_main, seen_inner = [], []
    it_main = iter(main_responses)
    it_inner = iter(inner_responses)

    def fake_chat(messages, tools, *a, **k):
        marker = _role_marker(messages[0]["content"] or "")
        if marker == "main":
            seen_main.append(copy.deepcopy(messages))
            return next(it_main)
        seen_inner.append(copy.deepcopy(messages))
        return next(it_inner)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)
    _stub_tools(monkeypatch)

    # spawn/parallel delegation approval controlled by ask_spawn flag;
    # regular sensitive tools inside the agent ask for confirmation (ASK)
    def decide(mode, risk, name, args):
        if name in ("subagent_spawn", "subagent_parallel"):
            return (DECISION_ASK, "confirm delegation") if ask_spawn \
                else (DECISION_ALLOW, "delegation ok")
        return (DECISION_ASK, "confirm tool")

    monkeypatch.setattr(loop.permissions, "decide", decide)
    _stub_ask(monkeypatch, approved=True)

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        return await run_agent_task("派个子代理", emit=emit, max_steps=6,
                                    round_id=round_id)

    result = asyncio.run(go())
    return result, seen_main, seen_inner, events


def test_subagent_inner_round_has_lineage_and_same_round(monkeypatch):
    """Inner sub-agent run writes its own turn_start/request/assistant/done
    rows with round_id == parent and parent_task_id = 'sub-*' lineage."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    call = _tool("subagent_spawn", "s1", {"task": "子任务甲"})
    main_responses = [_resp(content="", tool_calls=[call]),
                      _resp(content="主任务完成", tool_calls=[])]
    inner_responses = [_resp(content="子代理汇报", tool_calls=[])]
    result, _, seen_inner, _ = _run_with_subagent(
        monkeypatch, db, main_responses, inner_responses, "r-sub-1")

    assert result.get("reply") == "主任务完成"
    # inner ran exactly once and its own request snapshot was logged
    assert len(seen_inner) == 1
    inner_requests = [r for r in _rows_of(db, "request")
                      if r["parent_task_id"].startswith("sub-")]
    assert len(inner_requests) == 1
    assert inner_requests[0]["round_id"] == "r-sub-1"
    assert inner_requests[0]["parent_task_id"].startswith("sub-")
    # inner turn_start exists with same lineage and depth marker in prompt
    inner_turn = [r for r in _rows_of(db, "turn_start")
                  if r["parent_task_id"].startswith("sub-")]
    assert len(inner_turn) == 1
    assert inner_turn[0]["round_id"] == "r-sub-1"
    assert "委派深度" in inner_requests[0]["payload"]["messages"][0]["content"]
    # main requests keep empty parent_task_id (root)
    main_requests = [r for r in _rows_of(db, "request")
                     if not r["parent_task_id"]]
    assert len(main_requests) == 2


def test_subagent_approval_request_logged_once(monkeypatch):
    """A3: an approval request raised inside the sub-agent must appear in the
    ledger exactly ONCE (inner wrapper logs it; parent wrapper must not
    re-log it on the way up via the raw wire emitter)."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    call = _tool("subagent_spawn", "s1", {"task": "子任务乙"})
    inner_tool = _tool("run_command", "ic1")
    main_responses = [_resp(content="", tool_calls=[call]),
                      _resp(content="结束", tool_calls=[])]
    # inner asks to run a tool (ASK) then reports back
    inner_responses = [_resp(content="", tool_calls=[inner_tool]),
                       _resp(content="子代理完成", tool_calls=[])]
    result, _, _, wire = _run_with_subagent(
        monkeypatch, db, main_responses, inner_responses, "r-a3-1")

    appr_req = _rows_of(db, "approval_request")
    appr_res = _rows_of(db, "approval_resolved")
    # exactly one request + one resolved across the whole round (A3 core)
    assert len(appr_req) == 1, f"expected 1 approval_request, got {len(appr_req)}"
    assert len(appr_res) == 1
    assert appr_req[0]["parent_task_id"].startswith("sub-")
    assert appr_req[0]["round_id"] == "r-a3-1"
    assert appr_req[0]["payload"]["tool"] == "run_command"
    assert appr_res[0]["payload"]["approved"] is True
    # frontend saw exactly one approval prompt on the wire too
    assert len([t for t, _ in wire if t == "approval_request"]) == 1
    # inner tool executed successfully after approval
    trs = [r for r in _rows_of(db, "tool_result")
           if r["payload"].get("name") == "run_command"]
    assert trs and trs[0]["payload"]["ok"] is True
    assert result.get("reply") == "结束"


def test_parallel_inner_rounds_logged_with_par_lineage(monkeypatch):
    """Parallel sub-agents each log inner turn_start/request rows sharing the
    round and carrying 'par-*' parent_task_id."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    call = _tool("subagent_parallel", "p1",
                 {"tasks": [{"task": "任务一"}, {"task": "任务二"}]})
    main_responses = [_resp(content="", tool_calls=[call]),
                      _resp(content="汇总完", tool_calls=[])]
    inner_responses = [_resp(content="甲完成", tool_calls=[]),
                       _resp(content="乙完成", tool_calls=[])]
    result, _, seen_inner, _ = _run_with_subagent(
        monkeypatch, db, main_responses, inner_responses, "r-par-1")

    assert result.get("reply") == "汇总完"
    assert len(seen_inner) == 2
    inner_requests = [r for r in _rows_of(db, "request")
                      if r["parent_task_id"].startswith("par-")]
    assert len(inner_requests) == 2
    assert all(r["parent_task_id"].startswith("par-") for r in inner_requests)
    # both inner tasks share the same parallel delegation base id
    bases = {r["parent_task_id"].rsplit("-", 1)[0] for r in inner_requests}
    assert len(bases) == 1 and bases.pop().startswith("par-")
    assert all(r["round_id"] == "r-par-1" for r in inner_requests)
    # both inner turns started
    inner_turn = [r for r in _rows_of(db, "turn_start")
                  if r["parent_task_id"].startswith("par-")]
    assert len(inner_turn) == 2


def test_subagent_spawn_approval_resolved_logged(monkeypatch):
    """When the delegation itself needs approval (ASK on subagent_spawn),
    approval_request + approval_resolved are logged at the parent scope."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    call = _tool("subagent_spawn", "s2", {"task": "子任务丙"})
    main_responses = [_resp(content="", tool_calls=[call]),
                      _resp(content="主收尾", tool_calls=[])]
    inner_responses = [_resp(content="内层干活完成", tool_calls=[])]
    result, _, _, wire = _run_with_subagent(
        monkeypatch, db, main_responses, inner_responses,
        "r-sp-1", ask_spawn=True)

    assert result.get("reply") == "主收尾"
    req = _rows_of(db, "approval_request")
    res = _rows_of(db, "approval_resolved")
    # spawn approval gate(s): every approval_request has a matching resolved
    # row, resolved approved=True, same round; at least one pair exists
    assert len(req) >= 1 and len(res) == len(req)
    assert all(r["payload"]["tool"] == "subagent_spawn" for r in req)
    assert all(r["payload"]["approved"] is True for r in res)
    assert all(r["round_id"] == "r-sp-1" for r in req + res)
    # inner agent ran (its own request row exists under the sub lineage)
    inner_requests = [r for r in _rows_of(db, "request")
                      if r["parent_task_id"].startswith("sub-")]
    assert len(inner_requests) == 1
    # every approval prompt that reached the wire has a resolved row behind it
    wire_appr = [t for t, _ in wire if t == "approval_request"]
    assert len(wire_appr) == len(req)


# ---------------------------------------------------------------------
# 6. router GET /api/v1/agent/events shape + cursor (invariant 6)
# ---------------------------------------------------------------------

def test_events_api_returns_shape_and_cursor(monkeypatch):
    """Router maps db rows -> {events, next_after, count}; after cursor
    advances to the last returned event id."""
    from app.routers import agent as agent_api

    fake = types.ModuleType("app.db")
    fake.query_agent_events = lambda round_id, after=0, limit=500: [
        {"id": 10, "type": "turn_start", "step": 0, "payload": {},
         "ts": "2026-09-06 10:00:00"},
        {"id": 11, "type": "request", "step": 1, "payload": {},
         "ts": "2026-09-06 10:00:01"},
    ]
    old = sys.modules.get("app.db")
    sys.modules["app.db"] = fake
    try:
        out = agent_api.api_v1_agent_events(round_id="r-x-1", after=5, limit=10)
    finally:
        if old is not None:
            sys.modules["app.db"] = old
        else:
            del sys.modules["app.db"]
    assert out["count"] == 2
    assert out["next_after"] == 11
    assert [e["id"] for e in out["events"]] == [10, 11]
    assert out["events"][0]["type"] == "turn_start"
    assert out["events"][1]["payload"] == {}


def test_events_api_empty_result_echoes_after(monkeypatch):
    """No rows -> count 0 and next_after echoes the requested after cursor."""
    from app.routers import agent as agent_api

    fake = types.ModuleType("app.db")
    fake.query_agent_events = lambda round_id, after=0, limit=500: []
    old = sys.modules.get("app.db")
    sys.modules["app.db"] = fake
    try:
        out = agent_api.api_v1_agent_events(round_id="r-none", after=99)
    finally:
        if old is not None:
            sys.modules["app.db"] = old
        else:
            del sys.modules["app.db"]
    assert out == {"events": [], "next_after": 99, "count": 0}


def test_done_event_payload_round_id_injection_route(monkeypatch):
    """The SSE done event receives round_id + event_id injected by the router
    (event_id = ledger tail id for the round)."""
    # this is exercised in agent.py's SSE generator; emulate its logic:
    # after a round the router reads last_agent_event_id(round_id)
    from app.routers import agent as agent_api

    fake = types.ModuleType("app.db")
    fake.last_agent_event_id = lambda round_id: 42
    old = sys.modules.get("app.db")
    sys.modules["app.db"] = fake
    try:
        # router imports db lazily inside the SSE coroutine; here we only
        # verify the query function is reachable through the app.db seam
        assert agent_api is not None
        assert fake.last_agent_event_id("r-x-1") == 42
    finally:
        if old is not None:
            sys.modules["app.db"] = old
        else:
            del sys.modules["app.db"]


# ---------------------------------------------------------------------
# extra detail assertions
# ---------------------------------------------------------------------

def test_assistant_row_carries_full_content_and_tool_calls(monkeypatch):
    """assistant row holds full text + tool_calls + usage + finish_reason."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    tool_call = _tool("run_command", "c9", {"cmd": "dir"})
    responses = [_resp(content="", tool_calls=[tool_call],
                       usage={"prompt_tokens": 11, "completion_tokens": 7}),
                 _resp(content="完成", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("查一下", emit=emit, max_steps=4,
                                    round_id="r-asst-1")

    asyncio.run(go())
    asst = _rows_of(db, "assistant")
    assert len(asst) == 2
    first = asst[0]["payload"]
    assert first["step"] == 1
    assert first["tool_calls"] == [{"id": "c9", "name": "run_command",
                                    "args": {"cmd": "dir"}}]
    assert first["usage"] == {"prompt_tokens": 11, "completion_tokens": 7}
    assert first["finish_reason"] == "stop"
    assert asst[1]["payload"]["content"] == "完成"


def test_turn_start_row_payload_fields(monkeypatch):
    """turn_start carries role/depth/mode/user_message + history count."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="好", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("开头", emit=emit, max_steps=2,
                                    round_id="r-ts-1")

    asyncio.run(go())
    ts = _rows_of(db, "turn_start")
    assert len(ts) == 1
    pl = ts[0]["payload"]
    assert pl["role"] == "main" and pl["depth"] == 0
    assert pl["user_message"] == "开头"
    assert pl["history_len"] == 0
    assert ts[0]["round_id"] == "r-ts-1"


def test_tool_call_and_result_payload(monkeypatch):
    """tool_call/tool_result rows keep tool name, args, ok and brief."""
    db = FakeDb()
    _install_db(monkeypatch, db)
    _stub_tools(monkeypatch)
    _stub_decide(monkeypatch, (DECISION_ALLOW, "test"))
    seen, events = [], []

    async def emit(t, p):
        events.append((t, p))

    responses = [_resp(content="", tool_calls=[_tool("run_command", "c3")]),
                 _resp(content="收工", tool_calls=[])]
    _make_chat_stub(monkeypatch, seen, responses)

    async def go():
        return await run_agent_task("执行", emit=emit, max_steps=4,
                                    round_id="r-tr-1")

    asyncio.run(go())
    tc = _rows_of(db, "tool_call")
    assert len(tc) == 1
    assert tc[0]["payload"]["name"] == "run_command"
    assert tc[0]["payload"]["risk"] == "sensitive"
    assert tc[0]["payload"]["args"] == {"cmd": "echo hi"}
    tr = _rows_of(db, "tool_result")
    assert len(tr) == 1
    assert tr[0]["payload"]["ok"] is True
    # write order: tool_call before tool_result
    assert tc[0]["id"] < tr[0]["id"]


def test_events_api_passes_round_after_limit_to_db(monkeypatch):
    """Router forwards round_id/after/limit verbatim to query_agent_events."""
    from app.routers import agent as agent_api
    captured = {}

    def fake_query(round_id, after=0, limit=500):
        captured.update(round_id=round_id, after=after, limit=limit)
        return []

    fake = types.ModuleType("app.db")
    fake.query_agent_events = fake_query
    old = sys.modules.get("app.db")
    sys.modules["app.db"] = fake
    try:
        out = agent_api.api_v1_agent_events(round_id="r-param-1", after=7,
                                            limit=321)
    finally:
        if old is not None:
            sys.modules["app.db"] = old
        else:
            del sys.modules["app.db"]
    assert captured == {"round_id": "r-param-1", "after": 7, "limit": 321}
    assert out["next_after"] == 7  # empty result echoes after
