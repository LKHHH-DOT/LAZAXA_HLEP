# -*- coding: utf-8 -*-
"""pytest 公共配置：把项目根目录加入 sys.path，便于 `from app import ...`。"""
import os
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ---- 测试期外部 GUI 启动守卫（2026-09-06）----
# 历史教训：test_mcp_tools 的超时用例漏 mock subprocess.Popen，导致每次全量
# pytest 都真实拉起 Blender GUI 窗口。这里做一道全局保险：测试期间任何代码
# 想真实启动黑名单内的外部 GUI 程序（即说明该用例漏 mock），立即 fail-loud，
# 而不是在桌面上莫名弹窗。各用例自己 monkeypatch 的 Popen 会临时覆盖本守卫、
# 用例结束后自动恢复，互不冲突。
_FORBIDDEN_GUI = ("blender.exe",)
_REAL_POPEN = subprocess.Popen


class _GuardedPopen(_REAL_POPEN):
    def __init__(self, args, *a, **k):
        flat = (" ".join(args).lower() if isinstance(args, (list, tuple))
                else str(args).lower())
        hit = next((x for x in _FORBIDDEN_GUI if x in flat), None)
        if hit:
            raise RuntimeError(
                f"测试中禁止真实启动外部 GUI（{hit}）：args={args!r}；"
                f"请在该用例 monkeypatch 对应模块的 subprocess.Popen")
        super().__init__(args, *a, **k)


@pytest.fixture(autouse=True)
def _guard_external_gui_launch(monkeypatch):
    monkeypatch.setattr(subprocess, "Popen", _GuardedPopen)
    yield
