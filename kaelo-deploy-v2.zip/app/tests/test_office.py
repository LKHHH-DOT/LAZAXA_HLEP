# -*- coding: utf-8 -*-
"""办公工具单元测试（app/agent/tools/office.py · 批次 D）。

覆盖：Excel 写→读回环、Excel 汇总、Word 写→读回环、PDF 文本提取（动态生成最小 PDF）、
run_python_script（基本执行/超时终止/错误退出码/空代码拒绝/联网放行）、
受保护目录拒绝、注册完整性。
"""
import os
import tempfile

from app.agent.tools import office
from app.agent.registry import ToolRegistry


def _make_min_pdf(text: str) -> bytes:
    """字节级构造一个含单行文本的最小 PDF（xref 偏移用实际长度计算，保证可解析）。"""
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
    ]
    stream = b"BT /F1 24 Tf 100 700 Td (" + text.encode("latin-1") + b") Tj ET"
    objs.append(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref_pos = len(out)
    out += b"xref\n0 %d\n" % (len(objs) + 1)
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (
        len(objs) + 1, xref_pos)
    return bytes(out)


# ---------- Excel ----------

def test_excel_write_then_read_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "成绩.xlsx")
        r = office._excel_write(path, headers=["姓名", "分数"],
                                data=[["张三", 90], ["李四", 85]])
        assert r.ok, r.error
        assert os.path.exists(path)
        r = office._excel_read(path)
        assert r.ok, r.error
        assert "张三" in r.text and "90" in r.text and "李四" in r.text


def test_excel_write_backs_up_existing_file():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "a.xlsx")
        office._excel_write(path, data=[["v1"]])
        office._excel_write(path, data=[["v2"]])
        assert os.path.exists(path + ".bak"), "写第二次前应自动备份 .bak"


def test_excel_summary_lists_sheets():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "s.xlsx")
        office._excel_write(path, headers=["A", "B"], data=[[1, 2], [3, 4]])
        r = office._excel_summary(path)
        assert r.ok and "Sheet1" in r.text and "3 行" in r.text


def test_excel_read_missing_file():
    r = office._excel_read(r"C:\不存在\no.xlsx")
    assert not r.ok and "文件不存在" in r.error


# ---------- Word ----------

def test_word_write_then_read_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "报告.docx")
        r = office._word_write(path, title="测试报告", paragraphs=["第一段", "第二段"])
        assert r.ok, r.error
        r = office._word_read(path)
        assert r.ok, r.error
        assert "测试报告" in r.text and "第一段" in r.text


# ---------- PDF ----------

def test_pdf_read_extracts_text():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "doc.pdf")
        with open(path, "wb") as f:
            f.write(_make_min_pdf("Hello PDF"))
        r = office._pdf_read(path)
        assert r.ok, r.error
        assert "Hello PDF" in r.text


def test_pdf_read_single_page_and_missing():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "doc.pdf")
        with open(path, "wb") as f:
            f.write(_make_min_pdf("PageOne"))
        r = office._pdf_read(path, page=1)
        assert r.ok and "PageOne" in r.text
    r = office._pdf_read(r"C:\不存在\no.pdf")
    assert not r.ok and "文件不存在" in r.error


# ---------- 受保护目录 ----------

def test_office_rejects_protected_path():
    r = office._excel_read(r"C:\Windows\System32\a.xlsx")
    assert not r.ok and "受保护目录" in r.error
    r = office._word_write(r"C:\Windows\b.docx", paragraphs=["x"])
    assert not r.ok and "受保护目录" in r.error


# ---------- run_python_script ----------

def test_run_python_script_basic():
    r = office._run_python_script(code="print('hello lazaxa')\nprint(1 + 2)")
    assert r.ok, r.error
    assert "hello lazaxa" in r.text and "3" in r.text


def test_run_python_script_rejects_empty():
    r = office._run_python_script(code="   ")
    assert not r.ok and "不能为空" in r.error


def test_run_python_script_timeout_kills_process():
    r = office._run_python_script(
        code="import time\ntime.sleep(30)\nprint('never')", timeout=2)
    assert not r.ok and "超时" in r.error


def test_run_python_script_error_exit_code():
    r = office._run_python_script(code="raise ValueError('boom')")
    assert not r.ok and "ValueError" in r.error


def test_run_python_script_can_reach_network_when_allowed():
    import threading
    import http.server

    class _H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")
        def log_message(self, *args):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 0), _H)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        code = (
            "import urllib.request\n"
            'print(urllib.request.urlopen("http://127.0.0.1:%d/", timeout=3).read().decode())\n' % port
        )
        r = office._run_python_script(code=code, allow_network=True)
        assert r.ok and "OK" in r.text, r.text
    finally:
        srv.shutdown()


# ---------- 注册 ----------

def test_office_tools_registered():
    reg = ToolRegistry()
    office.register_all(reg)
    names = reg.names()
    for expected in ("office_excel_read", "office_excel_write", "office_excel_summary",
                     "office_word_read", "office_word_write", "office_pdf_read",
                     "run_python_script"):
        assert expected in names, f"缺少工具 {expected}"


def test_run_python_script_risk_is_dangerous():
    reg = ToolRegistry()
    office.register_all(reg)
    assert reg.get("run_python_script").risk == "dangerous"
    assert reg.get("office_excel_write").risk == "sensitive"
    assert reg.get("office_pdf_read").risk == "safe"
