# -*- coding: utf-8 -*-
"""GUI 里程碑断言测试（2026-09-04 · P3：借微软 fara）。

覆盖 gui.py 新增的 run_action_milestones 原语：
  1. 工具注册与风险分级（sensitive / 超时给足）
  2. 逐段顺序执行 + text/vlm 段末断言命中 → completed 全通过
  3. text 断言持续未命中 → 停在失败段，completed 保留前缀，重试 2 次耗尽
  4. vlm 不可用自动降级放行；可用但描述"目标未出现" → 段失败
  5. stable（屏幕静下来）断言与 _wait_stable 直接行为
  6. expect.type 非法 / 缺 expect → 前置拒绝不空转
"""
import json

from PIL import Image

from app import config
from app.agent.registry import ToolRegistry, ToolResult
from app.agent.tools import gui


def _fresh_registry():
    r = ToolRegistry()
    from app.agent.tools import register_all
    register_all(r)
    return r


def _solid(size, color=(255, 255, 255)):
    return Image.new("RGB", size, color)


class _FakePG:
    """最小 pyautogui 替身：记录 click/typewrite/press 调用。"""

    def __init__(self):
        self.calls = []

    def click(self, *a, **kw):
        self.calls.append(("click", a, kw))

    def typewrite(self, text, **kw):
        self.calls.append(("typewrite", text, kw))

    def press(self, key):
        self.calls.append(("press", key))


def _patch_screen(monkeypatch, fake):
    """把里程碑执行依赖的感知件/耗时全部替换为确定性替身。"""
    monkeypatch.setattr(gui, "_lazy_pyautogui", lambda: fake)
    monkeypatch.setattr(gui, "_set_clipboard_text", lambda t: None)
    monkeypatch.setattr(config, "UI_VERIFY_WAIT_MS", 0)


def _ok_text(value: str, x: int = 1, y: int = 2):
    return ToolResult.ok_result(json.dumps(
        {"found": True, "text": value, "x": x, "y": y}, ensure_ascii=False))


def _hit_text(text):
    def _find(text, occurrence=1):
        return _ok_text(text)

    return _find


# ---------- 1. 注册与风险 ----------

def test_milestones_tool_registered():
    r = _fresh_registry()
    assert "run_action_milestones" in r.names()
    t = r.get("run_action_milestones")
    assert t.risk == "sensitive"
    assert t.timeout >= 120  # 含重试 + stable 等待，超时要给足


# ---------- 2. 逐段执行 + 断言命中 ----------

def test_milestones_all_pass_sequential(monkeypatch):
    fake = _FakePG()
    _patch_screen(monkeypatch, fake)
    monkeypatch.setattr(gui, "_find_on_screen", _hit_text("hello"))
    monkeypatch.setattr(gui, "_vlm_available", lambda: "gemma3:4b 不可用")

    res = gui._run_action_milestones(milestones=[
        {"name": "输入", "actions": [{"type": "click", "x": 5, "y": 5},
                                     {"type": "type_text", "text": "hello"}],
         "expect": {"type": "text", "value": "hello"}},
        {"name": "保存", "actions": [{"type": "press_key", "key": "enter"}],
         "expect": {"type": "vlm", "value": "保存框出现了吗？"}},
    ])
    assert res.ok
    out = json.loads(res.text)
    assert out["ok"] is True
    assert out["completed"] == ["输入", "保存"]
    assert [c[0] for c in fake.calls] == ["click", "typewrite", "press"]


# ---------- 3. 断言失败 → 停在失败段 + completed 前缀 + 重试耗尽 ----------

def test_milestones_miss_stops_with_completed_prefix(monkeypatch):
    fake = _FakePG()
    _patch_screen(monkeypatch, fake)
    hits = {"n": 0}

    def _find(text, occurrence=1):
        hits["n"] += 1
        if text == "标题":  # 第一段命中
            return _ok_text("标题")
        return ToolResult.err_result(f"未在屏幕上找到文字 '{text}'")

    monkeypatch.setattr(gui, "_find_on_screen", _find)
    res = gui._run_action_milestones(milestones=[
        {"name": "打开", "actions": [{"type": "click", "x": 1, "y": 1}],
         "expect": {"type": "text", "value": "标题"}},
        {"name": "保存确认", "actions": [{"type": "click", "x": 9, "y": 9}],
         "expect": {"type": "text", "value": "确定保存"}},
    ])
    assert not res.ok
    out = json.loads(res.text)
    assert out["ok"] is False
    assert out["completed"] == ["打开"]  # 前缀保留
    assert out["failed_milestone"] == "保存确认"
    assert "未在屏幕上找到" in out["error"] or "未命中" in out["error"]
    # 失败段原执行 + 2 次重试 → 该段 click 共 3 次
    n_click = sum(1 for c in fake.calls if c[0] == "click")
    assert n_click == 4  # 第一段 1 次 + 失败段 3 次
    assert out["retries"] == 2
    # P2-2：重试次数经 result.meta 上报，供审计落 agent_tasks.retries
    assert res.meta["retries"] == 2


# ---------- 4. vlm 降级 / 否定判据 ----------

def test_milestones_vlm_available_but_not_appeared(monkeypatch):
    fake = _FakePG()
    _patch_screen(monkeypatch, fake)
    monkeypatch.setattr(gui, "_vlm_available", lambda: "")

    def _describe(region=None, question=""):
        return ToolResult.ok_result(json.dumps(
            {"description": "屏幕上没有出现保存按钮"}, ensure_ascii=False),
            brief="没有出现")

    monkeypatch.setattr(gui, "_screen_describe", _describe)
    res = gui._run_action_milestones(milestones=[
        {"name": "等弹窗", "actions": [],
         "expect": {"type": "vlm", "value": "弹窗出现了吗？"}},
    ])
    assert not res.ok
    out = json.loads(res.text)
    assert out["completed"] == []
    assert out["failed_milestone"] == "等弹窗"
    assert "尚未出现" in out["error"]


def test_milestones_vlm_missing_degrades_not_block(monkeypatch):
    # VLM 不可用 → 自动降级放行（不因感知件缺失卡死链路）
    fake = _FakePG()
    _patch_screen(monkeypatch, fake)
    monkeypatch.setattr(gui, "_vlm_available", lambda: "本地视觉模型 gemma3:4b 不可用")
    monkeypatch.setattr(gui, "_find_on_screen", _hit_text("保存"))
    res = gui._run_action_milestones(milestones=[
        {"name": "确认", "actions": [],
         "expect": {"type": "vlm", "value": "界面正常吗？"}},
        {"name": "已就绪", "actions": [],
         "expect": {"type": "text", "value": "保存"}},
    ])
    assert res.ok
    out = json.loads(res.text)
    assert out["completed"] == ["确认", "已就绪"]
    assert res.meta["retries"] == 0     # P2-2：未重试上也上报（供审计区分 0 次）


# ---------- 5. stable：屏幕静下来 ----------

def test_wait_stable_returns_true_when_static(monkeypatch):
    import time as _t
    monkeypatch.setattr(_t, "sleep", lambda s: None)
    monkeypatch.setattr(gui, "_grab_screen",
                        lambda pg, region=None: _solid((200, 200)))
    ok, note = gui._wait_stable(_FakePG(), timeout=0.4, interval=0.2, frames=2)
    assert ok and "静" in note


def test_milestones_stable_expect(monkeypatch):
    fake = _FakePG()
    _patch_screen(monkeypatch, fake)
    monkeypatch.setattr(gui, "_wait_stable",
                        lambda pg, region=None, timeout=8.0,
                               frames=2, interval=0.6: (True, "已静下来"))
    res = gui._run_action_milestones(milestones=[
        {"name": "落地", "actions": [{"type": "press_key", "key": "enter"}],
         "expect": {"type": "stable", "timeout": 1}},
    ])
    assert res.ok
    out = json.loads(res.text)
    assert out["completed"] == ["落地"]


# ---------- 6. 前置校验：expect.type 非法 ----------

def test_milestones_rejects_bad_expect_type():
    res = gui._run_action_milestones(milestones=[
        {"name": "x", "actions": [], "expect": {"type": "fly"}},
    ])
    assert not res.ok and "expect.type" in res.error

    res = gui._run_action_milestones(milestones=[{"name": "x"}])
    assert not res.ok and "expect.type" in res.error

    res = gui._run_action_milestones(milestones=[])
    assert not res.ok and "milestones" in res.error
