# -*- coding: utf-8 -*-
"""超长上下文与压缩工程单元测试（app/agent/context.py · 2026-08-17 四层方案）。

覆盖：字符估算、工具结果修剪（截断/归档/未超限不动）、按轮切分、
LLM 交接单压缩（阈值不触发原样 / 触发替换+归档+保留最近轮 / LLM 失败退化）。
压缩走 LLM 的用例全部 monkeypatch，绝不真实调用 DeepSeek。
"""
import os

from app.agent import context


def _mk_messages(n_user: int = 6, payload: int = 100) -> list[dict]:
    """构造 n_user 轮 user+assistant 对话，payload 为每条内容附加字符数。"""
    msgs = []
    for i in range(n_user):
        msgs.append({"role": "user", "content": f"用户问题{i}：" + "x" * payload})
        msgs.append({"role": "assistant", "content": f"回答{i}：" + "y" * payload})
    return msgs


class _FakeResp:
    """伪造 llm.chat 返回对象（只需 content 属性）。"""

    def __init__(self, content: str):
        self.content = content


# ---------- 字符估算 ----------

def test_estimate_chars_counts_content_and_tool_calls():
    msgs = [
        {"role": "user", "content": "abc"},
        {"role": "assistant", "content": "中文", "tool_calls": [
            {"function": {"name": "run_command",
                          "arguments": '{"cmd":"x"}'}}]},
    ]
    expected = 3 + 2 + len("run_command") + len('{"cmd":"x"}')
    assert context.estimate_chars(msgs) == expected


# ---------- 层一：工具结果修剪 ----------

def test_trim_short_unchanged():
    text = "short"
    assert context.trim_tool_result(text, limit=200) == text


def test_trim_long_truncates_and_archives(tmp_path):
    text = "A" * 5000
    out = context.trim_tool_result(text, limit=200,
                                   archive_dir=str(tmp_path), name="tt")
    assert len(out) < 5000
    assert "已截断" in out
    archive = os.path.join(str(tmp_path), "tt.jsonl")
    assert os.path.exists(archive)
    with open(archive, encoding="utf-8") as f:
        assert "A" * 5000 in f.read()  # 完整原文归档


# ---------- 层三：按轮切分 ----------

def test_split_keep_recent():
    msgs = _mk_messages(5, 5)
    old, tail = context._split_keep_recent(msgs, 2)
    assert len(old) == 6   # 3 轮 × 2 条
    assert len(tail) == 4  # 最近 2 轮 × 2 条
    assert "用户问题0" in str(old[0]["content"])
    assert "用户问题3" in str(tail[0]["content"])


def test_split_keep_recent_not_enough_returns_empty_old():
    msgs = _mk_messages(2, 5)
    old, tail = context._split_keep_recent(msgs, 3)
    assert old == []
    assert tail is msgs


# ---------- 层二+三：LLM 交接单压缩 ----------

def test_compact_below_threshold_unchanged():
    messages = _mk_messages(2, 10)
    out = context.compact_history(messages, keep_recent=2, threshold=100000)
    assert out is messages  # 未超阈值原样返回（同一对象）


def test_compact_replaces_and_keeps_recent(tmp_path, monkeypatch):
    messages = [{"role": "system", "content": "sys"}] + _mk_messages(6, 100)
    monkeypatch.setattr(context.llm, "chat",
                        lambda *a, **k: _FakeResp("目标: 测试\n已完成: 压缩"))
    out = context.compact_history(messages, keep_recent=2, threshold=50,
                                  archive_dir=str(tmp_path), name="t")
    texts = [str(m.get("content")) for m in out]
    # 交接单插入、旧段移除
    assert any("交接单" in t for t in texts)
    assert not any("用户问题0" in t for t in texts)
    assert not any("回答0" in t for t in texts)
    # 保留最近 2 轮完整
    assert any("用户问题4" in t for t in texts)
    assert any("用户问题5" in t for t in texts)
    # 压缩前原文归档
    archive = os.path.join(str(tmp_path), "t.jsonl")
    assert os.path.exists(archive)
    with open(archive, encoding="utf-8") as f:
        assert "用户问题0" in f.read()


def test_compact_llm_failure_fallback(tmp_path, monkeypatch):
    messages = [{"role": "system", "content": "sys"}] + _mk_messages(6, 100)

    def boom(*a, **k):
        raise RuntimeError("DeepSeek API 错误 500")

    monkeypatch.setattr(context.llm, "chat", boom)
    out = context.compact_history(messages, keep_recent=2, threshold=50,
                                  archive_dir=str(tmp_path), name="t")
    texts = [str(m.get("content")) for m in out]
    # 不抛异常，退化为基础截断（保留头部指令 + 最近轮）
    assert any("截断归档" in t for t in texts)
    assert any("用户问题5" in t for t in texts)


def test_compact_force_threshold_zero_on_overflow(tmp_path, monkeypatch):
    """故障兜底场景：threshold=0 强制压缩（400 上下文超限后重试用）。"""
    messages = [{"role": "system", "content": "sys"}] + _mk_messages(4, 20)
    monkeypatch.setattr(context.llm, "chat",
                        lambda *a, **k: _FakeResp("交接单内容"))
    out = context.compact_history(messages, keep_recent=1, threshold=0,
                                  archive_dir=str(tmp_path), name="t")
    assert out is not messages
    assert any("交接单" in str(m.get("content")) for m in out)
