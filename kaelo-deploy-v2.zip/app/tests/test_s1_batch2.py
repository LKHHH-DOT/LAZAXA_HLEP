# -*- coding: utf-8 -*-
"""M1 止血第二批（S1-6 ~ S1-10）单元测试。

覆盖：
  S1-6  finish_reason=length 断点续写（直答路径）：首段实况流出后追加
        assistant+续写 user 重问；usage 逐轮累计；续写受 _CONTINUE_MAX 上限；
        续写轮空输出/调工具 → 并入已有文本 + 截断说明收尾
  S1-7  交接单改为 system 角色注入（紧随原 system 之后，带分隔标记），
        不再以 user 消息混入对话（避免污染用户指令区 / 破坏 tool 配对）
  S1-8  CONTEXT_COMPACT_KEEP_RECENT 默认 3（config 常量 + compact_history
        默认参数同步，行为上多留一轮工作上下文）
  S1-9  run_action_sequence 标注已弃用（description 引导改用 milestones，
        仍保留注册以兼容旧任务）
  S1-10 list_skills 按目录签名缓存：文件未变不重扫、增删改自动失效重扫、
        对外返回拷贝防污染
"""
import asyncio
import types

import pytest

from app import config
from app.agent import context, loop, skills
from app.agent.registry import ToolRegistry


# ---------- 通用 helper（对齐 test_loop_reliability 的桩模式） ----------

class _FakeResp:
    """伪造 llm.chat 返回对象（context.compact_history 只需 content）。"""

    def __init__(self, content: str):
        self.content = content


def _mk_messages(n_user: int = 6, payload: int = 100,
                 with_system: bool = True) -> list[dict]:
    """构造 n_user 轮 user+assistant 对话，可带首条 system。"""
    msgs = [{"role": "system", "content": "sys"}] if with_system else []
    for i in range(n_user):
        msgs.append({"role": "user", "content": f"用户问题{i}：" + "x" * payload})
        msgs.append({"role": "assistant", "content": f"回答{i}：" + "y" * payload})
    return msgs


def _resp(content, finish_reason="stop", usage=None):
    """直答响应桩：携带 finish_reason/usage（S1-2/S1-6 字段）。"""
    return types.SimpleNamespace(
        has_tool_calls=False,
        content=content,
        tool_calls=[],
        finish_reason=finish_reason,
        usage=usage,
        to_assistant_message=lambda content=content: {"role": "assistant",
                                                      "content": content or "",
                                                      "tool_calls": []},
    )


def _run(monkeypatch, responses, max_steps=20):
    """mock llm.chat，跑一次直答任务；返回 (各轮 messages 快照, 事件, 汇总)。"""
    from app.agent import llm as llm_mod

    seen = []
    it = iter(responses)

    def fake_chat(messages, tools, *a, **k):
        seen.append([dict(m) for m in messages])  # 快照：messages 同一对象会被续写追加
        return next(it)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        return await loop.run_agent_task("测试任务", emit=emit, max_steps=max_steps)

    result = asyncio.run(go())
    return seen, events, result


def _done(events):
    ds = [p for t, p in events if t == "done"]
    return ds[-1] if ds else None


def _tokens(events):
    return "".join(p.get("text", "") for t, p in events if t == "token")


# ---------- S1-6：finish_reason=length 断点续写 ----------

def test_s16_truncated_continues_once_and_accumulates_usage(monkeypatch):
    """length 截断：续写一次并拼接；续写请求把"上段+续写提示"追加进历史；
    usage 全程累计进 done.tokens。"""
    seg1 = "这是第一段被截断的内容。"
    seg2 = "这是续写出来的第二段。"
    seen, events, result = _run(monkeypatch, [
        _resp(seg1, finish_reason="length", usage={"prompt_tokens": 100,
                                                   "completion_tokens": 50}),
        _resp(seg2, finish_reason="stop", usage={"prompt_tokens": 80,
                                                 "completion_tokens": 70}),
    ])
    assert len(seen) == 2          # 首轮 + 1 次续写
    # 续写轮历史尾部 = 上一段 assistant + 续写 user 提示
    assert seen[1][-1]["role"] == "user"
    assert seen[1][-1]["content"] == loop._CONTINUE_PROMPT
    assert seen[1][-2]["role"] == "assistant"
    assert seg1 in seen[1][-2]["content"]
    # 有提示续写的 thinking 事件
    assert any(t == "thinking" and "续写" in p.get("note", "")
               for t, p in events)
    # 最终回复 = 两段拼接；token 实况包含两段
    done = _done(events)
    assert done["reply"] == seg1 + seg2
    assert result["reply"] == seg1 + seg2
    assert _tokens(events) == seg1 + seg2
    # usage 累计
    assert done["tokens"] == {"prompt_tokens": 180, "completion_tokens": 120}


def test_s16_no_truncation_unchanged(monkeypatch):
    """正常结束（stop / 无 finish_reason 字段）：只问一次，不追加续写消息。"""
    text = "普通完整回答。"
    seen, events, result = _run(monkeypatch, [_resp(text, finish_reason="stop")])
    assert len(seen) == 1
    assert not any(t == "thinking" and "续写" in p.get("note", "")
                   for t, p in events)
    done = _done(events)
    assert done["reply"] == text
    assert done["stop_reason"] == "completed"
    # 无 usage 桩（旧服务端）不崩、token 为 0
    seen2, events2, result2 = _run(monkeypatch, [_resp(text)])
    assert result2["reply"] == text
    assert _done(events2)["tokens"] == {"prompt_tokens": 0, "completion_tokens": 0}


def test_s16_truncation_respects_continue_max(monkeypatch):
    """连续两次 length 截断：最多续写 _CONTINUE_MAX 次后收尾（即使仍截断）。"""
    seg1, seg2, seg3 = "第一段", "第二段", "第三段"
    seen, events, result = _run(monkeypatch, [
        _resp(seg1, finish_reason="length", usage={"prompt_tokens": 10,
                                                   "completion_tokens": 10}),
        _resp(seg2, finish_reason="length", usage={"prompt_tokens": 10,
                                                   "completion_tokens": 10}),
        _resp(seg3, finish_reason="length", usage={"prompt_tokens": 10,
                                                   "completion_tokens": 10}),
    ])
    # 首次 + 续写 2 次 = 3 次模型调用，之后不再追问
    assert len(seen) == 3
    assert _done(events)["reply"] == seg1 + seg2 + seg3
    # 三份 usage 全累计
    assert _done(events)["tokens"] == {"prompt_tokens": 30,
                                       "completion_tokens": 30}


def test_s16_continuation_empty_ends_with_truncate_note(monkeypatch):
    """续写轮空输出（未截断）：不再追问，附加"已截断"说明后正常收尾。"""
    seg1 = "被截断的前半段"
    seen, events, result = _run(monkeypatch, [
        _resp(seg1, finish_reason="length"),
        _resp("", finish_reason="stop"),
    ])
    assert len(seen) == 2
    done = _done(events)
    assert done["reply"].startswith(seg1)
    assert "被截断" in done["reply"]
    assert done["stop_reason"] == "completed"


# ---------- S1-7：交接单 role=system + 分隔标记 ----------

def test_s17_handoff_is_system_role_and_after_original_system(monkeypatch, tmp_path):
    """交接单以 system 角色注入、紧随原 system 之后，且带分隔标记。"""
    messages = _mk_messages(6, 100)
    monkeypatch.setattr(context.llm, "chat",
                        lambda *a, **k: _FakeResp("目标: 测试\n已完成: 压缩"))
    out = context.compact_history(messages, keep_recent=2, threshold=50,
                                  archive_dir=str(tmp_path), name="t")
    roles = [m["role"] for m in out]
    # 头部仍是 system 序列；原 system 后紧跟交接单 system（不再是 user）
    assert roles[0] == "system"
    handoff_idx = next(i for i, m in enumerate(out)
                       if "交接单开始" in str(m.get("content")))
    assert roles[handoff_idx] == "system"
    assert handoff_idx == 1          # 紧随原 system 之后
    assert "交接单结束" in out[handoff_idx]["content"]
    # 最近轮仍保留（role 改动不影响轮次保留）
    texts = [str(m.get("content")) for m in out]
    assert any("用户问题4" in t for t in texts)
    assert any("用户问题5" in t for t in texts)


# ---------- S1-8：keep_recent 2→3 ----------

def test_s18_keep_recent_default_is_three(monkeypatch, tmp_path):
    """config 常量与 compact_history 默认参数均为 3；默认调用多留一轮上下文。"""
    assert config.CONTEXT_COMPACT_KEEP_RECENT == 3
    import inspect
    default = inspect.signature(context.compact_history).parameters[
        "keep_recent"].default
    assert default == 3
    messages = _mk_messages(6, 20)
    monkeypatch.setattr(context.llm, "chat",
                        lambda *a, **k: _FakeResp("交接单内容"))
    out = context.compact_history(messages, threshold=0)   # 不传 keep_recent
    texts = [str(m.get("content")) for m in out]
    assert not any("用户问题2" in t for t in texts)   # 前 3 轮被压缩
    assert any("用户问题3" in t for t in texts)       # 最近 3 轮保留
    assert any("用户问题4" in t for t in texts)
    assert any("用户问题5" in t for t in texts)


# ---------- S1-9：run_action_sequence 标注弃用 ----------

def test_s19_run_action_sequence_deprecated_note():
    """run_action_sequence 保留注册（兼容旧任务）但 description 标注弃用，
    并引导改用 run_action_milestones。"""
    reg = ToolRegistry()
    from app.agent import tools as all_tools
    all_tools.register_all(reg)
    t = reg.get("run_action_sequence")
    assert t is not None
    assert "已弃用" in t.description
    assert "run_action_milestones" in t.description
    # 替代工具本身仍在、description 无弃用标记
    m = reg.get("run_action_milestones")
    assert m is not None and "已弃用" not in m.description


# ---------- S1-10：list_skills 目录签名缓存 ----------

@pytest.fixture(autouse=True)
def _reset_skills_cache():
    """每测重置进程级缓存，保证用例独立。"""
    skills._cache_sig = None
    skills._cache_skills = None
    yield


def _write_skill(tmp_path, name, description, body="操作正文"):
    p = tmp_path / f"{name}.md"
    p.write_text(f"---\ndescription: {description}\n---\n{body}",
                 encoding="utf-8")
    return p


def test_s110_cache_hit_avoids_rescan(monkeypatch, tmp_path):
    _write_skill(tmp_path, "alpha-skill", "Alpha 技能")
    _write_skill(tmp_path, "beta-skill", "Beta 技能")
    monkeypatch.setattr(config, "SKILLS_DIR", str(tmp_path))
    calls = {"n": 0}
    orig = skills._read_meta

    def counting(path):
        calls["n"] += 1
        return orig(path)

    monkeypatch.setattr(skills, "_read_meta", counting)
    first = skills.list_skills()
    assert {s["name"] for s in first} == {"alpha-skill", "beta-skill"}
    reads_after_first = calls["n"]
    assert reads_after_first == 2      # 初扫逐个读 frontmatter
    second = skills.list_skills()
    assert [s["name"] for s in second] == [s["name"] for s in first]
    assert calls["n"] == reads_after_first   # 命中缓存，未重读


def test_s110_returns_copies_and_invalidation(monkeypatch, tmp_path):
    """对外返回拷贝（routers/skills 追加 size/mtime 不污染缓存）；
    文件内容变更 → 签名失效自动重扫。"""
    _write_skill(tmp_path, "alpha-skill", "v1 描述")
    monkeypatch.setattr(config, "SKILLS_DIR", str(tmp_path))
    # 拷贝隔离
    a = skills.list_skills()
    assert a and a[0]["name"] == "alpha-skill"
    a[0]["size"] = 999
    b = skills.list_skills()
    assert "size" not in b[0]
    # 修改文件（内容长度不同，签名必变）→ 自动失效
    _write_skill(tmp_path, "alpha-skill", "v2 描述，这是更新后的新描述")
    c = skills.list_skills()
    assert c[0]["description"] == "v2 描述，这是更新后的新描述"


def test_s110_removal_invalidates(monkeypatch, tmp_path):
    _write_skill(tmp_path, "alpha-skill", "Alpha")
    monkeypatch.setattr(config, "SKILLS_DIR", str(tmp_path))
    assert [s["name"] for s in skills.list_skills()] == ["alpha-skill"]
    (tmp_path / "alpha-skill.md").unlink()
    assert skills.list_skills() == []   # 文件删除 → 缓存失效
