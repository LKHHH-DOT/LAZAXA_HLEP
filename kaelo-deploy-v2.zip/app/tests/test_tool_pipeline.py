# -*- coding: utf-8 -*-
"""M5-1 工具流水线测试：registry pre/gate/post 钩子链 + arun 统一入口。

覆盖（对应《M5-架构化-细化方案》D1/D2 验收口径）：
  1. 钩子执行顺序 pre → gate → fn → post（post 按注册序）
  2. pre 同步短路：block 后不跑 gate、不执行 fn（post 仍跑做留痕）
  3. gate async 短路：block 后不执行 fn，结果 gate_blocked=True
  4. async fn 被直接 await（不走线程池）
  5. post 修剪只改 model_text，原文 text 不动（模型所见 / 审计原文分离）
  6. 同步 execute 入口不过 gate（保持旧调用/测试语义）
  7. 审批 gate 三模式等价：deny 直接拦 / ask 拒绝 / ask 同意 / allow 放行，
     deny 文案与 approval.deny_model_text 逐字一致
  8. screen_lock 工具拿不到屏幕锁时返回 SCREEN_BUSY_NOTE 且不执行 fn
  9. post 钩子抛异常不阻断流水线（容错）

约定：纯机制测试用独立 new ToolRegistry()（不挂默认钩子、不碰 DB）；
审批测试手动挂 approval_gate_hook 并 monkeypatch decide/ask。
跟随仓库既有风格，用 asyncio.run 跑协程，不引入 pytest-asyncio。
"""

import asyncio
import sys
import types

import pytest

from app.agent.registry import (
    ToolRegistry, Tool, ToolResult, HookResult, ExecContext, SCREEN_BUSY_NOTE)
from app.agent import pipeline
from app.agent import approval as approval_mod
from app.agent import permissions
from app import config as app_config


# --------------------------------------------------------------------- #
# 辅助
# --------------------------------------------------------------------- #
def _make_registry(risk="safe", fn=None, screen_lock=False):
    """构造只含一个工具 t_demo 的干净注册表（不挂任何默认钩子）。"""
    reg = ToolRegistry()
    called = {"n": 0}

    def _fn(**args):
        called["n"] += 1
        if fn is not None:
            return fn(**args)
        return ToolResult.ok_result("done", brief="ok")

    reg.register(Tool("t_demo", "demo", {"type": "object", "properties": {}},
                      risk, 30, _fn, screen_lock=screen_lock))
    return reg, called


def _ctx(**kw):
    base = dict(mode="standard", round_id="", parent_task_id="",
                user_message="u", task_id="tid", compact_name="c")
    base.update(kw)
    return ExecContext(**base)


def _arun(reg, name="t_demo", args=None, ctx=None):
    return asyncio.run(reg.arun(name, args or {}, ctx or _ctx()))


# --------------------------------------------------------------------- #
# 1. 钩子顺序
# --------------------------------------------------------------------- #
def test_hook_chain_order():
    reg, called = _make_registry()
    order = []

    def pre(name, args, risk, ctx):
        order.append("pre")
        return None  # None = 不拦截

    async def gate(name, args, risk, ctx):
        order.append("gate")
        return HookResult.pass_()

    def post1(name, args, risk, ctx, result):
        order.append("post1")
        return result

    def post2(name, args, risk, ctx, result):
        order.append("post2")
        return result

    reg.add_pre_hook(pre)
    reg.add_gate_hook(gate)
    reg.add_post_hook(post1)
    reg.add_post_hook(post2)

    result = _arun(reg)
    assert result.ok and called["n"] == 1
    assert order == ["pre", "gate", "post1", "post2"]


# --------------------------------------------------------------------- #
# 2. pre 同步短路
# --------------------------------------------------------------------- #
def test_pre_hook_short_circuits():
    reg, called = _make_registry()
    order = []
    reg.add_pre_hook(lambda n, a, r, c: (order.append("pre") or
                                         HookResult.block("pre-no", "前置拦截", "deny")))

    async def gate(n, a, r, c):
        order.append("gate")
        return HookResult.pass_()

    reg.add_gate_hook(gate)
    reg.add_post_hook(lambda n, a, r, c, res: (order.append("post") or res))

    result = _arun(reg)
    assert called["n"] == 0                  # fn 未执行
    assert result.gate_blocked is True
    assert result.error == "pre-no"
    assert order == ["pre", "post"]          # gate 被短路，post 仍留痕


# --------------------------------------------------------------------- #
# 3. gate async 短路
# --------------------------------------------------------------------- #
def test_gate_hook_short_circuits():
    reg, called = _make_registry()

    async def block_gate(n, a, r, c):
        return HookResult.block("gate-no", "关卡拦截", "deny")

    reg.add_gate_hook(block_gate)
    result = _arun(reg)
    assert called["n"] == 0
    assert result.gate_blocked is True
    assert not result.ok
    assert result.error == "gate-no"
    assert result.decision == "deny"


# --------------------------------------------------------------------- #
# 4. async fn 直接 await
# --------------------------------------------------------------------- #
def test_async_fn_awaited_directly():
    reg = ToolRegistry()
    mark = {"ran": False}

    async def async_fn(**args):
        await asyncio.sleep(0)
        mark["ran"] = True
        return ToolResult.ok_result("async-done")

    reg.register(Tool("t_async", "a", {"type": "object"}, "safe", 30, async_fn))
    result = _arun(reg, name="t_async")
    assert mark["ran"] is True
    assert result.ok and result.text == "async-done"


# --------------------------------------------------------------------- #
# 5. trim post：model_text / text 分离
# --------------------------------------------------------------------- #
def test_trim_post_sets_model_text_keeps_text(monkeypatch):
    reg, called = _make_registry(fn=lambda **k: ToolResult.ok_result("X" * 5000))
    # 不写真实归档，把修剪函数替换成固定标记，验证"只改模型所见"
    monkeypatch.setattr(pipeline.context, "trim_tool_result",
                        lambda text, limit, archive, name: "[TRIMMED]")
    monkeypatch.setattr(pipeline.config, "CONTEXT_COMPACT_ENABLED", True)
    monkeypatch.setattr(pipeline.config, "TOOL_RESULT_TRIM_CHARS", 1000)
    reg.add_post_hook(pipeline.trim_post_hook)

    result = _arun(reg)
    assert result.ok
    assert len(result.text) == 5000          # 原文保留（审计/截图提取用）
    assert result.model_text == "[TRIMMED]"  # 模型所见被修剪


def test_trim_post_skips_gate_blocked(monkeypatch):
    reg, called = _make_registry()
    monkeypatch.setattr(pipeline.config, "CONTEXT_COMPACT_ENABLED", True)
    monkeypatch.setattr(pipeline.config, "TOOL_RESULT_TRIM_CHARS", 10)

    async def block(n, a, r, c):
        return HookResult.block("blocked", "b", "deny")

    reg.add_gate_hook(block)
    reg.add_post_hook(pipeline.trim_post_hook)
    result = _arun(reg)
    assert result.gate_blocked
    assert not result.model_text            # 拦截结果不修剪


# --------------------------------------------------------------------- #
# 6. 同步 execute 不过 gate
# --------------------------------------------------------------------- #
def test_execute_skips_gate():
    reg, called = _make_registry()
    hits = {"gate": 0}

    async def gate(n, a, r, c):
        hits["gate"] += 1
        return HookResult.block("should-not-happen", "x", "deny")

    reg.add_gate_hook(gate)
    result = reg.execute("t_demo", {})       # 同步入口
    assert result.ok and called["n"] == 1
    assert hits["gate"] == 0                 # gate 完全不跑


# --------------------------------------------------------------------- #
# 7. 审批 gate 三模式等价 + deny 文案逐字
# --------------------------------------------------------------------- #
def _registry_with_approval_gate(monkeypatch, decide_ret, ask_ret=None):
    reg, called = _make_registry(risk="sensitive")
    reg.add_gate_hook(approval_mod.approval_gate_hook)
    # gate 内函数级 from .permissions import decide —— patch permissions 模块属性即生效
    monkeypatch.setattr(permissions, "decide", lambda *a, **k: decide_ret)
    monkeypatch.setattr(app_config, "AGENT_EVENTS_ENABLED", False)

    async def fake_ask(task_id, tool_name, args, risk, emit):
        return ask_ret

    monkeypatch.setattr(approval_mod.approval, "ask", fake_ask)
    return reg, called


def test_approval_gate_deny_blocks_with_verbatim_text(monkeypatch):
    reg, called = _registry_with_approval_gate(
        monkeypatch, (permissions.DECISION_DENY, "策略原因r"))
    result = _arun(reg)
    assert called["n"] == 0
    assert result.gate_blocked
    assert result.error == approval_mod.deny_model_text("策略原因r")  # 逐字
    assert "未实际执行" in result.error and "严禁" in result.error


def test_approval_gate_ask_rejected_blocks(monkeypatch):
    reg, called = _registry_with_approval_gate(
        monkeypatch, (permissions.DECISION_ASK, "需确认"), ask_ret=False)
    result = _arun(reg)
    assert called["n"] == 0
    assert result.gate_blocked
    assert result.error == approval_mod.REJECTED_MODEL_TEXT


def test_approval_gate_ask_approved_runs(monkeypatch):
    reg, called = _registry_with_approval_gate(
        monkeypatch, (permissions.DECISION_ASK, "需确认"), ask_ret=True)
    ctx = _ctx()
    result = _arun(reg, ctx=ctx)
    assert called["n"] == 1 and result.ok
    assert ctx.approved is True and ctx.decision == "ask"


def test_approval_gate_allow_runs_without_ask(monkeypatch):
    ask_calls = {"n": 0}

    async def counting_ask(*a, **k):
        ask_calls["n"] += 1
        return True

    reg, called = _registry_with_approval_gate(
        monkeypatch, (permissions.DECISION_ALLOW, ""))
    monkeypatch.setattr(approval_mod.approval, "ask", counting_ask)
    ctx = _ctx()
    result = _arun(reg, ctx=ctx)
    assert called["n"] == 1 and result.ok
    assert ask_calls["n"] == 0               # allow 不弹窗
    assert ctx.approved is True


# --------------------------------------------------------------------- #
# 8. 屏幕锁占用
# --------------------------------------------------------------------- #
def test_screen_lock_busy_returns_guidance():
    reg, called = _make_registry(screen_lock=True)

    class _BusySem:
        async def try_acquire(self, wait):
            return False

        def release(self):
            pass

    result = _arun(reg, ctx=_ctx(screen_sem=_BusySem()))
    assert called["n"] == 0
    assert not result.ok
    assert result.error == SCREEN_BUSY_NOTE


def test_screen_lock_acquired_then_released():
    reg, called = _make_registry(screen_lock=True)
    events = []

    class _Sem:
        async def try_acquire(self, wait):
            events.append("acquire")
            return True

        def release(self):
            events.append("release")

    result = _arun(reg, ctx=_ctx(screen_sem=_Sem()))
    assert result.ok and called["n"] == 1
    assert events == ["acquire", "release"]


# --------------------------------------------------------------------- #
# 9. post 钩子异常不阻断
# --------------------------------------------------------------------- #
def test_post_hook_exception_isolated():
    reg, called = _make_registry()

    def boom(n, a, r, c, res):
        raise RuntimeError("post 炸了")

    seen = {}

    def ok_post(n, a, r, c, res):
        seen["got"] = res
        return res

    reg.add_post_hook(boom)
    reg.add_post_hook(ok_post)
    result = _arun(reg)
    assert result.ok                          # 主流程不受影响
    assert seen["got"] is result              # 后续 post 仍执行


# --------------------------------------------------------------------- #
# 10. P2-2 审计增强：element_id / retries 透传落库
# --------------------------------------------------------------------- #
def test_audit_post_hook_forwards_element_id_and_retries(monkeypatch):
    """post 审计把 args 的控件引用与 result.meta 的重试次数透传给 log_agent_task。"""
    seen = {}

    class FakeDb:
        @staticmethod
        def log_agent_task(*a, **kw):
            seen.update(kw)
            return True

    monkeypatch.setitem(sys.modules, "app.db", FakeDb)
    res = ToolResult.ok_result("done", brief="ok")
    res.meta = {"retries": 3}
    pipeline.audit_post_hook("mouse_click", {"element_id": "Button:ok", "x": 1},
                             "sensitive", _ctx(), res)
    assert seen["element_id"] == "Button:ok"
    assert seen["retries"] == 3


def test_audit_post_hook_without_trace_info_sends_empty(monkeypatch):
    """非 UI 动作 / 工具未上报 meta → element_id 空串、retries None（落库为 NULL）。"""
    seen = {}

    class FakeDb:
        @staticmethod
        def log_agent_task(*a, **kw):
            seen.update(kw)
            return True

    monkeypatch.setitem(sys.modules, "app.db", FakeDb)
    pipeline.audit_post_hook("read_file", {"path": "a.txt"}, "safe", _ctx(),
                             ToolResult.ok_result("done"))
    assert seen["element_id"] == ""
    assert seen["retries"] is None
