# -*- coding: utf-8 -*-
"""M2 · scripts/run_evals.py 单元测试（全 mock，不真调 DeepSeek/DB）。

gold 解析、judge 汇总、无轨迹兜底、报告写盘四块，均注入假数据。
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import run_evals  # noqa: E402


def _gold_line(rid="r-1", task="测试任务", expected="期望"):
    return json.dumps({"id": rid, "source_round_id": rid, "task": task,
                       "category": "文件/代码", "expected": expected},
                      ensure_ascii=False)


def _score_ok():
    return {"judge_error": False, "reply_missing": False, "dims": {},
            "any_fail": False, "pass_all": True, "n_na": 0}


def _score_fail():
    s = _score_ok()
    s["pass_all"] = False
    s["any_fail"] = True
    return s


def _traj(rid="r-1"):
    return {"round_id": rid, "user_message": "任务", "steps": [],
            "reply": "完成", "reply_missing": False, "job": None}


# ---------- gold 解析 ----------

def test_load_gold_parses_and_skips_bad_lines(tmp_path):
    p = tmp_path / "gold.jsonl"
    p.write_text("\n".join([_gold_line("r-1"), "not-json",
                            _gold_line("r-2")]) + "\n", encoding="utf-8")
    items = run_evals.load_gold(str(p))
    assert len(items) == 2
    assert items[0]["source_round_id"] == "r-1"
    assert items[1]["expected"] == "期望"
    assert items[1]["category"] == "文件/代码"


def test_load_gold_missing_file_returns_empty(tmp_path):
    assert run_evals.load_gold(str(tmp_path / "nope.jsonl")) == []


# ---------- judge 汇总 ----------

def test_judge_gold_happy_path(monkeypatch, tmp_path):
    items = [{"source_round_id": "r-1", "task": "t", "expected": "e",
              "category": "c"}]
    monkeypatch.setattr(run_evals.evals, "load_trajectory",
                        lambda rid: _traj(rid))
    seen = {}

    def fake_judge(traj, expected="", llm_call=None, use_cache=True):
        seen["expected"] = expected
        return _score_ok()

    monkeypatch.setattr(run_evals.evals, "judge_one", fake_judge)
    out = run_evals.judge_gold(items, use_cache=True)
    assert out[0]["trajectory"]["round_id"] == "r-1"
    assert out[0]["score"]["pass_all"] is True
    assert seen["expected"] == "e"


def test_judge_gold_no_trajectory_marks_unjudgeable(monkeypatch):
    items = [{"source_round_id": "r-x", "task": "t", "expected": "e",
              "category": "c"}]
    monkeypatch.setattr(run_evals.evals, "load_trajectory", lambda rid: None)

    def fake_judge(*a, **k):
        raise AssertionError("无轨迹不应触发 judge")

    monkeypatch.setattr(run_evals.evals, "judge_one", fake_judge)
    out = run_evals.judge_gold(items)
    assert out[0]["trajectory"] is None
    assert out[0]["score"]["judge_error"] is True
    assert out[0]["score"]["no_trajectory"] is True


# ---------- 报告写盘 ----------

def test_write_report_writes_file_and_summary(tmp_path, capsys):
    items = [
        {"id": "r-1", "task": "a", "category": "c", "expected": "",
         "trajectory": _traj("r-1"), "score": _score_ok()},
        {"id": "r-2", "task": "b", "category": "c", "expected": "",
         "trajectory": _traj("r-2"), "score": _score_fail()},
        {"id": "r-3", "task": "d", "category": "c", "expected": "",
         "trajectory": None, "score": {"judge_error": True,
                                       "no_trajectory": True, "dims": {}}},
    ]
    out = tmp_path / "report.md"
    run_evals.write_report(items, str(out))
    md = out.read_text(encoding="utf-8")
    assert "1/2 = 50.0%" in md      # 不可判的不进分母
    assert "r-2" in md              # 失败清单
    assert "r-3" in md              # 不可判清单
    capsys.readouterr()             # 吞掉 stdout 摘要
