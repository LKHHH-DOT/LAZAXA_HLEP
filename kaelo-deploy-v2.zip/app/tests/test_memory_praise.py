# -*- coding: utf-8 -*-
"""正反馈经验沉淀测试：note_task_done / auto_sink_praise。

全部 mock 掉 registry.execute（Qdrant）与 LLM 提炼，纯测规则逻辑：
  1. 有任务摘要 + 正反馈 → 沉淀 experience
  2. 无任务摘要 → 不沉淀
  3. 超出 10 分钟窗口 → 不沉淀
  4. 非正反馈词 → 不沉淀
  5. 同任务 30 分钟防抖 → 只沉淀一次
  6. LLM 失败 → 规则兜底仍沉淀
"""
import types

import pytest

from app import memory as mem


@pytest.fixture(autouse=True)
def _reset_state(monkeypatch):
    """每个用例前重置模块状态；用假 registry + 假 LLM 隔离外部依赖。"""
    from app.agent.registry import registry as _reg

    mem._recent_task.update(summary=None, ts=0.0, hash=None, last_sink_ts=0.0)

    calls = []

    def fake_execute(name, args):
        calls.append((name, args))
        return types.SimpleNamespace(ok=True)

    monkeypatch.setattr(_reg, "execute", fake_execute)
    monkeypatch.setattr(mem, "_build_experience_via_llm", lambda *a, **k: "经验：目标X，方法Y，可复用")
    yield calls


def _mock_llm(monkeypatch, result):
    monkeypatch.setattr(mem, "_build_experience_via_llm", lambda *a, **k: result)


def test_praise_sinks_experience(monkeypatch, _reset_state):
    """正反馈 + 10 分钟内刚完成任务 → 成功沉淀 experience。"""
    calls = _reset_state
    mem.note_task_done("帮我整理一份项目文档", "已整理完毕，共 12 个章节")
    assert mem.auto_sink_praise("完成得不错！")
    assert len(calls) == 1
    name, args = calls[0]
    assert name == "memory_add"
    assert args["type"] == "experience"
    assert args["tags"] == ["正反馈沉淀"]
    assert args["source"] == "[经验] 用户正反馈"
    # LLM 已 mock：沉淀的就是 LLM 提炼出的经验文本
    assert args["text"] == "经验：目标X，方法Y，可复用"


def test_praise_no_task_no_sink(_reset_state):
    """没有任务摘要（闲聊正反馈）→ 不沉淀。"""
    assert not mem.auto_sink_praise("说得不错")


def test_praise_window_expired(monkeypatch, _reset_state):
    """任务完成超过 10 分钟 → 不沉淀（防"天气不错"类误触）。"""
    _reset_state
    mem.note_task_done("帮我整理项目文档", "完成")
    mem._recent_task["ts"] = mem._recent_task["ts"] - mem._PRAISE_WINDOW_S - 1
    assert not mem.auto_sink_praise("不错")


def test_praise_not_praise_word(_reset_state):
    """非正反馈词 → 不沉淀。"""
    mem.note_task_done("帮我整理项目文档", "完成")
    assert not mem.auto_sink_praise("哦这样啊，我知道了")


def test_praise_debounce_once(monkeypatch, _reset_state):
    """同一任务 30 分钟内只沉淀一次。"""
    calls = _reset_state
    mem.note_task_done("帮我整理项目文档", "完成")
    assert mem.auto_sink_praise("不错")
    assert len(calls) == 1
    # 第二次正反馈（同任务）被防抖拦截
    assert not mem.auto_sink_praise("很好，干得漂亮")
    assert len(calls) == 1


def test_praise_llm_fallback_rule(monkeypatch, _reset_state):
    """LLM 提炼失败 → 规则兜底仍能沉淀。"""
    calls = _reset_state
    _mock_llm(monkeypatch, "")
    mem.note_task_done("帮我整理项目文档", "已整理 12 章")
    assert mem.auto_sink_praise("不错")
    assert len(calls) == 1
    # 兜底文本应包含任务描述与执行结果
    assert "项目文档" in calls[0][1]["text"]


def test_note_task_done_truncates_long(_reset_state):
    """超长任务/结果被截断，避免污染记忆。"""
    _reset_state
    mem.note_task_done("长" * 500, "结果" * 600)
    assert len(mem._recent_task["summary"]) < 700
    assert mem._recent_task["hash"]


# ============ round_id 溯源（A批2） ============

def test_praise_round_uses_recent_task_round(_reset_state):
    """note_task_done 带 round_id → 正反馈沉淀沿用该轮溯源 id。"""
    calls = _reset_state
    mem.note_task_done("帮我整理项目文档", "已整理完毕，共 12 个章节",
                       round_id="r-77")
    assert mem.auto_sink_praise("完成得不错！")
    assert calls[0][1]["round_id"] == "r-77"


def test_praise_round_explicit_overrides(_reset_state):
    """显式传 round_id（当前轮）优先于暂存的任务轮。"""
    calls = _reset_state
    mem.note_task_done("帮我整理项目文档", "完成", round_id="r-old")
    assert mem.auto_sink_praise("做得很好！", round_id="r-new")
    assert calls[0][1]["round_id"] == "r-new"


def test_praise_round_fallback_when_none(_reset_state):
    """任务轮与当前轮都没有 id → 自动补 chat- 前缀溯源 id。"""
    calls = _reset_state
    mem.note_task_done("帮我整理项目文档", "完成")
    assert mem.auto_sink_praise("不错")
    assert calls[0][1]["round_id"].startswith("chat-")
