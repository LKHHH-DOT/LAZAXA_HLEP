# -*- coding: utf-8 -*-
"""技能体系单元测试（app/agent/skills.py · 批次 E1）。

覆盖：技能目录扫描、frontmatter 解析、按需加载正文、use_skill 工具行为、
系统提示技能段注入、异常文件跳过。
"""
import os

from app.agent import skills
from app.agent.loop import _system_prompt
from app.agent.registry import ToolRegistry
from app import config


def test_list_skills_returns_catalog():
    skills_list = skills.list_skills()
    assert len(skills_list) >= 3, f"应至少 3 个示例技能，实际 {len(skills_list)}"
    names = {s["name"] for s in skills_list}
    assert {"file-organizer", "desktop-cleanup", "daily-report"} <= names
    # 目录条目必须带 description（省 token 只注入 name+description）
    for s in skills_list:
        assert s["name"] and s["description"], f"技能缺元数据: {s}"


def test_get_skill_returns_body():
    content = skills.get_skill("file-organizer")
    assert content and "# 技能：file-organizer" in content
    assert "操作指南" in content and "run_python_script" in content


def test_get_skill_missing_returns_none():
    assert skills.get_skill("not-exist-skill") is None
    assert skills.get_skill("非法名") is None  # 非 kebab-case


def test_use_skill_tool_found_and_missing():
    reg = ToolRegistry()
    skills.register_all(reg)
    fn = reg.get("use_skill").fn
    r = fn(name="daily-report")
    assert r.ok and "日报生成技能" in r.text
    r2 = fn(name="no-such-skill")
    assert not r2.ok and "可用技能" in r2.error


def test_skill_catalog_block_only_metadata():
    block = skills.skill_catalog_block()
    assert "可用技能" in block
    assert "file-organizer: " in block  # 只列 name: description
    assert "操作指南" not in block      # 正文不注入


def test_system_prompt_includes_skill_catalog():
    prompt = _system_prompt()
    assert "可用技能" in prompt
    assert "use_skill" in prompt  # 提示里说明用 use_skill 加载


def test_broken_skill_file_is_skipped():
    # 无 frontmatter / 无 description 的文件不应崩掉整个目录
    d = config.SKILLS_DIR
    broken = os.path.join(d, "_broken_test.md")
    with open(broken, "w", encoding="utf-8") as f:
        f.write("# 没有 frontmatter 的残缺文件\n")
    try:
        names = {s["name"] for s in skills.list_skills()}
        assert "_broken_test" not in names
    finally:
        os.remove(broken)


def test_use_skill_is_safe_risk():
    reg = ToolRegistry()
    skills.register_all(reg)
    assert reg.get("use_skill").risk == "safe"
