# -*- coding: utf-8 -*-
"""B批3 · agent_tasks 审计写入的"状态原子化"（app/db.py log_agent_task）。

不连真实 MySQL：monkeypatch db._execute 捕获 SQL，验证路径选择——
唯一索引就绪 → 单语句 INSERT IGNORE（无"先查后插"竞态窗口）；
索引不可用 → 先查后插兜底且幂等（已存在行直接返回 True）。
"""
from app import db

def _lock_migrate_guards(monkeypatch, uq_ready):
    """跳过四处惰性迁移（SHOW COLUMNS / SHOW INDEX 的连库探测），
    直接固定唯一索引就绪与否，让用例只测 log_agent_task 的路径分支。"""
    monkeypatch.setattr(db, "_MIGRATED_PARENT_COL", True)
    monkeypatch.setattr(db, "_MIGRATED_TASK_UNIQUE", True)
    monkeypatch.setattr(db, "_MIGRATED_TASK_TOKEN_COL", True)   # S1-2 token 列迁移
    monkeypatch.setattr(db, "_MIGRATED_TASK_TRACE_COL", True)   # P2-2 element_id/retries 列迁移
    monkeypatch.setattr(db, "_TASK_UQ_READY", uq_ready)


def test_atomic_ignore_single_statement_when_uq_ready(monkeypatch):
    """唯一索引就绪 → 只发一条 INSERT IGNORE，绝无 SELECT 预查。"""
    calls = []

    def fake_execute(sql, args=None, fetch_one=False):
        calls.append(sql)
        return None

    _lock_migrate_guards(monkeypatch, uq_ready=True)
    monkeypatch.setattr(db, "_execute", fake_execute)
    assert db.log_agent_task("t-atomic", "run_command", ok=True)
    assert len(calls) == 1
    assert "INSERT IGNORE INTO agent_tasks" in calls[0]
    assert "SELECT" not in calls[0]


def test_atomic_repeat_task_id_still_returns_true(monkeypatch):
    """重复 task_id 在原子路径下：INSERT IGNORE 整行静默忽略，仍返回 True。"""
    calls = []

    def fake_execute(sql, args=None, fetch_one=False):
        calls.append(sql)
        return None  # 冲突由唯一索引兜底（真实库里 rowcount=0 不抛错）

    _lock_migrate_guards(monkeypatch, uq_ready=True)
    monkeypatch.setattr(db, "_execute", fake_execute)
    assert db.log_agent_task("t-dup", "run_command", ok=True)
    assert db.log_agent_task("t-dup", "run_command", ok=True)  # 重复写不报错
    assert sum("INSERT IGNORE INTO agent_tasks" in c for c in calls) == 2


def test_fallback_check_then_insert_when_no_uq(monkeypatch):
    """唯一索引不可用 → 先 SELECT 无既有行才 INSERT（应用层去重兜底）。"""
    calls = []

    def fake_execute(sql, args=None, fetch_one=False):
        calls.append(sql)
        if "SELECT id FROM agent_tasks" in sql:
            return None  # 无既有行 → 允许插入
        return None

    _lock_migrate_guards(monkeypatch, uq_ready=False)
    monkeypatch.setattr(db, "_execute", fake_execute)
    assert db.log_agent_task("t-fb", "run_command", ok=True)
    assert len(calls) == 2
    assert "SELECT id FROM agent_tasks" in calls[0]
    assert "INSERT INTO agent_tasks" in calls[1]
    assert "IGNORE" not in calls[1]  # 兜底路径用普通 INSERT


def test_fallback_dup_skips_insert(monkeypatch):
    """唯一索引不可用 + task_id 已存在 → 只 SELECT 一次即返回 True，不重复插入。"""
    calls = []

    def fake_execute(sql, args=None, fetch_one=False):
        calls.append(sql)
        if "SELECT id FROM agent_tasks" in sql:
            return {"id": 1}  # 已有行 → 幂等去重
        return None

    _lock_migrate_guards(monkeypatch, uq_ready=False)
    monkeypatch.setattr(db, "_execute", fake_execute)
    assert db.log_agent_task("t-old", "run_command", ok=True)
    assert len(calls) == 1 and "SELECT" in calls[0]
