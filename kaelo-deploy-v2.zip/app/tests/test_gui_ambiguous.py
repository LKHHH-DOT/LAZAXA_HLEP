# -*- coding: utf-8 -*-
"""同名多窗口歧义消解测试（2026-09-06 · T03）。

根因：ui_find/ui_list 指定 window_title 时，pywinauto 按 title 匹配多个顶层
窗口（如开两个"微信"）会抛歧义异常，被笼统吞成"UI 读取失败"，模型卡死。
修复：先枚举可见窗口（windows.find_all），命中多个时抛 _WinAmbiguous，
由 ui_list/ui_find 返回候选窗口清单 + 引导（精确标题 / 先 window_control 激活）。
"""
from app.agent.tools import gui


class FakeWin:
    """最小 pywinauto Window 替身。"""

    def __init__(self, handle=0):
        self._h = handle

    def wait(self, *a, **k):
        return self

    def descendants(self):
        return []


class FakeDesktop:
    """最小 pywinauto Desktop 替身：记录 window(handle=...) 调用。"""

    def __init__(self):
        self.window_calls = []

    def window(self, **kw):
        self.window_calls.append(kw)
        return FakeWin(kw.get("handle", 0))


class FakeWindows:
    """windows._Windows 替身：按关键字返回预设窗口列表。"""

    def __init__(self, mapping):
        self._mapping = mapping  # kw -> [(hwnd, title)]

    def find_all(self, kw):
        return self._mapping.get(kw, [])


def _stub_env(monkeypatch, mapping):
    """把 UIA 可用性置真、窗口枚举换成假表。"""
    monkeypatch.setattr(gui, "_ui_available", lambda: "")
    fake = FakeWindows(mapping)
    monkeypatch.setattr(
        "app.agent.tools.windows._get_windows", lambda: fake)
    monkeypatch.setattr(gui, "_uia", FakeDesktop())
    return fake


def test_ui_find_ambiguous_returns_candidates(monkeypatch):
    """ui_find 标题命中 2 个可见窗口 → 返回候选清单而非含糊报错。"""
    _stub_env(monkeypatch, {"微信": [(1001, "微信 - 张三"), (1002, "微信 - 李四")]})
    res = gui._ui_find(text="发送", window_title="微信")
    assert not res.ok
    assert "1001" in res.error and "1002" in res.error
    assert "张三" in res.error and "李四" in res.error
    assert "window_control" in res.error   # 引导先激活目标窗口


def test_ui_list_ambiguous_returns_candidates(monkeypatch):
    """ui_list 标题命中多窗口 → 同样返回候选清单。"""
    _stub_env(monkeypatch, {"微信": [(1001, "微信 - 张三"), (1002, "微信 - 李四")]})
    res = gui._ui_list(window_title="微信")
    assert not res.ok
    assert "2 个" in res.error
    assert "1001" in res.error and "1002" in res.error


def test_resolve_single_window_uses_handle(monkeypatch):
    """单窗口命中 → 用窗口句柄取目标（不再按 title 匹配，天然规避歧义）。"""
    _stub_env(monkeypatch, {"微信": [(777, "微信 - 张三")]})
    desktop = FakeDesktop()
    win = gui._resolve_target_window(desktop, "微信")
    assert win is not None
    assert desktop.window_calls == [{"handle": 777}]


def test_ui_find_no_window_gives_guidance(monkeypatch):
    """0 个窗口命中 → 明确"未找到"并提示先 screen_ocr 看真实标题。"""
    _stub_env(monkeypatch, {})  # 任何关键字都查不到
    res = gui._ui_find(text="发送", window_title="不存在的窗口")
    assert not res.ok
    assert "未找到可见实例" in res.error
    assert "screen_ocr" in res.error
