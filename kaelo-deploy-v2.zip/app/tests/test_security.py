# -*- coding: utf-8 -*-
"""安全体检工具单元测试（app/agent/tools/security.py）。

不真正跑 PowerShell，monkeypatch subprocess.run 验证工具逻辑与错误分支。
"""
from app.agent.registry import ToolRegistry
from app.agent.tools import security


class FakeProc:
    """假的 subprocess 结果。"""

    def __init__(self, stdout="", stderr="", returncode=0):
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode


SAMPLE_REPORT = """\
========================================================
  Lazaxa 电脑安全体检报告
========================================================
✅ [defender   ] Defender 实时防护开启
🔴 [ports      ] 高危端口对外监听且未被拦截: 192.168.1.5 3389
✅ [rdp        ] 远程桌面(RDP)未开启
========================================================
汇总: ✅ 2 正常 | ⚠️ 0 注意 | 🔴 1 紧急
"""


def _patch_run(monkeypatch, fake):
    monkeypatch.setattr(security.subprocess, "run", lambda *a, **k: fake)


# ---------- 注册 ----------

def test_register_all_registers_security_check():
    r = ToolRegistry()
    security.register_all(r)
    t = r.get("security_check")
    assert t is not None
    assert t.display_name == "安全体检"
    assert t.risk == "safe"
    assert t.timeout == 90
    # schema：check 参数可选
    assert t.parameters["required"] == []


# ---------- 执行 ----------

def test_security_check_ok_extracts_summary(monkeypatch):
    _patch_run(monkeypatch, FakeProc(stdout=SAMPLE_REPORT))
    res = security._security_check()
    assert res.ok
    assert "🔴" in res.text          # 全文保留
    assert "汇总" in res.brief        # brief 取汇总行


def test_security_check_with_check_param(monkeypatch):
    captured = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        return FakeProc(stdout=SAMPLE_REPORT)

    monkeypatch.setattr(security.subprocess, "run", fake_run)
    security._security_check(check="ports")
    assert "--check" in captured["argv"]
    assert "ports" in captured["argv"]


def test_security_check_missing_script(monkeypatch):
    monkeypatch.setattr(security, "SCRIPT", r"C:\no\such\security_check.py")
    res = security._security_check()
    assert not res.ok
    assert "缺失" in res.error


def test_security_check_no_output(monkeypatch):
    _patch_run(monkeypatch, FakeProc(stdout=""))
    res = security._security_check()
    assert not res.ok
    assert "无输出" in res.error


def test_security_check_timeout(monkeypatch):
    import subprocess

    def boom(*a, **k):
        raise subprocess.TimeoutExpired(cmd=a[0], timeout=90)

    monkeypatch.setattr(security.subprocess, "run", boom)
    res = security._security_check()
    assert not res.ok
    assert "超时" in res.error
