# -*- coding: utf-8 -*-
"""acceptance_suite（C批3 · 真屏验收回归基准集 runner）单元测试。

覆盖：用例登记完整性（文件存在/字段齐全/危险标记）、组名解析与危险放行、
退出码语义映射、runner 汇总逻辑（monkeypatch run_case，不真跑子进程）。
"""
import os
import sys

SCRIPTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)
import acceptance_suite as suite  # noqa: E402


# ---------- 登记完整性 ----------

def test_cases_registry_complete():
    assert len(suite.CASES) >= 3
    names = [c["name"] for c in suite.CASES]
    assert len(names) == len(set(names)), "用例名必须唯一"
    for c in suite.CASES:
        for key in ("name", "file", "group", "danger", "desc", "rc_note"):
            assert key in c, f"用例 {c.get('name')} 缺字段 {key}"
        assert isinstance(c["danger"], bool)


def test_case_scripts_exist_on_disk():
    """登记文件必须真实存在于 scripts/（防止基准集悬空）。"""
    for c in suite.CASES:
        assert os.path.isfile(suite.case_script(c)), f"脚本缺失: {c['file']}"


def test_publish_marked_danger():
    pub = {c["name"]: c for c in suite.CASES}["agent-publish"]
    assert pub["danger"] is True


# ---------- 组名解析 ----------

def test_resolve_gui_group():
    names = suite.resolve_names("gui", danger=False)
    assert names == ["gui-milestones"]


def test_resolve_all_safe_excludes_danger():
    names = suite.resolve_names("all-safe", danger=False)
    assert "agent-publish" not in names
    assert names == [c["name"] for c in suite.CASES if not c["danger"]]


def test_resolve_all_requires_danger_flag():
    without = suite.resolve_names("all", danger=False)
    assert "agent-publish" not in without
    with_flag = suite.resolve_names("all", danger=True)
    assert "agent-publish" in with_flag
    assert with_flag == [c["name"] for c in suite.CASES]


def test_resolve_agent_group_excludes_gui():
    names = suite.resolve_names("agent", danger=False)
    assert "gui-milestones" not in names
    assert all(suite._BY_NAME[n]["group"] == "agent" for n in names)


def test_resolve_comma_list_keeps_order_and_dedup():
    names = suite.resolve_names("agent-office,gui-milestones,agent-office",
                                danger=False)
    assert names == ["agent-office", "gui-milestones"]


def test_resolve_unknown_raises():
    try:
        suite.resolve_names("nope", danger=False)
        assert False, "应抛出 ValueError"
    except ValueError:
        pass


def test_resolve_empty_returns_empty():
    assert suite.resolve_names("", danger=False) == []


# ---------- 退出码语义 ----------

def test_interpret_mapping():
    assert suite.interpret(0) == "PASS"
    assert suite.interpret(2) == "SKIP"
    assert suite.interpret(1) == "FAIL"
    assert suite.interpret(3) == "FAIL"     # 超时/启动失败归失败


# ---------- runner 汇总（monkeypatch，不真跑） ----------

def _fake_case(name, rc):
    return suite._BY_NAME[name]


def test_main_list_ok(capsys):
    assert suite.main(["--list"]) == 0
    out = capsys.readouterr().out
    assert "基准集共" in out and "gui-milestones" in out


def test_main_gui_all_pass(monkeypatch, capsys):
    monkeypatch.setattr(suite, "run_case", lambda case, timeout=None: 0)
    assert suite.main(["--run", "gui"]) == 0
    assert "✅ 1/1 全过" in capsys.readouterr().out


def test_main_fail_exits_1(monkeypatch, capsys):
    rc_map = {"gui-milestones": 1}
    monkeypatch.setattr(suite, "run_case",
                        lambda case, timeout=None: rc_map.get(case["name"], 0))
    assert suite.main(["--run", "all-safe"]) == 1
    out = capsys.readouterr().out
    assert "FAIL" in out and "1 项未过" in out


def test_main_skip_env_exits_2(monkeypatch, capsys):
    monkeypatch.setattr(suite, "run_case", lambda case, timeout=None: 2)
    assert suite.main(["--run", "all-safe"]) == 2
    out = capsys.readouterr().out
    assert "SKIP" in out and "环境不可用" in out


def test_main_no_args_prints_help_exits_2(capsys):
    assert suite.main([]) == 2
    assert "usage" in capsys.readouterr().out.lower()


def test_main_unknown_group_exits_2(capsys):
    assert suite.main(["--run", "bogus"]) == 2
    assert "未知用例" in capsys.readouterr().out
