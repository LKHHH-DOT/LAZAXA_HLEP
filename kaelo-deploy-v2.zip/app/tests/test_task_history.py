# -*- coding: utf-8 -*-
"""任务记录中心（round_id 聚合）测试。

覆盖（均以 fake 替换 app.db，不依赖真实 MySQL）：
1. loop._audit 把 round_id 原样传给 log_agent_task；
2. GET /api/v1/agent/tasks 的聚合：按 round_id 分组、worker/legacy/main 来源标签、
   步骤平铺顺序、时间倒序、关键词/round 过滤参数透传。
"""
import sys
from datetime import datetime

from app.agent import loop
from app.routers import agent as agent_api
from app.agent.permissions import DECISION_ALLOW


# ---------- 1. _audit 传递 round_id ----------

def test_audit_passes_round_id(monkeypatch):
    """_audit 带 round_id 调用 log_agent_task 不应抛异常，round_id 原样透传。"""
    calls = {}

    class FakeDb:
        @staticmethod
        def log_agent_task(task_id, tool_name, args, risk, approved,
                           result_text, ok, user_message="", session_id="",
                           mode="standard", decision="ask",
                           parent_task_id="", round_id="",
                           token_in=None, token_out=None,
                           element_id="", retries=None):
            calls["round_id"] = round_id
            calls["token_in"] = token_in
            return True

    monkeypatch.setitem(sys.modules, "app.db", FakeDb)
    loop._audit("msg", "tid", "tool", {}, "safe", "standard", DECISION_ALLOW,
                True, "ok", True, parent_task_id="", round_id="r-1-2")
    assert calls.get("round_id") == "r-1-2"


# ---------- 2. /tasks 聚合 ----------

_ROWS = [
    # r-1：主对话两工具步骤（用户消息相同 → 应并成一卡）
    dict(id=1, task_id="t-1", parent_task_id="", round_id="r-1",
         session_id="", user_message="把桌面文件归类",
         tool_name="open_app", tool_args='{"name": "资源管理器"}',
         tool_result="ok", risk="safe", mode="standard", decision="allow",
         approved=1, ok=1, created_at=datetime(2026, 8, 18, 10, 0, 1)),
    dict(id=2, task_id="t-2", parent_task_id="", round_id="r-1",
         session_id="", user_message="把桌面文件归类",
         tool_name="list_dir", tool_args='{"path": "D:\\\\"}',
         tool_result="done", risk="safe", mode="standard", decision="allow",
         approved=1, ok=1, created_at=datetime(2026, 8, 18, 10, 0, 2)),
    # legacy：round_id 为空 → 按 task_id 独立一卡
    dict(id=3, task_id="t-x", parent_task_id="", round_id="",
         session_id="", user_message="旧记录", tool_name="search",
         tool_args='{}', tool_result="hit", risk="safe", mode="standard",
         decision="allow", approved=1, ok=0,
         created_at=datetime(2026, 8, 18, 9, 0, 0)),
    # job-9：后台 worker → source=worker
    dict(id=4, task_id="t-4", parent_task_id="", round_id="job-9",
         session_id="", user_message="把照片整理成相册",
         tool_name="mkdir", tool_args='{"path": "x"}', tool_result="ok",
         risk="safe", mode="standard", decision="allow", approved=1, ok=1,
         created_at=datetime(2026, 8, 18, 11, 0, 0)),
]


class _FakeDb:
    """最小 app.db 替身：记录调用参数并返回预设行。"""
    def __init__(self, rows=None):
        self.rows = rows or _ROWS
        self.last_kwargs = {}

    def query_agent_tasks(self, q="", tool="", minutes=1440,
                          limit=300, round_id=""):
        self.last_kwargs = dict(q=q, tool=tool, minutes=minutes,
                                limit=limit, round_id=round_id)
        return self.rows


def _call_tasks(fake_db, **overrides):
    import app.routers.agent as api_mod
    monkey = None
    import app
    # 替换包内 db 引用：端点内部 `from ..db import query_agent_tasks`
    import types
    mod = types.ModuleType("app.db")
    mod.query_agent_tasks = fake_db.query_agent_tasks
    old = sys.modules.get("app.db")
    sys.modules["app.db"] = mod
    try:
        return api_mod.api_v1_agent_tasks(**overrides)
    finally:
        if old is not None:
            sys.modules["app.db"] = old
        else:
            del sys.modules["app.db"]


def test_tasks_aggregation_groups_by_round():
    fake = _FakeDb()
    out = _call_tasks(fake)
    tasks = out["tasks"]
    # 时间倒序：job-9(最新) → legacy → r-1
    assert [t["round_id"] for t in tasks] == ["job-9", "", "r-1"]
    # 主对话卡：两步骤并一卡，source=main
    main_card = tasks[-1]
    assert main_card["source"] == "main"
    assert main_card["tool_count"] == 2
    assert main_card["ok_count"] == 2
    assert [s["tool"] for s in main_card["steps"]] == ["open_app", "list_dir"]
    # worker / legacy 标签
    assert tasks[0]["source"] == "worker"
    assert tasks[1]["source"] == "legacy"
    assert tasks[1]["tool_count"] == 1
    # legacy 步骤：ok 转 bool、args 解析为 dict
    legacy_step = tasks[1]["steps"][0]
    assert legacy_step["ok"] is False
    assert legacy_step["approved"] is True
    assert isinstance(legacy_step["args"], dict)
    assert "created" not in out


def test_tasks_params_passthrough_and_filter():
    fake = _FakeDb()
    _call_tasks(fake, q="文件", tool="mkdir", minutes=60, limit=10,
                round_id="job-9")
    assert fake.last_kwargs == dict(q="文件", tool="mkdir", minutes=60,
                                    limit=10, round_id="job-9")
