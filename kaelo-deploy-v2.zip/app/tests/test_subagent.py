# -*- coding: utf-8 -*-
"""子代理单元测试（app/agent/loop.py + tools/subagent.py · 批次 E2）。

覆盖：subagent_spawn 注册与风险、占位实现、工具可见性过滤（白名单 + 深度上限）、
子代理系统提示、_execute_subagent 参数/深度校验、审批事件透传、审计谱系参数。
"""
import asyncio

from app.agent import loop
from app.agent.loop import (_execute_subagent, _execute_subagent_parallel,
                            _extract_role_card, _filter_tools,
                            _make_subagent_emitter, _render_role_card,
                            _system_prompt)
from app.agent.registry import ToolRegistry, ToolResult
from app.agent.tools import subagent
from app.agent.permissions import DECISION_ALLOW, normalize_mode
from app import config

RELAXED = normalize_mode("relaxed")


# ---------- 注册与 schema ----------

def test_subagent_tool_registered():
    reg = ToolRegistry()
    subagent.register_all(reg)
    tool = reg.get("subagent_spawn")
    assert tool is not None
    assert tool.risk == "sensitive"
    schemas = {s["function"]["name"]: s["function"] for s in reg.openai_schemas()}
    assert schemas["subagent_spawn"]["parameters"]["required"] == ["task"]


def test_subagent_placeholder_fn_errors():
    reg = ToolRegistry()
    subagent.register_all(reg)
    r = reg.execute("subagent_spawn", {"task": "x"})
    assert isinstance(r, ToolResult) and not r.ok


def test_subagent_parallel_registered():
    reg = ToolRegistry()
    subagent.register_all(reg)
    tool = reg.get("subagent_parallel")
    assert tool is not None and tool.risk == "sensitive"
    schemas = {s["function"]["name"]: s["function"] for s in reg.openai_schemas()}
    assert schemas["subagent_parallel"]["parameters"]["required"] == ["tasks"]
    r = reg.execute("subagent_parallel", {"tasks": [{"task": "x"}]})
    assert isinstance(r, ToolResult) and not r.ok


# ---------- 工具可见性过滤 ----------

def _fake_schemas():
    return [{"function": {"name": n}} for n in
            ("subagent_spawn", "subagent_parallel", "run_command", "list_dir", "screen_analyze")]


def test_filter_tools_whitelist():
    out = _filter_tools(_fake_schemas(), ["list_dir"], depth=0)
    names = [s["function"]["name"] for s in out]
    assert names == ["list_dir"]


def test_filter_tools_depth_removes_spawn():
    out = _filter_tools(_fake_schemas(), None, depth=config.AGENT_MAX_SUBAGENT_DEPTH)
    names = [s["function"]["name"] for s in out]
    assert "subagent_spawn" not in names
    assert "subagent_parallel" not in names
    assert "list_dir" in names


def test_filter_tools_depth_below_limit_keeps_spawn():
    out = _filter_tools(_fake_schemas(), None, depth=0)
    names = [s["function"]["name"] for s in out]
    assert "subagent_spawn" in names


# ---------- 系统提示 ----------

def test_subagent_system_prompt():
    p = _system_prompt(role="subagent", depth=1)
    assert "子代理" in p and "委派深度 1" in p
    p_main = _system_prompt()
    assert "子代理" not in p_main


def test_system_prompt_injects_memory_context():
    """记忆注入段（extra_system）应拼接进系统提示，且子代理不携带主任务记忆。"""
    p = _system_prompt(extra_system="- 用户偏好用国内镜像源安装 Python 包 [preference]")
    assert "相关长期记忆" in p
    assert "国内镜像源" in p
    p_sub = _system_prompt(role="subagent", depth=1,
                           extra_system="- 用户偏好用国内镜像源安装 Python 包")
    assert "相关长期记忆" in p_sub  # 子代理同样可注入（独立场景另行控制）
    p_empty = _system_prompt(extra_system=None)
    assert "相关长期记忆" not in p_empty


# ---------- _execute_subagent 校验 ----------

def _run(coro):
    return asyncio.run(coro)


def test_execute_subagent_missing_task():
    r = _run(_execute_subagent({}, RELAXED, None, 0, "parent", "msg"))
    assert not r.ok and "task" in r.error


def test_execute_subagent_depth_exceeded():
    r = _run(_execute_subagent({"task": "t"}, RELAXED, None,
                               config.AGENT_MAX_SUBAGENT_DEPTH, "parent", "msg"))
    assert not r.ok and "深度上限" in r.error


def test_execute_parallel_missing_tasks():
    r = _run(_execute_subagent_parallel({}, RELAXED, None, 0, "parent", "msg"))
    assert not r.ok and "tasks" in r.error


def test_execute_parallel_too_many():
    many = [{"task": f"t{i}"} for i in range(config.AGENT_MAX_PARALLEL_SUBAGENTS + 1)]
    r = _run(_execute_subagent_parallel({"tasks": many}, RELAXED, None, 0, "parent", "msg"))
    assert not r.ok and "超限" in r.error


def test_execute_parallel_missing_task_field():
    r = _run(_execute_subagent_parallel({"tasks": [{"task": "ok"}, {"tool_filter": ["x"]}]},
                                        RELAXED, None, 0, "parent", "msg"))
    assert not r.ok and "tasks[1]" in r.error


def test_execute_parallel_depth_exceeded():
    r = _run(_execute_subagent_parallel({"tasks": [{"task": "t"}]}, RELAXED, None,
                                        config.AGENT_MAX_SUBAGENT_DEPTH, "parent", "msg"))
    assert not r.ok and "深度上限" in r.error


# ---------- 事件转发 ----------

def test_subagent_emitter_only_passes_approval():
    got = []

    async def emit(t, p):
        got.append(t)

    inner = _make_subagent_emitter(emit)
    async def go():
        await inner("token", {})
        await inner("tool_call", {})
        await inner("approval_request", {"task_id": "x"})
    asyncio.run(go())
    assert got == ["approval_request"]


# ---------- 审计谱系参数 ----------

def test_audit_accepts_parent_task_id(monkeypatch):
    """_audit 带 parent_task_id 调用 log_agent_task 不应抛异常（库不可用时静默 False）。"""
    calls = {}

    class FakeDb:
        @staticmethod
        def log_agent_task(task_id, tool_name, args, risk, approved,
                           result_text, ok, user_message="", mode="standard",
                           decision="ask", parent_task_id="", round_id="",
                           token_in=None, token_out=None,
                           element_id="", retries=None):
            calls["parent"] = parent_task_id
            calls["round_id"] = round_id
            return True

    import sys
    sys.modules["app.db"] = FakeDb
    try:
        loop._audit("msg", "tid", "tool", {}, "safe", "standard", DECISION_ALLOW,
                    True, "ok", True, parent_task_id="sub-1")
    finally:
        del sys.modules["app.db"]
    assert calls.get("parent") == "sub-1"


# ---------- 阶段 3：tool_result 截图路径提取（前端预览） ----------

def test_extract_image_paths_from_json(tmp_path):
    # JSON 转义路径（双反斜杠）应被还原并去重
    png = tmp_path / "shot.png"
    png.write_bytes(b"x")
    import json
    text = json.dumps({"path": str(png), "after": str(png), "note": "无图"})
    assert loop._extract_image_paths(text) == [str(png)]


def test_extract_image_paths_missing_file(tmp_path):
    # 文件不存在 → 不返回（防止前端渲染坏图）
    import json
    text = json.dumps({"path": str(tmp_path / "ghost.png")})
    assert loop._extract_image_paths(text) == []


def test_extract_image_paths_plain_text(tmp_path):
    # 普通文本路径（非 JSON）也应能提取
    png = tmp_path / "plain.png"
    png.write_bytes(b"x")
    text = "截图已保存到 %s，共 800x600" % png
    assert loop._extract_image_paths(text) == [str(png)]


def test_extract_image_paths_empty():
    assert loop._extract_image_paths("") == []
    assert loop._extract_image_paths("没有截图") == []


# ---------- B批1：子代理角色化（role/goal/backstory 角色卡） ----------

def test_render_role_card_full():
    card = {"role": "资深 Python 代码审查员", "goal": "找出 3 类缺陷",
            "backstory": "项目用 Flask，注意安全"}
    out = _render_role_card(card)
    assert "【你的角色卡】" in out
    assert "角色：资深 Python 代码审查员" in out
    assert "目标：找出 3 类缺陷" in out
    assert "背景：项目用 Flask" in out


def test_render_role_card_empty_variants():
    assert _render_role_card(None) == ""
    assert _render_role_card({}) == ""
    assert _render_role_card({"role": "  ", "goal": ""}) == ""


def test_render_role_card_partial_keeps_order():
    out = _render_role_card({"goal": "达成目标", "role": "审查员"})
    assert out.index("角色：审查员") < out.index("目标：达成目标")


def test_extract_role_card_filters_blanks():
    assert _extract_role_card({"task": "x", "role": "审查员",
                               "goal": "  ", "backstory": "背景"}) == {
        "role": "审查员", "backstory": "背景"}
    assert _extract_role_card({"task": "x"}) is None
    assert _extract_role_card(None) is None


def test_system_prompt_subagent_renders_role_card():
    p = _system_prompt(role="subagent", depth=1,
                       role_card={"role": "审查员", "goal": "找缺陷",
                                  "backstory": "Flask 项目"})
    assert "你的角色卡" in p
    assert "角色：审查员" in p and "目标：找缺陷" in p and "背景：Flask 项目" in p
    # 主代理不渲染角色卡（即使误传）
    p_main = _system_prompt(role="main",
                            role_card={"role": "审查员", "goal": "找缺陷"})
    assert "你的角色卡" not in p_main


def test_schema_exposes_role_fields():
    reg = ToolRegistry()
    subagent.register_all(reg)
    schemas = {s["function"]["name"]: s["function"] for s in reg.openai_schemas()}
    spawn = schemas["subagent_spawn"]["parameters"]["properties"]
    for k in ("role", "goal", "backstory"):
        assert k in spawn
    item = schemas["subagent_parallel"]["parameters"]["properties"]["tasks"]["items"]["properties"]
    for k in ("role", "goal", "backstory"):
        assert k in item


def test_execute_subagent_passes_role_card(monkeypatch):
    """委派时 role 卡应原样透传给内层 run_agent_task 并出现在 start 事件。"""
    calls, events = {}, []

    async def fake_run(user_message, history=None, emit=None, max_steps=None,
                       mode=None, depth=0, tool_filter=None, role="main",
                       parent_task_id="", extra_system=None, inbox=None,
                       round_id="", role_card=None):
        calls["task"], calls["role_card"] = user_message, role_card
        calls["role"] = role
        return {"reply": "已审查完成", "steps": 0, "limit": 1,
                "stop_reason": "completed"}

    async def emit(t, p):
        events.append((t, p))

    async def go():
        monkeypatch.setattr(loop, "run_agent_task", fake_run)
        monkeypatch.setattr(loop.permissions, "decide",
                            lambda *a, **k: (DECISION_ALLOW, "test"))
        return await _execute_subagent(
            {"task": "审查这段代码", "role": "资深 Python 代码审查员",
             "goal": "找出 3 类缺陷", "backstory": "Flask 项目"},
            RELAXED, emit, 0, "parent", "msg", round_id="r1")

    r = asyncio.run(go())
    assert r.ok
    assert calls["task"] == "审查这段代码"
    assert calls["role"] == "subagent"
    assert calls["role_card"] == {"role": "资深 Python 代码审查员",
                                  "goal": "找出 3 类缺陷", "backstory": "Flask 项目"}
    start_payloads = [p for t, p in events if t == "subagent_start"]
    assert start_payloads and start_payloads[0]["role"] == "资深 Python 代码审查员"


def test_execute_parallel_passes_per_task_role_card(monkeypatch):
    """并行各任务的 role 卡应各自透传；不带卡的任务 role_card 为 None。"""
    received, events = [], []

    async def fake_run(user_message, history=None, emit=None, max_steps=None,
                       mode=None, depth=0, tool_filter=None, role="main",
                       parent_task_id="", extra_system=None, inbox=None,
                       round_id="", role_card=None):
        received.append({"task": user_message, "role_card": role_card})
        return {"reply": f"完成 {user_message}", "steps": 0, "limit": 1,
                "stop_reason": "completed"}

    async def emit(t, p):
        events.append((t, p))

    async def go():
        monkeypatch.setattr(loop, "run_agent_task", fake_run)
        monkeypatch.setattr(loop.permissions, "decide",
                            lambda *a, **k: (DECISION_ALLOW, "test"))
        return await _execute_subagent_parallel(
            {"tasks": [{"task": "t1", "role": "审查员", "goal": "找缺陷"},
                       {"task": "t2"}]},
            RELAXED, emit, 0, "parent", "msg", round_id="r1")

    r = asyncio.run(go())
    assert r.ok and "【任务1" in r.text and "【任务2" in r.text
    assert received[0]["role_card"] == {"role": "审查员", "goal": "找缺陷"}
    assert received[1]["role_card"] is None
    starts = [p for t, p in events if t == "subagent_start"]
    assert starts[0]["role"] == "审查员"
    assert starts[1]["role"] == ""


# ---------- B批4：并行回收原子终态（单槽失败不抹整批） ----------

def test_execute_parallel_one_subagent_raise_keeps_others(monkeypatch):
    """原子终态回收：单个子代理异常只落自身失败槽，gather 不整体抛错，
    已完成的其它子代理结果照常保留（防"竞争写回"整批回退）。"""
    async def fake_run(user_message, history=None, emit=None, max_steps=None,
                       mode=None, depth=0, tool_filter=None, role="main",
                       parent_task_id="", extra_system=None, inbox=None,
                       round_id="", role_card=None):
        if user_message == "boom":
            raise RuntimeError("子代理内部崩溃")
        return {"reply": f"完成 {user_message}", "steps": 0, "limit": 1,
                "stop_reason": "completed"}

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        monkeypatch.setattr(loop, "run_agent_task", fake_run)
        monkeypatch.setattr(loop.permissions, "decide",
                            lambda *a, **k: (DECISION_ALLOW, "test"))
        return await _execute_subagent_parallel(
            {"tasks": [{"task": "normal"}, {"task": "boom"}]},
            RELAXED, emit, 0, "parent", "msg", round_id="r1")

    r = asyncio.run(go())
    assert r.ok  # 整批不因单槽崩溃失败
    assert "完成 normal" in r.text        # 已完成子代理结果保留
    assert "任务2 · failed" in r.text     # 异常槽标注失败终态
    assert "RuntimeError" in r.text       # 失败原因可见，供主模型判断


def test_execute_parallel_two_fail_one_ok_marks_all_in_text(monkeypatch):
    """多个失败槽与成功槽并存：汇总逐槽展示，ok_all 语义由文本承载。"""
    async def fake_run(user_message, history=None, emit=None, max_steps=None,
                       mode=None, depth=0, tool_filter=None, role="main",
                       parent_task_id="", extra_system=None, inbox=None,
                       round_id="", role_card=None):
        if user_message.startswith("崩"):
            raise ValueError("任务执行中断")
        return {"reply": f"结果 {user_message}", "steps": 1, "limit": 1,
                "stop_reason": "completed"}

    async def emit(t, p):
        pass

    async def go():
        monkeypatch.setattr(loop, "run_agent_task", fake_run)
        monkeypatch.setattr(loop.permissions, "decide",
                            lambda *a, **k: (DECISION_ALLOW, "test"))
        return await _execute_subagent_parallel(
            {"tasks": [{"task": "好"}, {"task": "崩一"}, {"task": "崩二"}]},
            RELAXED, emit, 0, "parent", "msg", round_id="r1")

    r = asyncio.run(go())
    assert r.ok and "结果 好" in r.text
    assert "任务2 · failed" in r.text and "任务3 · failed" in r.text
    assert r.text.index("任务1") < r.text.index("任务2") < r.text.index("任务3")
