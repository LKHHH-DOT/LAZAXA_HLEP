# -*- coding: utf-8 -*-
"""M4b 结构化规划层测试（plan_store / tools/plan / loop 注入 / registry 上下文传播）。

全部 mock 掉 db.log_agent_event（不碰 MySQL）与 loop 的 LLM/工具，纯测：
  1. plan_create：建 N 步、render 含 goal 与各步 ⬜
  2. 同轮重复 create：覆盖且提示重建
  3. plan_update 合法流转 pending→in_progress→done，图标更新、返回全量
  4. plan_update 非法跳转（pending→done 跳步）报错；坏 status / 越界 step_id 报错
  5. blocked→in_progress 恢复允许
  6. plan_get 读取；无计划返回"尚未建立"
  7. 步骤超 12 / 标题超长：截断（护栏）
  8. ContextVar 隔离：两个 round_id 互不串台；取不到 round_id 工具报错不写脏
  9. loop 集成：plan_create 后下一轮请求 messages 含【当前执行计划】；update 后状态变化
  10. registry context 传播：注册读 current_round_id 的测试工具，经 registry.execute 能读到
  11. 回归：copy_context 改造后，普通工具行为/返回不变
"""
import contextvars
import types

import pytest

from app.agent import task_context
from app.agent.plan_store import PlanStore, plan_store
from app.agent.registry import ToolRegistry, ToolResult


@pytest.fixture(autouse=True)
def _iso_plan_store(monkeypatch):
    """每个用例用独立 PlanStore + mock 掉 db 落账（不碰 MySQL）。"""
    fresh = PlanStore()
    # 三处引用都要替换：plan_store 模块、tools.plan、loop（from ... import 是导入时绑定）
    monkeypatch.setattr("app.agent.plan_store.plan_store", fresh)
    monkeypatch.setattr("app.agent.tools.plan.plan_store", fresh)
    monkeypatch.setattr("app.agent.loop.plan_store", fresh)
    monkeypatch.setattr("app.agent.plan_store._emit_plan_event", lambda *a, **k: None)
    return fresh


def _mk_store(store: PlanStore, rid="r-test", steps=None):
    return store.create(rid, "整理项目文档并归档",
                        steps or [{"title": "梳理目录结构"},
                                  {"title": "撰写总结"},
                                  {"title": "归档发布"}])


# ---------- 1. plan_create 基础 ----------

def test_create_renders_goal_and_pending_steps(_iso_plan_store):
    plan = _mk_store(_iso_plan_store)
    assert len(plan.steps) == 3
    r = plan.render()
    assert "整理项目文档并归档" in r
    assert "⬜ [s1]" in r and "⬜ [s2]" in r and "⬜ [s3]" in r
    assert "进度：0/3" in r


# ---------- 2. 同轮重复 create 覆盖 ----------

def test_create_overwrites_same_round(_iso_plan_store):
    _mk_store(_iso_plan_store)
    p2 = _iso_plan_store.create("r-test", "新目标", [{"title": "只做一步"}])
    assert p2.goal == "新目标"
    assert len(p2.steps) == 1
    plan = _iso_plan_store.get("r-test")
    assert plan.goal == "新目标" and len(plan.steps) == 1


# ---------- 3. 合法流转 ----------

def test_update_legal_transition_and_full_render(_iso_plan_store):
    _mk_store(_iso_plan_store)
    plan, err = _iso_plan_store.update("r-test", "s1", "in_progress")
    assert err == "" and plan is not None
    plan, err = _iso_plan_store.update("r-test", "s1", "done", "结构梳理完成")
    assert err == ""
    r = plan.render()
    assert "✅ [s1]" in r and "结构梳理完成" in r
    assert "⬜ [s2]" in r
    assert "进度：1/3" in r


# ---------- 4. 非法流转 / 坏参数 ----------

def test_update_illegal_skip_rejected(_iso_plan_store):
    _mk_store(_iso_plan_store)
    # 未开始（pending）直接跳 done —— 非法
    plan, err = _iso_plan_store.update("r-test", "s2", "done")
    assert err and "不允许" in err
    assert plan is None
    # 坏 status
    plan, err = _iso_plan_store.update("r-test", "s1", "weird")
    assert err and "未知状态" in err
    # 越界 step_id
    plan, err = _iso_plan_store.update("r-test", "s99", "done")
    assert err and "找不到步骤" in err
    # 无计划轮次
    plan, err = _iso_plan_store.update("r-none", "s1", "done")
    assert err and "请先调用 plan_create" in err


def test_update_blocked_recover_allowed(_iso_plan_store):
    _mk_store(_iso_plan_store)
    _, err = _iso_plan_store.update("r-test", "s2", "in_progress")
    assert err == ""
    _, err = _iso_plan_store.update("r-test", "s2", "blocked", "依赖缺失")
    assert err == ""
    plan, err = _iso_plan_store.update("r-test", "s2", "in_progress", "已解决")
    assert err == ""
    assert "⛔" not in plan.render()
    assert "已解决" in plan.render()


# ---------- 5. plan_get ----------

def test_get_returns_plan_and_empty(_iso_plan_store):
    _mk_store(_iso_plan_store)
    assert _iso_plan_store.get("r-test") is not None
    assert _iso_plan_store.get("r-empty") is None


# ---------- 6. 护栏：步数/长度 ----------

def test_create_limits_steps_and_titles(_iso_plan_store):
    steps = [{"title": f"步骤{i}"} for i in range(20)]  # 超 12
    plan = _iso_plan_store.create("r-test", "目标" * 500, steps)  # goal 超 200
    assert len(plan.steps) == 12
    assert len(plan.goal) <= 200


# ---------- 7. 工具层：无 round_id 报错不写脏 ----------

def test_tool_no_round_id_reports_error(_iso_plan_store):
    from app.agent.tools.plan import _plan_create, _plan_update, _plan_get
    # 未设 ContextVar
    tok = task_context.current_round_id.set("")
    try:
        r = _plan_create("目标", [{"title": "步骤"}])
        assert not r.ok and "上下文" in r.error
        r2 = _plan_update("s1", "done")
        assert not r2.ok and "上下文" in r2.error
        r3 = _plan_get()  # get 无轮次 → 提示无计划（安全降级）
        assert r3.ok and "没有结构化计划" in r3.text
    finally:
        task_context.current_round_id.reset(tok)


# ---------- 8. ContextVar 隔离 ----------

def test_plan_isolated_between_rounds(_iso_plan_store):
    _mk_store(_iso_plan_store, rid="r-a", steps=[{"title": "A 的步骤"}])
    _mk_store(_iso_plan_store, rid="r-b", steps=[{"title": "B 的步骤"}])
    assert "A 的步骤" in _iso_plan_store.get("r-a").render()
    assert "B 的步骤" in _iso_plan_store.get("r-b").render()
    assert "A 的步骤" not in _iso_plan_store.get("r-b").render()


# ---------- 9. loop 集成：每轮注入计划段 ----------

def test_loop_injects_plan_and_reflects_update(monkeypatch):
    import asyncio

    from app.agent import llm as llm_mod
    from app.agent import loop
    from app.agent.registry import registry as reg
    from app.agent.tools.plan import _plan_create, _plan_update

    # 用真实 plan 工具（mock 掉 db 落账）
    monkeypatch.setattr("app.agent.plan_store._emit_plan_event", lambda *a, **k: None)
    seen = []

    def fake_chat(messages, tools, *a, **k):
        seen.append(messages)
        # 第 1 轮：建计划；第 2 轮：s1 进行中；第 3 轮：s1 完成；第 4 轮：收尾
        if len(seen) == 1:
            _plan_create("做三件事", [{"title": "一"}, {"title": "二"}, {"title": "三"}])
            return types.SimpleNamespace(
                has_tool_calls=True, content="开始", tool_calls=[
                    types.SimpleNamespace(id="c1", name="plan_create",
                                          args={"goal": "做三件事",
                                                "steps": [{"title": "一"}, {"title": "二"},
                                                          {"title": "三"}]})],
                to_assistant_message=lambda: {"role": "assistant", "content": "开始", "tool_calls": []},
                usage=None)
        if len(seen) == 2:
            _plan_update("s1", "in_progress")
            return types.SimpleNamespace(
                has_tool_calls=True, content="", tool_calls=[
                    types.SimpleNamespace(id="c2", name="plan_update",
                                          args={"step_id": "s1", "status": "in_progress"})],
                to_assistant_message=lambda: {"role": "assistant", "content": "", "tool_calls": []},
                usage=None)
        if len(seen) == 3:
            _plan_update("s1", "done", "完成一")
            return types.SimpleNamespace(
                has_tool_calls=True, content="", tool_calls=[
                    types.SimpleNamespace(id="c3", name="plan_update",
                                          args={"step_id": "s1", "status": "done"})],
                to_assistant_message=lambda: {"role": "assistant", "content": "", "tool_calls": []},
                usage=None)
        return types.SimpleNamespace(has_tool_calls=False, content="收工",
                                     tool_calls=[], to_assistant_message=lambda: {"role": "assistant", "content": "收工", "tool_calls": []},
                                     usage=None)

    monkeypatch.setattr(llm_mod, "chat", fake_chat)
    monkeypatch.setattr(reg, "get", lambda name: types.SimpleNamespace(
        risk="safe", display_name=name))
    monkeypatch.setattr(reg, "execute", lambda name, args: types.SimpleNamespace(
        ok=True, text="ok", error="", brief=""))

    events = []

    async def emit(t, p):
        events.append((t, p))

    async def go():
        return await loop.run_agent_task("帮我做三件事", emit=emit,
                                         max_steps=5, round_id="r-loop-test")

    asyncio.run(go())
    # 第 2/4 轮请求里应注入【当前执行计划】段（以该标记开头，区别于系统提示内文）
    plan_inj = [m for m in seen[1]
                if m.get("role") == "system"
                and m.get("content", "").startswith("【当前执行计划】")]
    assert plan_inj, "第 2 轮应注入计划段"
    assert "做三件事" in plan_inj[0]["content"]
    # 第 4 轮：s1 已是 done（且旧计划段已被替换——每轮至多一条）
    plan_inj2 = [m for m in seen[3]
                 if m.get("role") == "system"
                 and m.get("content", "").startswith("【当前执行计划】")]
    assert plan_inj2, "第 4 轮应注入计划段"
    assert len(plan_inj2) == 1, "计划段应每轮替换而非累积"
    assert "✅ [s1]" in plan_inj2[0]["content"]
    assert "完成一" in plan_inj2[0]["content"]


# ---------- 10. registry context 传播 ----------

def test_registry_propagates_task_context(monkeypatch):
    from app.agent.registry import ToolRegistry

    tr = ToolRegistry()
    captured = {}

    def read_round(**kw):
        captured["rid"] = task_context.get_round_id()
        return types.SimpleNamespace(ok=True, text=captured["rid"], error="", brief="")

    from app.agent.registry import Tool
    tr.register(Tool(name="test_read_round", description="", parameters={},
                     risk="safe", timeout=5, fn=read_round))
    tok = task_context.current_round_id.set("r-ctx-test")
    try:
        res = tr.execute("test_read_round", {})
        assert res.ok and captured["rid"] == "r-ctx-test"
    finally:
        task_context.current_round_id.reset(tok)


# ---------- 11. 回归：普通工具不受 copy_context 影响 ----------

def test_registry_normal_tool_unchanged():
    from app.agent.registry import Tool

    tr = ToolRegistry()
    tr.register(Tool(name="test_add", description="", parameters={},
                     risk="safe", timeout=5,
                     fn=lambda a, b: ToolResult.ok_result(str(a + b))))
    res = tr.execute("test_add", {"a": 2, "b": 3})
    assert res.ok and res.text == "5"
