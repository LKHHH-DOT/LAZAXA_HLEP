# -*- coding: utf-8 -*-
"""S1-2 usage 落库 / S1-4 审计失败计数测试（M1 止血第一批）。

S1-2 覆盖：
  1. 流末 usage chunk → ChatResponse.usage 正确收集
  2. 旧服务端无 usage chunk → usage 为 None 不崩
  3. log_agent_task 把 token_in/token_out 写入 INSERT 参数（fake 捕获，不依赖 MySQL）
S1-4 覆盖：
  4. log_agent_task 写库异常 → audit_failure_count +1 且返回 False
  5. /api/health 与 /api/metrics 暴露 db.audit_failures / audit_failure_last
"""
import json

from app import db
from app.routers import health
from app.agent import llm


# ---------- S1-2：流式 usage 收集（复用轻量 fake 响应） ----------

class _FakeResp:
    def __init__(self, chunks):
        self.status_code = 200
        self._chunks = chunks
        self.text = ""

    def iter_lines(self, decode_unicode=True):
        return iter(self._chunks)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _ok_with_usage():
    chunks = [
        f"data: {json.dumps({'choices': [{'delta': {'content': '答'}}]})}",
        f"data: {json.dumps({'choices': [], 'usage': {'prompt_tokens': 33, 'completion_tokens': 7, 'total_tokens': 40}})}",
        "data: [DONE]",
    ]
    return _FakeResp(chunks)


def _ok_without_usage():
    chunks = [
        f"data: {json.dumps({'choices': [{'delta': {'content': '无用量'}}]})}",
        "data: [DONE]",
    ]
    return _FakeResp(chunks)


def _patch_post(monkeypatch, resp):
    def fake_post(url, **kw):
        return resp
    monkeypatch.setattr(llm.requests, "post", fake_post)


def test_chat_captures_usage_chunk(monkeypatch):
    _patch_post(monkeypatch, _ok_with_usage())
    r = llm.chat([{"role": "user", "content": "hi"}])
    assert r.usage is not None
    assert r.usage.get("prompt_tokens") == 33
    assert r.usage.get("completion_tokens") == 7
    assert r.content == "答"


def test_chat_usage_none_when_absent(monkeypatch):
    _patch_post(monkeypatch, _ok_without_usage())
    r = llm.chat([{"role": "user", "content": "hi"}])
    assert r.usage is None            # 旧服务端不带 usage chunk → None 不崩
    assert r.content == "无用量"


def test_log_agent_task_writes_token_columns(monkeypatch):
    """token_in/token_out 出现在 INSERT 参数尾部（fake _execute 捕获，不依赖 MySQL）。"""
    calls = {"sql": "", "params": None}

    def noop(*a, **kw):
        return None

    def fake_execute(sql, args=None, fetch_one=False):
        calls["sql"] = sql
        calls["params"] = args
        return None

    monkeypatch.setattr(db, "_ensure_agent_tasks_parent_col", noop)
    monkeypatch.setattr(db, "_ensure_agent_task_unique_idx", noop)
    monkeypatch.setattr(db, "_ensure_agent_tasks_token_col", noop)
    monkeypatch.setattr(db, "_MIGRATED_TASK_TRACE_COL", True)   # P2-2 列迁移免探测
    monkeypatch.setattr(db, "_TASK_UQ_READY", True)      # 走原子 INSERT IGNORE 路径
    monkeypatch.setattr(db, "_execute", fake_execute)

    before = db.audit_failure_count()
    ok = db.log_agent_task("t-token", "search", {"q": "x"}, "safe", True,
                           "hit", True, round_id="r-1", token_in=12, token_out=34)
    assert ok is True
    assert "token_in, token_out" in calls["sql"]
    assert calls["params"][-2] == 12 and calls["params"][-1] == 34
    assert db.audit_failure_count() == before           # 正常路径不计数


def test_log_agent_task_writes_element_id_and_retries(monkeypatch):
    """P2-2：element_id/retries 落在 ok 与 token_in 之间（追溯"为什么点了这里"）。"""
    calls = {"sql": "", "params": None}

    def noop(*a, **kw):
        return None

    def fake_execute(sql, args=None, fetch_one=False):
        calls["sql"] = sql
        calls["params"] = args
        return None

    monkeypatch.setattr(db, "_ensure_agent_tasks_parent_col", noop)
    monkeypatch.setattr(db, "_ensure_agent_task_unique_idx", noop)
    monkeypatch.setattr(db, "_ensure_agent_tasks_token_col", noop)
    monkeypatch.setattr(db, "_MIGRATED_TASK_TRACE_COL", True)
    monkeypatch.setattr(db, "_TASK_UQ_READY", True)
    monkeypatch.setattr(db, "_execute", fake_execute)

    ok = db.log_agent_task("t-trace", "mouse_click", {"element_id": "Button:btnOk"},
                           "sensitive", True, "clicked", True,
                           element_id="Button:btnOk", retries=2)
    assert ok is True
    assert "element_id, retries, token_in, token_out" in calls["sql"]
    assert calls["params"][-4] == "Button:btnOk"
    assert calls["params"][-3] == 2
    # 未提供时写 NULL（不是空串/0，便于区分"无此信息"与"零次重试"）
    ok2 = db.log_agent_task("t-trace2", "ui_list", {}, "safe", None, "x", True)
    assert ok2 is True
    assert calls["params"][-4] is None and calls["params"][-3] is None


# ---------- S1-4：审计失败计数 ----------

def test_audit_failure_bumped_on_db_error(monkeypatch):
    """写库路径抛异常 → 计数 +1 且返回 False（不再全静默）。"""
    def boom(sql, args=None, fetch_one=False):
        raise RuntimeError("mysql down")

    monkeypatch.setattr(db, "_execute", boom)
    before = db.audit_failure_count()
    ok = db.log_agent_task("t-err", "run_command", {"cmd": "x"}, "safe",
                           None, "ok", True, mode="standard", decision="allow")
    assert ok is False
    assert db.audit_failure_count() == before + 1
    assert "log_agent_task" in (db.audit_failure_last() or "")


def test_health_and_metrics_expose_audit_failures(monkeypatch):
    """health/metrics 的 db 段带 audit_failures 与 audit_failure_last（进程内累计）。"""
    monkeypatch.setattr(health, "_db_alive", lambda: (True, 1.0))
    monkeypatch.setattr(health.db, "count_sessions", lambda: 0)
    monkeypatch.setattr(health.db, "count_messages", lambda: 0)

    h = health.api_health()
    assert "audit_failures" in h["db"]
    assert "audit_failure_last" in h["db"]
    assert isinstance(h["db"]["audit_failures"], int)

    m = health.api_metrics()
    assert "audit_failures" in m["db"]
    assert isinstance(m["db"]["audit_failures"], int)
