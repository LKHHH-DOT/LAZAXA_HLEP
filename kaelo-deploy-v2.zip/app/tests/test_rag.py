# -*- coding: utf-8 -*-
"""RAG 核心算法单元测试：切块 / 中文切词 / BM25 / RRF 融合（均不依赖 Ollama embedding）。"""
from app import rag


# ---------- 切块 _split_text ----------

def test_split_short_text_single_chunk():
    chunks = rag._split_text("今天天气很好。明天应该也不错。")
    assert len(chunks) == 1
    assert "今天天气很好" in chunks[0]


def test_split_empty_text():
    assert rag._split_text("") == []
    assert rag._split_text("   \n\t ") == []


def test_split_long_text_hard_cut():
    # 150 字无标点的长文本会被硬切成多块，且每块不超过 max_len
    text = "字" * 300
    chunks = rag._split_text(text)
    assert len(chunks) >= 2
    assert all(len(c) <= 150 for c in chunks)
    # 重叠：下一块开头应包含上一块尾部内容
    assert chunks[0][-30:] in chunks[1]


def test_split_overlap_joins_chunks():
    # 两句拼接后超过 max_len 时，第二块携带第一块尾部 overlap 字
    text = "，" * 90 + "。" + "，" * 90 + "。"
    chunks = rag._split_text(text)
    assert len(chunks) >= 2
    assert chunks[0][-30:] in chunks[1]


# ---------- 中文切词 _tokenize ----------

def test_tokenize_unigram_bigram():
    toks = rag._tokenize("苹果")
    assert "苹" in toks and "果" in toks
    assert "苹果" in toks


def test_tokenize_strips_punctuation():
    toks = rag._tokenize("你好，世界！")
    unigrams = [t for t in toks if len(t) == 1]
    assert all(c not in "，！" for c in unigrams)
    assert "你好" in toks


def test_tokenize_empty():
    assert rag._tokenize("！！！  ") == []


# ---------- BM25 ----------

def test_bm25_ranks_relevant_first():
    bm = rag.BM25Index()
    bm.build(["我喜欢吃苹果", "我喜欢吃香蕉", "今天下雨了"])
    hits = bm.search("苹果")
    assert hits, "应至少命中一个文档"
    top_idx, top_score = hits[0]
    assert top_idx == 0
    assert top_score > 0


def test_bm25_no_match():
    bm = rag.BM25Index()
    bm.build(["我喜欢吃苹果", "今天下雨了"])
    assert bm.search("火箭") == []


def test_bm25_empty_index():
    bm = rag.BM25Index()
    bm.build([])
    assert bm.search("苹果") == []


# ---------- RRF 融合 ----------

def test_rrf_ranked_first():
    # 两路排序一致时，融合后第一个文档就是排位最高者
    fused = rag._rrf_fuse([0, 1, 2], [0, 1, 2])
    assert fused[0] == 0
    assert sorted(fused) == [0, 1, 2]


def test_rrf_intersection_boosted():
    # 同时出现在两路的文档排名应高于只在一路出现的文档
    fused = rag._rrf_fuse([0, 1, 2, 3], [0, 2, 4, 5])
    pos0 = fused.index(0)
    pos3 = fused.index(3)
    pos4 = fused.index(4)
    assert pos0 < pos3 and pos0 < pos4  # 0 在两路都靠前
    assert pos4 < pos3  # 只在 bm25 出现的 4 高于只在 vec 出现的 3（二者排名相同则同秩）


def test_rrf_empty_ranked():
    assert rag._rrf_fuse([], []) == []
    assert rag._rrf_fuse([1, 2], []) == [1, 2]
