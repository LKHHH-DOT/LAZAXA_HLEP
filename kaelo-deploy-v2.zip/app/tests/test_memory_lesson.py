# -*- coding: utf-8 -*-
"""M4c 失败教训沉淀测试（app/memory.py::sink_failure_lesson / 注入置前）。

全部 mock registry.execute（Qdrant）与 LLM 提炼，纯测规则：
  1. loop_capped / max_steps 行为类失败 → 沉淀 experience（tags/source/round_id）
  2. error / empty_response → 不沉淀（外部故障/空回复，宁缺毋滥）
  3. LLM 提炼失败 → 规则兜底仍沉淀，文本含工具序列
  4. 同任务同停因 30 分钟防抖；不同任务/不同停因不受限
  5. 任务描述过短 → 不沉淀
  6. get_memory_context：experience 稳定置前、组内保持相关度原序、profile 排除
"""
import types

import pytest

from app import memory as mem


@pytest.fixture
def _setup(monkeypatch):
    """重置防抖状态；假 registry（记录写入）+ 假 LLM（返回固定教训）。"""
    from app.agent.registry import registry as reg

    mem._recent_lesson.update(fp=None, ts=0.0)
    calls = []

    def fake_execute(name, args):
        calls.append((name, args))
        return types.SimpleNamespace(ok=True)

    monkeypatch.setattr(reg, "execute", fake_execute)
    monkeypatch.setattr(mem, "_build_lesson_via_llm",
                        lambda *a, **k: "教训：情形X，根因Y，下次换工具Z")
    return calls


# ---------- 1. 行为类失败沉淀 ----------

def test_lesson_loop_capped_sinks(_setup):
    ok = mem.sink_failure_lesson(
        "帮我反复分析这块屏幕", "loop_capped", error="重复调用",
        tool_path=["screenshot", "screenshot", "analyze_screen"], round_id="r-1")
    assert ok
    name, args = _setup[0]
    assert name == "memory_add"
    assert args["type"] == "experience"
    assert "失败教训" in args["tags"] and "loop_capped" in args["tags"]
    assert args["source"] == "[教训] 失败终态"
    assert args["round_id"] == "r-1"
    assert args["text"] == "教训：情形X，根因Y，下次换工具Z"


def test_lesson_max_steps_sinks(_setup):
    assert mem.sink_failure_lesson("完成一个多步骤的复杂整理任务", "max_steps")
    args = _setup[0][1]
    assert args["type"] == "experience"
    assert "max_steps" in args["tags"]


# ---------- 2. 外部故障/空回复不沉淀 ----------

def test_lesson_error_not_sunk(_setup):
    assert not mem.sink_failure_lesson("一个足够长的正常任务描述", "error",
                                       error="DeepSeek API 500")
    assert _setup == []


def test_lesson_empty_response_not_sunk(_setup):
    assert not mem.sink_failure_lesson("一个足够长的正常任务描述", "empty_response")
    assert _setup == []


# ---------- 3. LLM 失败 → 规则兜底 ----------

def test_lesson_llm_empty_rule_fallback(monkeypatch, _setup):
    monkeypatch.setattr(mem, "_build_lesson_via_llm", lambda *a, **k: "")
    ok = mem.sink_failure_lesson(
        "帮我分析屏幕内容并逐步操作界面", "loop_capped",
        tool_path=["screenshot", "analyze_screen", "screenshot"])
    assert ok
    text = _setup[0][1]["text"]
    assert "教训" in text
    assert "screenshot" in text          # 规则兜底带工具序列
    assert _setup[0][1]["type"] == "experience"


# ---------- 4. 防抖 ----------

def test_lesson_debounce_same_task(_setup):
    desc = "同一个足够长的任务名字用来测试防抖逻辑"
    assert mem.sink_failure_lesson(desc, "loop_capped")
    assert not mem.sink_failure_lesson(desc, "loop_capped")   # 30 分钟内同指纹
    assert len(_setup) == 1
    # 不同任务不受限
    assert mem.sink_failure_lesson("另一个完全不同的长任务描述", "loop_capped")
    assert len(_setup) == 2
    # 同任务不同停因（指纹不同）也不受限
    assert mem.sink_failure_lesson(desc, "max_steps")
    assert len(_setup) == 3


# ---------- 5. 描述过短不沉淀 ----------

def test_lesson_short_desc_not_sunk(_setup):
    assert not mem.sink_failure_lesson("短", "loop_capped")
    assert _setup == []


# ---------- 6. 注入段 experience 稳定置前 ----------

def test_memory_context_experience_first(monkeypatch):
    items = (
        {"text": "普通记忆A", "type": "memory"},
        {"text": "经验教训B", "type": "experience"},
        {"text": "画像P", "type": "profile"},      # 应被排除
        {"text": "普通记忆C", "type": "memory"},
        {"text": "经验D", "type": "experience"},
    )
    monkeypatch.setattr(mem, "_cached_retrieve", lambda q, k: items)
    out = mem.get_memory_context("某个查询", top_k=5)
    lines = [ln for ln in out.splitlines() if ln.startswith("- ")]
    assert len(lines) == 4                          # profile 被排除
    assert "经验教训B" in lines[0] and "经验D" in lines[1]   # experience 在前、保原序
    assert "普通记忆A" in lines[2] and "普通记忆C" in lines[3]  # 其余在后、保原序
    assert "画像P" not in out
