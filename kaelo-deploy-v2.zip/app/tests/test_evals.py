# -*- coding: utf-8 -*-
"""M2 立尺 · app/evals.py 单元测试。

全部 mock：不连真实 MySQL、不真调 DeepSeek。
- db 层：monkeypatch app.db._execute / evals._fetch_* 返回假数据；
- judge 层：注入 llm_call 假函数；缓存路径改到 tmp_path。
"""
import json

import pytest

from app import evals

DIM_NAMES = [d[0] for d in evals.DIMS]


def _good_judge_json(overrides=None, na=None):
    """构造合法 judge 输出（默认五维全 true）。"""
    dims = {}
    for name in DIM_NAMES:
        p = True
        if overrides and overrides.get(name) is not None:
            p = overrides[name]
        if na and name in na:
            p = None
        dims[name] = {"pass": p, "reason": f"{name}判据"}
    return json.dumps({"dims": dims}, ensure_ascii=False)


def _trajectory(n_steps=2, ok_all=True):
    """假轨迹：默认 2 步全 ok。"""
    steps = []
    for i in range(n_steps):
        steps.append({
            "tool_name": "read_file",
            "args": {"path": f"C:/t/{i}.txt"},
            "result": "file content",
            "ok": ok_all,
            "decision": "allow",
            "created_at": "2026-09-06 10:00:00",
        })
    return {
        "round_id": "r-1",
        "user_message": "帮我读一下文件并总结",
        "steps": steps,
        "reply": "已读取文件并总结：……",
        "reply_missing": False,
        "job": None,
    }


def _toy_dims(pass_map):
    """pass_map: name -> True/False/None → 构造 score.dims（供 render_report）。"""
    return {
        name: {"pass": pass_map.get(name, True), "reason": f"{name}原因"}
        for name in DIM_NAMES
    }


# ---------- 轨迹读取 ----------

def test_load_trajectory_none_when_no_rows(monkeypatch):
    monkeypatch.setattr(evals, "_fetch_round_rows", lambda rid: [])
    assert evals.load_trajectory("r-x") is None


def test_load_trajectory_job_reply(monkeypatch):
    rows = [{
        "task_id": 1, "parent_task_id": None, "session_id": 1,
        "user_message": "统计一下目录里文件大小",
        "tool_name": "list_dir", "tool_args": '{"path": "C:/t"}',
        "tool_result": '{"files": 3}', "risk": "safe", "mode": "auto",
        "decision": "allow", "approved": 1, "ok": 1,
        "token_in": 10, "token_out": 5, "created_at": "2026-09-06 10:00:00",
    }]
    monkeypatch.setattr(evals, "_fetch_round_rows", lambda rid: rows)
    monkeypatch.setattr(evals, "_fetch_job", lambda rid: {
        "job_id": 9, "status": "done",
        "reply": "共 3 个文件，总大小 10MB", "error": None,
        "stop_reason": "completed", "steps": 1, "ms": 200,
        "created_at": "2026-09-06 10:00:05",
    })
    monkeypatch.setattr(evals, "_find_chat_reply", lambda text: "")
    traj = evals.load_trajectory("r-1")
    assert traj["user_message"] == "统计一下目录里文件大小"
    assert traj["steps"][0]["tool_name"] == "list_dir"
    assert traj["steps"][0]["args"] == {"path": "C:/t"}  # JSON 字符串已解析
    assert traj["steps"][0]["ok"] is True
    assert traj["reply"] == "共 3 个文件，总大小 10MB"
    assert traj["reply_missing"] is False


def test_load_trajectory_chat_reply_fallback(monkeypatch):
    rows = [{
        "task_id": 2, "parent_task_id": None, "session_id": 1,
        "user_message": "现在几点了", "tool_name": "get_time",
        "tool_args": "{}", "tool_result": "10:30", "risk": "safe",
        "mode": "auto", "decision": "allow", "approved": 1, "ok": 1,
        "token_in": 0, "token_out": 0, "created_at": "2026-09-06 10:00:00",
    }]
    monkeypatch.setattr(evals, "_fetch_round_rows", lambda rid: rows)
    monkeypatch.setattr(evals, "_fetch_job", lambda rid: None)  # 主对话型无 job
    monkeypatch.setattr(evals, "_find_chat_reply", lambda text: "现在是 10:30。")
    traj = evals.load_trajectory("r-2")
    assert traj["reply"] == "现在是 10:30。"
    assert traj["reply_missing"] is False


def test_find_chat_reply_latest_user_then_assistant(monkeypatch):
    """chat_messages 查询分支：user 原话 → 紧随 assistant。"""
    calls = []

    def fake_execute(sql, args=None):
        calls.append((sql, args))
        if "role = 'user'" in sql:
            return [{"session_id": 5, "id": 100}]
        if "role = 'assistant'" in sql:
            return [{"content": "这是回复正文"}]
        return []

    monkeypatch.setattr(evals.db, "_execute", fake_execute)
    assert evals._find_chat_reply("原话") == "这是回复正文"
    assert len(calls) == 2


def test_find_chat_reply_empty_when_no_user(monkeypatch):
    def fake_execute(sql, args=None):
        return []

    monkeypatch.setattr(evals.db, "_execute", fake_execute)
    assert evals._find_chat_reply("不存在的原话") == ""


# ---------- 摘要 ----------

def test_trunc_keeps_tail_and_marks_omission():
    long = "字" * 1000
    out = evals._trunc(long, head=100, tail=100)
    assert "省略" in out
    assert len(out) < 300


def test_summarize_step_flags():
    ok = {"tool_name": "read_file", "args": {}, "result": "x", "ok": True,
          "decision": "allow"}
    fail = {"tool_name": "write_file", "args": {"p": "a"}, "result": "err",
            "ok": False, "decision": "allow"}
    deny = {"tool_name": "del_file", "args": {}, "result": "", "ok": None,
            "decision": "deny"}
    assert "→ ok:" in evals._summarize_step(ok)
    assert "→ FAIL:" in evals._summarize_step(fail)
    assert "→ DENY:" in evals._summarize_step(deny)


def test_summarize_trajectory_short_no_ellipsis():
    traj = _trajectory(n_steps=1)
    text = evals.summarize_trajectory(traj, max_chars=8000)
    assert "轨迹（1 步）" in text
    assert "read_file" in text


def test_summarize_trajectory_long_markers():
    traj = _trajectory(n_steps=30, ok_all=False)  # 全 FAIL
    text = evals.summarize_trajectory(traj, max_chars=800)
    assert "省略" in text or "中段" in text


# ---------- Judge ----------

def test_build_judge_messages_includes_parts():
    traj = _trajectory()
    system, user = evals.build_judge_messages(traj, expected="输出总结")
    assert "用户请求" in user
    assert "期望结果\n输出总结" in user
    assert "read_file" in user
    assert "最终回复" in user
    assert "task_success" in system  # 五维英文键名在 system 提示词中


def test_parse_judge_output_fenced_and_garbage_ok():
    wrapped = "解释如下\n```json\n" + _good_judge_json() + "\n```\n完毕"
    parsed = evals.parse_judge_output(wrapped)
    assert parsed is not None
    for name in DIM_NAMES:
        assert parsed["dims"][name]["pass"] is True


def test_parse_judge_output_na_and_false():
    text = _good_judge_json(overrides={"tool_selection": False},
                            na={"loop_health"})
    parsed = evals.parse_judge_output(text)
    assert parsed["dims"]["tool_selection"]["pass"] is False
    assert parsed["dims"]["loop_health"]["pass"] is None


def test_parse_judge_output_bad_json_none():
    assert evals.parse_judge_output("不是 JSON") is None
    assert evals.parse_judge_output(None) is None
    assert evals.parse_judge_output('{"dims": []}') is None


def test_judge_one_injected_llm_and_any_fail(monkeypatch, tmp_path):
    monkeypatch.setattr(evals, "_DATA_DIR", str(tmp_path))
    calls = []
    llm_call = lambda *a, **k: (calls.append(1), _good_judge_json(
        overrides={"task_success": False}))[1]
    traj = _trajectory()
    out = evals.judge_one(traj, expected="输出总结", llm_call=llm_call,
                          use_cache=False)
    assert calls == [1]
    assert out["judge_error"] is False
    assert out["any_fail"] is True
    assert out["pass_all"] is False
    assert out["reply_missing"] is False
    assert out["dims"]["task_success"]["pass"] is False


def test_judge_one_cache_hit_skips_llm(monkeypatch, tmp_path):
    monkeypatch.setattr(evals, "_DATA_DIR", str(tmp_path))
    cache_store = {}
    monkeypatch.setattr(evals, "_load_cache", lambda: cache_store)
    monkeypatch.setattr(evals, "_save_cache",
                        lambda key, value: cache_store.update({key: value}))
    llm_call = lambda *a, **k: _good_judge_json()
    traj = _trajectory()
    first = evals.judge_one(traj, llm_call=llm_call, use_cache=True)
    assert first["cached"] is False
    assert len(cache_store) == 1
    # 第二次命中缓存，不再调用 llm_call
    second = evals.judge_one(traj, llm_call=llm_call, use_cache=True)
    assert second["cached"] is True
    assert second["pass_all"] is True


def test_judge_one_llm_exception_judge_error(monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("network down")

    out = evals.judge_one(_trajectory(), llm_call=boom, use_cache=False)
    assert out["judge_error"] is True
    assert out["dims"] == {}


# ---------- 报告 ----------

def _item(item_id, pass_map, judge_error=False):
    return {
        "id": item_id, "task": f"任务{item_id}", "category": "文件",
        "expected": "期望", "trajectory": _trajectory(),
        "score": {"judge_error": judge_error, "pass_all": not any(
            v is False for v in pass_map.values()),
            "any_fail": any(v is False for v in pass_map.values()),
            "reply_missing": False, "dims": _toy_dims(pass_map)},
    }


def test_render_report_pass_rate_and_lists():
    items = [
        _item("r-1", {name: True for name in DIM_NAMES}),
        _item("r-2", {"task_success": False, **{n: True for n in DIM_NAMES[1:]}}),
        _item("r-3", {name: True for name in DIM_NAMES}, judge_error=True),
    ]
    md = evals.render_report(items)
    assert "1/2 = 50.0%" in md  # 可判 2，通过 1（r-3 不可判不计）
    assert "失败任务清单" in md
    assert "r-2" in md
    assert "任务成功" in md  # 失败理由里带维度中文名
    assert "不可判清单" in md
    assert "r-3" in md


def test_render_report_zero_denominator_no_crash():
    md = evals.render_report([
        _item("r-1", {n: True for n in DIM_NAMES}, judge_error=True),
    ])
    assert "通过率" in md
    assert "r-1" in md
