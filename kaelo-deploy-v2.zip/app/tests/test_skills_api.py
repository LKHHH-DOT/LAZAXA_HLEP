# -*- coding: utf-8 -*-
"""技能中心接口测试（2026-09-03）：md/url/zip 安装 + zip-slip + 同名冲突 + 卸载 + 列表。

技能目录被 monkeypatch 到 tmp_path，绝不写入真实 Kaelo/skills/。
不触发网络：URL 抓取函数被 stub，仅私有地址分支用真函数断言拦截。
"""
import io
import zipfile

import pytest
from fastapi.testclient import TestClient

from app import config
from app.main import app
from app.routers import skills as skills_router

TOKEN = config.ADMIN_TOKEN
H = {"X-Admin-Token": TOKEN}


@pytest.fixture(autouse=True)
def disable_autorebuild(monkeypatch):
    monkeypatch.setattr(config, "AUTO_REBUILD", False)


@pytest.fixture
def skills_dir(monkeypatch, tmp_path):
    """把技能目录指到临时目录，避免污染真实技能库。"""
    monkeypatch.setattr(config, "SKILLS_DIR", str(tmp_path))
    return tmp_path


def test_skills_requires_token():
    with TestClient(app) as c:
        assert c.get("/api/v1/skills").status_code == 401


def test_import_md_pure_text_then_list_and_delete(skills_dir):
    """纯文本导入自动补 description；列表可见；卸载后消失。"""
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/md", headers=H,
                   json={"name": "My Skill!", "content": "这是我整理的导出 PDF 的操作指南。" * 3})
        assert r.status_code == 200, r.text
        name = r.json()["name"]
        assert name == "my-skill"
        # 落在技能目录
        assert (skills_dir / (name + ".md")).exists()
        # 列表可查到，且 use_skill 目录（list_skills）可识别
        data = c.get("/api/v1/skills", headers=H).json()["skills"]
        assert any(s["name"] == name and s["size"] > 0 for s in data)
        # 卸载
        assert c.delete("/api/v1/skills/%s" % name, headers=H).json()["deleted"] == name
        assert not (skills_dir / (name + ".md")).exists()


def test_import_md_with_frontmatter_and_conflict(skills_dir):
    """带 description frontmatter 原样保留；重复导入同名 → 409。"""
    md = "---\ndescription: 归档旧项目的标准流程\n---\n\n# 归档\n1. 备份\n2. 清理"
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/md", headers=H, json={"name": "archive-project", "content": md})
        assert r.status_code == 200
        assert r.json()["description"] == "归档旧项目的标准流程"
        r2 = c.post("/api/v1/skills/md", headers=H,
                    json={"name": "archive-project", "content": md})
        assert r2.status_code == 409


def test_import_md_invalid_name(skills_dir):
    """无法生成技能名的输入被拒绝（如纯符号/纯中文文件名），且不落盘。"""
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/md", headers=H,
                   json={"name": "！!！#$%", "content": "x"})
        assert r.status_code == 400
        assert not list(skills_dir.iterdir())


def test_import_url_plain_text(skills_dir, monkeypatch):
    """直链 .md：正文收录，名字取自 URL 尾段。"""
    monkeypatch.setattr(skills_router, "_download",
                        lambda url: ("# 浏览器快捷键大全\n\nCtrl+T 新建标签".encode("utf-8"), "text/markdown"))
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/url", headers=H,
                   json={"url": "https://example.com/skills/browser-shortcuts.md"})
        assert r.status_code == 200, r.text
        assert r.json()["name"] == "browser-shortcuts"


def test_import_url_html_strips_tags(skills_dir, monkeypatch):
    """HTML 页自动抽正文并补 description。"""
    html = ("<html><head><script>var x=1</script></head><body>"
            "<h1>批量重命名技巧</h1><p>先预览再执行</p></body></html>")
    monkeypatch.setattr(skills_router, "_download", lambda url: (html.encode(), "text/html"))
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/url", headers=H, json={"url": "https://x.com/p/rename-tips"})
        assert r.status_code == 200, r.text
        res = r.json()
        assert res["name"] == "rename-tips"
        assert "description" in res and res["description"]


def test_import_url_rejects_private_host(skills_dir):
    """防 SSRF：本机/内网地址直接 400（不联网）。"""
    with TestClient(app) as c:
        for bad in ("http://127.0.0.1/skill.md",
                    "http://localhost/skill.md",
                    "http://192.168.1.10/skill.md"):
            assert c.post("/api/v1/skills/url", headers=H,
                          json={"url": bad}).status_code == 400


def _zip_bytes(entries: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, content in entries.items():
            z.writestr(name, content)
    return buf.getvalue()


def test_import_zip_multi_skills(skills_dir):
    """一包多技能：两个 .md 入库；README 等非技能文件跳过不入库。"""
    data = _zip_bytes({
        "skills/photo-organizer.md": "---\ndescription: 整理照片\n---\n按日期分文件夹",
        "skills/video-trim.md": "---\ndescription: 视频裁剪\n---\n用 ffmpeg -ss",
        "skills/README.md": "这是一个技能包说明",   # 非技能，应跳过
        "cover.png": b"\x89PNG",
    })
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/zip", headers=H,
                   files={"file": ("skills.zip", io.BytesIO(data), "application/zip")})
        assert r.status_code == 200, r.text
        res = r.json()
        assert sorted(res["installed"]) == ["photo-organizer", "video-trim"]
        assert any(s.endswith("README.md") for s in res["skipped"])
        assert "cover.png" in res["skipped"]
        assert not (skills_dir / "README.md").exists()


def test_import_zip_slip_rejected(skills_dir):
    """路径穿越/绝对路径条目被拒绝，不写盘。"""
    data = _zip_bytes({
        "../../evil.md": "---\ndescription: evil\n---\n入侵",
        "ok-skill.md": "---\ndescription: 正常\n---\n正文",
    })
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/zip", headers=H,
                   files={"file": ("s.zip", io.BytesIO(data), "application/zip")})
        assert r.status_code == 200
        res = r.json()
        assert res["installed"] == ["ok-skill"]
        assert res["skipped"][0].startswith("⚠")
        assert not (skills_dir.parent / "evil.md").exists()


def test_import_zip_duplicate_names_conflict(skills_dir):
    """zip 内两个同名 .md：只装第一个，第二个记入 conflicts。"""
    data = _zip_bytes({
        "a/same-name.md": "---\ndescription: 一版\n---\n内容一",
        "b/same-name.md": "---\ndescription: 二版\n---\n内容二",
    })
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/zip", headers=H,
                   files={"file": ("s.zip", io.BytesIO(data), "application/zip")})
        assert r.status_code == 200
        assert r.json()["installed"] == ["same-name"]
        assert r.json()["conflicts"] == ["same-name.md"]


def test_import_zip_bad_file(skills_dir):
    """非 ZIP 文件 → 400。"""
    with TestClient(app) as c:
        r = c.post("/api/v1/skills/zip", headers=H,
                   files={"file": ("x.zip", io.BytesIO(b"not a zip"), "application/zip")})
        assert r.status_code == 400


def test_delete_missing_and_illegal(skills_dir):
    """卸载不存在的技能 → 404；非法名 → 404（防穿越删除）。"""
    with TestClient(app) as c:
        assert c.delete("/api/v1/skills/not-exist", headers=H).status_code == 404
        assert c.delete("/api/v1/skills/UPPER-BAD", headers=H).status_code == 404
