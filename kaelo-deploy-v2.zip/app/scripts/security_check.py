#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lazaxa 电脑安全体检脚本（Windows）
==================================
定位：电脑安全管家的一键体检工具（防御向）
- 零第三方依赖，仅用 Python 标准库 + Windows 系统命令（PowerShell）
- 输出分级报告：✅ 正常 / ⚠️ 注意 / 🔴 紧急
- 用法：
    python security_check.py            # 全量体检
    python security_check.py --check ports   # 只看监听端口
    python security_check.py --server   # 服务器模式（预留，网站上线后启用）

体检项说明见 docs/电脑安全防护技术文档.md §5
"""

import argparse
import re
import subprocess
import sys
from collections import Counter

CREATE_NO_WINDOW = 0x08000000  # Windows：隐藏 PowerShell 子进程窗口（后台/守护运行时不闪窗）

# ------------------------------------------------------------
# 基础工具
# ------------------------------------------------------------

def ps(cmd: str, timeout: int = 20) -> str:
    """执行 PowerShell 命令并返回 stdout（容错返回空串）"""
    try:
        # 强制 PowerShell 以 UTF-8 输出，避免中文（如账户名）经管道时乱码
        cmd = "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; " + cmd
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, creationflags=CREATE_NO_WINDOW,
        )
        return (r.stdout or "").strip()
    except Exception:
        return ""


def ps_list(cmd: str) -> list:
    """执行 PowerShell 命令，按行返回结果列表"""
    out = ps(cmd)
    return [ln.strip() for ln in out.splitlines() if ln.strip()]


# 级别标记
OK, WARN, CRIT = "✅", "⚠️", "🔴"


# ------------------------------------------------------------
# 体检项
# ------------------------------------------------------------

def check_system():
    """1. 系统信息（信息项，无风险判定）"""
    cap, ver = ps("(Get-CimInstance Win32_OperatingSystem).Caption"), ps("(Get-CimInstance Win32_OperatingSystem).Version")
    info = f"{cap} / {ver}".strip(" /")
    return OK, f"系统信息: {info or '获取失败'}"


def check_defender():
    """2. Windows Defender 实时防护"""
    out = ps("(Get-MpComputerStatus).RealTimeProtectionEnabled")
    if out == "True":
        return OK, "Defender 实时防护开启"
    if out == "False":
        return CRIT, "Defender 实时防护已关闭！请立即开启（设置→隐私和安全性→Windows 安全中心）"
    return WARN, "无法获取 Defender 状态（可能被第三方杀软接管或系统异常）"


def check_firewall():
    """3. 防火墙三配置文件状态"""
    rows = ps_list("Get-NetFirewallProfile | Select-Object Name,Enabled | Format-Table -HideTableHeaders")
    disabled = []
    for row in rows:
        parts = row.split()
        if len(parts) >= 2:
            name, enabled = parts[0], parts[-1]
            if enabled != "True":
                disabled.append(name)
    if not disabled:
        return OK, "防火墙 域/专用/公用 全部开启"
    return CRIT, f"防火墙已关闭的配置文件: {', '.join(disabled)}（请开启）"


def _blocked_inbound_ports() -> set:
    """已由防火墙入站 Block 规则覆盖的本地 TCP 端口集合（含范围）"""
    out = ps(
        "$ports = @(); "
        "Get-NetFirewallRule -Direction Inbound -Action Block -Enabled True | ForEach-Object { "
        "  $p = $_ | Get-NetFirewallPortFilter; "
        "  if ($p -and $p.Protocol -eq 'TCP' -and $p.LocalPort) { $ports += $p.LocalPort } }; "
        "$ports -join ','"
    )
    result = set()
    for token in re.split(r"[,\s]+", out):
        token = token.strip()
        if token.isdigit():
            result.add(int(token))
        elif "-" in token:
            a, b = token.split("-", 1)
            if a.isdigit() and b.isdigit():
                result.update(range(int(a), int(b) + 1))
    return result


def check_ports():
    """4. 监听端口（重点：对外监听的敏感端口，已考虑防火墙入站拦截）"""
    rows = ps_list(
        "Get-NetTCPConnection -State Listen | "
        "Select-Object -ExpandProperty LocalPort | Sort-Object -Unique"
    )
    if not rows:
        return OK, "未获取到监听端口（可能是权限受限）"
    ports = [int(p) for p in rows if p.isdigit()]
    # 高危端口：RDP/SSH/SMB/远程管理/VNC
    high_risk = {"22", "3389", "445", "139", "5900", "5800", "623", "5985", "5986"}
    # 对外（非仅回环）监听的高危端口
    ext_ips = ps_list(
        "Get-NetTCPConnection -State Listen | "
        "Where-Object { $_.LocalAddress -notin @('127.0.0.1','::1','0.0.0.0','::') -and "
        "$_.LocalPort -in @(22,3389,445,139,5900,5800,5985,5986) } | "
        "Select-Object LocalAddress,LocalPort | Format-Table -HideTableHeaders"
    )
    blocked = _blocked_inbound_ports()
    # 未被防火墙拦截的对外监听
    still_exposed = [ln for ln in ext_ips if ln.split()[-1].isdigit() and int(ln.split()[-1]) not in blocked]
    detail = f"共 {len(ports)} 个监听端口: {', '.join(map(str, sorted(ports)[:15]))}"
    if still_exposed:
        return CRIT, f"高危端口对外监听且未被拦截: {'; '.join(still_exposed)}（如非必需请关闭）"
    if ext_ips:
        return OK, f"高危端口对外监听但已被防火墙入站规则拦截（{len(ext_ips)} 条）；{detail}"
    exposed = sorted(p for p in ports if str(p) in high_risk)
    if exposed:
        return WARN, f"高危端口在监听(仅本机): {', '.join(map(str, exposed))}；{detail}"
    return OK, detail


def check_admins():
    """5. 管理员组成员"""
    rows = ps_list("Get-LocalGroupMember -Group 'Administrators' | Select-Object Name | Format-Table -HideTableHeaders")
    if not rows:
        return WARN, "无法读取管理员组（需要管理员权限）"
    names = [r.split("\\")[-1] for r in rows]
    return OK, f"管理员组成员: {', '.join(names)}（如有非预期账户请移除）"


def check_users():
    """6. 本地账户状态（来宾/管理员禁用情况）"""
    out = ps_list("Get-LocalUser | Select-Object Name,Enabled | Format-Table -HideTableHeaders")
    if not out:
        return WARN, "无法读取本地账户（需要管理员权限）"
    guest_on = any("Guest" in r and r.split()[-1] == "True" for r in out)
    if guest_on:
        return CRIT, f"来宾账户(Guest)已启用！请禁用: Disable-LocalUser -Name Guest"
    return OK, f"本地账户: {', '.join(r.split()[0] for r in out)}（Guest 已禁用/正常）"


def check_lockout():
    """7. 账户锁定阈值（防爆破）"""
    out = ps("net accounts")
    m = re.search(r"Lockout threshold:\s+(\S+)", out, re.IGNORECASE)
    if m and m.group(1).strip().lower() not in ("never", "0", "0次"):
        return OK, f"账户锁定阈值已设置: {m.group(1)} 次"
    if m:
        return WARN, "账户锁定阈值未设置（=0）→ 暴力破解无锁定，建议: net accounts /lockoutthreshold:5"
    return WARN, "无法读取账户锁定策略"


def check_shares():
    """8. 共享目录（非系统默认共享；默认管理共享如 C$/D$ 不计入）"""
    rows = ps_list("Get-SmbShare | Select-Object Name | Format-Table -HideTableHeaders")
    if not rows:
        return OK, "无可枚举的 SMB 共享"
    # 默认共享：管理共享 ADMIN$/IPC$ + 盘符根共享（C$/D$/...）
    default = {"ADMIN$", "IPC$"}
    non_default = [
        r.strip() for r in rows
        if r.strip() and r.strip() not in default and not re.match(r"^[A-Za-z]\$$", r.strip())
    ]
    if non_default:
        return WARN, f"发现非默认共享目录: {', '.join(non_default)}（如非必要请删除: Remove-SmbShare -Name <名>）"
    return OK, "无自定义共享目录"


def check_rdp():
    """9. RDP 远程桌面状态"""
    out = ps("(Get-ItemProperty 'HKLM:\\System\\CurrentControlSet\\Control\\Terminal Server').fDenyTSConnections")
    if out == "0":
        return WARN, "远程桌面(RDP)已开启！如非必要请关闭，或确认仅局域网+强密码"
    return OK, "远程桌面(RDP)未开启"


def check_patch():
    """10. 系统补丁新鲜度"""
    out = ps("Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 -ExpandProperty InstalledOn")
    if not out:
        return WARN, "无法获取最近补丁时间（可能无需补丁或信息受限）"
    return OK, f"最近安装补丁: {out}（建议每月更新一次）"


def check_startup():
    """11. 自启动项（注册表 Run + 启动文件夹）"""
    run_items = ps_list(
        "Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',"
        "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' | "
        "Select-Object -ExpandProperty * -ErrorAction SilentlyContinue | "
        "Where-Object { $_ -is [string] }"
    )
    startup_dir = ps_list("Get-ChildItem $env:APPDATA\\Microsoft\\Windows\\'Start Menu'\\Programs\\Startup -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name")
    total = run_items + startup_dir
    if not total:
        return OK, "未发现注册表 Run 启动项"
    return WARN, f"自启动项 {len(total)} 个: {', '.join(total[:8])}（请确认无可疑程序）"


def check_connections():
    """12. 已建立的外联连接摘要（异常外联检测）"""
    rows = ps_list(
        "Get-NetTCPConnection -State Established | "
        "Where-Object { $_.RemoteAddress -and $_.RemoteAddress -notin @('127.0.0.1','::1','0.0.0.0','::') } | "
        "Select-Object -ExpandProperty RemoteAddress"
    )
    if not rows:
        return OK, "当前无外部已建立连接"
    counter = Counter(rows)
    top = counter.most_common(5)
    # 阈值：同一目标外联过多视为可疑
    hot = [f"{ip}({n})" for ip, n in top if n >= 10]
    detail = "、".join(f"{ip}×{n}" for ip, n in top)
    if hot:
        return CRIT, f"异常高频外联: {', '.join(hot)}（请核查是否有后门/挖矿程序）"
    return OK, f"外部连接 {sum(counter.values())} 条: {detail}"


# ------------------------------------------------------------
# 主流程
# ------------------------------------------------------------

CHECKS = [
    ("system", check_system),
    ("defender", check_defender),
    ("firewall", check_firewall),
    ("ports", check_ports),
    ("admins", check_admins),
    ("users", check_users),
    ("lockout", check_lockout),
    ("shares", check_shares),
    ("rdp", check_rdp),
    ("patch", check_patch),
    ("startup", check_startup),
    ("connections", check_connections),
]


def main():
    parser = argparse.ArgumentParser(description="Lazaxa 电脑安全体检")
    parser.add_argument("--check", help="只看某一项（可选: system/defender/firewall/ports/admins/users/lockout/shares/rdp/patch/startup/connections）")
    parser.add_argument("--server", action="store_true", help="服务器模式（预留：网站上线后启用）")
    args = parser.parse_args()

    # 统一以 UTF-8 输出，保证被工具/守护 capture 时中文不乱码
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass

    if args.server:
        print("🔴 服务器模式尚未启用：请先按 docs/电脑安全防护技术文档.md §6 完成服务器加固清单")
        return 1

    print("=" * 56)
    print("  Lazaxa 电脑安全体检报告")
    print("=" * 56)

    stat = {OK: 0, WARN: 0, CRIT: 0}
    for name, fn in CHECKS:
        if args.check and name != args.check:
            continue
        try:
            level, detail = fn()
        except Exception as e:  # 单项失败不中断整体
            level, detail = WARN, f"检查异常: {e}"
        stat[level] += 1
        print(f"{level} [{name:<12}] {detail}")

    print("=" * 56)
    print(f"汇总: {OK} {stat[OK]} 正常 | {WARN} {stat[WARN]} 注意 | {CRIT} {stat[CRIT]} 紧急")
    if stat[CRIT]:
        print("建议: 立即处理 🔴 紧急项（见 docs/电脑安全防护技术文档.md §4 加固清单）")
    elif stat[WARN]:
        print("建议: 按需处理 ⚠️ 注意项，并保持每月复查")
    else:
        print("建议: 保持现状，每月复查一次")
    return 0 if stat[CRIT] == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
