# -*- coding: utf-8 -*-
"""真屏验收回归基准集 runner（C批3 · GUI 验收基准集）。

把 Lazaxa 历次真屏验收脚本沉淀为"可反复跑"的回归基准：每份脚本自带退出码
契约（0=全过 / 1=断言未过 / 2=环境不可用），runner 负责登记、按需执行、
汇总与统一退出码。这样散落的验收脚本不再是一次性脚本，而是可复跑的基准集。

基准集用例（CASES）：
  - gui-milestones  P3 记事本链路 M1 输入/M2 清空/M3 另存为落盘（引擎感知栈编排，
                    真屏 · 无需后端）── 这是 GUI 回归的核心样板链路
  - agent-approval  审批链路（真实 agent 任务自动拒绝，验证 approval 事件与挂起恢复）
  - agent-office    办公工具链路（真实 agent 调 office_excel_write + run_python_script）
  - agent-publish   自动归档发布（真实 agent 自主 publish_to_lazaxa；会推远程，危险项）

运行方式（SelfIterate 根目录）：
    python scripts/acceptance_suite.py --list          # 列全部基准集
    python scripts/acceptance_suite.py --run gui       # 只跑真屏 GUI 里程碑
    python scripts/acceptance_suite.py --run all-safe  # GUI + agent 非危险项
    python scripts/acceptance_suite.py --run all --danger   # 全部（含推远程的发布项）

约束与退出码：
  - 真屏 GUI 用例必须在真实桌面会话的 PowerShell 运行（见里程碑脚本 docstring）。
  - runner 汇总退出码：0=所选全部 PASS；1=存在 FAIL（断言未过）；
    2=存在环境不可用(SKIP)且无 FAIL（如 OCR/VLM/后端没就绪，需先修环境再复跑）。
  - agent 类用例需要后端已启动（127.0.0.1:8000）且 .env 有 ADMIN_TOKEN；
    后端不在线时脚本自身会立即报环境不可用，runner 归为 SKIP 不误报 FAIL。
"""
import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# 基准集登记（单一事实源：新增验收脚本在此追加一行即可）
# ---------------------------------------------------------------------------
CASES = [
    {
        "name": "gui-milestones",
        "file": "test_agent_gui_milestones.py",
        "group": "gui",
        "danger": False,
        "desc": "P3 记事本链路 M1输入/M2清空/M3另存为落盘（真屏 · 引擎感知栈 · 无需后端）",
        "rc_note": "0=全过 1=断言未过 2=环境不可用(OCR/真屏)",
        "timeout": 600,
    },
    {
        "name": "agent-approval",
        "file": "test_agent_approval.py",
        "group": "agent",
        "danger": False,
        "desc": "审批链路：真实 agent 任务触发 dangerous 工具→监听审批→自动拒绝→循环恢复",
        "rc_note": "0=链路通过（脚本内断言，异常即失败）",
        "timeout": 300,
    },
    {
        "name": "agent-office",
        "file": "test_agent_office.py",
        "group": "agent",
        "danger": False,
        "desc": "办公工具：真实 agent 调 office_excel_write 生成 Excel + run_python_script 读回",
        "rc_note": "0=通过 非0=断言未过/环境问题",
        "timeout": 700,
    },
    {
        "name": "agent-publish",
        "file": "test_agent_publish_e2e.py",
        "group": "agent",
        "danger": True,
        "desc": "自动归档发布：真实 agent 自主 publish_to_lazaxa 推送远程镜像仓库（危险项）",
        "rc_note": "0=通过 非0=断言未过/环境问题",
        "timeout": 700,
    },
]
_BY_NAME = {c["name"]: c for c in CASES}


def case_script(case) -> str:
    """用例脚本绝对路径。"""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), case["file"])


def resolve_names(run: str | None, danger: bool) -> list[str]:
    """把 --run 组名解析为用例名列表（保持 CASES 登记顺序）。

    组：gui / agent / all-safe(=gui+agent 非危险) / all / 任意逗号分隔的用例名。
    """
    if not run:
        return []
    run = run.strip().lower()
    if run == "all":
        out = [c["name"] for c in CASES]
    elif run == "all-safe":
        out = [c["name"] for c in CASES if not c["danger"]]
    elif run == "gui":
        out = [c["name"] for c in CASES if c["group"] == "gui"]
    elif run == "agent":
        out = [c["name"] for c in CASES if c["group"] == "agent"]
    else:
        out = []
        for token in run.split(","):
            token = token.strip()
            if token not in _BY_NAME:
                raise ValueError(f"未知用例: {token}（可用 --list 查看）")
            if token not in out:
                out.append(token)
    # 危险项必须显式 --danger 才放行
    if not danger:
        out = [n for n in out if not _BY_NAME[n]["danger"]]
    return out


def run_case(case, timeout: int | None = None) -> int:
    """子进程执行单个用例，返回退出码（超时视为 3）。"""
    script = case_script(case)
    cmd = [sys.executable, script]
    try:
        proc = subprocess.run(cmd, cwd=ROOT, timeout=timeout or case.get("timeout"))
        return int(proc.returncode)
    except subprocess.TimeoutExpired:
        print(f"    ⚠ 超时（>{timeout or case.get('timeout')}s），已终止")
        return 3
    except Exception as e:  # noqa: BLE001
        print(f"    ✘ 启动失败: {e}")
        return 3


def interpret(code: int) -> str:
    """退出码 → 汇总语义：0 通过 / 2 环境不可用 / 其余失败。"""
    if code == 0:
        return "PASS"
    if code == 2:
        return "SKIP"     # 环境不可用（OCR/真屏/后端未就绪），修环境后复跑
    return "FAIL"         # 断言未过 / 超时 / 启动失败


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="真屏验收回归基准集 runner（C批3）")
    ap.add_argument("--list", action="store_true", help="列出全部基准集用例")
    ap.add_argument("--run", default="", metavar="组/用例名",
                    help="要跑的组(gui|agent|all-safe|all)或逗号分隔的用例名")
    ap.add_argument("--danger", action="store_true",
                    help="显式允许危险项（agent-publish 会推远程）")
    args = ap.parse_args(argv)

    if args.list:
        print(f"基准集共 {len(CASES)} 个用例：")
        for c in CASES:
            danger = "  ⚠危险" if c["danger"] else ""
            print(f"  - {c['name']:16s} [{c['group']}]{danger}\n"
                  f"       {c['desc']}\n       rc: {c['rc_note']}  →  {case_script(c)}")
        return 0

    try:
        names = resolve_names(args.run, args.danger)
    except ValueError as e:
        print(f"✘ {e}")
        return 2
    if not names:
        ap.print_help()
        return 2

    print(f"▶ 验收回归基准集 · 共 {len(names)} 项")
    print("=" * 72)
    results = []
    for name in names:
        case = _BY_NAME[name]
        print(f"\n[{name}] {case['desc']}")
        print(f"    python {os.path.basename(case_script(case))}")
        rc = run_case(case)
        status = interpret(rc)
        results.append((name, status, rc))
        print(f"    → {status} (rc={rc})")
    print("\n" + "=" * 72)
    print("汇总：")
    failed = []
    skipped = []
    for name, status, rc in results:
        mark = {"PASS": "✅", "FAIL": "❌", "SKIP": "⏭"}[status]
        print(f"  {mark} {name:16s} {status} (rc={rc})")
        if status == "FAIL":
            failed.append(name)
        elif status == "SKIP":
            skipped.append(name)
    if failed:
        print(f"\n❌ {len(failed)} 项未过：{', '.join(failed)}（修复后复跑对应用例）")
        return 1
    if skipped:
        print(f"\n⏭ {len(skipped)} 项环境不可用：{', '.join(skipped)}（OCR/VLM/后端就绪后复跑）")
        return 2
    print(f"\n✅ {len(results)}/{len(results)} 全过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
