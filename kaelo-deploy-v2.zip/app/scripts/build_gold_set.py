# -*- coding: utf-8 -*-
"""M2 · gold set 候选生成器：从真实运行轨迹聚合候选任务。

依据《M2-立尺-细化方案.md》：gold set = 真实使用中收集的 30-50 个任务
（task=用户原话 / expected=期望结果 / category=分类），**含失败案例 ≥30%**。

本脚本只做"候选聚合"，不做 expected 草拟定稿（草拟由主智能体离线完成、
用户抽检后定稿 30 条）。聚合口径：
  - 只取 agent_tasks.round_id 非空、有 user_message 的轮次（主对话型 r-* 与
    worker 型 job-* 都算，run_evals 会按轮读取轨迹）；
  - 每轮标注：步数 / 前几工具 / 是否含失败或 deny 步（fail 候选）/ 终态；
  - 输出 data/gold_set_candidates.jsonl，每行一个候选（含给草拟用的信号）。

用法：cd SelfIterate && python scripts/build_gold_set.py [--out data/gold_set_candidates.jsonl]
"""
import argparse
import json
import os
import sys
from collections import Counter, defaultdict

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app import db  # noqa: E402

# 粗分类关键词（给草拟提供信号，非权威）
_CAT_KEYWORDS = [
    ("GUI/桌面操作", ["screen", "gui", "click", "type", "key", "截图", "窗口", "鼠标",
                      "键盘", "ocr", "macro", "打开", "启动", "粘贴", "点击"]),
    ("文件/代码", ["file", "read", "write", "list", "mkdir", "代码", "文件", "目录",
                   "创建", "写", "读", "copy", "move", "删除", "grep", "search_code",
                   "rename"]),
    ("记忆/知识", ["memory", "回忆", "记住", "忘", "knowledge"]),
    ("网络/命令", ["web", "run_command", "install", "下载", "查一下", "搜索"]),
]


def _guess_category(user_message: str, tools: list[str]) -> str:
    """按用户话术+工具名的关键词粗猜分类（只给草拟当提示，可改）。"""
    text = f"{user_message} {' '.join(tools)}"
    for cat, kws in _CAT_KEYWORDS:
        if any(k.lower() in text.lower() for k in kws):
            return cat
    return "问答/其他"


def _collect_rounds() -> list[dict]:
    """agent_tasks 按 round_id 聚合 → 候选轮（含失败信号）。"""
    rows = db._execute(
        "SELECT round_id, user_message, tool_name, tool_args, tool_result, "
        "ok, decision, created_at FROM agent_tasks "
        "WHERE round_id != '' ORDER BY id ASC"
    ) or []
    agg: dict[str, dict] = defaultdict(lambda: {
        "steps": [], "tools": Counter(), "fail_steps": 0, "deny_steps": 0,
        "first_user": "", "created_at": ""})
    for r in rows:
        rid = r["round_id"]
        a = agg[rid]
        a["steps"].append(r)
        a["tools"][r.get("tool_name") or ""] += 1
        if r.get("ok") is False:
            a["fail_steps"] += 1
        if (r.get("decision") or "") == "deny":
            a["deny_steps"] += 1
        if not a["first_user"] and (r.get("user_message") or "").strip():
            a["first_user"] = (r.get("user_message") or "").strip()
        if not a["created_at"]:
            a["created_at"] = str(r.get("created_at") or "")
    out = []
    for rid, a in sorted(agg.items(), key=lambda kv: kv[1]["created_at"]):
        if not a["first_user"]:
            continue  # 无用户原话的轮次无法作 gold task
        tools_top = [t for t, _ in a["tools"].most_common(5)]
        fail_signal = (a["fail_steps"] > 0 or a["deny_steps"] > 0)
        out.append({
            "round_id": rid,
            "task": a["first_user"][:300],          # 用户原话（截断防超长）
            "category": _guess_category(a["first_user"], tools_top),
            "n_steps": len(a["steps"]),
            "tools_top": tools_top,
            "n_fail_steps": a["fail_steps"],
            "n_deny_steps": a["deny_steps"],
            "is_fail_candidate": fail_signal,
            "created_at": a["created_at"],
        })
    return out


def _attach_job_status(cands: list[dict]) -> None:
    """批量查 agent_jobs 终态并回填（worker 型任务可看 status/reply）。"""
    ids = [c["round_id"] for c in cands]
    for i in range(0, len(ids), 200):
        chunk = ids[i:i + 200]
        placeholders = ",".join(["%s"] * len(chunk))
        rows = db._execute(
            f"SELECT round_id, status, reply, error, stop_reason FROM agent_jobs "
            f"WHERE round_id IN ({placeholders})", chunk
        ) or []
        by_rid = {r["round_id"]: r for r in rows}
        for c in cands:
            if c["round_id"] in by_rid:
                j = by_rid[c["round_id"]]
                c["job_status"] = j.get("status") or ""
                c["job_reply"] = (j.get("reply") or "")[:200]
                c["job_stop"] = j.get("stop_reason") or ""


def main() -> int:
    ap = argparse.ArgumentParser(description="gold set 候选生成器（只读 DB）")
    ap.add_argument("--out", default=os.path.join(BASE_DIR, "data",
                                                  "gold_set_candidates.jsonl"))
    ap.add_argument("--min-steps", type=int, default=1,
                    help="最少步数（过滤过短轮次，默认 1）")
    ap.add_argument("--top", type=int, default=0,
                    help="只输出前 N 轮（0=全部，按时间升序）")
    args = ap.parse_args()

    cands = _collect_rounds()
    _attach_job_status(cands)
    cands = [c for c in cands if c["n_steps"] >= args.min_steps]
    if args.top:
        cands = cands[:args.top]

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        for c in cands:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")

    n_fail = sum(1 for c in cands if c.get("is_fail_candidate"))
    by_cat = Counter(c.get("category", "问答/其他") for c in cands)
    print(f"候选总数：{len(cands)}（含失败信号 {n_fail} 条 = "
          f"{n_fail / max(len(cands), 1) * 100:.0f}%）")
    print("分类分布：" + ", ".join(f"{k}={v}" for k, v in by_cat.most_common()))
    print(f"已写入：{args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
