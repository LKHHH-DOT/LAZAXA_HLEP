# -*- coding: utf-8 -*-
"""批量【增量】加书脚本（借 kada 医学库部署经验移植）。

适用：一次性往某个分支源目录（如 data/knowledge/）拷了很多新的 .md/.txt，
      想让它们立刻可检索，又不想触发总库/分支库的"清空全量重建"。

做了什么（全部基于 app/rag.py 现有接口，按文本去重，可重复执行）：
  1) 扫描分支源目录，把【尚未收录】的文件切块，增量加入分支向量库
     （embed=False：先只建 meta + BM25，立即可关键词检索）；
  2) 只给新增块补向量（不重算旧块，不碰已算好的向量）；
  3) sync_master_from_branches() 把新书软拷贝进总库源目录；
  4) 对总库做同样的增量收录 + 增量补向量（不清空、不重建旧块）。

用法（任意位置执行均可，脚本自动定位项目根）：
  python scripts/add_books.py --kb knowledge --dry-run   # 只预览，不写库
  python scripts/add_books.py --kb knowledge             # 正式执行
  python scripts/add_books.py --kb experience

执行后：请重启后端服务（Python 进程），让它重新加载向量库。

注意：
  - 仅识别 UTF-8 的 .md/.txt；PDF/Word/GBK 请先转成 UTF-8 文本。
  - 同名文件默认视为"已收录"而跳过；要更新某本书内容，请走网页"同名上传
    自动替换"，或先在网页/接口删除该来源，再跑本脚本。
  - 补向量需要本机 Ollama 在线；向量不完整时检索会退化为 BM25 兜底，
    可用 /api/health 的 vector_integrity.ok 检查，或单独跑
    python scripts/embed_increment.py <kb> 补齐。
"""
import argparse
import json
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app import config, rag  # noqa: E402
from embed_increment import fill_incremental  # noqa: E402  （同目录，复用补向量逻辑）


def list_new_files(kb_key):
    """返回分支目录中"库里尚无同名来源"的文件 [(name, 块数)]，不写库。"""
    cfg = config.KNOWLEDGE_BASES[kb_key]
    kb_dir = cfg["knowledge_dir"]
    if not os.path.isdir(kb_dir):
        return [], kb_dir, set()
    # 只从 meta.json 读 source 集合，避免加载巨大向量
    meta_path = os.path.join(cfg["vector_dir"], "meta.json")
    existing = set()
    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            existing = {m.get("source", "") for m in json.load(f)}
    todo = []
    for name in sorted(os.listdir(kb_dir)):
        if not name.lower().endswith((".md", ".txt")):
            continue
        p = os.path.join(kb_dir, name)
        if not os.path.isfile(p) or name in existing:
            continue
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            chunks = rag._split_text(f.read())
        if chunks:
            todo.append((name, len(chunks)))
    return todo, kb_dir, existing


def main():
    ap = argparse.ArgumentParser(description="知识库批量增量加书")
    ap.add_argument("--kb", required=True, choices=["knowledge", "experience", "personal"])
    ap.add_argument("--dry-run", action="store_true", help="只预览，不写库")
    ap.add_argument("--batch", type=int, default=500, help="补向量分批大小")
    args = ap.parse_args()

    todo, kb_dir, existing = list_new_files(args.kb)
    print(f"分支 {args.kb} 源目录：{kb_dir}", flush=True)
    print(f"已收录来源 {len(existing)} 个；待新增文件 {len(todo)} 个，"
          f"共约 {sum(c for _, c in todo)} 块。", flush=True)
    for name, cnt in todo:
        print(f"  + {name}  ({cnt} 块)", flush=True)

    if args.dry_run:
        print("\n[dry-run] 未写库。确认无误后去掉 --dry-run 正式执行。", flush=True)
        return
    if not todo:
        print("没有新文件需要收录。", flush=True)
        return

    # 1) 分支库：增量收录（embed=False 先建 BM25），再只补新块向量
    store = rag.get_store(args.kb)
    before = store.size
    rag.build_from_dir(config.KNOWLEDGE_BASES[args.kb]["knowledge_dir"], store, embed=False)
    print(f"[{args.kb}] 收录完成：{before} -> {store.size} 块", flush=True)
    fill_incremental(store, args.kb, batch=args.batch)

    # 2) 同步源文件到总库目录（软拷贝，分支库为真实源）
    synced = rag.sync_master_from_branches()
    print(f"[master] 分支同步：{synced}", flush=True)

    # 3) 总库：多目录增量收录（embed=False），再只补新块向量
    mcfg = config.KNOWLEDGE_BASES["master"]
    mstore = rag.get_store("master")
    mb = mstore.size
    dirs = {b: os.path.join(mcfg["knowledge_dir"], b) for b in mcfg.get("branches", [])}
    rag.build_from_dir_multi(dirs, mstore, embed=False)
    print(f"[master] 收录完成：{mb} -> {mstore.size} 块", flush=True)
    fill_incremental(mstore, "master", batch=args.batch)

    print("\n全部完成。请重启后端服务，让它重新加载向量库。", flush=True)


if __name__ == "__main__":
    main()
