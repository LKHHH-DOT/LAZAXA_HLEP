# -*- coding: utf-8 -*-
"""端到端验收：智能体完成独立项目后是否自动 publish_to_lazaxa 归档。

场景：让智能体从零做一个独立小工具项目（不提示"上传/发布"字样），
观察它完成任务闭环后，是否遵守守则第 14 条【归档自觉】——
主动调用 publish_to_lazaxa 把项目发布到 LAZAXA 仓库。

用法：
  python scripts/test_agent_publish_e2e.py [--auto-approve]

--auto-approve：自动批准所有审批请求（否则需在前端手动审批，脚本挂起等待）。
"""
import argparse
import json
import os
import re
import sys

import requests

BASE = "http://127.0.0.1:8000"


def _admin_token() -> str:
    """从后端 .env 读取管理令牌（与 kb_gui.py 同一来源）。"""
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    try:
        with open(env_path, encoding="utf-8") as f:
            m = re.search(r"^\s*ADMIN_TOKEN\s*=\s*(\S+)\s*$", f.read(), re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    return ""

# 任务描述：要求做出一个独立可交付的项目。
# 刻意不出现"上传/发布/归档/LAZAXA"等词，考验守则第 14 条的自觉性。
TASK = (
    "帮我做一个独立的小工具项目：一个批量重命名图片文件的命令行工具。"
    "要求：1) 用 Python 实现（主脚本 + 简短 README）；"
    "2) 能识别 IMG_1234.JPG 这类文件名，重命名为 YYYY-MM-DD_1234.jpg 格式；"
    "3) 支持 --dry-run 参数：只预览不改名；"
    "4) 把项目完整放在工作区里一个叫 batch_rename 的独立文件夹里。"
    "这是一个可以交付的独立项目，完成后请按你的行为守则处理它的收尾归档。"
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto-approve", action="store_true", help="自动批准所有审批请求")
    args = ap.parse_args()

    print(f"发送任务（等待智能体完成…超时 10 分钟）")
    headers = {"X-Admin-Token": _admin_token()}
    tool_calls: list[str] = []
    approved = 0
    published = False
    with requests.post(f"{BASE}/api/v1/agent", json={"message": TASK},
                       headers=headers, stream=True, timeout=660) as r:
        r.raise_for_status()
        for raw in r.iter_lines(decode_unicode=True):
            if not raw or not raw.startswith("data:"):
                continue
            try:
                ev = json.loads(raw[5:].strip())
            except json.JSONDecodeError:
                continue
            et = ev.get("type")
            if et == "thinking":
                print(f"  [思考] {ev.get('text', '')}")
            elif et == "tool_call":
                name = ev.get("tool", ev.get("name", ""))
                args_s = json.dumps(ev.get("args", {}), ensure_ascii=False)[:120]
                tool_calls.append(name)
                print(f"  [工具] {name} {args_s}")
                if name == "publish_to_lazaxa":
                    published = True
            elif et == "tool_result":
                ok = ev.get("ok", "?")
                brief = ev.get("brief") or str(ev.get("result", ""))[:100]
                print(f"  [结果] ok={ok} {brief}")
            elif et == "approval_request":
                if args.auto_approve:
                    tid = ev.get("task_id")
                    resp = requests.post(
                        f"{BASE}/api/v1/agent/approve",
                        json={"task_id": tid, "approved": True},
                        headers=headers, timeout=15)
                    approved += 1
                    print(f"  [审批] 已自动批准 {ev.get('tool')} (task={tid}) {resp.status_code}")
                else:
                    print(f"  [审批] 等待人工: {ev.get('tool')} task={ev.get('task_id')}")
            elif et == "error":
                print(f"  [错误] {ev.get('message', '')}")
            elif et == "done":
                st = ev.get("stats", {})
                print(f"  [完成] {st}")

    print("\n========== 验收结论 ==========")
    print(f"工具调用序列: {' -> '.join(tool_calls) if tool_calls else '(无)'}")
    print(f"自动审批次数: {approved}")
    if published:
        print("✅ 通过：智能体完成独立项目后主动调用了 publish_to_lazaxa（守则第 14 条生效）")
        return 0
    print("❌ 未通过：智能体未主动调用 publish_to_lazaxa 归档")
    return 1


if __name__ == "__main__":
    sys.exit(main())
