# -*- coding: utf-8 -*-
"""Kaelo 工作区同步 + 云备份脚本（backup_to_cloud 工具的后端实现）。

仓库分工（2026-08-17 用户确定的模型）：
- Kaelo（脚本所在项目）= 更新工作区：日常改代码/加功能都在这，不装 git
- Kaelo1（Kaelo 的兄弟目录）= git 权威仓库：镜像 Kaelo 内容，负责 commit + push

流程（一步到位）：
1. robocopy /MIR 把 Kaelo 镜像到 Kaelo1（排除 .git 与密钥/运行数据目录）
2. 在 Kaelo1 里 git add -A + 二次校验暂存区（文件名或内容命中密钥样式即中止回滚）
3. commit + push 到 GitHub 私有仓库 super-fiesta（SSH Deploy Key，权限最小化）
无改动且无待推送提交时跳过推送（防静默漏推）。

运行方式（任意目录均可，脚本自动定位）：
    python SelfIterate/scripts/backup.py [--message "说明"]
"""
import argparse
import os
import re
import subprocess
import sys
from datetime import datetime

# Kaelo 工作区根（脚本位于 Kaelo/SelfIterate/scripts/，上溯三级）
KAELO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# git 权威备份仓库（Kaelo 的兄弟目录 Kaelo1）
BACKUP_REPO = os.path.join(os.path.dirname(KAELO_ROOT), "Kaelo1")

# robocopy 排除的目录名（密钥/运行数据，永不进备份仓库；.git 是 Kaelo1 自己的版本库）
ROBOCOPY_EXCLUDE = [
    ".git", "data", "version", "storage", "venv", "models",
    "_archive", "__pycache__", "history", "logs", ".venv",
]

# 敏感文件名模式：命中即中止提交（.gitignore 之外的兜底）
SENSITIVE_FILENAME = [
    re.compile(r"(^|[/\\])\.env$"),
    re.compile(r"\.env\.(?!example)"),          # .env.xxx（排除 .env.example）
    re.compile(r"config\.json$"),
    re.compile(r"\.(pem|key|p12|pfx|jks|crt)$"),
    re.compile(r"(^|[/\\])\.ssh[/\\]"),
]

# 敏感内容模式：暂存文本文件内容出现密钥样式即中止（防 agent 把密钥写进普通文件）
# 只保留两类判定，避免误伤普通代码：
#   1. 前缀分支（sk-/ghp_/github_pat_/tvly-/pk-）：主流 API 密钥，引号内同样命中
#   2. 引号分支：敏感键名 + 引号包裹的 8+ 字符串
# 刻意不加"裸值分支"——`token = localStorage` 这类普通标识符会被误判为密钥；
# 无引号裸 token 在代码里几乎不存在，.env 等真实密钥文件已由文件名排除兜底。
# 键名用 (?<![A-Za-z0-9_-]) 前缀 + \b 后缀：避免把 "X-Admin-Token" 的 Token、
# "deepseek_api_key" 的 api_key 这类嵌入标识符误当敏感键。
SENSITIVE_CONTENT = re.compile(
    r"(?:sk-|tvly-|pk-|ghp_|github_pat_)[A-Za-z0-9_\-]{12,}|"
    r"(?<![A-Za-z0-9_-])(?:api_key|apikey|admin_token|secret|token|password)\b\s*[=:]\s*"
    r"['\"]([^'\"]{8,})['\"]",
    re.IGNORECASE)

# 全大写+下划线的"环境变量名"样式（如 DEEPSEEK_API_KEY）不是密钥值，需跳过
VAR_NAME_STYLE = re.compile(r"^[A-Z][A-Z0-9_]{7,}$")

MAX_CONTENT_SCAN_BYTES = 1_000_000   # 只扫描 1MB 以内的文本文件
CONTENT_SCAN_HEAD_BYTES = 64_000     # 每个文件只读头部 64KB


def _run(args: list, cwd: str, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", **kw)


def _load_env() -> None:
    """加载 Kaelo/SelfIterate/.env（仅取 GITHUB_DEPLOY_KEY），供独立运行时使用。"""
    env_path = os.path.join(KAELO_ROOT, "SelfIterate", ".env")
    if not os.path.isfile(env_path):
        return
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip('"'))


def _sensitive_in_file(path: str) -> str | None:
    """扫描单个文本文件内容，命中密钥样式返回命中片段所在行摘要。"""
    if not os.path.isfile(path):
        return None
    if os.path.getsize(path) > MAX_CONTENT_SCAN_BYTES:
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            head = f.read(CONTENT_SCAN_HEAD_BYTES)
    except OSError:
        return None
    # 逐行扫描（密钥不会跨行书写；避免"空值键"跨行误伤下一行普通文本）
    for line in head.splitlines():
        for m in SENSITIVE_CONTENT.finditer(line):
            # 捕获组里的值若是"全大写+下划线"的变量名样式（如 DEEPSEEK_API_KEY）则跳过
            hit = m.group(1) or m.group(2) or m.group(0)
            if VAR_NAME_STYLE.match(hit):
                continue
            return hit
    return None


def _check_staged() -> str | None:
    """二次校验备份仓库暂存区。返回 None=通过；否则返回命中说明。"""
    staged = _run(["git", "diff", "--cached", "--name-only"], BACKUP_REPO).stdout.splitlines()
    for f in staged:
        # 1) 文件名模式
        for pat in SENSITIVE_FILENAME:
            if pat.search(f):
                return f"文件名命中敏感模式 {pat.pattern}: {f}"
        # 2) 文本内容密钥样式（文件存在且非二进制才扫）
        hit = _sensitive_in_file(os.path.join(BACKUP_REPO, f))
        if hit:
            return f"文件内容疑似密钥（{hit}）: {f}"
    return None


def _sync_workspace() -> str | None:
    """robocopy 镜像 Kaelo → Kaelo1（排除密钥/运行数据目录）。返回 None=成功，否则报错。"""
    if not os.path.isdir(KAELO_ROOT):
        return f"工作区不存在: {KAELO_ROOT}"
    os.makedirs(BACKUP_REPO, exist_ok=True)
    cmd = ["robocopy", KAELO_ROOT, BACKUP_REPO, "/MIR",
           "/XD", *ROBOCOPY_EXCLUDE, "/R:0", "/W:0", "/NP", "/NFL", "/NDL"]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    # robocopy 退出码 0-7 均表示成功（1=有复制，3=有复制有额外），>=8 才是失败
    if proc.returncode >= 8:
        return f"同步失败(robocopy exit={proc.returncode})\n{(proc.stdout or '')[-2000:]}"
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Kaelo 工作区同步 + 云备份（镜像 Kaelo1 + commit + push）")
    parser.add_argument("--message", "-m", default="", help="本次备份的说明文字（可选）")
    args = parser.parse_args()
    _load_env()

    # 1. 同步 Kaelo → Kaelo1
    sync_err = _sync_workspace()
    if sync_err:
        print(f"❌ {sync_err}")
        return 1
    print(f"ℹ️  已镜像工作区到备份仓库：{BACKUP_REPO}")

    # 2. 校验备份仓库 git 环境与远端
    if _run(["git", "rev-parse", "--is-inside-work-tree"], BACKUP_REPO).returncode != 0:
        print("❌ Kaelo1 不是 git 仓库（备份仓库未初始化，请先 git init）")
        return 1
    remote = _run(["git", "remote", "get-url", "origin"], BACKUP_REPO).stdout.strip()
    if not remote:
        print("❌ Kaelo1 未配置远端 origin（请先 git remote add origin <仓库地址>）")
        return 1

    # 3. 无改动且无待推送提交 → 跳过（避免"上次推送失败"被静默漏掉）
    has_changes = bool(_run(["git", "status", "--porcelain"], BACKUP_REPO).stdout.strip())
    unpushed = _run(["git", "rev-list", "--count", "HEAD", "--not", "--remotes=origin"],
                    BACKUP_REPO).stdout.strip()
    if not has_changes and unpushed in ("", "0"):
        print("✅ 工作区无改动，无需备份")
        return 0

    # 4. 有改动 → 暂存全部 + 二次校验 + 提交
    if has_changes:
        _run(["git", "add", "-A"], BACKUP_REPO)
        hit = _check_staged()
        if hit:
            _run(["git", "reset", "--quiet"], BACKUP_REPO)
            print(f"❌ 已中止备份：{hit}")
            print("   暂存已回滚，请检查对应文件后重试（确认无敏感信息再备份）")
            return 1
        msg = f"backup: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        if args.message:
            msg += f" · {args.message}"
        commit = _run(["git", "commit", "-m", msg], BACKUP_REPO)
        if commit.returncode != 0:
            print(f"⚠️ 提交失败：{commit.stderr.strip()}")
            return 1

    # 5. 推送（origin 为 SSH 地址 + super-fiesta 专属 Deploy Key，不占用高权限凭据）
    deploy_key = os.environ.get("GITHUB_DEPLOY_KEY") or os.path.join(
        KAELO_ROOT, "SelfIterate", "keys", "lazaxa_deploy_sf")
    env = dict(os.environ)
    if os.path.isfile(deploy_key):
        env["GIT_SSH_COMMAND"] = (
            f'ssh -i "{deploy_key}" -o IdentitiesOnly=yes '
            "-o StrictHostKeyChecking=accept-new -o BatchMode=yes"
        )
    push = _run(["git", "push", "origin", "HEAD"], BACKUP_REPO, env=env)
    if push.returncode != 0:
        print(f"⚠️ 提交成功但推送失败：{push.stderr.strip()}")
        print("   可稍后手动执行：git -C Kaelo1 push origin HEAD")
        return 1
    branch = _run(["git", "branch", "--show-current"], BACKUP_REPO).stdout.strip()
    print(f"✅ 备份完成（已同步 Kaelo1 并推送到 origin/{branch}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
