# -*- coding: utf-8 -*-
"""GUI 自动化验收脚本（批次 C · M2 里程碑）。

完整链路：打开记事本 → 激活窗口 → 输入中文（剪贴板路径）→ 截图 → OCR 复核 → 关闭。

运行方式（SelfIterate 根目录或任意位置均可）：
    python scripts/test_agent_gui.py

注意：脚本会真的操作屏幕（打开/关闭记事本并输入文字），运行前请确认无重要
未保存文档。
"""
import json
import os
import sys
import time

# 把 SelfIterate 根目录加入模块搜索路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.agent.tools.gui import _find_on_screen, _keyboard_type, _screen_capture, _screen_ocr
from app.agent.tools.windows import _open_app, _window_control


def main():
    # ① 打开记事本（自动置前窗口）
    r = _open_app(target="记事本")
    print("① open_app(记事本):", r.ok, r.brief)
    assert r.ok, r.error
    time.sleep(1.5)

    # ② 激活记事本窗口（新版记事本窗口标题为英文 "Notepad"，如"无标题 - Notepad"）
    r = _window_control(title="Notepad", action="activate")
    print("② window_control(activate):", r.ok, r.brief)
    assert r.ok, r.error
    time.sleep(0.8)

    # ③ 输入中文（走剪贴板粘贴 + 前台窗口校验，防 IDE 抢焦点误输入）
    #    再次激活是模拟模型的做法：窗口可能被其他应用抢焦点
    _window_control(title="Notepad", action="activate")
    text = "你好 Lazaxa，GUI 自动化测试 2026-08-16"
    r = _keyboard_type(text=text, window_title="Notepad")
    print("③ keyboard_type:", r.ok, r.brief)
    assert r.ok, r.error
    time.sleep(0.8)

    # ④ 截图保存
    r = _screen_capture()
    print("④ screen_capture:", r.ok, r.brief)
    assert r.ok, r.error

    # ⑤ OCR 复核屏幕上出现输入的文字
    r = _screen_ocr(min_confidence=30)
    if r.ok:
        items = [i["text"] for i in json.loads(r.text)["items"]]
        joined = "".join(items)
        print(f"⑤ OCR 复核: 识别 {len(items)} 块；屏幕含'你好'? {'你好' in joined}；含'Lazaxa'? {'Lazaxa' in joined}")
    else:
        print("⑤ OCR 复核失败:", r.error)

    # ⑥ 关闭记事本
    r = _window_control(title="Notepad", action="close")
    print("⑥ window_control(close):", r.ok, r.brief)
    assert r.ok, r.error

    print("\n=== 验收完成 ===")


if __name__ == "__main__":
    main()
