# -*- coding: utf-8 -*-
"""Lazaxa 全流程验收（2026-08-17 压缩工程落地后）。

A. 服务健康    : Backend 8000 / Qdrant 6333 / Ollama 11434 / Blender-MCP 9876
B. 压缩工程 E2E : 真实 DeepSeek 调用 context.compact_history（超阈值→交接单+归档+保留最近轮）
C. Agent 链路冒烟: POST /api/v1/agent（SSE），验证 loop 主流程未受压缩改动影响
"""
import json
import os
import socket
import sys
import time

sys.path.insert(0, r"D:\Users\Hasee\Desktop\Kaelo\SelfIterate")

import requests

from app import config
from app.agent import context

ARCHIVE_DIR = config.CONTEXT_ARCHIVE_DIR
os.makedirs(ARCHIVE_DIR, exist_ok=True)


def port_alive(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=2):
            return True
    except OSError:
        return False


def check(name: str, ok: bool, detail: str = "") -> bool:
    mark = "✅" if ok else "❌"
    print(f"{mark} {name} {detail}")
    return ok


def main() -> None:
    ok_all = True

    print("=" * 60)
    print("A. 服务健康检查")
    print("=" * 60)
    ok_all &= check("Backend 8000", port_alive(8000))
    ok_all &= check("Qdrant 6333（记忆底座）", port_alive(6333))
    ok_all &= check("Ollama 11434（嵌入）", port_alive(11434))
    ok_all &= check("Blender-MCP 9876", port_alive(9876))

    print()
    print("=" * 60)
    print("B. 压缩工程 E2E（真实 DeepSeek 交接单压缩）")
    print("=" * 60)
    msgs = [{"role": "system", "content": "你是测试助手"}]
    for i in range(120):
        msgs.append({"role": "user",
                     "content": f"第{i}轮问题：请详细说明第 {i} 号数据点的处理步骤。" + "x" * 120})
        msgs.append({"role": "assistant",
                     "content": f"第{i}轮回答：第 {i} 号数据点处理如下……" + "y" * 120})
    chars = context.estimate_chars(msgs)
    print(f"  构造历史: {len(msgs)} 条消息 / 估算 {chars} 字符（阈值 {config.CONTEXT_COMPACT_THRESHOLD}）")
    name = f"flow-{int(time.time())}"
    t0 = time.time()
    out = context.compact_history(msgs, archive_dir=ARCHIVE_DIR, name=name)
    dt = time.time() - t0
    ok_all &= check("触发压缩（返回新列表）", out is not msgs, f"耗时 {dt:.1f}s")
    texts = [str(m.get("content")) for m in out]
    handoff = next((t for t in texts if "交接单" in t), "")
    ok_all &= check("交接单已生成", bool(handoff))
    ok_all &= check("最近 2 轮保留", any("第119轮问题" in t for t in texts))
    ok_all &= check("旧段已移除", not any("第0轮问题" in t for t in texts))
    archives = [f for f in os.listdir(ARCHIVE_DIR) if f.startswith("flow-")]
    ok_all &= check("归档文件已落盘", bool(archives), str(archives))
    print(f"  交接单示例: {handoff[:220]}")

    print()
    print("=" * 60)
    print("C. Agent 链路冒烟（HTTP SSE）")
    print("=" * 60)
    try:
        resp = requests.post(
            "http://127.0.0.1:8000/api/v1/agent",
            headers={"X-Admin-Token": config.ADMIN_TOKEN},
            json={"message": "请用一句话介绍你自己，不要调用工具。",
                  "mode": "relaxed", "max_steps": 5},
            stream=True, timeout=180)
        types: list = []
        reply = ""
        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data:"):
                continue
            try:
                evt = json.loads(line[5:].strip())
            except Exception:
                continue
            types.append(evt.get("type"))
            if evt.get("type") == "token":
                reply += evt.get("text", "")
            if evt.get("type") == "done":
                break
        ok_all &= check("SSE 事件流完整", "done" in types, f"事件序: {types}")
        ok_all &= check("有回复", bool(reply.strip()), f"回复: {reply[:80]}")
    except Exception as e:
        ok_all &= check("Agent 请求", False, str(e))

    print()
    print("=" * 60)
    print(f"全流程验收: {'✅ 全部通过' if ok_all else '❌ 存在失败项'}")
    print("=" * 60)
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
