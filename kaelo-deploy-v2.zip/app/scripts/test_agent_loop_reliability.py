# -*- coding: utf-8 -*-
"""端到端验收：循环可靠性护栏（P2 · 借 DeerFlow loop_detection 轻量版）。

场景 A（确定性）：让智能体直接回答、不调用工具 → SSE done 事件与审计
  摘要必须携带 stop_reason="completed"（P2 前 done 没有该字段）。

场景 B（循环诱饵）：命令智能体"原样重复调用 run_command echo hi 多次"。
  P2 的循环熔断应在同指纹重复达阈值后先软警告、仍重复则 loop_capped 硬停
  （partial output 保留）。真实大模型行为不完全确定（可能中途自动收敛），
  故 B 只要求 stop_reason 落在合法枚举内并打印熔断是否生效，供人工复核。

用法：
  python scripts/test_agent_loop_reliability.py [--auto-approve]
"""
import argparse
import json
import os
import re
import sys

import requests

BASE = "http://127.0.0.1:8000"
VALID_STOPS = {"completed", "error", "max_steps", "loop_capped",
               "empty_response", "cancelled", "timeout"}


def _admin_token() -> str:
    """从后端 .env 读取管理令牌（与 kb_gui.py 同一来源）。"""
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    try:
        with open(env_path, encoding="utf-8") as f:
            m = re.search(r"^\s*ADMIN_TOKEN\s*=\s*(\S+)\s*$", f.read(), re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    return ""


def _run_task(headers, task: str, tag: str, auto_approve: bool,
              timeout: float = 300) -> dict:
    """跑一次任务，返回 {stop_reason, warns, calls, reply}。"""
    warns = 0
    calls: list[str] = []
    stop_reason = ""
    reply = ""
    print(f"\n---------- [{tag}] 发送任务 ----------")
    print(task)
    with requests.post(f"{BASE}/api/v1/agent", json={"message": task},
                       headers=headers, stream=True,
                       timeout=timeout + 60) as r:
        r.raise_for_status()
        for raw in r.iter_lines(decode_unicode=True):
            if not raw or not raw.startswith("data:"):
                continue
            try:
                ev = json.loads(raw[5:].strip())
            except json.JSONDecodeError:
                continue
            et = ev.get("type")
            if et == "thinking":
                note = ev.get("note", ev.get("text", ""))
                if "重复调用" in note:
                    warns += 1
                print(f"  [思考] {note}")
            elif et == "tool_call":
                name = ev.get("tool", ev.get("name", ""))
                args_s = json.dumps(ev.get("args", {}), ensure_ascii=False)[:100]
                calls.append(name)
                print(f"  [工具] {name} {args_s}")
                if auto_approve and ev.get("task_id"):
                    requests.post(f"{BASE}/api/v1/agent/approve",
                                  json={"task_id": ev["task_id"], "approved": True},
                                  headers=headers, timeout=15)
            elif et == "tool_result":
                ok = ev.get("ok", "?")
                brief = ev.get("brief") or str(ev.get("result", ""))[:100]
                print(f"  [结果] ok={ok} {brief}")
            elif et == "error":
                print(f"  [错误] {ev.get('message', '')}")
            elif et == "done":
                stop_reason = ev.get("stop_reason", "")
                reply = ev.get("reply", "")
                print(f"  [完成] stop_reason={stop_reason} steps={ev.get('steps')}")
    return {"stop_reason": stop_reason, "warns": warns, "calls": calls,
            "reply": (reply or "")[:200]}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto-approve", action="store_true", help="自动批准所有审批请求")
    args = ap.parse_args()
    headers = {"X-Admin-Token": _admin_token()}
    if not headers["X-Admin-Token"]:
        print("❌ 读不到 ADMIN_TOKEN（.env），拒绝执行")
        return 2

    # 场景 A：确定性——直接回答，不调工具 → 必须 completed
    a = _run_task(headers, "不用调用任何工具，用一句话自我介绍。",
                  "A·直接回答", args.auto_approve)
    ok_a = (a["stop_reason"] == "completed")
    print(f"\n========== 场景 A 结论 ==========")
    print(f"stop_reason={a['stop_reason']}（期望 completed）→ "
          f"{'✅ 通过' if ok_a else '❌ 失败'}")

    # 场景 B：循环诱饵——命令反复调用同一工具同参数
    b_task = ("请连续调用 run_command 工具 5 次，每次参数完全相同："
              "{'command': 'echo hi'}。不要解释、不要改用其他工具，"
              "5 次全部调完后再用一句话收尾。")
    b = _run_task(headers, b_task, "B·循环诱饵", args.auto_approve)
    print(f"\n========== 场景 B 结论 ==========")
    print(f"stop_reason={b['stop_reason']}（合法枚举={b['stop_reason'] in VALID_STOPS}）")
    print(f"循环软警告次数={b['warns']}；工具调用序列={b['calls']}")
    if b["stop_reason"] == "loop_capped":
        print("✅ 熔断生效：同指纹重复调用被 loop_capped 截停")
    elif b["stop_reason"] == "completed":
        print("ℹ️ 大模型中途自行收敛（未到熔断阈值）——护栏未误伤，可接受")
    else:
        print(f"ℹ️ 以 {b['stop_reason']} 结束（非法枚举时为失败）")
    ok_b = b["stop_reason"] in VALID_STOPS

    print("\n========== 验收结论 ==========")
    if ok_a and ok_b:
        print("✅ P2 真链路通过：stop_reason 已透传到 SSE done；熔断逻辑在线")
        return 0
    print("❌ 未通过：见上方分项结论")
    return 1


if __name__ == "__main__":
    sys.exit(main())
