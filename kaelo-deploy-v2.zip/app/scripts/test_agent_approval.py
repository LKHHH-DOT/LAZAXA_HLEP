# -*- coding: utf-8 -*-
"""M0 验收脚本 2：验证审批链路。

发一个会触发 dangerous 工具（run_command）的任务，
脚本监听到 approval_request 后自动拒绝（approved=false），
验证：审批事件推送 → 挂起 → 应答 → 循环恢复。
"""
import json
import threading
import time
import urllib.request

BASE = "http://127.0.0.1:8000"
done = threading.Event()
approved_events = []


def approve(task_id, approved):
    body = json.dumps({"task_id": task_id, "approved": approved}).encode("utf-8")
    req = urllib.request.Request(
        f"{BASE}/api/v1/agent/approve", data=body,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        print("[approve]", r.read().decode("utf-8"))


def run_task():
    body = json.dumps({
        "message": "用 run_command 工具执行命令 echo Lazaxa测试，把输出告诉我",
        "max_steps": 5,
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{BASE}/api/v1/agent", data=body,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as resp:
        for line in resp:
            line = line.decode("utf-8", errors="replace").strip()
            if not line.startswith("data:"):
                continue
            evt = json.loads(line[5:])
            t = evt.get("type")
            print(f"[evt] {t}: {json.dumps({k: v for k, v in evt.items() if k != 'type'}, ensure_ascii=False)[:200]}")
            if t == "approval_request":
                approved_events.append(evt)
                # 自动拒绝（危险操作，测试链路即可）
                threading.Thread(target=approve, args=(evt["task_id"], False), daemon=True).start()
            if t == "done":
                done.set()
                print("\n=== 最终回复 ===\n", evt.get("reply", ""))


threading.Thread(target=run_task, daemon=True).start()
done.wait(timeout=180)
print("\n审批事件数:", len(approved_events))
