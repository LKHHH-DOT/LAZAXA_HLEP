# -*- coding: utf-8 -*-
"""长期记忆预灌脚本（幂等，可重复执行）。

数据源：
  - data/personal/*.md 个人档案   → type=memory,  tags=["档案"],        source="[档案] 文件名"
  - PROJECT.md 决策/约束/教训/规范 → type=experience, tags=[分类],       source="[项目经验] 分类"
  - Sanctum 搭建经验               → type=experience, tags=["Sanctum"], source="[项目经验] Sanctum"

幂等策略：每个 source 先删后灌，重复执行不产生重复记忆。
用法：cd SelfIterate && python scripts/seed_memory.py
"""
import os
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app.agent.registry import registry  # 触发 agent 包初始化（自动注册全部工具）
from app.rag import _split_text

PERSONAL_DIR = os.path.join(BASE_DIR, "data", "personal")
CHUNK_MAX_LEN = 150   # 与知识库 RAG 分块粒度一致
CHUNK_OVERLAP = 30

# ---- PROJECT.md 精选条目（决策/约束/教训/规范，显式维护保证质量） ----
PROJECT_ENTRIES = [
    ("[项目经验] 决策", "决策", [
        "不集成官方 deepseek-harness，直接自研 Agent 框架（官方为开发者预览版，规避破坏性变更与 Node 技术栈风险）",
        "harness 插件无法单独抽取（与 Cordis 框架深度耦合），改为读源码学设计、用 Python 重写",
        "GUI 自动化移植 AIPC 而非自研（已是纯 Python 且链路验证过，避免重复造轮子）",
        "开工前先做全知识整合，防止做大项目时丢上下文、忘记目标",
    ]),
    ("[项目经验] 硬约束", "约束", [
        "语音输入热键必须 Alt+Q（开关式：按一下开始录音，再按发送）",
        "模拟的 Ctrl+Win 键退出时必须释放，防止系统按键卡死",
        "语音录音窗口必须是标准系统窗口（带标题栏），不能无边框透明",
        "TTS 朗读必须有可开关按钮（关=🔇 蓝 / 开=🔊 绿），状态存 config.json",
    ]),
    ("[项目经验] 教训", "教训", [
        "旧 Python 进程不关会占用端口/热键，改代码必须重启进程",
        "热键用 Space 键会导致微信输入法忽略模拟按键",
        "按住热键录音会触发录音提前结束",
        "Alt 键热键可能干扰系统快捷键",
        "PowerShell 发 JSON 转义易错，测试脚本用 Python urllib 写",
    ]),
    ("[项目经验] 工程规范", "规范", [
        "命令执行：UTF-8 固定、超时杀进程树、64KB 尾部截断、危险命令黑名单",
        "文件写入：先写 .bak 备份",
        "工具返回统一走 ToolResult，不裸抛异常",
        "pip 安装一律用国内镜像源",
    ]),
    ("[项目经验] Sanctum", "Sanctum", [
        "Qdrant 配置文件按相对 CWD 自动加载（config/development.yaml），必须从 qdrant/ 目录内启动 qdrant.exe 配置才生效",
        "huggingface_hub 新版默认走 Xet 协议，hf-mirror 镜像不支持（401），需设 HF_HUB_DISABLE_XET=1 走传统 HTTP",
        "agent 执行环境下 Start-Process 启动的子进程会随命令结束被杀，长期服务需用户自行双击 bat 启动",
    ]),
]


def seed_source(source: str, texts, mtype: str, tags):
    """按 source 幂等灌入：先删旧，再写入全部文本。返回 (写入数, 失败数)。"""
    r = registry.execute("memory_delete", {"source": source})
    if not r.ok:
        print(f"  [清理旧数据失败] {source}: {r.error}")
        return 0, 0
    ok_n = fail_n = 0
    for text in texts:
        r = registry.execute("memory_add", {
            "text": text, "type": mtype, "tags": tags, "source": source,
        })
        if r.ok:
            ok_n += 1
        else:
            fail_n += 1
            if fail_n <= 3:
                print(f"  [写入失败] {r.error}")
    return ok_n, fail_n


def main():
    t0 = time.time()
    total_ok = total_fail = 0

    # ---- 1. 个人档案预灌 ----
    print("=" * 56)
    print("[1/2] 个人档案预灌:", PERSONAL_DIR)
    files = sorted(f for f in os.listdir(PERSONAL_DIR) if f.lower().endswith(".md"))
    print(f"      发现 {len(files)} 份档案")
    for fname in files:
        path = os.path.join(PERSONAL_DIR, fname)
        source = f"[档案] {fname}"
        with open(path, encoding="utf-8") as f:
            raw = f.read()
        chunks = _split_text(raw, max_len=CHUNK_MAX_LEN, overlap=CHUNK_OVERLAP)
        ok_n, fail_n = seed_source(source, chunks, "memory", ["档案"])
        total_ok += ok_n
        total_fail += fail_n
        print(f"  {fname}: {len(chunks)} 块 -> 写入 {ok_n}, 失败 {fail_n}")

    # ---- 2. 项目经验预灌 ----
    print("=" * 56)
    print("[2/2] 项目经验预灌（决策/约束/教训/规范/Sanctum）")
    for source, tag, entries in PROJECT_ENTRIES:
        ok_n, fail_n = seed_source(source, entries, "experience", [tag])
        total_ok += ok_n
        total_fail += fail_n
        print(f"  {tag}: {len(entries)} 条 -> 写入 {ok_n}, 失败 {fail_n}")

    # ---- 3. 统计 ----
    print("=" * 56)
    print(f"预灌完成：共写入 {total_ok} 条，失败 {total_fail} 条，耗时 {time.time() - t0:.0f}s")
    r = registry.execute("memory_search", {"query": "我的技术栈是什么", "top_k": 3})
    print("\n抽验检索'我的技术栈是什么':")
    print(r.text if r.ok else r.error)


if __name__ == "__main__":
    main()
