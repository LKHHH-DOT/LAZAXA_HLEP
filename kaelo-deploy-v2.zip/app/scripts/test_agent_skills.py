# -*- coding: utf-8 -*-
"""技能体系验收脚本（批次 E1 · 真实 agent 链路）。

验证：系统提示技能目录注入 → 模型自主调 use_skill 按需加载正文 → 按技能说明作答。
只读场景（safe，无审批），无副作用。

运行方式（SelfIterate 根目录）：
    python scripts/test_agent_skills.py
"""
import json
import os
import sys
import urllib.request

AGENT_URL = "http://127.0.0.1:8000/api/v1/agent"


def load_token():
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def main():
    token = load_token()
    if not token:
        print("❌ 未找到 ADMIN_TOKEN（.env）")
        sys.exit(1)
    message = (
        "请查看你的技能库：\n"
        "1. 系统提示里列出了哪些可用技能？\n"
        "2. 加载 file-organizer 技能（use_skill），用 3 句话说明这个技能会怎么做文件整理。"
    )
    payload = {"message": message, "mode": "relaxed"}
    req = urllib.request.Request(
        AGENT_URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    print("→ 发送任务:", message[:50], "…")

    tool_calls = []
    reply = ""
    with urllib.request.urlopen(req, timeout=660) as resp:
        chunk = ""
        while True:
            line = resp.readline()
            if not line:
                break
            chunk += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in chunk:
                block, chunk = chunk.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    try:
                        evt = json.loads(raw)
                    except Exception:
                        continue
                    t = evt.get("type")
                    if t == "tool_call":
                        tool_calls.append(evt.get("name") or evt.get("display_name"))
                        print(f"  🔧 {evt.get('display_name') or evt.get('name')}"
                              f"({json.dumps(evt.get('args', {}), ensure_ascii=False)[:50]})")
                    elif t == "tool_result":
                        print(f"  {'✔' if evt.get('ok') else '✘'} {evt.get('brief') or evt.get('error')}")
                    elif t == "error":
                        print("  ⚠️", evt.get("message"))
                    elif t == "done":
                        reply = evt.get("reply", "")
                        print(f"  ✅ done（{evt.get('steps')} 步 · {evt.get('ms')}ms）")

    print("\n=== 结果 ===")
    print("调用的工具:", tool_calls)
    print("模型回复:", reply[:300])
    assert reply, "模型未返回有效回复"
    assert "use_skill" in [str(n) for n in tool_calls], f"模型未调用 use_skill，实际: {tool_calls}"
    assert "file-organizer" in reply, "回复未体现技能内容"
    print("\n✅ 技能体系验收通过（目录注入 → use_skill 加载 → 按技能作答）")


if __name__ == "__main__":
    main()
