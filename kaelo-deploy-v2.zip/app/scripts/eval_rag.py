# -*- coding: utf-8 -*-
"""RAG 回归评测：跑金标问题的检索命中率（阶段 3 专业化核心）。

用法（项目根目录）：
    python scripts/eval_rag.py            # 默认读 data/golden_questions.json，top_k=5
    python scripts/eval_rag.py --top-k 10 # 自定义 top_k

判定规则：检索结果来源（source）包含 expected 任一关键词即算命中。
统计 top-1 / top-k 命中率，供改动检索/切块/embedding 参数前后对比。
依赖：本地向量库已构建（Ollama + embedding 模型在线）。
"""
import argparse
import json
import os
import sys

# 保证可从项目根目录直接运行
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import config  # noqa: E402
from app.state import _get_store  # noqa: E402


def _hit(sources: list[str], expected: list[str]) -> bool:
    """命中判定：任一检索来源包含 expected 任一关键词（子串匹配，忽略分支前缀）。"""
    for src in sources:
        for kw in expected:
            if kw in src:
                return True
    return False


def main():
    ap = argparse.ArgumentParser(description="RAG 金标回归评测")
    ap.add_argument("--golden", default="data/golden_questions.json", help="金标文件路径")
    ap.add_argument("--top-k", type=int, default=5, help="检索候选数（命中判定窗口）")
    args = ap.parse_args()

    with open(args.golden, "r", encoding="utf-8") as f:
        golden = json.load(f)
    questions = golden["questions"]
    print(f"=== RAG 回归评测：{len(questions)} 题，top_k={args.top_k} ===")
    print(f"embedding: {config.EMBED_MODEL}  backend: {config.CHAT_BACKEND}\n")

    top1_hit = topk_hit = 0
    print(f"{'#':>2} {'命中':>2} 库         预期来源 / 实际来源")
    for idx, item in enumerate(questions, start=1):
        store = _get_store(item["kb"])
        hits = store.search(item["q"], top_k=args.top_k)
        sources = [h["source"] for h in hits]
        h1 = _hit(sources[:1], item["expected"])
        hk = _hit(sources, item["expected"])
        top1_hit += h1
        topk_hit += hk
        actual = sources[0] if sources else "(无命中)"
        mark = "✓" if hk else "✗"
        print(f"{idx:>2} {mark:>2}  {item['kb']:<10} 预期={item['expected'][0]} 实际={actual}")

    n = len(questions)
    print(f"\n=== 汇总 ===")
    print(f"top-1 命中率: {top1_hit}/{n} = {top1_hit / n * 100:.1f}%")
    print(f"top-{args.top_k} 命中率: {topk_hit}/{n} = {topk_hit / n * 100:.1f}%")


if __name__ == "__main__":
    main()
