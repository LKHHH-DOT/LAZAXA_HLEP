#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lazaxa 环境配置体检脚本（B批2 · config doctor）
===============================================
定位：开机/排障时一键显式报告"环境配置与服务"健康度，并支持一键修复。
- 零第三方依赖（socket 探测 + 文件读写），风格对齐 scripts/security_check.py
- 输出分级：✅ 正常 / ⚠️ 注意（建议处理）/ 🔴 紧急（error，需处理）
- 用法：
    python scripts/config_doctor.py             # 体检报告
    python scripts/config_doctor.py --fix       # 体检 + 一键补齐 .env 缺失键
    python scripts/config_doctor.py --skill-check   # 只看技能目录健康（B批2）
- 退出码：0=无 error；1=存在 error 级问题

检查项：
  A. .env 与 .env.example 模板对照（缺失键 🔴 / 配置类空值 ⚠️ / 密钥留空仅提示）
  B. 关键服务连通（socket 2s）：Ollama(嵌入/RAG) · Qdrant(记忆) · 后端自检
  C. 技能目录健康（复用 app.agent.skills.validate_skills，error 级 🔴）
  D. 关键目录可写/存在（SKILLS_DIR / data / archives / 桌面临时目录）

--fix 只做安全的一键修复：把 .env.example 存在但 .env 缺失的键追加到 .env
（沿用模板值，密钥保持空值待填），绝不改动/覆盖 .env 已有内容。
"""

import argparse
import hashlib
import os
import socket
import sys
import tempfile
import time
from datetime import datetime

OK, WARN, CRIT = "✅", "⚠️", "🔴"

# 脚本位于 SelfIterate/scripts/，上一级即项目根（.env 所在）
ENV_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_PATH = os.path.join(ENV_DIR, ".env")
EXAMPLE_PATH = os.path.join(ENV_DIR, ".env.example")

# socket 探测统一超时（秒）
PROBE_TIMEOUT = 2


# ------------------------------------------------------------
# A. .env 模板对照
# ------------------------------------------------------------

def parse_dotenv(text: str) -> dict:
    """解析 dotenv 文本 → {KEY: value}（仅 KEY=VALUE 行，忽略注释与空行）。"""
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k:
            out[k] = v
    return out


def load_env_file(path: str) -> dict:
    """容错读 .env 类文件 → dict；文件缺失返回 {}。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return parse_dotenv(f.read())
    except OSError:
        return {}


def diff_env(example: dict, actual: dict) -> list[dict]:
    """对照 example 与 actual，返回分级问题（不含 info 级"密钥留空"之外的多余键）。

    - error: example 存在但 actual 缺失（缺行）
    - warning: example 该键模板值非空（配置类：URL/路径），actual 却为空串
    - info:   example 该键模板值为空（密钥类，本身可空/留待填）
    返回 [{"key", "level", "msg", "template"}, ...]（只含非正常项；正常键不入列）。
    """
    issues = []
    for key, tpl in example.items():
        if key not in actual:
            issues.append({"key": key, "level": "error",
                           "msg": f"缺失键 {key}（.env 中无该行，可运行 --fix 补齐）",
                           "template": tpl})
        elif actual[key] == "":
            if tpl:
                issues.append({"key": key, "level": "warning",
                               "msg": f"{key} 为空但模板有默认值（{tpl}），运行可能异常",
                               "template": tpl})
            else:
                issues.append({"key": key, "level": "info",
                               "msg": f"{key} 未配置（密钥留空，按需填写）",
                               "template": tpl})
    return issues


def fix_env(example_path: str, env_path: str) -> list[str]:
    """把 example 有而 .env 缺的键追加到 .env（保留已有内容），返回补写的键名列表。

    追加行沿用模板值（密钥类模板值为空 → 写 KEY= 待填）。追加块带时间注释。
    """
    example = load_env_file(example_path)
    actual = load_env_file(env_path)
    missing = [k for k in example if k not in actual]
    if not missing:
        return []
    os.makedirs(os.path.dirname(env_path), exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    with open(env_path, "a", encoding="utf-8") as f:
        f.write(f"\n# ---- config doctor 补齐缺失键（{stamp}，勿覆盖上方手填值）----\n")
        for k in missing:
            f.write(f"{k}={example[k]}\n")
    return missing


def _fix_env_safely() -> list[str] | None:
    """--fix 执行体：跨进程文件锁（app.fs_lock）串行化补键，防双终端并发写 .env。

    锁文件放系统临时目录（文件名哈希自 .env 路径），不污染工作区；
    app 导入失败或锁不可用时降级为直接修复（单机手动场景极少并发）。
    返回补写键名列表；被锁占用（另一实例正在 --fix）返回 None。
    """
    try:
        if ENV_DIR not in sys.path:
            sys.path.insert(0, ENV_DIR)
        from app import fs_lock
    except Exception:  # noqa: BLE001
        return fix_env(EXAMPLE_PATH, ENV_PATH)
    lock_path = os.path.join(
        tempfile.gettempdir(),
        "lazaxa_envfix_" + hashlib.md5(ENV_PATH.encode("utf-8")).hexdigest() + ".lock")
    try:
        with fs_lock.acquire_lock(lock_path, timeout=5):
            return fix_env(EXAMPLE_PATH, ENV_PATH)
    except TimeoutError:
        print("\n🔒 已有另一个 config doctor --fix 正在运行（.env 修复锁被占用），"
              "本次跳过补键，稍后重试。")
        return None


# ------------------------------------------------------------
# B. 服务连通探测
# ------------------------------------------------------------

def probe(host: str, port: int) -> bool:
    """socket 探测 host:port 是否可达（2s 超时）。"""
    try:
        with socket.create_connection((host, port), timeout=PROBE_TIMEOUT):
            return True
    except OSError:
        return False


def parse_host_port(url: str, default_port: int) -> tuple[str, int]:
    """从 http://host:port 形式 URL 取 (host, port)；解析失败回退默认。"""
    try:
        from urllib.parse import urlparse
        u = urlparse(url)
        host = u.hostname or "127.0.0.1"
        port = u.port or default_port
        return host, port
    except Exception:
        return "127.0.0.1", default_port


def check_services() -> list[dict]:
    """B. 关键服务连通（不 import app 避免副作用，端口从 .env 原文读）。"""
    out = []
    env = load_env_file(ENV_PATH)
    # Ollama（bge-m3 嵌入 / RAG）
    ollama = env.get("OLLAMA_HOST", "http://localhost:11434")
    h, p = parse_host_port(ollama, 11434)
    ok = probe(h, p)
    out.append({"key": "ollama", "level": OK if ok else CRIT,
                "msg": f"Ollama {h}:{p} {'可达（嵌入/RAG 可用）' if ok else '不可达！RAG/嵌入静默降级，请启动 ollama serve'}"})
    # Qdrant（Sanctum 长期记忆）
    ok = probe("127.0.0.1", 6333)
    out.append({"key": "qdrant", "level": OK if ok else CRIT,
                "msg": f"Qdrant 127.0.0.1:6333 {'可达（记忆检索可用）' if ok else '不可达！长期记忆检索将失败，请启动 Sanctum/qdrant/start_qdrant.bat'}"})
    # 后端自检（8000；未启动属正常，仅提示，不算 error——可能用户还没起）
    ok = probe("127.0.0.1", 8000)
    out.append({"key": "backend", "level": OK if ok else WARN,
                "msg": f"Lazaxa 后端 127.0.0.1:8000 {'可达' if ok else '未启动（运行 uvicorn 或 重启Lazaxa服务.bat 后自愈）'}"})
    return out


# ------------------------------------------------------------
# C. 技能目录健康 + D. 关键目录
# ------------------------------------------------------------

def check_skills() -> dict:
    """C. 技能 frontmatter 校验（B批2：复用 app.agent.skills.validate_skills）。"""
    try:
        if ENV_DIR not in sys.path:
            sys.path.insert(0, ENV_DIR)
        from app.agent import skills as agent_skills
        return agent_skills.validate_skills()
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "total": 0,
                "issues": [{"name": "<import>", "level": "error",
                            "msg": f"无法加载 app.agent.skills：{e}"}]}


def check_dirs() -> list[dict]:
    """D. 关键目录存在性（缺失 → 🔴，涉及写入/清理依赖）。"""
    checks = []
    env = load_env_file(ENV_PATH)
    # 桌面临时目录（config 默认 Desktop/LazaxaTemp；.env 覆盖则用覆盖值）
    temp = env.get("AGENT_TEMP_DIR", os.path.join(os.path.expanduser("~"),
                                                  "Desktop", "LazaxaTemp"))
    for label, path in (("桌面临时目录 AGENT_TEMP_DIR", temp),
                        ("技能目录 Kaelo/skills", os.path.join(os.path.dirname(ENV_DIR), "skills")),
                        ("数据目录 data", os.path.join(ENV_DIR, "data"))):
        ok = os.path.isdir(path)
        checks.append({"key": label, "level": OK if ok else CRIT,
                       "msg": f"{label}: {path} {'存在' if ok else '缺失（首次启动会自动创建；不存在则相关功能不可用）'}"})
    return checks


# ------------------------------------------------------------
# 主流程
# ------------------------------------------------------------

def run_report(include_env: bool = True, include_skills: bool = True,
               include_services: bool = True, include_dirs: bool = True) -> int:
    """执行体检并打印分级报告；返回退出码（0=无 error）。"""
    rows: list[dict] = []
    if include_env:
        ex = load_env_file(EXAMPLE_PATH)
        if not ex:
            rows.append({"level": CRIT, "msg": f".env.example 缺失或为空: {EXAMPLE_PATH}"})
        else:
            actual = load_env_file(ENV_PATH)
            if not actual:
                rows.append({"level": CRIT,
                             "msg": f".env 缺失或为空（可运行 --fix 从模板补齐）: {ENV_PATH}"})
            for it in diff_env(ex, actual):
                rows.append({"level": CRIT if it["level"] == "error" else
                             (WARN if it["level"] == "warning" else "ℹ️"),
                             "msg": it["msg"]})
    if include_services:
        rows += [{"level": s["level"], "msg": s["msg"]} for s in check_services()]
    if include_dirs:
        rows += [{"level": s["level"], "msg": s["msg"]} for s in check_dirs()]
    if include_skills:
        rep = check_skills()
        rows.append({"level": OK, "msg": f"技能目录共 {rep['total']} 个 .md，问题 {len(rep['issues'])} 条"
                    if rep["total"] else "技能目录为空（无可注入技能）"})
        for it in rep["issues"]:
            rows.append({"level": CRIT if it["level"] == "error" else
                         (WARN if it["level"] == "warning" else "ℹ️"),
                         "msg": f"[技能 {it['name']}] {it['msg']}"})

    for row in rows:
        print(f"{row['level']} {row['msg']}")
    has_error = any(r["level"] == CRIT for r in rows)
    summary = ("发现紧急问题" if has_error
               else ("发现注意项" if any(r["level"] == WARN for r in rows) else "一切正常"))
    print(f"\n结果：{summary}（共 {len(rows)} 项检查）")
    return 1 if has_error else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Lazaxa 环境配置体检（config doctor）")
    ap.add_argument("--fix", action="store_true",
                    help="体检后一键补齐 .env 缺失键（不覆盖已有内容）")
    ap.add_argument("--skill-check", action="store_true",
                    help="只做技能目录健康校验（B批2）")
    args = ap.parse_args(argv)

    if args.skill_check:
        rep = check_skills()
        for it in rep["issues"]:
            lv = CRIT if it["level"] == "error" else (WARN if it["level"] == "warning" else "ℹ️")
            print(f"{lv} [{it['name']}] {it['msg']}")
        print(f"\n技能目录共 {rep['total']} 个 .md；ok={rep['ok']}")
        return 0 if rep["ok"] else 1

    code = run_report()
    if args.fix:
        fixed = _fix_env_safely()
        if fixed is None:
            return code  # 修复锁被另一实例占用（已在上面打印提示）
        if fixed:
            print(f"\n🔧 --fix 已把缺失键补写进 .env：{', '.join(fixed)}")
            print("   请重启后端进程使新键生效。")
        else:
            print("\n🔧 --fix 无需补键（.env 与模板一致）")
    return code


if __name__ == "__main__":
    sys.exit(main())
