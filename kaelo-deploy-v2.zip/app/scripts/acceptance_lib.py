# -*- coding: utf-8 -*-
"""GUI 验收基准集 · VLM judge 工具库（C批3）。

用途：给"真屏验收脚本"提供可复用的语义层判断——用本地视觉模型（gemma3:4b，
与 screen_describe 同栈）对截图做"是/否题"复核。真屏脚本用 OCR 找不到/存疑时，
交给 VLM 看图复述，任一感知层确认即通过（多层感知互补，不卡死单点）。

设计对齐：
  - 温度低（temperature=0.2 / top_p=0.9 / num_predict 有界），输出短结论
  - fail-open：模型不在/不可用 → available=False，调用方自行降级，不抛异常
  - 与 app/agent/tools/gui.py 的 _vlm_describe_image 同参数口径，但零 GUI 依赖
    （纯 requests，验收脚本可独立于工具栈运行）

用法：
    from acceptance_lib import vlm_ask, vlm_judge, ollama_alive
    judge = vlm_judge("shot.png", "这是什么窗口？标题文字是什么？", must_contain="记事本")
"""
import base64
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def _ollama_host() -> str:
    """Ollama 地址：优先 app.config（读 .env OLLAMA_HOST），失败退回 11434。"""
    try:
        from app import config as c
        return c.OLLAMA_HOST
    except Exception:  # noqa: BLE001
        return os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")


def _post_json(url: str, payload: dict, timeout: int):
    """薄封装 requests.post（独立函数便于测试 monkeypatch）。"""
    import requests
    return requests.post(url, json=payload, timeout=timeout)


def ollama_alive(timeout: int = 3) -> bool:
    """Ollama 服务是否在线（/api/tags 可达）。"""
    try:
        r = _post_json(f"{_ollama_host()}/api/tags", {}, timeout)
        return r.status_code == 200
    except Exception:  # noqa: BLE001
        return False


def vlm_ask(image_path: str, prompt: str,
            model: str | None = None, timeout: int = 120) -> str | None:
    """让本地 VLM 看一张截图回答问题，返回简短结论；模型不可用返回 None。

    与 screen_describe 同一套纪律：低温、限长、要求直接中文结论。
    """
    if not image_path or not os.path.isfile(image_path):
        return None
    if not model:
        try:
            from app import config as c
            model = c.VLM_MODEL
        except Exception:  # noqa: BLE001
            model = os.environ.get("VLM_MODEL", "gemma3:4b")
    try:
        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        payload = {
            "model": model,
            "prompt": (prompt + "\n直接简短中文结论，≤80字，看不到就说「无法确认」，绝不编造。"),
            "images": [b64],
            "stream": False,
            "options": {"temperature": 0.2, "top_p": 0.9, "num_predict": 200},
        }
        r = _post_json(f"{_ollama_host()}/api/generate", payload, timeout)
        if r.status_code != 200:
            return None
        text = (r.json() or {}).get("response", "") or ""
        return re.sub(r"\s+", " ", text).strip()[:600] or None
    except Exception:  # noqa: BLE001
        return None


def vlm_judge(image_path: str, prompt: str, must_contain: str,
              model: str | None = None, timeout: int = 120) -> dict:
    """VLM 是/否题判定：verdict 命中 must_contain → passed。

    返回 {"available": bool, "verdict": str|None, "passed": bool}。
    available=False 表示模型不可用/图片缺失——调用方应降级（OCR/人工），
    不要因为 VLM 缺席就把验收判失败。
    """
    verdict = vlm_ask(image_path, prompt, model=model, timeout=timeout)
    if verdict is None:
        return {"available": False, "verdict": None, "passed": False}
    kw = (must_contain or "").strip().lower()
    return {"available": True, "verdict": verdict,
            "passed": bool(kw) and kw in verdict.lower()}
