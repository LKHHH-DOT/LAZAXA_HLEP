# -*- coding: utf-8 -*-
"""记忆体系四项功能实测脚本（M3 · agent 模式）。

场景：
  1. 知识库向量检索 —— 智能体用 kb_query 搜知识库（master/experience 等）
  2. 长期记忆检索 —— 智能体用 memory_search 查长期记忆
  3. 经验积累（自动沉淀）—— 说"记住……"触发 auto_sink_message 落库，
     随后再问相关内容验证记忆已生效（注入或检索）
  4. 项目积累 —— kb_query 查 experience/knowledge 库

运行方式（SelfIterate 根目录，后端已启动）：
    python scripts/test_memory_features.py
"""
import json
import os
import sys
import time
import urllib.request

# 保证 import app.xxx 可用（脚本运行时 sys.path[0] 是 scripts/，需手动挂项目根）
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

AGENT_URL = "http://127.0.0.1:8000/api/v1/agent"
SINK_TEXT = "我安装 Python 依赖时喜欢用国内的镜像源，这样可以加快下载速度"


def load_token():
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def agent(message: str, mode: str = "relaxed"):
    """发一条 agent 任务，返回 (工具调用名列表, 回复)。"""
    token = load_token()
    payload = {"message": message, "mode": mode}
    req = urllib.request.Request(
        AGENT_URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    tools, reply = [], ""
    with urllib.request.urlopen(req, timeout=660) as resp:
        chunk = ""
        while True:
            line = resp.readline()
            if not line:
                break
            chunk += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in chunk:
                block, chunk = chunk.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    try:
                        evt = json.loads(raw)
                    except Exception:
                        continue
                    t = evt.get("type")
                    if t == "tool_call":
                        name = evt.get("name")
                        tools.append(name)
                        print(f"     🔧 {evt.get('display_name') or name}"
                              f"({json.dumps(evt.get('args', {}), ensure_ascii=False)[:70]})")
                    elif t == "tool_result":
                        print(f"     {'✔' if evt.get('ok') else '✘'} {evt.get('brief') or evt.get('error')}")
                    elif t == "error":
                        print("     ⚠️", evt.get("message"))
                    elif t == "done":
                        reply = evt.get("reply", "")
                        print(f"     ✅ done（{evt.get('steps')} 步）")
    return tools, reply


def qdrant_sink_count():
    """查询 Qdrant 中 source=[自动记忆] 的条数（验证自动沉淀落库）。"""
    from qdrant_client import QdrantClient
    from qdrant_client.models import FieldCondition, Filter, MatchValue
    from app import config as _cfg

    client = QdrantClient(url=_cfg.SANCTUM_QDRANT_URL)
    r = client.count(
        collection_name=_cfg.SANCTUM_COLLECTION,
        count_filter=Filter(must=[FieldCondition(
            key="source", match=MatchValue(value="[自动记忆] 对话"))]),
        exact=True,
    )
    return r.count


def main():
    token = load_token()
    assert token, "未找到 ADMIN_TOKEN（.env）"

    print("=" * 60)
    print("① 知识库向量检索：智能体是否会主动搜知识库")
    tools1, reply1 = agent("我的知识库（master 库）里有没有关于我技术栈或项目的资料？"
                           "请用知识库检索工具查一下并简要说明。")
    assert "kb_query" in tools1, f"未调用 kb_query，实际工具: {tools1}"
    print("   ✅ 智能体会主动向量检索知识库")

    print("=" * 60)
    print("② 长期记忆检索：智能体主动查记忆")
    tools2, reply2 = agent("你还记得关于我的长期记忆吗（例如偏好、经验）？"
                           "请用记忆检索工具查一下并告诉我你记得什么。")
    assert "memory_search" in tools2, f"未调用 memory_search，实际工具: {tools2}"
    print("   ✅ 智能体会主动检索长期记忆")

    print("=" * 60)
    print("③ 经验积累：说『记住……』触发自动沉淀")
    tools3, reply3 = agent(f"帮我记住一件事：{SINK_TEXT}。")
    time.sleep(4)  # 自动沉淀为后台线程，等待落库
    n = qdrant_sink_count()
    print(f"   Qdrant 中 [自动记忆] 条数: {n}")
    assert n >= 1, "自动沉淀未落库"
    print("   ✅ 自动沉淀已落库")

    print("-" * 40)
    print("   ③-续 验证记忆已生效：再问相关内容")
    tools4, reply4 = agent("我装 Python 包一般用什么源？")
    hit = any(k in reply4 for k in ("镜像", "清华", "源", "国内"))
    print(f"   回复片段: {reply4[:100]}")
    assert hit or "memory_search" in tools4, f"记忆未生效: {reply4[:100]}"
    print("   ✅ 沉淀的记忆在后续对话中生效（注入或检索）")

    print("=" * 60)
    print("④ 项目积累：查 experience/knowledge 库（经验与知识）")
    tools5, reply5 = agent("请用知识库检索查一下 experience 经验库里的内容，"
                           "有没有关于项目经验或踩坑教训的条目？")
    assert "kb_query" in tools5, f"未调用 kb_query，实际工具: {tools5}"
    print("   ✅ 经验/知识库可检索（项目积累链路通）")

    print("=" * 60)
    print("全部通过 ✅")


if __name__ == "__main__":
    main()
