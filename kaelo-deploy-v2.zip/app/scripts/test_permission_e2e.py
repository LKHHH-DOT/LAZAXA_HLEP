# -*- coding: utf-8 -*-
"""三级权限体系验收脚本（权限-6 · E2E）。

覆盖：
  1. agent_tasks 表已含 mode/decision 列（迁移检查）
  2. locked 模式：系统目录访问被权限拒绝（protected-path deny）
  3. locked 模式：白名单只读工具（kb_query 等）可放行

运行方式：python scripts/test_permission_e2e.py
（需后端已在 127.0.0.1:8000 运行）
"""
import json
import os
import sys
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)


def _admin_token() -> str:
    """读取后端 .env 的 ADMIN_TOKEN。"""
    env_path = os.path.join(BASE, ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip().startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def _agent(message: str, mode: str) -> list:
    """发一次 agent 请求，返回 (type, payload) 事件列表（只留关键事件）。"""
    token = _admin_token()
    body = json.dumps({"message": message, "mode": mode}).encode("utf-8")
    req = urllib.request.Request(
        "http://127.0.0.1:8000/api/v1/agent", data=body,
        headers={"Content-Type": "application/json", "X-Admin-Token": token})
    out = []
    with urllib.request.urlopen(req, timeout=180) as resp:
        for line in resp:
            s = line.decode("utf-8", "ignore").strip()
            if not s.startswith("data:"):
                continue
            try:
                d = json.loads(s[5:].strip())
            except Exception:
                continue
            if d.get("type") in ("tool_call", "tool_result", "error", "done"):
                out.append(d)
    return out


def main():
    # 1. 迁移检查：agent_tasks 是否已有 mode/decision 列
    from app.db import list_agent_tasks
    rows = list_agent_tasks(1) or []
    print("① agent_tasks 查询 OK，最近记录数:", len(list_agent_tasks(50)))
    if rows:
        print("   字段含 mode/decision:", "mode" in rows[0] and "decision" in rows[0])

    # 2. locked 模式：写操作 → 应被 deny（不弹窗）
    print("\n② locked 模式请求『write_file 在桌面建文件』…")
    evts = _agent("用 write_file 工具在桌面上创建一个名为 perm_test.txt 的文件，内容是 test", "locked")
    denied = any(e["type"] == "tool_result" and "权限拒绝" in str(e)
                 for e in evts)
    print("   产生工具调用数:", sum(1 for e in evts if e["type"] == "tool_call"))
    print("   被权限策略拒绝:", denied)

    # 3. 权限决策矩阵对照（不依赖模型行为，纯单元级验证）
    print("\n③ 权限决策矩阵（单元级对照）:")
    from app.agent.permissions import decide
    for m, r, t, a in [
        ("standard", "safe", "kb_query", {}),
        ("standard", "sensitive", "write_file", {"path": r"D:\x\a.txt"}),
        ("standard", "dangerous", "run_command", {"command": "dir"}),
        ("relaxed", "sensitive", "write_file", {"path": r"D:\x\a.txt"}),
        ("relaxed", "dangerous", "run_command", {"command": "Remove-Item -Recurse -Force C:\\tmp"}),
        ("locked", "sensitive", "write_file", {"path": r"D:\x\a.txt"}),
        ("locked", "safe", "kb_query", {}),
        ("standard", "safe", "write_file", {"path": r"C:\Windows\system32\x"}),
    ]:
        print("   %-9s %-10s %-14s -> %s" % (m, r, t, decide(m, r, t, a)))

    print("\n=== 权限验收完成 ===")


if __name__ == "__main__":
    main()
