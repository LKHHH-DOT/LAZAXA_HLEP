# -*- coding: utf-8 -*-
"""向量库【增量】补齐脚本（借 kada 医学库部署经验移植）。

用途：加了少量新资料（或总库处于"只有 BM25、没有向量"的状态）后，只给
"还没有向量的块"补算 embedding，不动已经算好的旧块——几分钟完成，
而不是全量重建。

原理（安全前提）：VecStore.add() 总是把新块 append 到 meta 尾部，
因此缺向量的块一定在现有向量之后，可从 len(vectors) 开始补，
补完要求 len(vectors) == len(meta)。

用法（在项目根目录或任意位置执行）：
  python scripts/embed_increment.py knowledge
  python scripts/embed_increment.py master
  python scripts/embed_increment.py master --batch 500

注意：
  - 需要本机 Ollama 在线（嵌入走 Ollama bge-m3）。
  - 若输出"向量数 > 块数"等异常，说明 meta 被缩减过，请删掉该库
    data/vector_store_<kb>/ 下的 vectors.npy 与 meta.json 让服务全量重建。
  - 向量不完整时检索会退化为"部分块只有 BM25"（见 /api/health 的
    vector_integrity.ok=false），补完即恢复语义检索。
"""
import argparse
import os
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

import numpy as np  # noqa: E402

from app import rag  # noqa: E402


def fill_incremental(store, label, batch=500):
    """只给尾部缺向量的块补 embedding（分批落盘，中断可续）。"""
    n = store.size
    v0 = 0 if store.vectors is None else len(store.vectors)
    print(f"[{label}] 块数={n}  已有向量={v0}", flush=True)

    if v0 == n:
        print(f"[{label}] 向量已完整，无需补齐。", flush=True)
        return 0
    if v0 > n:
        print(f"[{label}] 异常：向量数({v0}) > 块数({n})，meta 可能被缩减；"
              f"请删除该库向量文件让服务全量重建。", flush=True)
        sys.exit(2)

    missing = n - v0
    print(f"[{label}] 需补 {missing} 个新块，开始增量嵌入（Ollama bge-m3，分批落盘）...",
          flush=True)
    base = store.vectors
    new_parts = []
    t0 = time.time()

    for start in range(v0, n, batch):
        texts = [m["text"] for m in store.meta[start:start + batch]]
        new_parts.append(np.asarray(rag._embed(texts), dtype=np.float32))
        done = min(start + batch, n)
        # 每 5 批或到末尾落盘一次（旧向量 + 已完成新向量），中断不丢进度
        if len(new_parts) % 5 == 0 or done == n:
            parts = ([base] if base is not None else []) + new_parts
            store.vectors = np.vstack(parts).astype(np.float32)
            store.save()
            print(f"[{label}] 已补 {done}/{n}（+{done - v0}），"
                  f"用时 {(time.time() - t0) / 60:.1f} min，已落盘", flush=True)

    parts = ([base] if base is not None else []) + new_parts
    store.vectors = np.vstack(parts).astype(np.float32)
    store.save()
    final = 0 if store.vectors is None else len(store.vectors)
    if final != n:
        print(f"[{label}] ★结果异常：向量 {final} != 块数 {n}，请检查后重跑。", flush=True)
        sys.exit(3)
    print(f"[{label}] 完成：向量 {final} == 块数 {n}，语义检索已恢复，"
          f"总用时 {(time.time() - t0) / 60:.1f} min。", flush=True)
    print(f"[{label}] 提示：若服务正在运行，请重启后端使其重新加载向量库。", flush=True)
    return missing


def main():
    ap = argparse.ArgumentParser(description="向量库增量补齐")
    ap.add_argument("kb", nargs="?", default="knowledge",
                    help="知识库 key：knowledge / master / experience / personal")
    ap.add_argument("--batch", type=int, default=500)
    args = ap.parse_args()

    store = rag.get_store(args.kb)
    fill_incremental(store, args.kb, batch=args.batch)


if __name__ == "__main__":
    main()
