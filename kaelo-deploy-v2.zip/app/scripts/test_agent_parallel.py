# -*- coding: utf-8 -*-
"""并行子代理验收脚本（批次 E2 后期 · 真实 agent 链路）。

场景：主代理用 subagent_parallel 一次并行委派两个独立子任务（互译），
两个子代理并发执行，主代理汇总两路结果回复。全程 relaxed 模式
（subagent_parallel 为 sensitive，relaxed 自动放行，一次审批免弹窗）。

验证：subagent_parallel_start/end 事件、两个 subagent_start/end（index 0/1）、
汇总文本含两路译文。

运行方式（SelfIterate 根目录）：
    python scripts/test_agent_parallel.py
"""
import json
import os
import sys
import urllib.request

AGENT_URL = "http://127.0.0.1:8000/api/v1/agent"


def load_token():
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def main():
    token = load_token()
    if not token:
        print("❌ 未找到 ADMIN_TOKEN（.env）")
        sys.exit(1)
    message = (
        "请用 subagent_parallel 并行委派两个子代理：\n"
        "任务1：把『今天天气很好，我们去公园散步吧』翻译成英文。\n"
        "任务2：把『The sun rises in the east and sets in the west.』翻译成中文。\n"
        "两个子代理直接给出译文即可，然后你把两路结果汇总回复给我。"
    )
    payload = {"message": message, "mode": "relaxed"}
    req = urllib.request.Request(
        AGENT_URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    print("→ 发送任务:", message[:50], "…")

    events = []
    reply = ""
    with urllib.request.urlopen(req, timeout=660) as resp:
        chunk = ""
        while True:
            line = resp.readline()
            if not line:
                break
            chunk += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in chunk:
                block, chunk = chunk.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    try:
                        evt = json.loads(raw)
                    except Exception:
                        continue
                    events.append(evt)
                    t = evt.get("type")
                    if t == "tool_call":
                        print(f"  🔧 {evt.get('display_name') or evt.get('name')}")
                    elif t == "subagent_parallel_start":
                        print(f"  🧩 并行开始 count={evt.get('count')} depth={evt.get('depth')}")
                    elif t == "subagent_start":
                        print(f"  🧩   →#{evt.get('index')} {evt.get('task')[:36]}")
                    elif t == "subagent_end":
                        print(f"  🧩   ←#{evt.get('index')} stop={evt.get('stop_reason')} "
                              f"steps={evt.get('steps')} ms={evt.get('ms')}")
                    elif t == "subagent_parallel_end":
                        print(f"  🧩 并行结束 count={evt.get('count')} ms={evt.get('ms')}")
                    elif t == "error":
                        print("  ⚠️", evt.get("message"))
                    elif t == "done":
                        reply = evt.get("reply", "")
                        print(f"  ✅ done（{evt.get('steps')} 步）")

    print("\n=== 结果 ===")
    types = [e.get("type") for e in events]
    print("事件序列:", types)
    print("模型回复:", reply[:400])
    assert "subagent_parallel_start" in types and "subagent_parallel_end" in types, \
        f"缺少并行事件，实际: {types}"
    starts = [e for e in events if e.get("type") == "subagent_start"]
    ends = [e for e in events if e.get("type") == "subagent_end"]
    assert len(starts) == 2 and len(ends) == 2, f"并行子代理数量不对: {len(starts)}/{len(ends)}"
    assert all(e.get("stop_reason") == "completed" for e in ends), \
        f"存在未完成的子代理: {[e.get('stop_reason') for e in ends]}"
    assert sorted(e.get("index") for e in starts) == [0, 1]
    assert reply and ("today" in reply.lower() or "sun" in reply.lower() or "公园" in reply or "太阳" in reply), \
        f"回复未体现两路译文: {reply[:150]}"
    print("\n✅ 并行子代理链路验收通过（一次审批 → 并发执行 2 路 → 汇总回填）")


if __name__ == "__main__":
    main()
