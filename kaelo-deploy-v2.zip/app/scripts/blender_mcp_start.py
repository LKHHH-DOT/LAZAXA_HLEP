# -*- coding: utf-8 -*-
"""Blender MCP 服务一键启动脚本（Lazaxa 电脑工具之一）。

用法：
    "D:\\Allapp\\blender\\blender.exe" --python SelfIterate\\scripts\\blender_mcp_start.py

功能：
    1. 启用 blender_mcp_harvey 插件（harveyxiacn/blender-mcp，359 工具）
    2. 在 9876 端口启动 MCP Socket 服务，供 blender-mcp server 驱动
    3. 顺带停用旧版同名插件（blender_mcp_addon），避免启动告警

注意：
    - 必须用 GUI 模式启动（不带 --background）：background 模式 Blender 主循环
      不 tick bpy.app.timers，插件命令会全部超时。
    - Blender 窗口保持打开期间，Lazaxa 可通过 mcp 桥接调用 3D 建模工具。
    - 窗口可最小化；不用时直接关闭 Blender 即可。
"""
import os
import sys

import bpy

STATE_FILE = os.path.join(os.environ.get("TEMP", "."), "blender_mcp_state.txt")


def main() -> None:
    # 1) 停用旧版同名插件（用户偏好里残留的注册名，加载会报 No module named）
    old = "blender_mcp_addon"
    if old in bpy.context.preferences.addons:
        try:
            bpy.ops.preferences.addon_disable(module=old)
            print(f"[MCP] disabled legacy addon: {old}")
        except Exception as e:
            print(f"[MCP] disable legacy addon failed (ignored): {e}")

    # 2) 启用 MCP 插件（harvey 版）
    mod = "blender_mcp_harvey"
    if mod not in bpy.context.preferences.addons:
        bpy.ops.preferences.addon_enable(module=mod)
    print(f"[MCP] addon enabled: {mod in bpy.context.preferences.addons}")

    # 3) 启动 9876 服务
    try:
        import blender_mcp_harvey.server as s

        if not s.is_running():
            ok = s.start_server(port=9876)
            print(f"[MCP] start_server(9876) -> {ok}")
        else:
            ok = True
            print("[MCP] server already running")
    except Exception as e:
        print(f"[MCP] failed to start server: {e}")
        ok = False

    # 4) 写状态文件供外部确认
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            f.write(f"started={ok}\n")
        print(f"[MCP] state written: {STATE_FILE}")
    except OSError as e:
        print(f"[MCP] state write failed (ignored): {e}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[MCP] startup script error: {exc}", file=sys.stderr)
        sys.exit(1)
