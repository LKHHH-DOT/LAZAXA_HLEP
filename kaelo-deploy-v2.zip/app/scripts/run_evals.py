# -*- coding: utf-8 -*-
"""M2 · run_evals：离线 LLM-as-Judge 评估 gold set，输出报告。

口径（用户 2026-09 拍板）：
  - 首轮**纯离线 judge 历史轨迹**：零重放、零屏幕操作、零重跑真实任务，
    只读 DB 轨迹 + 调 DeepSeek judge；
  - gold set 来源 data/gold_set.jsonl（30 条，含失败案例 ≥30%）；
  - judge 结果缓存 data/eval_cache.jsonl（同轨迹不重复调 API，--no-cache 可绕过）。

用法：
  python scripts/run_evals.py --list                    # 列出 gold 条目
  python scripts/run_evals.py --baseline                # 全量 judge + 写报告（默认动作）
  python scripts/run_evals.py --one <round_id>          # 单条 judge 详情
  python scripts/run_evals.py --baseline --no-cache     # 忽略缓存重判
"""
import argparse
import json
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app import evals  # noqa: E402

DEFAULT_GOLD = os.path.join(BASE_DIR, "data", "gold_set.jsonl")
DEFAULT_OUT = os.path.join(BASE_DIR, "data", "eval_baseline.md")


def load_gold(path: str = DEFAULT_GOLD) -> list[dict]:
    """读 gold_set.jsonl → [{id, task, category, expected, source_round_id}]。"""
    items = []
    if not os.path.isfile(path):
        print(f"[gold] 找不到文件：{path}")
        return items
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                it = json.loads(line)
            except Exception as e:
                print(f"[gold] 跳过坏行：{e}")
                continue
            it.setdefault("expected", "")
            it.setdefault("category", "")
            items.append(it)
    return items


def judge_gold(items: list[dict], use_cache: bool = True,
               llm_call=None, only: str = "") -> list[dict]:
    """逐条补轨迹 + judge。返回与原列表同序、附 score/trajectory 的 items。"""
    judged = []
    for it in items:
        if only and it.get("source_round_id") != only:
            judged.append(it)
            continue
        traj = evals.load_trajectory(it.get("source_round_id") or "")
        it["trajectory"] = traj
        if traj is None:
            # 无轨迹：判不可判（score.judge_error=True，报告会归入不可判清单）
            it["score"] = {"judge_error": True, "no_trajectory": True,
                           "reply_missing": True, "dims": {},
                           "any_fail": False, "pass_all": False, "n_na": 0}
        else:
            it["score"] = evals.judge_one(
                traj, expected=it.get("expected", ""),
                llm_call=llm_call, use_cache=use_cache)
        judged.append(it)
    return judged


def write_report(items: list[dict], out_path: str = DEFAULT_OUT) -> None:
    md = evals.render_report(items)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(md + "\n")
    judged = [it for it in items
              if it.get("score") and not it["score"].get("judge_error")]
    n_pass = sum(1 for it in judged if it["score"].get("pass_all"))
    print(f"[report] 已写入：{out_path}")
    print(f"[report] 可判 {len(judged)} / {len(items)}，通过 "
          f"{n_pass}（详见报告头部）")


def main() -> int:
    ap = argparse.ArgumentParser(description="M2 离线评估 CLI")
    ap.add_argument("--list", action="store_true", help="只列出 gold 条目")
    ap.add_argument("--baseline", action="store_true", help="全量 judge 并写报告")
    ap.add_argument("--one", metavar="ROUND_ID", default="",
                    help="只 judge 指定 round_id")
    ap.add_argument("--no-cache", action="store_true", help="忽略 judge 缓存")
    ap.add_argument("--gold", default=DEFAULT_GOLD, help="gold 文件路径")
    ap.add_argument("--out", default=DEFAULT_OUT, help="报告输出路径")
    args = ap.parse_args()

    items = load_gold(args.gold)
    if not items:
        print("gold set 为空，退出")
        return 2

    use_cache = not args.no_cache

    if args.list:
        for it in items:
            print(f"- [{it.get('category', '')}] {it.get('source_round_id')} "
                  f"{it.get('task', '')[:60]}")
        return 0

    # 动作优先级：--list > --one > --baseline（默认）
    if args.one:
        judged = judge_gold(items, use_cache=use_cache, only=args.one)
        it = next((x for x in judged if x.get("source_round_id") == args.one), None)
        if it is None or not it.get("trajectory"):
            print(f"round {args.one} 无轨迹或不在 gold 集")
            return 1
        print(json.dumps(it["score"], ensure_ascii=False, indent=2))
        return 0

    judged = judge_gold(items, use_cache=use_cache)
    write_report(judged, args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
