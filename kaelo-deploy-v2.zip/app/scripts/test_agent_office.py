# -*- coding: utf-8 -*-
"""办公工具验收脚本（批次 D · M4 办公里程碑）。

真实 agent 链路（POST /api/v1/agent SSE）：让模型自主调用 office_excel_write /
run_python_script 完成"生成 Excel 报表并读取打印"任务；审批请求自动通过
（模拟用户在弹窗点允许，验证 dangerous 工具审批链路）。

运行方式（SelfIterate 根目录）：
    python scripts/test_agent_office.py
"""
import json
import os
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"
AGENT_URL = BASE + "/api/v1/agent"
APPROVE_URL = BASE + "/api/v1/agent/approve"


def load_token():
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def approve(task_id, approved=True):
    token = load_token()
    data = json.dumps({"task_id": task_id, "approved": approved}).encode("utf-8")
    req = urllib.request.Request(
        APPROVE_URL, data=data,
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    with urllib.request.urlopen(req, timeout=30) as resp:
        resp.read()
    print(f"    ↳ 审批 {task_id} → {'允许' if approved else '拒绝'}")


def main():
    token = load_token()
    if not token:
        print("❌ 未找到 ADMIN_TOKEN（.env）")
        sys.exit(1)
    # 工作目录放工作区（仓库）内：工作区白名单要求文件类工具只能在仓库内操作
    workdir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "data", "agent_tests")
    os.makedirs(workdir, exist_ok=True)
    xlsx = os.path.join(workdir, "成绩单.xlsx")
    print(f"工作目录: {workdir}")

    message = (
        f"请完成一个小任务：\n"
        f"1. 用办公工具在 {xlsx} 生成一个 Excel 表格，"
        f"表头为【姓名、语文、数学】，数据两行：张三 90 85、李四 88 92。\n"
        f"2. 然后用 Python 脚本读取这个 Excel 并 print 出每一行内容。"
    )
    payload = {"message": message, "mode": "relaxed"}
    req = urllib.request.Request(
        AGENT_URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    print("→ 发送任务:", message[:60], "…")

    tool_calls = []
    reply = ""
    with urllib.request.urlopen(req, timeout=660) as resp:
        chunk = ""
        while True:
            line = resp.readline()
            if not line:
                break
            chunk += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in chunk:
                block, chunk = chunk.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    try:
                        evt = json.loads(raw)
                    except Exception:
                        continue
                    t = evt.get("type")
                    if t == "tool_call":
                        tool_calls.append(evt.get("name") or evt.get("display_name"))
                        print(f"  🔧 {evt.get('display_name') or evt.get('name')}"
                              f"({json.dumps(evt.get('args', {}), ensure_ascii=False)[:60]})")
                    elif t == "tool_result":
                        ok = evt.get("ok")
                        print(f"  {'✔' if ok else '✘'} {evt.get('brief') or evt.get('error')}")
                    elif t == "approval_request":
                        print(f"  ⏳ 审批请求: {evt.get('tool')}")
                        approve(evt.get("task_id"))
                    elif t == "error":
                        print("  ⚠️", evt.get("message"))
                    elif t == "done":
                        reply = evt.get("reply", "")
                        print(f"  ✅ done（{evt.get('steps')} 步 · {evt.get('ms')}ms）")

    print("\n=== 结果 ===")
    print("调用的工具:", tool_calls)
    print("模型回复:", (reply or "")[:200])
    assert reply, "模型未返回有效回复"
    names = [str(n) for n in tool_calls]
    assert any("office_excel" in n or "run_python_script" in n for n in names), \
        f"模型未调用办公/脚本工具，实际: {names}"
    # 脚本执行成功，文件应已生成
    assert os.path.exists(xlsx), f"Excel 未生成: {xlsx}"
    print(f"\n✅ 验收通过（Excel 已生成: {xlsx}，文件 {os.path.getsize(xlsx)} 字节）")
    print("（测试文件保留在工作目录，如需清理可手动删除）")


if __name__ == "__main__":
    main()
