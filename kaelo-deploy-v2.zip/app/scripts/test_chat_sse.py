# -*- coding: utf-8 -*-
"""/api/chat SSE 迁移验收脚本（阶段 2 遗留收尾 · M5）。

验证三点：
  ① 响应是 SSE 事件流（data: {json}），事件序列为 meta → token* → done
  ② 会话模型对齐：同一 session_id 两次请求归组到同一会话
  ③ 前端依赖字段齐全（query_used / sources / session_id / kb）
运行：python scripts/test_chat_sse.py（需后端已启动）
"""
import json
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"


def post_chat(message, session_id=None):
    """POST /api/chat，逐事件解析 SSE，返回 (events, session_id)。"""
    payload = {"message": message, "kb": "master"}
    if session_id:
        payload["session_id"] = session_id
    req = urllib.request.Request(
        BASE + "/api/chat",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"})
    events = []
    with urllib.request.urlopen(req, timeout=120) as resp:
        assert resp.headers.get("Content-Type", "").startswith("text/event-stream"), \
            "响应不是 SSE：%s" % resp.headers.get("Content-Type")
        buf = ""
        while True:
            line = resp.readline()
            if not line:
                break
            buf += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in buf:
                block, buf = buf.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    events.append(json.loads(raw))
    sid = None
    for evt in events:
        if evt.get("session_id"):
            sid = evt.get("session_id")
    return events, sid


def main():
    print("=" * 60)
    print("① SSE 事件流结构")
    events, sid1 = post_chat("你的技术栈是什么？")
    types = [e.get("type") for e in events]
    print("   事件序列:", " → ".join(types))
    assert types[0] == "meta", "首个事件必须是 meta"
    assert "token" in types, "必须包含 token 事件"
    assert types[-1] == "done", "末个事件必须是 done"
    meta = events[0]
    full = "".join(e.get("text", "") for e in events if e.get("type") == "token")
    print("   ✔ session_id=%s  sources=%d  query_used=%r" % (
        sid1, len(meta.get("sources") or []), meta.get("query_used", "")))
    print("   ✔ 回答长度=%d，回答开头: %s" % (len(full), full[:40].replace("\n", " ")))
    assert sid1, "meta 必须带 session_id"
    assert len(full) > 10, "回答过短"

    print("=" * 60)
    print("② 会话模型对齐：同一 session_id 复用")
    events2, sid2 = post_chat("具体说说你熟悉的开发工具？", session_id=sid1)
    assert sid2 == sid1, "同一 session_id 应归组到同一会话（%s != %s）" % (sid1, sid2)
    print("   ✔ 两次请求 session_id 一致（%s）" % sid2)
    assert [e.get("type") for e in events2][0] == "meta"

    print("=" * 60)
    print("③ 前端依赖字段")
    for field in ("query_used", "sources", "session_id", "kb"):
        assert field in meta, "meta 缺字段: %s" % field
    print("   ✔ meta 含 query_used / sources / session_id / kb")

    print("=" * 60)
    print("全部通过 ✅（/api/chat 已迁移 SSE，会话归组生效）")


if __name__ == "__main__":
    sys.exit(main())
