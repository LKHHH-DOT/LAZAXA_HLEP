# -*- coding: utf-8 -*-
"""子代理验收脚本（批次 E2 · 真实 agent 链路）。

场景：主代理把翻译任务委派给子代理（subagent_spawn），子代理独立上下文
直接作答（无工具调用），主代理汇总子代理结果回复。全程 relaxed 模式
（subagent_spawn 为 sensitive，relaxed 自动放行，无审批弹窗）。

验证：subagent_start / subagent_end 事件、stop_reason=completed、
主代理回复包含子代理产出。

运行方式（SelfIterate 根目录）：
    python scripts/test_agent_subagent.py
"""
import json
import os
import sys
import urllib.request

AGENT_URL = "http://127.0.0.1:8000/api/v1/agent"


def load_token():
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("ADMIN_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def main():
    token = load_token()
    if not token:
        print("❌ 未找到 ADMIN_TOKEN（.env）")
        sys.exit(1)
    message = (
        "请委派一个子代理（subagent_spawn）完成翻译任务："
        "把『今天天气很好，我们去公园散步吧』翻译成英文。"
        "子代理直接给出译文即可，然后你把子代理的译文汇总回复给我。"
    )
    payload = {"message": message, "mode": "relaxed"}
    req = urllib.request.Request(
        AGENT_URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "X-Admin-Token": token})
    print("→ 发送任务:", message[:60], "…")

    events = []
    reply = ""
    with urllib.request.urlopen(req, timeout=660) as resp:
        chunk = ""
        while True:
            line = resp.readline()
            if not line:
                break
            chunk += line.decode("utf-8", "ignore").replace("\r\n", "\n")
            while "\n\n" in chunk:
                block, chunk = chunk.split("\n\n", 1)
                for ln in block.splitlines():
                    if not ln.startswith("data:"):
                        continue
                    raw = ln[5:].strip()
                    if not raw:
                        continue
                    try:
                        evt = json.loads(raw)
                    except Exception:
                        continue
                    events.append(evt)
                    t = evt.get("type")
                    if t == "tool_call":
                        print(f"  🔧 {evt.get('display_name') or evt.get('name')}"
                              f"({json.dumps(evt.get('args', {}), ensure_ascii=False)[:60]})")
                    elif t == "subagent_start":
                        print(f"  🧩 子代理开始 depth={evt.get('depth')} "
                              f"tools={evt.get('tool_filter')} task={evt.get('task')[:40]}")
                    elif t == "subagent_end":
                        print(f"  🧩 子代理结束 stop={evt.get('stop_reason')} "
                              f"steps={evt.get('steps')} ms={evt.get('ms')}")
                    elif t == "error":
                        print("  ⚠️", evt.get("message"))
                    elif t == "done":
                        reply = evt.get("reply", "")
                        print(f"  ✅ done（{evt.get('steps')} 步）")

    print("\n=== 结果 ===")
    types = [e.get("type") for e in events]
    print("事件序列:", types)
    print("模型回复:", reply[:300])
    assert "subagent_start" in types and "subagent_end" in types, \
        f"缺少子代理事件，实际: {types}"
    end = next(e for e in events if e.get("type") == "subagent_end")
    assert end.get("stop_reason") == "completed", f"子代理未完成: {end}"
    assert reply, "主代理未返回回复"
    assert any(w in reply.lower() for w in ("the weather", "park", "walk")), \
        f"回复未包含子代理译文: {reply[:120]}"
    print("\n✅ 子代理委派链路验收通过（spawn → 独立上下文执行 → 汇总回填）")


if __name__ == "__main__":
    main()
