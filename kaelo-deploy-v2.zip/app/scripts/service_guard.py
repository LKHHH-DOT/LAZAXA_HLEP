# -*- coding: utf-8 -*-
"""Lazaxa 服务常驻守护（2026-08-17）。

背景
----
Ollama / Qdrant / 后端 / GUI 都是"手动启动、关机即消失"的服务。任一个没跑，
Lazaxa 的功能就会静默降级（记忆检索返回空、RAG 不可用、对话无响应），且
不报错、极难排查。本脚本常驻后台，周期检测各服务存活状态，哪个没了就用
对应命令自动拉起，保证服务栈持续在线。

用法
----
    python scripts/service_guard.py      # 前台运行（调试）
    重启Lazaxa服务.bat                    # 重启全部后自动进入守护（推荐）

检测项（可随时增删 SERVICES 列表）
    ollama      : 端口 11434（bge-m3 嵌入）
    qdrant      : 端口 6333（长期记忆底座，必须在 qdrant/ 目录内启动）
    backend     : 端口 8000（FastAPI）
    blender_mcp : 端口 9876（Blender MCP，GUI 模式；未装 Blender 会自动跳过）
    kb_gui      : 进程命令行匹配 kb_gui.py（前端界面）

防抖：同一服务拉起失败后 GUARD_SECONDS 秒内不重复尝试，避免反复拉起刷屏。
日志：data/logs/service_guard.log（含拉起的后端日志 backend.log）。
"""
import logging
import os
import shutil
import socket
import subprocess
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # SelfIterate/
ROOT_DIR = os.path.dirname(BASE_DIR)                                    # Kaelo/
LOG_DIR = os.path.join(BASE_DIR, "data", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

POLL_SECONDS = 15        # 轮询间隔（秒）
GUARD_SECONDS = 90       # 拉起失败后的防抖间隔（秒）
CREATE_NO_WINDOW = 0x08000000  # Windows：隐藏子进程窗口

# 周期安全体检（防御向"安全管家"，2026-08-18）
# 每 6 小时自动跑一次 scripts/security_check.py，有 🔴 紧急项即告警并存档报告
SECURITY_CHECK_SECONDS = 6 * 3600

# pythonw / 最小化运行时可能没有 stderr，此时只写文件日志
_handlers = [logging.FileHandler(os.path.join(LOG_DIR, "service_guard.log"),
                                 encoding="utf-8")]
if sys.stderr is not None:
    _handlers.append(logging.StreamHandler())
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s %(message)s",
    handlers=_handlers,
)
log = logging.getLogger("service_guard")

# 防止 Popen / 日志文件对象被 GC 回收导致子进程输出句柄关闭
_KEEPALIVE: list = []


def port_alive(port: int, host: str = "127.0.0.1") -> bool:
    """端口存活检测（2 秒超时）。"""
    try:
        with socket.create_connection((host, port), timeout=2.0):
            return True
    except OSError:
        return False


def process_alive(match: str) -> bool:
    """检测是否存在命令行包含 match 的进程（仅 Windows）。"""
    ps = (
        "Get-CimInstance Win32_Process | "
        f"Where-Object {{ $_.CommandLine -match '{match}' }} | "
        "Measure-Object | Select-Object -ExpandProperty Count"
    )
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=10,
            creationflags=CREATE_NO_WINDOW).stdout.strip()
        return out not in ("", "0")
    except Exception:
        return True  # 检测异常时视为存活，避免误判导致反复拉起


def _spawn(argv: list, cwd=None, no_window=True, log_path=None) -> bool:
    """拉起一个子进程；可选把输出重定向到日志文件（防句柄 GC 关闭）。"""
    try:
        kwargs = {"cwd": cwd}
        if no_window:
            kwargs["creationflags"] = CREATE_NO_WINDOW
        if log_path:
            f = open(log_path, "a", encoding="utf-8")
            kwargs["stdout"] = f
            kwargs["stderr"] = subprocess.STDOUT
        proc = subprocess.Popen(argv, **kwargs)
        _KEEPALIVE.append(proc)
        if log_path:
            _KEEPALIVE.append(f)
        return True
    except Exception as e:
        log.error("拉起失败 %s: %s", argv, e)
        return False


# ---------- 各服务启动器 ----------

def start_ollama() -> bool:
    exe = shutil.which("ollama")
    if not exe:
        log.warning("[ollama] 未找到 ollama 可执行文件，跳过")
        return False
    ok = _spawn([exe, "serve"])
    log.info("[ollama] 已拉起 serve")
    return ok


def start_qdrant() -> bool:
    qd = os.path.join(ROOT_DIR, "Sanctum", "qdrant", "qdrant.exe")
    if not os.path.exists(qd):
        log.warning("[qdrant] 未找到 %s，跳过", qd)
        return False
    # 配置按 CWD 加载，必须在 qdrant/ 目录内启动
    ok = _spawn([qd], cwd=os.path.dirname(qd))
    log.info("[qdrant] 已拉起（REST 127.0.0.1:6333）")
    return ok


def start_backend() -> bool:
    ok = _spawn(
        [sys.executable, "-m", "uvicorn", "app.main:app",
         "--host", "127.0.0.1", "--port", "8000"],
        cwd=BASE_DIR,
        log_path=os.path.join(LOG_DIR, "backend.log"),
    )
    log.info("[backend] 已拉起 uvicorn（127.0.0.1:8000）")
    return ok


def start_kb_gui() -> bool:
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    gui_dir = os.path.join(ROOT_DIR, "kb-gui-assistant")
    ok = _spawn([pyw, "kb_gui.py"], cwd=gui_dir)
    log.info("[kb_gui] 已拉起前端界面")
    return ok


def start_blender_mcp() -> bool:
    """按需拉起 Blender MCP（由 mcp_call_tool 触发，服务守护不再自动拉起）。

    保留供 mcp_tools._ensure_blender_up 之外的手动/脚本调用复用。
    """
    exe = r"D:\Allapp\blender\blender.exe"
    script = os.path.join(BASE_DIR, "scripts", "blender_mcp_start.py")
    if not os.path.exists(exe):
        log.warning("[blender_mcp] 未找到 %s，跳过（不守护）", exe)
        return False
    if not os.path.exists(script):
        log.warning("[blender_mcp] 未找到 %s，跳过", script)
        return False
    # Blender 必须 GUI 模式（background 模式 timers 不 tick）
    ok = _spawn([exe, "--python", script], no_window=False)
    log.info("[blender_mcp] 已拉起 Blender GUI（9876）")
    return ok


SERVICES = [
    {"name": "ollama",      "check": lambda: port_alive(11434),
     "start": start_ollama},
    {"name": "qdrant",      "check": lambda: port_alive(6333),
     "start": start_qdrant},
    {"name": "backend",     "check": lambda: port_alive(8000),
     "start": start_backend},
    {"name": "kb_gui",      "check": lambda: process_alive("kb_gui"),
     "start": start_kb_gui},
]


# ---------- 周期安全体检（防御向） ----------

def run_security_check() -> None:
    """跑一次安全体检；有紧急项(🔴)时告警，报告全文存档 data/logs/security_report.log。"""
    script = os.path.join(BASE_DIR, "scripts", "security_check.py")
    if not os.path.exists(script):
        log.warning("[security] 体检脚本缺失 %s，跳过", script)
        return
    try:
        r = subprocess.run(
            [sys.executable, script], capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=120,
            creationflags=CREATE_NO_WINDOW,
        )
    except Exception as e:
        log.warning("[security] 体检执行异常: %s", e)
        return
    out = (r.stdout or "").strip()
    if not out:
        log.warning("[security] 体检无输出（exit=%s）", r.returncode)
        return
    # 报告全文存档（追加，含时间戳）
    report_path = os.path.join(LOG_DIR, "security_report.log")
    with open(report_path, "a", encoding="utf-8") as f:
        f.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n{out}\n")
    crit = [ln for ln in out.splitlines() if ln.startswith("🔴")]
    if crit:
        log.warning("[security] 体检发现 %d 个紧急项！\n%s",
                    len(crit), "\n".join(crit))
    else:
        log.info("[security] 体检完成：无紧急项（详见 security_report.log）")


def main() -> None:
    log.info("=" * 60)
    log.info("Lazaxa 服务守护启动 | 轮询 %ss | 防抖 %ss | 安全体检每 %.1fh", POLL_SECONDS, GUARD_SECONDS, SECURITY_CHECK_SECONDS / 3600)
    log.info("SelfIterate: %s", BASE_DIR)
    last_try = {svc["name"]: 0.0 for svc in SERVICES}
    last_security = 0.0  # 0 表示启动后立即跑首次体检
    while True:
        for svc in SERVICES:
            name = svc["name"]
            try:
                alive = svc["check"]()
            except Exception as e:
                log.warning("[%s] 检测异常: %s", name, e)
                continue
            if alive:
                continue
            now = time.time()
            if now - last_try[name] < GUARD_SECONDS:
                continue  # 防抖
            last_try[name] = now
            log.warning("[%s] 检测到未存活，尝试拉起...", name)
            if not svc["start"]():
                log.warning("[%s] 拉起失败，%.0fs 后再试", name, GUARD_SECONDS)
        now = time.time()
        if now - last_security >= SECURITY_CHECK_SECONDS:
            last_security = now
            run_security_check()
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.info("守护已退出（Ctrl+C）")
