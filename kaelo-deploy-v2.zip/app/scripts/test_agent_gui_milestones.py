# -*- coding: utf-8 -*-
"""端到端验收：P3 GUI 里程碑真屏跑（引擎感知栈版，2026-09-04 重写）。

为什么这样写（上一版教训）：
  旧版在验收脚本里手搓了第三套"键鼠/剪贴板注入"（IME 组字、前台锁、标题语义、
  剪贴板哨兵回读），越写越死。GUI 验证本该让 AI/脚本复用引擎既有的
  "分层视觉感知栈 + 行动-观察闭环"多方位协作，而不是另起炉灶去模拟键盘。

本版 = 引擎感知栈编排（与智能体真跑 GUI 任务同源同行为）：

  感知（视觉升级方案四层，缺层自动降级，均来自 app.agent.tools）：
    结构层  window_control / windows 封装：激活置前、拿窗口标题与矩形
    文字层  screen_ocr：OCR"看见"屏幕文字
    语义层  screen_describe：本地 VLM 复核画面（不可用自动跳过，不阻塞）
  动作（引擎原语，自带防护与闭环）：
    keyboard_type(text, window_title=)：输入前校验前台是目标窗口；中文走剪贴板
    keyboard_press(keys=...)：黑名单拦截 + 操作前后截图 diff 回填
    _mouse_click(x, y)：OCR 定位按钮后点击（自动附行动-观察闭环）
    window_control(close)：优雅关闭（WM_CLOSE），不 taskkill
  断言（不再"剪贴板回读"，而是"看屏幕 + 看落盘"两层）：
    ① OCR 命中输入文案，且命中块中心落在记事本窗口矩形内
       —— 排除"终端回显脚本字符串"造成的假阳性（块坐标在终端窗口里，不算看见）
    ② 保存后读盘断言文件内容（真实世界最终成果物，最权威）

验收场景（记事本样板链路，可复跑、无账号耦合）：
  ① 打开并归零：看标题清理"最近更新/帮助/会话恢复脏文档/已保存文件窗"，
     收敛到一个可输入的空白"无标题"文档窗
  ② M1【输入文本】：英文唯一标记（ASCII 保证 OCR 门禁稳定）→ OCR 看见它在记事本内
  ③ M2【清空收尾】：Ctrl+A + Delete → OCR 不再看见该标记
  ④ M3【保存并关闭】：输入中文文案（验证中文剪贴板通道）→ Ctrl+S →
     系统"另存为"对话框 → 【真实用户顺序】UIA 点"文件路径"(地址栏)输目标目录
     → Enter 导航 → 点回"文件名"框输纯文件名 → UIA Invoke 保存按钮 →
     读盘断言中文内容 → 优雅关闭 → 断言窗口消失

退出码：0=全部通过  1=里程碑断言未过（护栏如实报告卡点）  2=环境不可用
运行要求：请在真实桌面会话的 PowerShell 窗口运行
（python scripts/test_agent_gui_milestones.py）；不要在 IDE 内嵌终端跑——
该类环境通常无法把目标窗口真正带到可见前台，键鼠注入会落空。
"""
import os
import re
import shutil
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from app import config as app_config
from app.agent.tools import gui
from app.agent.tools import windows as win_tools

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
M1_MARK = "LazaxaGUI-P3-OK"              # M1/M2 门禁：全大写 ASCII，OCR 最稳
M3_TEXT = "你好，Lazaxa GUI 验收通过！"    # M3 保存内容：中文，验证剪贴板通道 + 落盘
_SAVE_SUB_DIR = "notepad-e2e"            # LazaxaTemp 下的验收专用子目录

# 标题语义判断（只读文本判定，非注入 hack）——中英文系统界面都兼容
_WIN_KWS = ("记事本", "notepad")          # 记事本主窗标题命中词
_BAD_WORDS = ("帮助", "help", "设置", "settings", "support", "支持",
              "反馈", "版本", "获取")      # 帮助/设置等杂窗
_NOISE_WORDS = ("最近更新", "新增功能", "what's new", "whats new",
                "开始使用", "入门", "使用提示", "了解新")   # 阅读页/引导页噪音


def log(*msgs):
    print(*msgs, flush=True)


# ---------------------------------------------------------------------------
# 结构层：窗口只读感知（复用引擎 UIA / Win32 后端）
# ---------------------------------------------------------------------------
def _notepad_windows():
    """枚举记事本顶层窗 → [(hwnd, title)]（排除帮助/设置等杂窗）。

    优先 UIA（pywinauto Desktop），可一次拿全部窗口用于多窗收敛；
    UIA 不可用则降级到 Win32 单窗查找（windows._Windows.find 同源）。
    """
    uia = gui._lazy_uia()
    out = []
    try:
        for w in uia.windows():
            t = (w.window_text() or "").strip()
            low = t.lower()
            if not t or not any(k in low for k in _WIN_KWS):
                continue
            if any(b in low for b in _BAD_WORDS):
                continue
            out.append((int(w.handle), t))
    except Exception:
        out = []
    if out:
        return out
    # 降级：单窗查找（多窗并存时只能处理第一个，真实桌面场景一般只有一个主窗）
    win = win_tools._get_windows()
    for kw in _WIN_KWS:
        hwnd, t = win.find(kw)
        if hwnd and not any(b in t.lower() for b in _BAD_WORDS):
            return [(hwnd, t)]
    return []


def _window_rect(hwnd):
    """窗口矩形 (l, t, r, b)——物理屏幕坐标，与截图/OCR 同坐标系。

    坑（2026-09-04 实测）：UIA wrapper.rectangle() 返回 DIP 逻辑坐标，
    系统显示缩放 >100%（如 125%）时与 pyautogui 截图的物理坐标错位，
    导致 OCR 命中块被"不在窗口内"误滤 → 输入成功却断言失败。
    win32functions.GetWindowRect 与截图像素同一坐标系，DPI 虚拟化一致。
    """
    if not hwnd:
        return None
    # 第一优先：pywinauto 封装（与截图同坐标系）
    try:
        from pywinauto import win32functions
        l, t, r, b = win32functions.GetWindowRect(int(hwnd))
        return int(l), int(t), int(r), int(b)
    except Exception:
        pass
    # 兜底：ctypes user32.GetWindowRect（脚本顶部已有 user32），最底层最可靠
    try:
        rc = ctypes.wintypes.RECT()
        user32.GetWindowRect.argtypes = [ctypes.wintypes.HWND, ctypes.POINTER(ctypes.wintypes.RECT)]
        if user32.GetWindowRect(int(hwnd), ctypes.byref(rc)):
            return int(rc.left), int(rc.top), int(rc.right), int(rc.bottom)
    except Exception:
        pass
    return None


def _strip_body(title):
    """去掉 ' - 记事本 / - Notepad' 后缀，得到文件主体。"""
    for sep in (" - ", " -"):
        if sep in title:
            return title.split(sep)[0].strip()
    return title.strip()


def _blank_doc(title):
    """是否为可输入、保存必弹"另存为"的空白文档窗（无标题/未命名/untitled）。

    只认标准"未命名"标题（可带 * 脏标记）；任何自定义名字（如会话恢复带出的
    probe-xyz / foo.txt / 路径名）一律视为"已命名文档窗"——Ctrl+S 会静默保存、
    不再弹"另存为"，M3 链路必断，必须收敛关闭（2026-09-04 实测踩坑：
    「*probe-xyz - Notepad」曾被误判为空白窗保留）。
    """
    low = title.lower()
    if any(n in low for n in _NOISE_WORDS):
        return False
    body = _strip_body(title).rstrip("*").strip()   # 去脏星号看主体
    low_b = body.lower()
    if not body or low_b in ("记事本", "notepad"):
        return True
    # 标准未命名空白文档（中文/英文系统）
    if "无标题" in body or "未命名" in body or low_b.startswith("untitled"):
        return True
    # 其余一律视为已命名文档窗（含无扩展名自定义名）：关闭收敛，保证 Ctrl+S 弹"另存为"
    return False


def _is_foreground_notepad() -> bool:
    """当前前台窗口是否是记事本（keyboard_type 同款关键词判定）。"""
    t = gui._foreground_title().lower()
    return any(k in t for k in _WIN_KWS)


# ---------------------------------------------------------------------------
# 文字层：OCR 感知（复用引擎 screen_ocr）
# ---------------------------------------------------------------------------
def _ocr_blocks():
    """全屏 OCR 文字块列表；引擎不可用/失败返回 (None, 原因)。"""
    r = gui._screen_ocr(min_confidence=10.0)   # 放宽阈值，兜小字号/浅灰文字
    if not r.ok:
        return None, r.error or "OCR 读取失败"
    try:
        import json
        return json.loads(r.text).get("items", []), ""
    except Exception as e:
        return None, f"OCR 结果解析失败: {e}"


def _ocr_hit_in_window(hwnd, probe):
    """probe 是否被 OCR"看见"且命中块中心落在 hwnd 窗口矩形内。

    返回 (命中?, 说明)。矩形归属过滤是防假阳性关键：终端/IDE 若回显了脚本
    源码字符串，命中块坐标在终端窗口里 → 不算"看见"，不会误判输入成功。
    """
    rect = _window_rect(hwnd)
    blocks, err = _ocr_blocks()
    if blocks is None:
        return False, err
    target = probe.lower()
    hits = []
    for b in blocks:
        if target not in str(b.get("text", "")).lower():
            continue
        c = b.get("center") or []
        if len(c) != 2:
            continue
        if rect and not (rect[0] <= c[0] <= rect[2] and rect[1] <= c[1] <= rect[3]):
            continue    # 文字不在记事本窗口内 → 视作没看到
        hits.append(b)
    if hits:
        h = hits[0]
        conf = f" conf={h.get('confidence')}" if h.get("confidence") else ""
        return True, (f"OCR 命中 '{probe}' @({h['center'][0]},{h['center'][1]}){conf}"
                      f"（命中块 {len(hits)} 处）")
    if rect:
        return False, f"OCR 未见 '{probe}' 出现在记事本窗口矩形内"
    return False, f"OCR 未见 '{probe}'（窗口矩形不可用，退化为全屏判空）"


# ---------------------------------------------------------------------------
# 动作层：激活/输入/按键/关闭（全部走引擎原语）
# ---------------------------------------------------------------------------
def _activate_first_blank():
    """激活第一个可输入的空白记事本窗。返回 (hwnd, title) 或 (None, 原因)。"""
    win = win_tools._get_windows()
    for hwnd, title in _notepad_windows():
        if not _blank_doc(title):
            continue
        if not win.activate(hwnd):
            return None, f"activate 失败（窗口『{title}』）"
        time.sleep(0.5)
        if not _is_foreground_notepad():
            return None, (f"activate 后前台仍是 '{gui._foreground_title()}'，"
                          "请从桌面正常 PowerShell 窗口运行（勿用 IDE 内嵌终端）")
        return hwnd, title
    return None, "没有可输入的空白记事本窗口（归零阶段未收敛）"


def _type_text(text, window_title):
    """IME 免疫输入：剪贴板写入 + Ctrl+V（引擎原语编排）。

    为何不直接走 keyboard_type 的 ASCII 直敲分支：用户开着中文输入法时，
    pyautogui.typewrite 的 ASCII 会被 IME 当拼音组字吞掉，打不进去
    （旧版反复踩的老坑，本次 M1 OCR 未命中的根因）。统一走剪贴板粘贴，
    与 keyboard_type 的中文分支同一条已实测稳定的路径。
    返回 (成功?, 错误或'').
    """
    real = gui._foreground_title()
    kws = win_tools._title_keywords(window_title)
    if not any(k.lower() in real.lower() for k in kws):
        return False, (f"前台窗口 '{real}' 与目标 '{window_title}' 不匹配，"
                       "拒绝输入（请先 window_control 激活目标窗口）")
    try:
        gui._set_clipboard_text(text)
    except Exception as e:
        return False, f"剪贴板写入失败: {e}"
    time.sleep(0.1)
    r = gui._keyboard_press(keys=["ctrl", "v"])
    if not r.ok:
        return False, r.error or "Ctrl+V 失败"
    return True, ""


def _vlm_diag(hwnd, scene) -> str:
    """OCR 断言未过时的语义层诊断：VLM 看图说明"到底发生了什么"。

    用户要求视觉模型要真正用起来（光标位置/误开按钮/弹窗状态都由它看），
    而非脚本盲猜。VLM 不可用时如实降级说明。
    """
    reason = gui._vlm_available()
    if reason:
        return f"VLM 不可用，无法诊断（{reason[:60]}…）"
    rect = _window_rect(hwnd)
    region = None
    if rect:
        region = [rect[0], rect[1], rect[2] - rect[0], rect[3] - rect[1]]
    q = (f"{scene}。请用中文回答（150 字内）："
         "1)这是什么窗口，标题栏写的是什么？"
         "2)文本编辑区里当前能看到哪些文字？"
         "3)有没有光标在闪烁？大致在哪一行？"
         "4)有没有意外弹出的菜单/按钮/对话框（开始菜单/右键菜单/帮助页等）？")
    r = gui._screen_describe(region=region, question=q)
    if not r.ok:
        return f"VLM 诊断调用失败：{r.error}"
    try:
        import json as _json
        return (_json.loads(r.text).get("description") or "")[:300]
    except Exception:
        return (r.text or "")[:300]


def _vlm_confirm(hwnd, probe):
    # VLM 语义是/否确认：编辑区是否显示了 probe 的近似文本。
    # 用户拍板（2026-09-04）：OCR 与 VLM 是互补感知件，任一确认即通过；
    # 不要求 VLM 逐字复述（gemma3 对紧凑字母数字易读走样，曾把
    # LazaxaGUI-P3-OK 读成 LazadaGUI.PNG）→ 改为询问是否显示该标记文本。
    # 返回 (ok, diag)。
    reason = gui._vlm_available()
    if reason:
        return False, 'VLM 不可用，无法语义确认（' + reason[:50] + '…）'
    rect = _window_rect(hwnd)
    region = None
    if rect:
        region = [rect[0], rect[1], rect[2] - rect[0], rect[3] - rect[1]]
    q = ('看这张截图里的文本编辑区。请只回答：编辑区内是否显示有一段字母数字标记文本'
         '（形似 ' + probe + '，允许个别字符被误读）？先只用一个字回答：是 或 否，'
         '再一句话说清你实际看到的文字。')
    r = gui._screen_describe(region=region, question=q)
    if not r.ok:
        return False, 'VLM 确认调用失败：' + str(r.error)
    try:
        import json as _json
        desc = (_json.loads(r.text).get('description') or '')
    except Exception:
        desc = (r.text or '')
    head = desc.strip().lower()[:12]
    if head.startswith(('是', '对', 'yes')):
        return True, desc[:200]
    return False, desc[:200]



def _click_ocr_button(targets, timeout=6.0):
    """文字层定位按钮（OCR 短块过滤）→ 引擎点击。返回是否点到。

    只认"短文本块"（≤12 字符去空格后），避免命中"是否将更改保存到…"这类长句。
    """
    tup = tuple(targets) if isinstance(targets, (tuple, list)) else (targets,)
    deadline = time.time() + timeout
    while time.time() < deadline:
        blocks, err = _ocr_blocks()
        for b in blocks or []:
            compact = str(b.get("text", "") or "").strip().replace(" ", "").replace("\u3000", "")
            if not compact or len(compact) > 12:
                continue
            if not any(t in compact for t in tup):
                continue
            c = b.get("center") or []
            if len(c) == 2:
                r = gui._mouse_click(x=int(c[0]), y=int(c[1]))   # 引擎点击（自带闭环）
                if r.ok:
                    time.sleep(0.5)
                    return True
        time.sleep(0.5)
    return False


def _close_window(hwnd):
    """优雅关闭：引擎 WM_CLOSE → 弹"是否保存"则 OCR 点"不保存"。

    不 taskkill：强杀会让 Win11 记事本把崩溃现场记成会话，下次冷启动冒出
    '最近更新/What's new' 阅读页与恢复的脏文档（旧版反复翻车的乱源）。
    """
    win_tools._get_windows().close(hwnd)          # WM_CLOSE（引擎封装）
    time.sleep(0.8)
    _click_ocr_button(("不保存", "Don't Save"), timeout=2.0)


def _wait_saveas_dialog(timeout=8.0):
    """结构层等系统"另存为"对话框（顶层窗标题判定，比 OCR 认字稳）。"""
    win = win_tools._get_windows()
    deadline = time.time() + timeout
    while time.time() < deadline:
        for kw in ("另存为", "save as"):
            hwnd, t = win.find(kw)
            if hwnd:
                return hwnd, t
        time.sleep(0.25)
    return None


# ---------------------------------------------------------------------------
# M3 保存核心（2026-09-04 第四版）：UIA 控件树直操作"另存为"对话框
# 学自 pywinauto 官方 notepad_slow.py 等 FileDialog 自动化范式——
#   成熟 GUI 自动化定位"文件名"框(AutomationId=FileNameControlHost)直接写值、
#   再真实点击"保存"按钮(auto_id=1)；不依赖 Alt+N/Enter 键盘焦点猜测，
#   写值用 SetValue 无需焦点、天然 IME 免疫。这才是"AI 操作另存为"的标准姿势。
# 第四版升级（用户拍板）：默认焦点在"文件名"框，先点"文件路径"组件（地址栏
#   ToolBar auto_id=1001）导航目录、再点回文件名框写纯文件名——绝不往文件名框
#   写整路径（Win11 会当文件名处理、看似成功却按默认目录落盘）。
# ---------------------------------------------------------------------------
def _desc_controls(w, ctype):
    """枚举 UIA 窗口下指定控件类型元素列表（与引擎 _ui_collect 同源遍历法）。"""
    out = []
    try:
        for el in w.descendants():
            try:
                if (el.element_info.control_type or "") == ctype:
                    out.append(el)
            except Exception:
                continue
    except Exception:
        pass
    return out


def _dlg_uia_wrap(dlg_hwnd):
    """拿"另存为"对话框的 UIA 窗口包装（与引擎 _ui_collect 同源的 handle 取窗）。"""
    try:
        d = gui._lazy_uia()
        if d is None:
            return None
        w = d.window(handle=int(dlg_hwnd))
        w.wait("exists", timeout=2)
        return w
    except Exception:
        return None


def _dlg_filename_edit(w):
    """定位"文件名"编辑框：优先系统标准 AutomationId（FileNameControlHost /
    兼容 id 1001，个别实现外层包 Spinner/Document）；找不到再退化取对话框内
    第一个可写 Edit。
    """
    for aid in ("FileNameControlHost", "1001"):
        try:
            e = w.child_window(auto_id=aid, control_type="Edit")
            if e.exists(timeout=0.5):
                return e
        except Exception:
            continue
    # 不限定 control_type 再找一次：个别实现把 FileNameControlHost 包在 Spinner 里
    try:
        e = w.child_window(auto_id="FileNameControlHost")
        if e.exists(timeout=0.5):
            try:
                if (e.element_info.control_type or "") in ("Spinner", "Document"):
                    for c in _desc_controls(e, "Edit"):
                        return c
            except Exception:
                pass
            return e
    except Exception:
        pass
    for e in _desc_controls(w, "Edit"):
        try:
            if e.is_enabled():
                return e
        except Exception:
            continue
    return None


def _dlg_save_button(w):
    """定位"保存"主按钮：按可见文字（保存/Save）优先，再按官方 auto_id='1'。"""
    for e in _desc_controls(w, "Button"):
        n = (e.window_text() or "").strip()
        if n.startswith("保存") or n.startswith("Save"):
            return e
    try:
        e = w.child_window(auto_id="1", control_type="Button")
        if e.exists(timeout=0.5):
            return e
    except Exception:
        pass
    return None


def _element_physical_center(dlg_hwnd, el, x_frac=0.5, y_frac=0.5):
    """UIA 元素上任意比例点 → 物理屏幕坐标（兼容显示缩放>100%）。

    默认 x_frac=y_frac=0.5 取元素中心；传比例可点元素内相对位置
    （如地址栏右 3/4 空白处，避免点中中心可能落到的文字/按钮）。
    坑（2026-09-04）：pywinauto UIA wrapper.rectangle() 返回 DIP 逻辑坐标，
    125% 缩放时与 pyautogui 点击用的物理坐标错位。用窗口自身 GetWindowRect
    （物理）与 UIA 窗口矩形（DIP）的比例做换算，并夹在窗口物理范围内。
    """
    try:
        r = el.rectangle()
        cx = int(r.left + (r.right - r.left) * float(x_frac))
        cy = int(r.top + (r.bottom - r.top) * float(y_frac))
        phw = _window_rect(dlg_hwnd)              # 物理
        if not phw:
            return cx, cy                         # 取不到物理矩形直接用（100% 缩放时相等）
        wrap = _dlg_uia_wrap(dlg_hwnd)
        if wrap is not None:
            try:
                wr = wrap.rectangle()             # DIP
                sx = (phw[2] - phw[0]) / max(1, int(wr.right) - int(wr.left))
                sy = (phw[3] - phw[1]) / max(1, int(wr.bottom) - int(wr.top))
                cx = int(cx * sx)
                cy = int(cy * sy)
            except Exception:
                pass
        cx = max(phw[0], min(phw[2], cx))
        cy = max(phw[1], min(phw[3], cy))
        return cx, cy
    except Exception:
        return 0, 0


def _mouse_click_element(dlg_hwnd, el, x_frac=0.5, y_frac=0.5, desc="元素"):
    """引擎真实鼠标点击 UIA 元素上某点（DIP→物理换算 + 行动-观察闭环）。

    返回 (成功?, 说明)。用于"点文件路径(地址栏)"/"点回文件名框"这类
    UIA 树已定位到组件、需以真人鼠标落点的场景。
    """
    cx, cy = _element_physical_center(dlg_hwnd, el, x_frac, y_frac)
    if cx <= 0 or cy <= 0:
        return False, f"{desc}物理坐标换算失败"
    r = gui._mouse_click(x=cx, y=cy)
    if not r.ok:
        return False, r.error or f"引擎点击{desc}失败"
    return True, f"引擎点击{desc} @({cx},{cy})"


def _dump_dialog_tree(w):
    """把"另存为"对话框 UIA 控件树落盘（真屏侧自探针，供远程对症下轮）。

    每次 M3 覆盖写 LazaxaTemp/saveas_uia_dump.txt；格式：
    control_type|automation_id|名称|en/dis|矩形。返回行数。
    """
    lines = []
    try:
        for el in w.descendants():
            try:
                info = el.element_info
                ct = info.control_type or "-"
                aid = info.automation_id or "-"
                name = (el.window_text() or "").strip()[:36]
                try:
                    en = "en" if el.is_enabled() else "dis"
                except Exception:
                    en = "?"
                r = el.rectangle()
                geo = f"{int(r.left)},{int(r.top)} {int(r.right - r.left)}x{int(r.bottom - r.top)}"
                lines.append(f"{ct}|{aid}|{name}|{en}|{geo}")
            except Exception:
                continue
    except Exception:
        pass
    try:
        p = os.path.join(app_config.AGENT_TEMP_DIR, "saveas_uia_dump.txt")
        with open(p, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except Exception:
        pass
    return len(lines)


def _element_value(el):
    """尽力读 UIA 元素当前文本（写值后回读校验用）；读不到返回 ''。"""
    try:
        v = el.get_value()
        if v:
            return str(v)
    except Exception:
        pass
    try:
        return (el.window_text() or "").strip()
    except Exception:
        return ""


def _uia_save_via_controls(dlg_hwnd, value, tag):
    """在"另存为"对话框 UIA 控件树写"文件名"框值 + 触发"保存"按钮。

    tag 用一句话说明这次写的是什么（调用方传如 '文件名'），用于步骤回显。
    第四版加强（学 FileDialog 自动化范式）：
      ① 写值后【回读校验】——值没进编辑框就如实报失败，杜绝"点了保存却存成
         默认名/默认位置"这类假成功（2026-09-04 实测踩坑）；
      ② 触发保存优先 UIA Invoke/click（坐标无关，规避 DPI 缩放错位导致点偏），
         引擎 _mouse_click 坐标点击降为兜底；
      ③ 命中控件与读回值写进回显，下轮可对症。
    返回 (成功?, 说明)。
    """
    w = _dlg_uia_wrap(dlg_hwnd)
    if w is None:
        return False, "UIA 取窗失败"
    tree_n = _dump_dialog_tree(w)
    edit = _dlg_filename_edit(w)
    if edit is None:
        return False, (f"UIA 控件树未找到文件名编辑框"
                       f"（树已落盘 LazaxaTemp/saveas_uia_dump.txt，{tree_n} 控件）")
    try:
        info = edit.element_info
        edit_desc = (f"auto_id={info.automation_id or '-'} "
                     f"type={info.control_type or '-'} class={info.class_name or '-'}")
    except Exception:
        edit_desc = "auto_id=? type=?"
    try:
        edit.wait("enabled", timeout=3)
        # 真实用户顺序（2026-09-04 用户拍板）：地址栏导航后焦点可能残留别处，
        # 须先"点回文件名"框再写值。点击 best-effort，失败不阻塞——
        # 后续 set_text 走 SetValue 本就不依赖焦点（IME 免疫）。
        _mouse_click_element(dlg_hwnd, edit, desc="文件名框")
        time.sleep(0.25)
        try:
            edit.set_text(value)                  # 优先 SetValue：无需焦点、IME 免疫
        except Exception:
            edit.set_edit_text(value)             # 退化：聚焦后全选输入
    except Exception as e:
        return False, f"UIA 向文件名框写{tag}失败: {e}"
    time.sleep(0.2)
    readback = _element_value(edit)
    if readback and str(value) not in readback:
        return False, (f"写入未通过回读校验：框[{edit_desc}] 期望含 '{value}'，"
                       f"实际为 '{readback[:60]}'")
    btn = _dlg_save_button(w)
    if btn is None:
        return False, f"文件名已写入（{tag}，回读={'确认' if readback else '无法读取'}），但未找到保存按钮"
    # ① 坐标无关触发保存：UIA Invoke/click（不移动鼠标，最稳）
    for m in sorted(set(dir(btn)) & {"invoke", "click", "click_input"}):
        try:
            getattr(btn, m)()
            return True, (f"UIA 直操作：向'文件名'框[{edit_desc}]写{tag} '{value}'"
                          f"（回读{'确认' if readback else '不可读'}），以 {m}() 触发保存")
        except Exception:
            continue
    # ② 兜底：物理坐标引擎点击（DIP→物理换算，兼容 125% 缩放）
    cx, cy = _element_physical_center(dlg_hwnd, btn)
    if cx <= 0 or cy <= 0:
        return False, f"文件名已写入（{tag}），但换算保存按钮物理坐标失败"
    r = gui._mouse_click(x=cx, y=cy)
    if not r.ok:
        return False, f"引擎点击保存按钮失败: {r.error}"
    return True, (f"UIA 直操作：向'文件名'框[{edit_desc}]写{tag} '{value}'"
                  f"（回读{'确认' if readback else '不可读'}），引擎点击保存 @({cx},{cy})")


# ---------------------------------------------------------------------------
# M3 保存（2026-09-04 第四版）：地址栏导航目录 → 文件名 → 保存
# 用户拍板："默认焦点在文件名那，所以要控制鼠标点'文件路径'那一组件输入路径，
# 再点回文件名输入文件名，再保存"。别再往文件名框写整路径（Win11 会当文件名
# 处理、看似保存成功却不按目标目录落盘，已踩坑）。
# ---------------------------------------------------------------------------
def _dlg_address_bar(w):
    """定位"另存为"对话框顶部的"文件路径"组件——地址栏（面包屑态）。

    系统标准结构：ToolBar automation_id=1001，名称以 '地址: ' 开头，其后就是
    当前所在目录的完整路径——可直接回读做"目录是否切成功"的断言。
    """
    for aid in ("1001",):
        for el in _desc_controls(w, "ToolBar"):
            try:
                if (el.element_info.automation_id or "") == aid:
                    return el
            except Exception:
                continue
    for el in _desc_controls(w, "ToolBar"):
        try:
            n = (el.window_text() or "").strip()
            if n.startswith("地址") or n.lower().startswith("address"):
                return el
        except Exception:
            continue
    return None


def _dlg_navigate_via_address_bar(dlg_hwnd, dlg_title, target_dir):
    """【M3 真实用户流程·第 1 步】把"另存为"对话框导航到目标目录。

    实测演进（2026-09-04 三版踩坑后定型）：
      · 地址栏编辑框与顶部"搜索"框难用 UIA 几何可靠区分——曾把路径写进搜索框、
        回车变"搜索"、目录纹丝不动；typewrite 直敲含反斜杠路径在部分键盘布局
        会打错。因此【不再识别/写值到具体编辑框元素】。
      · 改走与真人完全一致的序列：聚焦地址栏（鼠标点"文件路径"组件空白处，
        Ctrl+L 兜底）→ 全选旧文本 → 剪贴板粘贴目标目录（IME/反斜杠/中文
        全免疫）→ 【输完立刻回车】提交导航 → 回读地址栏名称断言已切到目标目录。
    返回 (导航成功?, 说明)。
    """
    def _wait_addr_shows(secs):
        """最多等 secs 秒，直到地址栏名称(去'地址:'前缀)等于目标目录。
        返回 (是否命中, 最后一次读到的名称)。"""
        last_n = ""
        deadline = time.time() + secs
        while time.time() < deadline:
            time.sleep(0.35)
            w3 = _dlg_uia_wrap(dlg_hwnd)
            if w3 is None:
                continue
            bar3 = _dlg_address_bar(w3)
            if bar3 is None:
                continue
            try:
                last_n = (bar3.window_text() or "").strip()
            except Exception:
                last_n = ""
            cur = re.sub(r"^地址[:：]?\s*", "", last_n, flags=re.I).strip()
            if cur and os.path.normpath(cur).lower() == os.path.normpath(target_dir).lower():
                return True, cur
        return False, last_n

    def _paste_and_enter():
        """全选地址框旧文本 → 剪贴板粘贴目标目录 → 立刻回车。"""
        r = gui._keyboard_press(keys=['ctrl', 'a'])
        if not r.ok:
            return False, r.error or 'Ctrl+A 失败'
        time.sleep(0.1)
        ok_t, err_t = _type_text(target_dir, window_title=dlg_title)
        if not ok_t:
            return False, '地址栏路径输入失败：' + err_t
        time.sleep(0.2)
        r = gui._keyboard_press(keys=['enter'])   # 用户拍板：输完路径必须回车
        if not r.ok:
            return False, r.error or '地址栏导航 Enter 失败'
        return True, ""

    # ① 鼠标点"文件路径"组件（用户语义）：地址栏右 3/4 空白 → 面包屑切可输入态。
    #    OS 级行为：点击地址栏后焦点自动落入其编辑框内（真人可直接打字）。
    w = _dlg_uia_wrap(dlg_hwnd)
    if w is None:
        return False, "UIA 取窗失败"
    bar = _dlg_address_bar(w)
    if bar is None:
        return False, "未找到地址栏组件（ToolBar auto_id=1001，树已落盘供对症）"
    ok_c, note_c = _mouse_click_element(dlg_hwnd, bar, x_frac=0.72, y_frac=0.5,
                                        desc="地址栏(文件路径)")
    if not ok_c:
        return False, note_c
    time.sleep(0.45)          # 等地址栏完成"面包屑 → 编辑态"切换

    ok_p, err_p = _paste_and_enter()
    if not ok_p:
        return False, err_p
    hit, last_n = _wait_addr_shows(4.0)
    if not hit:
        # 鼠标点击未让焦点落进地址框（部分系统差异）→ Ctrl+L 兜底重试：
        # Ctrl+L 是文件对话框标准"聚焦地址栏"，焦点必落地址编辑框。
        r = gui._keyboard_press(keys=['ctrl', 'l'])
        if not r.ok:
            return False, r.error or 'Ctrl+L 聚焦地址栏失败'
        time.sleep(0.3)
        ok_p2, err_p2 = _paste_and_enter()
        if not ok_p2:
            return False, err_p2
        hit, last_n = _wait_addr_shows(4.0)
    if hit:
        return True, f"文件路径组件已点开，路径输入回车后导航到目录：{target_dir}"
    return False, (f"回车后地址栏未回读到目标目录（当前名称 '{last_n or '无'}'；"
                   f"目标 {target_dir}）")


def _notepad_gone(timeout=6.0) -> bool:
    """轮询判断记事本顶层窗是否已全部消失。"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _notepad_windows():
            return True
        time.sleep(0.3)
    return False


# ---------------------------------------------------------------------------
# 里程碑
# ---------------------------------------------------------------------------
def _milestone_reset():
    """①·归零：收敛到恰好一个可输入空白文档窗（用户拍板：不做标签快捷键手术）。

    结构层只读看标题逐窗决策：噪音/阅读页/已保存文件窗/多余窗 → 优雅关闭；
    没有可输入窗 → 重开记事本。循环上限内收敛即算就绪。
    """
    steps = []
    max_reopen = 2
    opened = 0
    for rnd in range(6):
        wins = _notepad_windows()
        if not wins:
            opened += 1
            if opened > max_reopen + 1:
                return False, "止损：反复无法获得记事本窗口，请手动关闭记事本后重跑；" + "；".join(steps)
            log("[①·归零] 无记事本窗口 → open_app(记事本)")
            steps.append("open_app")
            win_tools._open_app(target="记事本")
            time.sleep(1.6)
            continue
        titles = " | ".join(f"「{t}」" for _, t in wins)
        log(f"[①·归零] 第{rnd + 1}轮：{len(wins)} 个窗口 {titles}")
        blank = [(h, t) for h, t in wins if _blank_doc(t)]
        keep = blank[0] if blank else None
        for hwnd, title in wins:
            if keep is not None and hwnd == keep[0]:
                continue
            log(f"[①·归零] 关闭非工作窗口「{title}」")
            steps.append(f"close:{title[:14]}")
            _close_window(hwnd)
        if keep is None:
            opened += 1
            if opened > max_reopen + 1:
                return False, "止损：归零反复失败，请手动关闭记事本后重跑；" + "；".join(steps)
            log("[①·归零] 无可输入空白窗 → 重开记事本")
            steps.append("reopen")
            win_tools._open_app(target="记事本")
            time.sleep(1.6)
            continue
        if not any(h == keep[0] for h, _ in _notepad_windows()):
            continue    # 保留窗被自己关闭动作误伤 → 下一轮重开
        log(f"[①·归零] 就绪：空白文档窗「{keep[1]}」")
        return True, "；".join(steps) or "初始即就绪"
    return False, "超时：归零未收敛；" + "；".join(steps)


def _milestone_input(hwnd):
    """M1【输入文本】：IME 免疫输入 → 感知层确认文本可见。

    输入用剪贴板粘贴（中文输入法开启时 typewrite 会被 IME 吞掉，已踩坑）。
    确认走"多层感知协作"：先文字层 OCR 判命中；OCR 漏识（DPI 错位/字体等）
    时语义层 VLM 上场——只要 VLM 看图能复述出目标文本，即软通过并标注
    "OCR 漏识、VLM 确认"（不强求每一层都成功，避免单一感知件卡死链路）。
    """
    ok_t, err_t = _type_text(M1_MARK, window_title="记事本")
    if not ok_t:
        return False, err_t
    time.sleep(0.6)     # 等渲染稳定再 OCR
    ok, note = _ocr_hit_in_window(hwnd, M1_MARK)
    if ok:
        return True, f"已输入 {len(M1_MARK)} 字符（剪贴板粘贴，IME 免疫）；{note}"
    # OCR 未命中 → 交给语义层 VLM 做是/否题（任一感知层确认即通过，不卡死）
    ok_v, diag = _vlm_confirm(hwnd, M1_MARK)
    if ok_v:
        return True, (str(note) + '；OCR 未命中但 VLM 语义确认文本已显示' 
                      '（多层感知：任一确认即通过）。[语义层确认] ' + diag)
    return False, ('输入动作已执行但 OCR 与 VLM 均未确认：' + str(note)
                   + '。[语义层诊断] ' + diag)



def _milestone_clear(hwnd):
    """M2【清空收尾】：Ctrl+A + Delete → OCR 不再看见标记。"""
    r1 = gui._keyboard_press(keys=["ctrl", "a"])
    if not r1.ok:
        return False, r1.error or "Ctrl+A 失败"
    time.sleep(0.15)
    r2 = gui._keyboard_press(keys=["delete"])
    if not r2.ok:
        return False, r2.error or "Delete 失败"
    time.sleep(0.6)
    ok, note = _ocr_hit_in_window(hwnd, M1_MARK)
    if ok:
        return False, f"清空后 OCR 仍在记事本窗口内看见 {M1_MARK}（Ctrl+A+Delete 未生效）"
    return True, "Ctrl+A + Delete 已执行，OCR 不再看见标记"


def _milestone_save_close(hwnd):
    """M3【保存并关闭】：中文输入 → Ctrl+S → 另存为起标题落盘 → 读盘断言 → 优雅关闭。"""
    steps = []
    # ① 输入中文待保存内容（验证中文剪贴板通道 + 前台防护）
    r = gui._keyboard_type(text=M3_TEXT, window_title="记事本")
    if not r.ok:
        return False, r.error or "中文输入失败", steps
    steps.append(f"中文内容已输入（{M3_TEXT}）")
    time.sleep(0.3)
    # ② Ctrl+S → 系统"另存为"对话框（未命名文档首次保存必经之路）
    r = gui._keyboard_press(keys=["ctrl", "s"])
    if not r.ok:
        return False, r.error or "Ctrl+S 失败", steps
    dlg = _wait_saveas_dialog(timeout=8.0)
    if not dlg:
        return False, f"Ctrl+S 后未见'另存为'对话框（当前前台={gui._foreground_title()}）", steps
    dlg_hwnd, dlg_title = dlg
    steps.append(f"'另存为'对话框已出现（结构层标题判定『{dlg_title}』）")
    win = win_tools._get_windows()
    if not win.activate(dlg_hwnd):
        return False, f"'另存为'对话框激活失败", steps
    time.sleep(0.4)
    if dlg_title.lower() not in gui._foreground_title().lower():
        return False, f"'另存为'对话框未到前台（前台={gui._foreground_title()}）", steps
    # ③ 按【真实用户操作顺序】保存（2026-09-04 用户拍板）：
    #    Win11"另存为"默认焦点在"文件名"框，直接往它写"整路径"会被当成文件名，
    #    界面看似保存成功、实际按默认目录/默认名落盘（已踩坑）。
    #    正确姿势 = 鼠标点"文件路径"组件(地址栏) → 输目标目录导航 →
    #               点回"文件名"框 → 输文件名 → 点"保存"按钮。
    save_dir = os.path.join(app_config.AGENT_TEMP_DIR, _SAVE_SUB_DIR)
    os.makedirs(save_dir, exist_ok=True)
    # 只保留本次最新成果：清掉上次验收遗留的 txt（跑完本次的成果会留下，勿删——
    # 曾在此 rmtree 把刚落盘的成果文件整个删掉，导致"报告成功却找不到文件"）
    try:
        for old in os.listdir(save_dir):
            if old.startswith("Lazaxa验收-") and old.endswith(".txt"):
                os.remove(os.path.join(save_dir, old))
    except OSError:
        pass
    fname = f"Lazaxa验收-{int(time.time()) % 100000}.txt"
    save_path = os.path.join(save_dir, fname)
    steps.append(f"目标目录={save_dir}，文件名={fname}")
    def _fill_filename(text):
        # 键盘兜底（UIA 全失败才用）：Alt+N 聚焦文件名框 -> 全选预填 -> 输入
        gui._keyboard_press(keys=['alt', 'n'])
        time.sleep(0.3)
        gui._keyboard_press(keys=['ctrl', 'a'])
        time.sleep(0.15)
        return gui._keyboard_type(text=text, window_title=dlg_title)

    # —— 第 1 步：点"文件路径"组件(地址栏) → 输目录路径 → 立刻回车导航 ——
    #    导航函数内含 Ctrl+L 聚焦兜底与地址栏名称回读断言；即使回读未确认
    #    （仅断言慢/名称格式差异）也不中断——继续第 2 步，最终以落盘断言为准。
    nav_ok, nav_note = _dlg_navigate_via_address_bar(dlg_hwnd, dlg_title, save_dir)
    steps.append(nav_note)
    if not nav_ok:
        steps.append('目录导航未确认，继续保存步骤（以落盘断言为准）')
    time.sleep(0.4)
    # —— 第 2 步：点回"文件名"框 → 写文件名 → 触发"保存"按钮（UIA 直操作，
    #    FileDialog 自动化范式：SetValue 写值免焦点 IME、Invoke 触发免坐标）——
    _, note_uia = _uia_save_via_controls(dlg_hwnd, fname, "文件名")
    steps.append(note_uia)
    time.sleep(1.5)
    if os.path.exists(save_path):
        steps.append('已提交保存：' + save_path)
    if not os.path.exists(save_path) and _wait_saveas_dialog(timeout=1.0):
        # UIA 两步都未落盘且对话框仍开 → 键盘兜底（Alt+N → 输入 → Enter → Alt+S）
        steps.append("UIA 保存未落盘，键盘兜底：Alt+N 输入文件名 + Enter")
        r = _fill_filename(fname)
        if r.ok:
            time.sleep(0.2)
            gui._keyboard_press(keys=['enter'])
            time.sleep(1.5)
            if _wait_saveas_dialog(timeout=2.0):
                gui._keyboard_press(keys=['alt', 's'])
                time.sleep(1.5)
                steps.append('键盘兜底：Alt+S 保存')
    if os.path.exists(save_path):
        steps.append('已提交保存：' + save_path)
    # ④ 落盘断言：文件存在且内容含中文文案（读盘 = 真实世界最终成果物）
    exists = os.path.exists(save_path)
    content_ok = False
    if exists:
        try:
            with open(save_path, "r", encoding="utf-8", errors="ignore") as f:
                content_ok = M3_TEXT in f.read()
        except Exception:
            pass
    if not exists:
        # 内容级全盘搜救：实测部分 Win11"另存为"会无视整路径/中文名，把文件落到
        # 默认目录、默认名（如 Documents\无标题.txt）。按"近 3 分钟新建且内容含
        # M3_TEXT"去找——命中就搬回验收目录并如实记录，证明保存链路真实成功，
        # 只是目录/命名没按对话框走（下轮据 saveas_uia_dump.txt 对症修框定位）。
        cand = None
        bases = [save_dir, app_config.AGENT_TEMP_DIR,
                 os.path.join(os.path.expanduser('~'), 'Documents'),
                 os.path.join(os.path.expanduser('~'), 'Desktop'),
                 os.path.join(os.path.expanduser('~'), 'Downloads'),
                 os.getcwd()]
        now = time.time()
        for base in dict.fromkeys(bases):
            if cand:
                break
            try:
                for f in os.listdir(base):
                    p = os.path.join(base, f)
                    if not (os.path.isfile(p) and f.lower().endswith('.txt')):
                        continue
                    try:
                        if now - os.path.getmtime(p) > 180:
                            continue
                    except Exception:
                        continue
                    try:
                        with open(p, 'r', encoding='utf-8', errors='ignore') as fh:
                            if M3_TEXT in fh.read():
                                cand = p
                                break
                    except Exception:
                        continue
            except Exception:
                continue
        if cand:
            try:
                os.makedirs(save_dir, exist_ok=True)
                if os.path.abspath(cand) != os.path.abspath(save_path):
                    shutil.move(cand, save_path)
                steps.append(f"另存为框未按目标目录/文件名落盘，内容先落 {cand}；已搬回 {save_path}")
                exists = True
                try:
                    with open(save_path, "r", encoding="utf-8", errors="ignore") as fh:
                        content_ok = M3_TEXT in fh.read()
                except Exception:
                    content_ok = False
            except Exception as e:
                steps.append(f"搜到内容在 {cand} 但搬回失败：{e}")
        else:
            dump_p = os.path.join(app_config.AGENT_TEMP_DIR, "saveas_uia_dump.txt")
            return False, (f"保存后未在磁盘生成文件（{save_path}），内容级搜救未命中"
                           f"（另存为框 UIA 树已落盘 {dump_p}，供对症）"), steps
    if not content_ok:
        return False, f"文件已生成但内容不含中文文案（可能是假保存/编码问题）：{save_path}", steps
    steps.append(f"文件已落盘且读盘命中中文内容：{save_path}")
    # ⑤ 优雅关闭：已保存 → 无确认框；意外弹框由 OCR 点"不保存"
    _close_window(hwnd)
    if not _notepad_gone(timeout=8.0):
        _click_ocr_button(("不保存", "Don't Save"), timeout=2.0)
        if not _notepad_gone(timeout=4.0):
            return False, "文件已保存但记事本窗口未关闭（残留）", steps
    steps.append("记事本优雅关闭（WM_CLOSE）")
    return True, "；".join(steps), steps


# ---------------------------------------------------------------------------
# 语义层：VLM 复核（可选，不可用/失败自动跳过，不阻塞链路）
# ---------------------------------------------------------------------------
def _vlm_review(hwnd) -> str:
    """用本地 VLM 复核当前记事本画面语义（演示"结构+文字+语义"多感知层协作）。"""
    reason = gui._vlm_available()
    if reason:
        return f"（VLM 不可用自动跳过：{reason[:40]}…）"
    region = None
    rect = _window_rect(hwnd)
    if rect:
        region = [rect[0], rect[1], rect[2] - rect[0], rect[3] - rect[1]]
    r = gui._screen_describe(
        region=region,
        question="这是什么应用窗口？当前编辑区能看到哪些文字？")
    if not r.ok:
        return "（VLM 调用失败自动跳过，不阻塞）"
    return (r.text or "")[:180]


def main() -> int:
    print("=" * 64)
    print("P3 GUI 里程碑真屏验收（引擎感知栈版 · 借微软 fara 行动-观察闭环）")
    print("=" * 64)
    # ---- 环境预检：逐层报告感知栈可用性（OCR 是文字层门禁） ----
    ocr_reason = gui._ocr_available()
    ui_reason = gui._ui_available()
    vlm_reason = gui._vlm_available()
    print(f"[感知栈] 结构层 UIA: {'就绪' if not ui_reason else '降级 → ' + ui_reason}")
    print(f"[感知栈] 文字层 OCR: {'就绪（' + app_config.OCR_LANG + '）' if not ocr_reason else '不可用 → ' + ocr_reason}")
    print(f"[感知栈] 语义层 VLM: {'就绪' if not vlm_reason else '跳过 → ' + vlm_reason}")
    if ocr_reason:
        print("❌ 文字层 OCR 不可用，验收无法形成视觉闭环。"
              "请安装 Tesseract 5.x（勾选 chi_sim 中文包）后重跑。")
        return 2
    log("")

    # ① 打开记事本 + 归零（结构层看标题 → 优雅关闭噪音窗 → 收敛到空白文档）
    r0 = win_tools._open_app(target="记事本")
    log(f"① open_app(记事本): {'✅' if r0.ok else '❌'} {r0.brief or r0.error}")
    if not r0.ok:
        return 2
    time.sleep(1.5)
    ok0, note0 = _milestone_reset()
    log("①·归零（结构层标题闭环）:", "✅" if ok0 else "❌", note0)
    if not ok0:
        return 2
    hwnd, title = _activate_first_blank()
    if not hwnd:
        log("❌", title)
        return 2
    log(f"✓ 前台就绪：『{gui._foreground_title()}』（结构层 window_control 激活）")
    log("")

    # ② M1 输入 → OCR 视觉闭环
    ok1, note1 = _milestone_input(hwnd)
    log(f"② 里程碑 M1【输入文本】: {'✅' if ok1 else '❌'} {note1}")
    if ok1:
        log(f"   [语义层] screen_describe 复核：{_vlm_review(hwnd)}")
    if not ok1:
        # 前台漂移属于环境问题（键鼠注入落空），里程碑失败才是引擎如实报告
        return 2 if not _is_foreground_notepad() else 1

    # ③ M2 清空 → OCR 视觉闭环
    ok2, note2 = _milestone_clear(hwnd)
    log(f"③ 里程碑 M2【清空收尾】: {'✅' if ok2 else '❌'} {note2}")
    if not ok2:
        return 1

    # ④ M3 保存并关闭 → 读盘断言
    ok3, note3, steps3 = _milestone_save_close(hwnd)
    log(f"④ 里程碑 M3【保存并关闭】: {'✅' if ok3 else '❌'} {note3}")
    if not ok3:
        if steps3:
            log("   已执行步骤：" + " → ".join(steps3))
        return 1

    log("")
    log("========== P3 验收结论 ==========")
    log("✅ 3/3 里程碑全部通过：M1 输入落地（OCR 看见）、M2 清空（OCR 不见）、")
    log("   M3 Ctrl+S 保存落盘（读盘断言中文内容）+ 优雅关闭。")
    log("   全程编排引擎感知栈原语：window_control / keyboard_type / keyboard_press /")
    log("   screen_ocr / screen_describe —— 与智能体真跑 GUI 任务同源同行为。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
