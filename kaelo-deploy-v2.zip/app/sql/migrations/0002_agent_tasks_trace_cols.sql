-- ============================================================
-- 0002_agent_tasks_trace_cols.sql · agent_tasks 增审计追溯列（P2-2）
--
-- 背景（2026-10-02 · 09-computer_use 对标方案 P2-2 审计增强）：
--   为「回溯为什么点了这里 / 这一步自动重试了几次」补两列。列定义已并入
--   app/db.py 的 _INIT_SQL（新库建表即含）；本文件是本次变更的版本化镜像，
--   供**已存在**的旧库手工补齐使用。
--
-- Schema 单一来源约定参见 0001_init.sql 头部：唯一权威 = app/db.py 的 _INIT_SQL。
-- 幂等性说明：MySQL 的 ALTER TABLE ADD COLUMN 不支持 IF NOT EXISTS，
--   服务侧由 app/db.py::_ensure_agent_tasks_trace_col()（先 SHOW COLUMNS 判断）
--   保证幂等；手工执行本文件前请先确认该列不存在，或忽略「Duplicate column」报错。
-- 执行方式：mysql -uroot personal_kb < sql/migrations/0002_agent_tasks_trace_cols.sql
-- ============================================================
USE personal_kb;

ALTER TABLE agent_tasks
  ADD COLUMN element_id VARCHAR(190) NULL
    COMMENT '本步定向操作的控件稳定引用（P2-2 回溯"为什么点了这里"）' AFTER ok;

ALTER TABLE agent_tasks
  ADD COLUMN retries INT UNSIGNED NULL
    COMMENT '本步自动重试次数（P2-2 里程碑断言失败重试）' AFTER element_id;
