-- ============================================================
-- 0001_init.sql · 初始表结构（7 张表）
--
-- Schema 单一来源约定（阶段 2 可靠性）：
--   1. 唯一权威 = app/db.py 的 _INIT_SQL（服务启动自动幂等建表）
--   2. 本目录 sql/migrations/ 是 db.py 建表逻辑的版本化镜像，
--      供人工初始化新机器 / 手工核对用（与 _INIT_SQL 保持一致）
--   3. schema 变更流程：改 app/db.py 的 _INIT_SQL（增量用 ALTER 放在代码里幂等执行）
--      + 新增 000N_描述.sql 记录本次变更
-- 执行方式：mysql -uroot < sql/migrations/0001_init.sql
-- 注意：建表均用 IF NOT EXISTS（幂等），不会覆盖已有数据。
-- ============================================================
CREATE DATABASE IF NOT EXISTS personal_kb
  DEFAULT CHARACTER SET utf8mb4;

USE personal_kb;

CREATE TABLE IF NOT EXISTS chat_sessions (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key      VARCHAR(50)  NOT NULL DEFAULT '',
  kb_name     VARCHAR(50)  NOT NULL DEFAULT '',
  model       VARCHAR(100) DEFAULT '',
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_kb_time (kb_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS chat_messages (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id    BIGINT UNSIGNED NOT NULL,
  role          ENUM('user','assistant') NOT NULL,
  content       MEDIUMTEXT      NOT NULL,
  kb_key        VARCHAR(50)  DEFAULT '',
  retrieved     JSON          NULL,
  query_used    VARCHAR(1000) DEFAULT '',
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_session (session_id, created_at),
  KEY idx_kb_time (kb_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS kb_docs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key      VARCHAR(50)   NOT NULL,
  kb_name     VARCHAR(50)   NOT NULL DEFAULT '',
  filename    VARCHAR(200)  NOT NULL,
  chunk_count INT UNSIGNED  DEFAULT 0,
  status      VARCHAR(20)   NOT NULL DEFAULT 'active',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_kb_file (kb_key, filename, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS highlights (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(200)  NOT NULL,
  content     TEXT          NOT NULL,
  category    VARCHAR(50)   NOT NULL DEFAULT '通用',
  tags        VARCHAR(255)  DEFAULT '',
  level       TINYINT       NOT NULL DEFAULT 3,
  source      VARCHAR(200)  DEFAULT '',
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_category (category),
  KEY idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_settings (
  `key`  VARCHAR(50)   NOT NULL PRIMARY KEY,
  value  VARCHAR(1000) DEFAULT '',
  updated_at DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='应用设置（API Key/模型等，网页可改）';

CREATE TABLE IF NOT EXISTS personal_profile (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  field       VARCHAR(50)   NOT NULL COMMENT '档案项（如 性格/背景/目标）',
  field_key   VARCHAR(50)   DEFAULT '' COMMENT '英文标志（可选）',
  content     TEXT          NOT NULL COMMENT '档案内容',
  visibility  VARCHAR(20)   NOT NULL DEFAULT 'private' COMMENT 'private/sensitive（默认私有）',
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_field (field)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='个人敏感档案（性格/背景/想法）';

CREATE TABLE IF NOT EXISTS api_keys (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL COMMENT '用途/说明（如 好友-聊天）',
  key_hash     CHAR(64)      NOT NULL COMMENT 'API Key 的 SHA-256 哈希（不存明文）',
  key_prefix   VARCHAR(16)   NOT NULL COMMENT 'Key 前 8 位，用于界面展示',
  scopes       VARCHAR(255)  NOT NULL DEFAULT '["chat"]' COMMENT '权限 JSON 数组',
  status       VARCHAR(20)   NOT NULL DEFAULT 'active' COMMENT 'active/disabled',
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_used_at DATETIME      NULL COMMENT '最近调用时间',
  UNIQUE KEY uk_hash (key_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对外 API 密钥（鉴权用，仅存哈希）';
