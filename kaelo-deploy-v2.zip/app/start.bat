@echo off
rem ==========================================
rem  Local Voice RAG Assistant (multi-KB)
rem  (pure ASCII to avoid codepage issues)
rem ==========================================
cd /d "%~dp0"

rem --- check Ollama (embedding engine) ---
echo [1/3] Checking Ollama on port 11434...
curl -s -o nul -w "%%{http_code}" http://localhost:11434/api/tags > %temp%\ollama_check.txt 2>nul
set /p OLLAMA_CODE=<%temp%\ollama_check.txt
if "%OLLAMA_CODE%"=="200" (
    echo       Ollama is running.
) else (
    echo       Ollama not running. Starting it...
    start "Ollama" ollama serve
    timeout /t 3 /nobreak >nul
)
del %temp%\ollama_check.txt >nul 2>&1

rem --- kill old server on port 8000 ---
echo [2/3] Releasing port 8000...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8000" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul

rem --- start server ---
echo [3/3] Starting server...
echo ==========================================
echo   Local:  http://127.0.0.1:8000
echo   LAN:    http://YOUR_IP:8000
echo ------------------------------------------
echo   LAN IP:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4" ^| findstr /v "127.0.0.1"') do echo           %%a:8000
echo ==========================================
echo.

if not exist "logs" mkdir logs
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 >> logs\rag_out.log 2>> logs\rag_err.log

pause
