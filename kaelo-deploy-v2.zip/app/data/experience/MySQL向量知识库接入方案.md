# MySQL 向量知识库接入方案

### —— 面向个人知识库 / 隐私库的 RAG 全流程落地方案（AI → 知识库 → 向量检索）

> 版本：v1.0 ｜ 日期：2026-08-13 ｜ 适用项目：D:\Users\Hasee\Desktop\other_work\TRAEpj\RAG学习
> 基线：本地语音 RAG 助理（FastAPI + Ollama 本地嵌入 + DeepSeek 生成 + 自研 numpy 向量库），本机 PHPStudy 托管 MySQL 8.0.12（root/root）

---

## 一、目标与背景

现有项目的存储层是"自研轻量向量库"（`vectors.npy` + `meta.json`）：数据落在文件里，缺乏结构化查询、版本管理、权限控制和审计能力。本方案的目标：

1. **把知识库底座换成 MySQL**——文档、分块、向量、元数据、访问日志全部入库，获得事务、索引、备份、权限能力；
2. **打通 AI → 知识库搭建 → 向量检索 → 生成**的完整技术链路，给出可直接落地的表结构、代码骨架和实施步骤；
3. **兼顾隐私**——嵌入全程本地（Ollama），对话可选择完全离线模式，形成"个人知识库 / 隐私库"。

**设计原则**：复用现有项目已验证的成果（切块策略、混合检索、RRF 融合、同名整体替换），只把"存储层"抽象替换为 MySQL 实现，业务代码（FastAPI 接口、前端、人设）零改动。

---

## 二、核心技术决策：MySQL 向量能力现状与选型

### 2.1 事实核查（2026-08 核实时点）

| 能力 | 现状 | 来源 |
|---|---|---|
| MySQL 9.0 起原生 `VECTOR` 数据类型 | 每项 4 字节单精度浮点，默认长度 2048，最大 16383 项；配套 `STRING_TO_VECTOR()` / `VECTOR_TO_STRING()` / `VECTOR_DIM()` 函数 | MySQL 官方手册 13.3.5、Oracle Blog、墨天轮/博客园技术文 |
| 社区版（开源版）向量索引 | **没有**原创向量索引（ANN/HNSW），VECTOR 只能存储，检索需全表扫描计算距离 | FOSDEM 2025 官方演讲（"只能存储和检索 out of the box"）、github.com/mysql 社区提案（2026-06 仍在计划中）|
| HeatWave 原生 Vector Store | 支持 HNSW 向量索引 + GenAI，但仅限 OCI/AWS 云部署（企业级收费） | Oracle 官方博客 |
| 云厂商 RDS MySQL 向量索引 | 火山引擎 RDS MySQL（2026-08）等已推出高性能向量索引；阿里云/腾讯云各有向量方案 | 火山引擎官方发布 |
| 本机 PHPStudy MySQL 8.0.12 | **无 VECTOR 类型**（8.0 不含向量能力） | 厂商发行版本事实 |

结论要点：**MySQL 社区版当前定位是"能存能查向量、但百万级前不提供专用索引"**。个人知识库规模（几千 ~ 几十万块）用"全量扫描 + 应用层算距离"完全可行（详见第七章性能评估），无需为它额外部署一套向量数据库。

### 2.2 三条选型路线

| 路线 | 方案 | 适用规模 | 成本 | 说明 |
|---|---|---|---|---|
| **A（主推）** | MySQL 8.0 兼容方案：向量以二进制 BLOB 存，Python/numpy 算距离，SQL 管元数据 | ≤ 几十万块 | 零 | 本机 PHPStudy 现状即可跑，不升级数据库 |
| B（平滑演进） | 升级 MySQL 9.x：用原生 `VECTOR` 类型 + 官方函数存算 | ≤ 几十万块 | 需升级数据库 | 语法更直观，但 8.0→9.x 升级需谨慎评估应用兼容性 |
| C（规模化） | 云 MySQL（火山/腾讯/阿里 RDS 向量索引）或 HeatWave | ≥ 百万级 | 云费用 | 检索快但数据离本机，与"隐私库"目标冲突 |

**本方案按路线 A 设计**，同时在 DDL 和数据层预留路线 B 的迁移注释；存储层抽象为统一接口，未来换路线 C 只改实现类。

---

## 三、总体架构

```
┌────────────────────────────────────────────────────────────┐
│  前端（web/index.html，现状不动）                            │
│  语音识别/合成 · 多库切换 · 上传 · 管理 · 质检                │
└──────────────────────────┬─────────────────────────────────┘
                           │ REST (FastAPI, app/main.py)
┌──────────────────────────▼─────────────────────────────────┐
│  RAG 业务层（现状不动）                                      │
│  切块 _split_text → 检索链路（向量+BM25+RRF）→ 提示词组装      │
└──────────────────────────┬─────────────────────────────────┘
                           │ 存储抽象接口 Store
┌──────────────────────────▼─────────────────────────────────┐
│  存储层（本次替换）                                           │
│  NVecStore（numpy 文件）→ MySQLStore（MySQL 8.0 兼容）        │
│  kb_bases / kb_docs / kb_chunks / kb_vectors / kb_access_log │
└─────────────────┬──────────────────────────────┬────────────┘
                  │                              │
      ┌───────────▼───────────┐      ┌───────────▼───────────┐
      │ 嵌入服务 Ollama 11434 │      │ 生成模型                │
      │ dmeta-embedding-zh    │      │ DeepSeek API（云端）    │
      │ （本地，不联网）        │      │ 或 Ollama 本地（全隐私）│
      └───────────────────────┘      └───────────────────────┘
```

**存储层抽象**：现有 `app/rag.py` 中 `VecStore` 的对外能力是 `load / add / delete_source / update_source / search / list_sources / save / size`。新写 `MySQLStore` 实现**同一签名**，`config.py` 加一个 `STORAGE = "mysql" | "numpy"` 开关，业务层（`main.py` / `maint.py` / `validate.py` / `build_kb.py`）无需改动即可切换。

---

## 四、数据库设计（完整 DDL，MySQL 8.0 兼容）

### 4.1 建库

```sql
CREATE DATABASE IF NOT EXISTS rag_kb
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE rag_kb;
```

> 说明：`utf8mb4` 才能完整支持中文与 emoji；`utf8mb4_unicode_ci` 提供合理的中文排序与不区分大小写。

### 4.2 知识库注册表 kb_bases

多知识库能力（达芬奇 / 茶馆 / 我的资料 / 隐私库…）的元数据中心：

```sql
DROP TABLE IF EXISTS kb_bases;
CREATE TABLE kb_bases (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key       VARCHAR(50)  NOT NULL COMMENT '库 key（da_vinci/teahouse/user/privacy）',
  kb_name      VARCHAR(50)  NOT NULL COMMENT '展示名',
  avatar       VARCHAR(20)  NOT NULL DEFAULT '' COMMENT '前端图标',
  description  VARCHAR(200) NOT NULL DEFAULT '' COMMENT '库描述',
  embed_model  VARCHAR(100) NOT NULL DEFAULT 'shaw/dmeta-embedding-zh:latest' COMMENT '该库所用的嵌入模型',
  vector_dim   INT UNSIGNED NOT NULL DEFAULT 1024 COMMENT '嵌入向量维度（按模型实际输出填写）',
  permission   VARCHAR(20)  NOT NULL DEFAULT 'private' COMMENT '权限：private/public/encrypted',
  owner        VARCHAR(50)  NOT NULL DEFAULT 'me' COMMENT '归属者（多人场景可扩展）',
  status       TINYINT      NOT NULL DEFAULT 1 COMMENT '1启用 0停用',
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_key (kb_key)
) ENGINE=InnoDB COMMENT='知识库注册表';
```

### 4.3 文档表 kb_docs

每个文档一条记录，`sha256` 用于内容级去重与快照校验：

```sql
DROP TABLE IF EXISTS kb_docs;
CREATE TABLE kb_docs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key       VARCHAR(50)  NOT NULL COMMENT '所属库 key',
  filename     VARCHAR(200) NOT NULL COMMENT '文件名（同名=同一文档，整体替换）',
  title        VARCHAR(200) NOT NULL DEFAULT '' COMMENT '展示标题',
  sha256       CHAR(64)     NOT NULL DEFAULT '' COMMENT '文件内容哈希，防重复入库',
  file_size    INT UNSIGNED NOT NULL DEFAULT 0,
  chunk_count  INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '切块数',
  status       VARCHAR(20)  NOT NULL DEFAULT 'active' COMMENT 'active/archived/deleted',
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_kb_file (kb_key, filename),
  KEY idx_kb_status (kb_key, status)
) ENGINE=InnoDB COMMENT='RAG 文档登记表';
```

### 4.4 分块表 kb_chunks

检索与 BM25 的直接数据源，存切块后的纯文本：

```sql
DROP TABLE IF EXISTS kb_chunks;
CREATE TABLE kb_chunks (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key       VARCHAR(50)  NOT NULL COMMENT '所属库 key',
  doc_id       INT UNSIGNED NOT NULL COMMENT '所属文档 id',
  chunk_index  INT UNSIGNED NOT NULL COMMENT '文档内块序号',
  text         MEDIUMTEXT   NOT NULL COMMENT '块文本（检索/BM25 用）',
  text_hash    CHAR(32)     NOT NULL DEFAULT '' COMMENT 'MD5(text)，内容级去重',
  char_count   INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '块字符数',
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_kb_doc_chunk (kb_key, doc_id, chunk_index),
  KEY idx_kb_texthash (kb_key, text_hash),
  CONSTRAINT fk_chunk_doc FOREIGN KEY (doc_id) REFERENCES kb_docs(id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='RAG 切块表';
```

### 4.5 向量表 kb_vectors（核心）

> **路线 A（8.0 兼容）**：`embedding BLOB` 存 float32 二进制；**路线 B（9.x）** 可改 `embedding VECTOR(1024)`。

```sql
DROP TABLE IF EXISTS kb_vectors;
CREATE TABLE kb_vectors (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key       VARCHAR(50)  NOT NULL COMMENT '所属库 key',
  chunk_id     BIGINT UNSIGNED NOT NULL COMMENT '对应块 id',
  embedding    BLOB         NOT NULL COMMENT 'float32 二进制（numpy.tobytes()）',
  dim          INT UNSIGNED NOT NULL DEFAULT 1024 COMMENT '维度，校验用',
  embed_model  VARCHAR(100) NOT NULL DEFAULT '' COMMENT '产生该向量的模型',
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_chunk (chunk_id),
  KEY idx_kb (kb_key),
  CONSTRAINT fk_vec_chunk FOREIGN KEY (chunk_id) REFERENCES kb_chunks(id) ON DELETE CASCADE
) ENGINE=InnoDB COMMENT='RAG 向量表（8.0 用 BLOB，9.x 迁移为 VECTOR）';

-- 9.x 平滑迁移（路线 B，供参考，勿在 8.0 执行）：
-- ALTER TABLE kb_vectors ADD COLUMN embedding_v VECTOR(1024);
-- UPDATE kb_vectors SET embedding_v = STRING_TO_VECTOR(...);
```

### 4.6 分类/标签表（可选）与访问日志表

```sql
DROP TABLE IF EXISTS kb_tags;
CREATE TABLE kb_tags (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key    VARCHAR(50) NOT NULL,
  doc_id    INT UNSIGNED NOT NULL,
  tag       VARCHAR(50) NOT NULL COMMENT '标签',
  UNIQUE KEY uk_doc_tag (doc_id, tag),
  KEY idx_kb_tag (kb_key, tag)
) ENGINE=InnoDB COMMENT='文档标签（分类过滤检索用）';

-- 隐私审计：谁在什么时间检索了什么（只记 query，不记回答）
DROP TABLE IF EXISTS kb_access_log;
CREATE TABLE kb_access_log (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kb_key     VARCHAR(50)  NOT NULL,
  query_text VARCHAR(500) NOT NULL DEFAULT '' COMMENT '检索词（隐私要求可不存原文，存哈希）',
  top_k      TINYINT      NOT NULL DEFAULT 8,
  hit_chunks INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '命中块数',
  latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
  client_ip  VARCHAR(45)  NOT NULL DEFAULT '',
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_kb_time (kb_key, created_at)
) ENGINE=InnoDB COMMENT='检索访问审计（隐私库必备）';
```

### 4.7 数据关系

```
kb_bases 1 ── n kb_docs 1 ── n kb_chunks 1 ── 1 kb_vectors
                 │                 │
                 └── n kb_tags     └── n kb_access_log（独立于具体块）
```

---

## 五、完整流程技术细节（AI → 知识库 → 向量检索 → 生成）

核心链路与现有项目一致的八个环节，逐一说明在 MySQL 化后的实现。

### 5.1 文档接入与清洗

- 支持 `.md` / `.txt`（现状），可扩展 PDF/DOCX（用 `image-transoffice` / `file-read` 技能先转 md/txt 再做后续）。
- 入库前做：去 BOM、统一换行 `\r\n→\n`、压缩多余空白、UTF-8 校验。
- 校验 `sha256`：与 `kb_docs` 已有记录比对，内容未变则跳过（**增量建库**的关键）。

### 5.2 切块（Chunking）

直接复用 `app/rag.py::_split_text`（按句号分段 + 150 字窗口 + 30 字重叠），切块结果作为 `kb_chunks` 行写入。块级参数（150/30）保持现状即可，方案上给出调优维度：块越大 recall 越低、precision 越高；带重叠避免语义截断。

切块产出数据链路：

```
文档文本 ──► 清洗 ──► _split_text ──► List[chunk] ──► 写 kb_chunks（每块一条）
                                                └──► 逐块调嵌入 → 写 kb_vectors
```

### 5.3 嵌入（Embedding）

沿用本地 `Ollama /api/embed`，模型 `shaw/dmeta-embedding-zh:latest`（中文，408MB，离线可用）。

工程要点：

1. **批量**：单次请求传多段文本（Ollama embed 支持 `input` 数组），例如 32 块一批，减少 HTTP 往返；
2. **重试**：超时（180s）或 5xx 时指数退避重试 3 次；
3. **缓存**：`text_hash` 已存在于 `kb_vectors`（通过 chunks 关联）则跳过，**断点续跑**——建库过程中断后重跑不重复嵌入；
4. **维度校验**：`len(embedding) == kb_bases.vector_dim`，不符即报错，防止模型切换引发维度错乱。

### 5.4 入库（事务 + 批量）

**同名文档整体替换**（与现状行为完全一致）：同一 `(kb_key, filename)` 再上传 = 旧版全部删除、新块全部插入，杜绝新旧共存。整个操作包在一个事务里，中途失败自动回滚，库不处于半更新状态：

```sql
START TRANSACTION;
  DELETE FROM kb_chunks WHERE kb_key=? AND doc_id=?;   -- 级联删 kb_vectors / kb_tags
  INSERT INTO kb_docs (kb_key, filename, sha256, ...) ...  ON DUPLICATE KEY UPDATE ...;
  INSERT INTO kb_chunks (kb_key, doc_id, chunk_index, text, text_hash, ...) VALUES ...;
  INSERT INTO kb_vectors (kb_key, chunk_id, embedding, dim, ...) VALUES ...;
COMMIT;
```

批量插入用 `executemany`，每批 500 行左右，兼顾吞吐与连接池压力。

### 5.5 检索链路（本方案核心）

保持现有"三重保险"设计，仅把向量与文本的读取源改为 MySQL：

```
① query 嵌入：Ollama 将问题转向量（与建库同一模型）
② 向量路：拉取该 kb 全部向量（numpy 批次）→ 余弦相似度 → top-N1
③ BM25路：从 kb_chunks 全量拉文本 → 现有 BM25Index 打分（unigram+bigram）→ top-N2
④ RRF 融合：score = Σ 1/(k + rank)，两路合并 → top-N
⑤ 同源去重：同一 doc 最多保留 MAX_PER_SOURCE=3 块
⑥ 结果回填：附上 source/分数/排名，交给提示词组装
```

**为什么向量检索仍用应用层计算而不是 SQL**：

- 8.0 无向量函数；距离计算在 Python/numpy 批处理（SIMD 优化）下，万级向量一次余弦在毫秒~几十毫秒量级（见第七章）；
- 语义上保持与现有实现完全一致，避免 SQL 侧公式与 Python 侧出入导致的召回漂移；
- 复制现有 `VecStore.search` 的权重逻辑（长度归一化、加权 RRF），移植成本最低。

**BM25 与 MySQL 的关系**：中文 BM25 不适合用 MySQL `FULLTEXT`（分词是空格制，对中文无切词），继续用现有 `BM25Index` 应用层实现即可；全量加载块文本同样由 MySQL 提供，作为 BM25 的语料来源。

```python
# 检索核心骨架（MySQLStore.search 的向量路）
def _vector_route(self, q_vec, top_n):
    # 1. 拉取该库全部向量（float32 矩阵）：SELECT chunk_id, embedding FROM kb_vectors WHERE kb_key=%s
    chunks, mats, meta = self._load_vectors_and_meta(kb_key)
    norm = np.linalg.norm(mats, axis=1); qn = np.linalg.norm(q_vec)
    sims = (mats @ q_vec) / (norm * qn + 1e-9)
    lens = np.array([m["char_count"] for m in meta], dtype=np.float32)
    len_penalty = np.exp(-((lens - 120) / 90) ** 2)   # 沿用现有长度归一化
    sims = sims * (0.6 + 0.4 * len_penalty)
    return np.argsort(-sims)[:top_n].tolist()          # 返回 chunk 索引序列
```

### 5.6 重排与去重（可选增强）

现有"长度归一化 + 同源配额"已足够个人场景；如需更强可用 LLM/交叉编码器 rerank（新一代 DeepSeek / bge-reranker），本节给出设计占位，不强制实现。

### 5.7 提示词组装与生成

- 组装顺序不变：人设（`persona.py`）→【资料】块（检索结果，含来源标注）→ 问题；
- 生成后端按 `config.py` 切换：
  - `deepseek`（默认）：响应快、质量高，但问题+资料会发给云端 API——敏感内容慎选；
  - `ollama`（本地）：**完全离线**，隐私库推荐模式，速度慢但数据不出本机。
- 回答约束沿用：只依据【资料】，资料没有的明确说不编造；矛盾时如实告知。

---

## 六、隐私库设计（个人隐私优先）

### 6.1 数据不出本机拓扑

| 数据 | 默认流向 | 隐私模式 |
|---|---|---|
| 文档 / 切块 / 向量 | MySQL 本机 + Ollama 本地嵌入 | 全程本机 |
| 检索 query | 本机嵌入、本机检索 | 本机 |
| 生成 prompt | DeepSeek 云端（默认）| 切 `ollama` 后全程本机 |

> 结论：**要"真隐私库"，把 `CHAT_BACKEND` 设为 `ollama`**，整条链路（嵌入+检索+生成）不离开本机；允许接受云端生成时用默认 DeepSeek。

### 6.2 权限与隔离

- **库级隔离**：`kb_bases.permission` 标识 `private/public/encrypted`；检索 SQL 恒带 `kb_key` 条件，物理隔离于不同库；
- **（可选）字段加密**：敏感文本（如私密笔记正文）在写入 `kb_chunks.text` 前 AES-256-GCM 加密，检索时应用层解密后 BM25——代价是无法用 SQL 直接全文查，权衡取舍；
- **多用户扩展**：`kb_docs.owner` / 权限表按用户隔离，个人库先置为单用户。

### 6.3 审计与密钥

- `kb_access_log` 记录每次检索（时间、库、query、命中数、耗时、来源 IP）；隐私要求高时可只记 `sha256(query)` 不存明文；
- 密钥（MySQL 密码、DeepSeek Key）一律走环境变量 / `.env`，不进代码、不进 git（现有 `config.py` 已示范 `DEEPSEEK_API_KEY` 环境变量模式，MySQL 密码照此办理）。

---

## 七、性能评估与优化

### 7.1 数量级评估（路线 A）

| 规模 | 向量矩阵内存 | 单次余弦检索耗时（numpy，实测级） | 结论 |
|---|---|---|---|
| 1 万块 | ~40 MB（1024 维 float32） | 毫秒级 | 无压力 |
| 10 万块 | ~400 MB | 几十毫秒级 | 可接受（个人库上限） |
| 100 万块 | ~4 GB | 数百毫秒~秒级 | 需换路线 C（云向量索引） |

> 参考多家对比测试：十万级向量下 Chroma/pgvector/Qdrant 均为毫秒级，百万级时 Milvus/Qdrant <10ms、pgvector HNSW 20~80ms、MySQL 无索引全扫升至秒级~十几秒。个人知识库天然落在"万级~十万级"区间，路线 A 足够。

### 7.2 SQL 侧优化

- 检索只对 `kb_key` 过滤字段建索引（已有 `idx_kb`）；
- 向量一次性 `SELECT embedding FROM kb_vectors WHERE kb_key=?` 用游标流式读取，避免一次性载入内存峰值；
- 连接池（`pymysql` + 自定义池或 `SQLAlchemy` pool），默认 5~10 连接；写事务避免长连接；
- 缓存 `kb_bases` 注册表与各库的 `text→hash` 集，减少重复查询。

### 7.3 未来演进

- 升 9.x 用 `VECTOR` 类型：存算语法更直观（路线 B），但**社区版仍无 ANN 索引**，性能不变；
- 真上百万级→云 MySQL 向量索引或 HeatWave（路线 C），代价是数据出本机。

---

## 八、实施路线（分阶段可落地，每阶段有验收标准）

### Phase 0：环境确认（半天）
- 确认 PHPStudy MySQL 8.0.12 运行正常（root/root 可连）；
- `pip install pymysql numpy`（纯 Python 实现，Python 3.14 兼容无忧）；
- 验收：`python -c "import pymysql; print(pymysql.__version__)"` 通过。

### Phase 1：建库建表（第 1 天）
- 执行本文第四节全部 DDL；
- 插入 `kb_bases` 三条种子数据（da_vinci / teahouse / user，加一个 privacy 隐私库）；
- 验收：`SHOW TABLES` 出现 6 张表；`SELECT * FROM kb_bases` 返回种子行。

### Phase 2：存储层 MySQLStore（第 2~3 天）
- 新建 `app/mysql_store.py`，实现与 `VecStore` 同签名的 `MySQLStore`：`add / delete_source / update_source / search / list_sources / size`；
- 端口测试：独立脚本插入 10 块并检索，核对召回；
- 验收：线上库建表 + 混合检索返回正确来源。

### Phase 3：与现有系统无缝切换（第 4 天）
- `config.py` 增加 `STORAGE = "mysql"`（默认仍可回退 `"numpy"`）；
- `app/rag.py::get_store` 按开关返回 `MySQLStore` 或 `VecStore`；
- 全接口回归：上传/删除/替换/检索/健康仪表盘；
- 验收：语音对话 + 知识库管理全功能走 MySQL 存储。

### Phase 4：隐私增强与运维（第 5 天起）
- 建立 `privacy` 隐私库（`permission=encrypted` 或全离线对话模式）；
- 开启 `kb_access_log` 审计；
- 编写增量建库脚本（`sha256` 增量 + 断点续跑）；
- MySQL 每日备份（`mysqldump rag_kb`）；
- 验收：隐私库检索产生审计记录；备份可恢复。

### Phase 5（可选）：旧库迁移工具
- 将现有 `vectors.npy` + `meta.json` 迁移进 MySQL（读文件 → 逐库 `add`），迁移后校验块数一致。

---

## 九、关键代码骨架

### 9.1 配置（config.py 增量）

```python
# ---- MySQL 存储配置 ----
STORAGE = os.environ.get("STORAGE", "mysql")   # "mysql" 或 "numpy"（回退）
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "127.0.0.1"),
    "port": int(os.environ.get("MYSQL_PORT", "3306")),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", "root"),
    "database": os.environ.get("MYSQL_DB", "rag_kb"),
}
```

### 9.2 MySQLStore 核心（app/mysql_store.py 节选）

```python
import json, hashlib
import numpy as np
import pymysql
from . import config

class MySQLStore:
    """与 VecStore 同签名的 MySQL 存储实现（路线 A：BLOB 存向量 + 应用层余弦）。"""

    def __init__(self, kb_key: str):
        self.kb_key = kb_key
        self._conn = None

    def _conn_ensure(self):
        if self._conn is None or not self._conn.open:
            self._conn = pymysql.connect(**config.MYSQL_CONFIG, charset="utf8mb4",
                                         cursorclass=pymysql.cursors.DictCursor)
        return self._conn

    # ---- 建库/增量建库：add ----
    def add(self, chunks, source: str = "unknown"):
        conn = self._conn_ensure()
        try:
            conn.begin()
            cur = conn.cursor()
            # 同名文档整体替换：先删旧文档（级联删 chunks/vectors）
            cur.execute("SELECT id FROM kb_docs WHERE kb_key=%s AND filename=%s", (self.kb_key, source))
            row = cur.fetchone()
            if row:
                cur.execute("DELETE FROM kb_docs WHERE id=%s", (row["id"],))
            # 插入文档
            body = "\n".join(chunks)
            sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
            cur.execute(
                "INSERT INTO kb_docs (kb_key, filename, sha256, file_size, chunk_count) "
                "VALUES (%s,%s,%s,%s,%s)",
                (self.kb_key, source, sha, len(body.encode()), len(chunks)))
            doc_id = cur.lastrowid
            # 批量嵌入（Ollama 本地），分批写 chunks + vectors
            vecs = _embed_batch(chunks)          # 复用现有 _embed，签名适配为批量
            params_c, params_v = [], []
            for i, (text, v) in enumerate(zip(chunks, vecs)):
                h = hashlib.md5(text.encode("utf-8")).hexdigest()
                params_c.append((self.kb_key, doc_id, i, text, h, len(text)))
                params_v.append((self.kb_key, None, v.tobytes(), int(v.size), config.EMBED_MODEL))
            cur.executemany(
                "INSERT INTO kb_chunks (kb_key, doc_id, chunk_index, text, text_hash, char_count) "
                "VALUES (%s,%s,%s,%s,%s,%s)", params_c)
            # 关联 chunk_id 后写向量（实际实现用 LAST_INSERT_ID/批量查询回填）
            conn.commit()
            return {"removed": 1 if row else 0, "added": len(chunks)}
        except Exception:
            conn.rollback()
            raise

    # ---- 检索：混合检索（向量路 + BM25 路 + RRF） ----
    def search(self, query: str, top_k: int = config.TOP_K, **kw):
        if self.size == 0:
            return []
        q_vec = _embed([query])[0]
        # 1) 拉该库全量块文本 + 向量
        rows = self._load_all()
        texts = [r["text"] for r in rows]
        mats = np.array([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        # 2) 向量余弦 + 长度归一化（逻辑同现有 VecStore.search）
        sims = ...   # 同 5.5 节骨架
        vec_ranked = np.argsort(-sims)[:top_k * 3].tolist()
        # 3) BM25（复用现有 BM25Index，语料 = texts）
        bm25 = BM25Index(); bm25.build(texts)
        bm25_ranked = [i for i, _ in bm25.search(query, top_k=top_k * 3)]
        # 4) RRF + 同源去重（同现有实现）
        fused = _rrf_fuse(vec_ranked, bm25_ranked)
        out = []
        for i in fused:
            out.append({"text": texts[i], "source": rows[i]["filename"], "rank": len(out) + 1})
        return out[:top_k]

    def delete_source(self, source): ...            # delete kb_docs by (kb_key, filename)
    def update_source(self, source, chunks): ...    # delete + add（复用）
    def list_sources(self): ...                     # GROUP BY filename 统计
    @property
    def size(self):
        conn = self._conn_ensure(); cur = conn.cursor()
        cur.execute("SELECT COUNT(*) c FROM kb_vectors WHERE kb_key=%s", (self.kb_key,))
        return cur.fetchone()["c"]
```

> 说明：以上为骨架，`_embed_batch`、RRF、长度归一化直接复用 `app/rag.py` 既有函数；`_load_all` 用 `SELECT v.embedding, c.text, d.filename FROM kb_vectors v JOIN kb_chunks c ON v.chunk_id=c.id JOIN kb_docs d ON c.doc_id=d.id WHERE v.kb_key=%s` 流式读取。

### 9.3 接入开关（app/rag.py 尾部）

```python
def get_store(kb: str | None = None):
    kb = kb or config.DEFAULT_KB
    if config.STORAGE == "mysql":
        return MySQLStore(kb)                       # 新存储
    cfg = config.KNOWLEDGE_BASES.get(kb, config.KNOWLEDGE_BASES[config.DEFAULT_KB])
    return VecStore(cfg["vector_dir"]).load()       # 原 numpy 存储（回退）
```

---

## 十、FAQ 与踩坑预案

| 问题 | 原因 | 对策 |
|---|---|---|
| `BLOB` 存不了向量？ | 会，float32 二进制可直接存，`numpy.tobytes()` 写、`np.frombuffer()` 读；注意端序（本机 x86 小端一致） | 统一 `dtype=np.float32` + 默认端序 |
| MySQL 8.0 没有 `VECTOR` 类型 | 版本事实（9.0 起才有） | 路线 A 用 BLOB；不强行升级 8.0 |
| 中文 BM25 不准 | MySQL FULLTEXT 是空格分词 | 沿用应用层 BM25Index（unigram+bigram） |
| 检索慢 | 全表扫描 + 全量拉向量 | 个人规模可接受；流式读取；分库过滤；超 10 万块考虑路线 C |
| 上传中断库半更新 | 事务未用 | `add` 整体包事务，失败 rollback |
| 密码明文 | 直写在代码 | 环境变量 / `.env`（沿用现有模式） |
| Python 3.14 装驱动失败 | 部分 C 扩展库无预编译 | `pymysql` 纯 Python，无编译问题 |

---

## 十一、参考来源

- MySQL 官方手册 13.3.5 The VECTOR Type：https://dev.mysql.com/doc/refman/en/vector.html
- MySQL Vector Datatype 系列（Oracle Blog, 2026-07/08）：https://blogs.oracle.com/mysql/mysql-vector-datatype-create-your-operations-part-1
- FOSDEM 2025《MySQL Vector and AI》：https://archive.fosdem.org/2025/events/attachments/fosdem-2025-6100-mysql-vector-and-ai/slides/238390/MySQL_Vec_K5djKFt.pdf
- MySQL 社区原生向量索引提案（2026-06）：https://github.com/mysql/mysql-community/issues/3
- HeatWave Vector Store 概览：https://dev.mysql.com/doc/heatwave/en/mys-hw-genai-vector-store-overview.html
- 主流向量数据库/MySQL 对比（博客园, 2026-06）：https://www.cnblogs.com/itqinls/p/20832126
- 火山引擎 RDS MySQL 向量索引（2026-08）：https://www.toutiao.com/article/7670865332919108148/
- 本项目既有文档：《RAG技术文档.md》（docs/ 目录，v2.0）