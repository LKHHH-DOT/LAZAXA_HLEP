# SelfIterate —— 本地语音 RAG 个人知识助手（四库架构）

一个语音对话助手：你对着麦克风说话（或输入文字）→ 识别成文字 → 从知识库检索 → 生成模型（DeepSeek API / 本地 Ollama）约束回答 → 语音朗读出来。

**不训练模型**——用 RAG 检索增强让 AI 依据你准备的知识库回答。知识库采用 **三分支 + 一总库** 架构，问答更全面、更精准。知识库 + MySQL 都搜不到时，自动联网搜索（Tavily）兜底，保证"问什么都能答"。

- **项目路径**：`D:\Users\Hasee\Desktop\Kaelo\SelfIterate`
- **统一人设**：`assistant`（个人知识助手），不扮演任何角色
- **默认知识库**：`master`（总库）
- **嵌入模型**：Ollama `bge-m3`（本地中文，1024 维，约 1.2GB）
- **状态**：已完成工业级升级（阶段 0-3），详情见根目录 `docs/项目诊断与工业级升级路线.md`

---

## 一、快速开始

### 1. 环境准备
- Python 3.11+，安装依赖：`pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple`
- **Ollama** 已启动且拉取嵌入模型：`ollama pull bge-m3`
- **MySQL**（PHPStudy 等）运行中，建库 `personal_kb`（表结构服务启动时自动创建）

### 2. 配置密钥（根目录 `.env`，可复制 `.env.example`）
```env
DEEPSEEK_API_KEY=sk-xxxx            # DeepSeek 生成模型 Key
DEEPSEEK_BASE_URL=https://api.deepseek.com
TAVILY_API_KEY=                     # Tavily 联网搜索 Key（不填则关闭联网）
OLLAMA_HOST=http://localhost:11434
MYSQL_HOST=127.0.0.1  MYSQL_PORT=3306  MYSQL_USER=root  MYSQL_PASSWORD=  MYSQL_DB=personal_kb
ADMIN_TOKEN=                        # 管理令牌（必填，管理接口鉴权用；可用 python -c "import secrets;print(secrets.token_urlsafe(32))" 生成）
```

### 3. 启动
```
双击 start.bat   （自动检查 Ollama、释放端口、启动 uvicorn 0.0.0.0:8000）
```
浏览器打开 **http://127.0.0.1:8000**（局域网设备用 `http://本机IP:8000`）。
管理后台 **http://127.0.0.1:8000/admin**（输入 ADMIN_TOKEN）。

### 4. 测试与检索评测
```bash
python -m pytest -q                   # 单元 + 接口测试（613 个）
python scripts/eval_rag.py            # 金标问题回归评测（当前 top-1 命中率 100%）
```

---

## 二、知识库配置（config.py KNOWLEDGE_BASES）

四个库，统一人设 `assistant`（个人知识助手）：

| 库 key | 名称 | 用途 | 属性 |
|---|---|---|---|
| `master` | 🧠 总知识库 | **默认问答库**：全库检索，自动同步三个分支 | `is_master=True`，`branches=["experience","personal","knowledge"]` |
| `experience` | 💼 经验库 | 工作项目经验 | 分支库 |
| `personal` | 👤 个人库 | 个人性格 / 想法 / 私密资料 | 分支库 |
| `knowledge` | 📚 知识库 | 通用知识 | 分支库 |

```
              ┌──────── 总知识库 master ────────┐
              │   (自动同步三个分支的全部文档)       │
              └───────┬──────────┬──────────┬───┘
                      │          │          │
              ┌───────▼──┐  ┌────▼─────┐  ┌─▼────────┐
              │ Experience│  │ Personal │  │ Knowledge │
              │  经验库    │  │  个人库   │  │  知识库   │
              └──────────┘  └──────────┘  └──────────┘
```

`DEFAULT_KB = "master"`

> 换嵌入模型（如 dmeta → bge-m3）后**必须清空旧向量库**再重启，服务会自动全量重建（新旧维度混用会崩溃）。

---

## 三、检索架构

### 1. 分支库提问
- 只搜本库 + MySQL 内容（高亮 / 档案 / 对话历史）

### 2. 总库 master 提问
- 三库同搜（master 天然含全部分支文档）

### 3. MySQL 内容独立向量库
- 独立向量库 `data/vector_store_mysql`，每次检索前增量同步

### 4. 检索合并策略
- 本地库 `TOP_K = 15` 条 + MySQL 内容最多 `MYSQL_HITS_LIMIT = 6` 条（先取大候选池降噪再截断），合并去重后按车道分组

### 5. 混合检索
- 向量余弦（bge-m3，1024 维）+ BM25 关键词（unigram+bigram）+ RRF 融合（k=60）
- **标题 boost**：块首行为 Markdown 标题且与查询字面共现 ≥2 词时加权（1.2 / 1.35），让"标题精确命中"胜过"正文语义接近"
- **长度归一化**：压制又长又泛的开场块，抬高短而具体的块
- 同源去重：`MAX_PER_SOURCE = 5`

### 6. 多车道检索（借 kada 医学库经验）
按内容类型分三条车道（项目经验 / 学习路线 / 自我认知），各留名额，避免某一类资料占满名额把另一类顶出去。
- 车道只决定**排序与分类配额**；候选必须**同时命中原查询**（相关性闸门），不给小库硬塞无关资料
- 上下文按车道分组加小标题；`meta.sources[].lane` 可查每块归属
- 可通过 `config.LANES_ENABLED` 关闭

### 7. LLM 检索词改写
- **每一轮（含首轮）**都用 LLM 把口语扩成检索关键词串，桥接"用户语言 ↔ 资料术语"；失败/超时降级为"上一轮问题 + 原文"

### 8. 检索质量自检
- 命中太少或分数 < 0.30 时用原文重查一次
- `/api/health` 的 `vector_integrity` 逐库报告"块数 vs 向量数"，`ok=false` 表示语义检索已静默降级，用 `python scripts/embed_increment.py <kb>` 补齐

### 9. 联网搜索兜底（Tavily）
知识库 + MySQL 都没搜到相关内容时，自动联网搜索补充。

- **双触发机制**：前置（合并检索为空/最高分 < 0.35）+ 后置（AI 拒答话术且未联网过）
- **来源展示**：网络结果在来源区显示 `🌐 [网络]` 标签，可点击打开原网页
- **配置**：后台 🔑 设置面板或 `.env` 填 Tavily Key；不填则自动跳过

---

## 四、技术栈

| 层 | 方案 |
|---|---|
| 语音识别 / 合成 | 浏览器 Web Speech API / SpeechSynthesis（Chrome/Edge） |
| 向量检索 | 自研轻量向量库（numpy + JSON，原子写防损坏） |
| 嵌入模型 | Ollama `bge-m3`（本地中文，1024 维） |
| 生成模型 | DeepSeek `deepseek-chat`（云端）/ 本地 Ollama 可选 |
| LLM 客户端 | 统一封装：超时 / 指数退避重试 / 错误分类 / token 成本统计 |
| 持久化 | MySQL 8.0（PHPStudy 托管，`personal_kb` 库，端口 3306） |
| 后端 | Python FastAPI + uvicorn |
| 监听 | `0.0.0.0:8000`（局域网可访问） |

---

## 五、MySQL 表（personal_kb 库）

Schema 以 `app/db.py` 为唯一权威，`sql/migrations/` 为版本化镜像。

| 表名 | 用途 |
|---|---|
| `app_settings` | 应用设置（API Key / 模型 / 接口地址） |
| `chat_sessions` | 对话会话（前端持 session_id 归组多轮） |
| `chat_messages` | 对话消息（含检索来源 JSON、实际检索词） |
| `highlights` | 高亮条目（学习重点 / 摘录 / 链接 / 待办） |
| `kb_docs` | 文档台账 |
| `personal_profile` | 个人敏感档案（性格 / 背景 / 想法） |
| `api_keys` | 对外 API 密钥（SHA-256 哈希存储，scope 权限控制） |

---

## 六、安全与对外接口

### 管理令牌（阶段 0 安全兜底）
- 除白名单外，所有 `/api/*` 管理接口必须携带 `X-Admin-Token` 或 `Authorization: Bearer`，令牌在 `.env` 的 `ADMIN_TOKEN`。
- **未配置令牌时 fail-closed**：管理接口一律 401。
- 公开白名单：`/api/kbs`、`/api/models`、`/api/chat`、`/api/v1/chat`、`/api/health`。

### POST /api/v1/chat（对外对话接口）
- **Bearer 鉴权对话接口**：别人凭 API Key 了解你（只读知识库）
- **限流**：按 API Key（30 次/分）+ 来源 IP（60 次/分）双维度滑动窗口，超限返回 429（防 Key 泄露后刷爆账单）

### API Key 管理
- 管理后台 🔑 标签页生成 / 禁用 / 删除；Key 只在创建时显示一次；数据库只存 SHA-256 哈希

### 运维接口（阶段 3）
- `GET /api/health`（公开）：DB/Ollama 连通、已加载向量库规模、LLM 统计摘要
- `GET /api/metrics`（需令牌）：检索耗时、LLM 延迟、token 成本估算、错误分类、会话/消息数

---

## 七、前端功能

- 🎤 **语音对话**：按住说话 → 识别 → 回答 → 朗读
- ⌨️ **文字输入**
- 🧭 **四库切换**
- 📎 **检索透明化**：展示检索词 + 来源，可点开看原文
- 🔄 **多轮上下文**：LLM 自动改写检索词 + 会话归组（session_id）
- 📄 **文档上传 / 删除**
- 📊 **健康仪表盘**
- 🔍 **知识库校验**
- 🧹 **知识库维护**
- 💾 **聊天记录按库隔离保存**：localStorage + MySQL 兜底恢复
- 🕘 **历史会话**
- ⭐ **高亮管理** / 👤 **个人档案管理** / 🔑 **API 密钥管理** / ⚙️ **设置后台**

---

## 八、目录结构

```
SelfIterate/
├── app/
│   ├── main.py         # 组合入口：FastAPI + 管理令牌中间件 + 挂载 routers/static
│   ├── config.py       # 配置：模型/四库/检索参数/MySQL/密钥（.env 优先）
│   ├── rag.py          # 向量库：切块/嵌入/混合检索(bge-m3+BM25+RRF)/原子写/标题boost
│   ├── db.py           # MySQL 持久化层（建表唯一权威）
│   ├── llm.py          # 统一 LLM 客户端（重试/退避/错误分类/token 统计）
│   ├── state.py        # 共享全局状态（多库 store 缓存/检索辅助）
│   ├── ratelimit.py    # 对外接口限流（Key+IP 滑动窗口）
│   ├── log_util.py     # 统一日志（轮转）
│   ├── persona.py      # 个人知识助手人设 + 提示词工程
│   ├── maint.py        # 知识库维护算法（去重/合并/提炼）
│   ├── validate.py     # 知识库校验
│   ├── memory.py       # 长期记忆（M3：注入 + 规则式沉淀）
│   ├── phone.py        # 手机事件反连（C1：dumpsys 解析 + 状态机 + vivo 壳清洗）
│   ├── fs_lock.py      # 跨进程文件锁（诊断/迁移并发串行化）
│   ├── jobs.py         # 边聊边做后台任务（worker 互斥 + 传话 inbox）
│   ├── agent/          # Lazaxa 智能体核心（loop/registry/approval/events/tools + skills/context）
│   └── routers/        # 按端点拆分：pages/kb/chat/highlights/history/settings/profile/keys/agent/phone/health
├── tests/              # pytest：切块/BM25/RRF/维护/API 冒烟/agent 全链路（613 个）
├── scripts/
│   ├── eval_rag.py         # 金标回归评测
│   ├── add_books.py        # 批量增量加书（不清空重建，kada 经验）
│   ├── embed_increment.py  # 只给缺向量的块补 embedding（中断可续）
│   └── ...
├── data/
│   ├── experience/  personal/  knowledge/  master/   # 知识库源文档
│   ├── vector_store_*/                                # 各库向量库（自动生成）
│   └── golden_questions.json                          # 金标评测集
├── web/
│   ├── index.html     # 前端主页面
│   └── admin.html     # 管理后台
├── sql/migrations/    # 版本化建表脚本（镜像 db.py）
├── logs/              # 运行日志
├── .env               # 密钥配置（不进 git）
├── README.md
├── start.bat          # 一键启动（检查Ollama+释放端口+启动服务，0.0.0.0:8000）
└── _archive/          # 归档区
```

> 知识库文档区与升级路线文档在项目根目录 `docs/`（本目录不再有 docs/）。
> 其中 **`docs/知识库运维与升级方法.md`** 是加资料 / 补向量 / 调参 / 排障的操作手册（融合 kada 医学库实战经验）。

---

## 九、常见问题

- **管理后台一直 401**：`ADMIN_TOKEN` 未配置或输入错误；轮换令牌后需重新输入（浏览器会记住）
- **麦克风没反应**：用 Chrome/Edge，允许麦克风权限
- **回答很慢**：默认 DeepSeek API 秒级响应；本地模型会慢
- **上传 / 对话报 500**：确认 Ollama 已启动（`ollama serve`）
- **首次提问很慢 / 报错**：向量库为空时会自动重建（需 Ollama 在线）；重建完成后再问
- **局域网访问**：`start.bat` 会自动显示局域网 IP，确保防火墙放行 8000 端口；管理接口记得带令牌
