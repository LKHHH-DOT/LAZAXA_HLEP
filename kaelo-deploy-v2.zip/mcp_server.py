#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lazaxa MCP Server - HTTP模式。
运行方式：python mcp_server.py [--port 8765]
"""

import argparse
import json
import logging
import os
import sys
import threading
import traceback

# ---------- 路径设置 ----------
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE = _SCRIPT_DIR

# 部署包内优先使用相邻 app 目录；回退到桌面 Kaelo 主项目
_APP_DIR_LOCAL = os.path.join(_WORKSPACE, "app")
_APP_DIR_DESKTOP = r"D:\Users\Hasee\Desktop\Kaelo\SelfIterate"
if os.path.isdir(_APP_DIR_LOCAL):
    _APP_DIR = _APP_DIR_LOCAL
    logger_source = "部署包内"
elif os.path.isdir(_APP_DIR_DESKTOP):
    _APP_DIR = _APP_DIR_DESKTOP
    logger_source = "桌面Kaelo"
else:
    print(f"[ERROR] 找不到 app 目录，请确认 Kaelo 项目位置", file=sys.stderr)
    raise FileNotFoundError("app directory not found")

if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

# ---------- 日志 ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("lazaxa-mcp")
logger.info(f"使用 {logger_source} app 目录: {_APP_DIR}")

# ---------- 启动时初始化 Kaelo（确保单进程内状态可用） ----------
logger.info("正在初始化 Kaelo 工具集...")
_tools_cache = []
_kaelo_registry = None

try:
    from app.agent.registry import ToolRegistry
    from app.agent.tools import register_all as register_tools

    _kaelo_registry = ToolRegistry()
    register_tools(_kaelo_registry)

    for name, tool in _kaelo_registry._tools.items():
        _tools_cache.append(
            {
                "name": name,
                "description": tool.description or tool.display_name or name,
                "inputSchema": tool.parameters or {"type": "object", "properties": {}},
            }
        )

    logger.info(f"Kaelo 工具集加载完成，共 {len(_tools_cache)} 个工具")
except Exception as e:
    logger.error(f"Kaelo 初始化失败: {e}")
    traceback.print_exc(file=sys.stderr)
    raise

# ---------- HTTP服务器 ----------
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import uvicorn

app = FastAPI(title="Lazaxa MCP Server")


@app.post("/mcp/initialize")
async def init(req: Request):
    body = await req.json()
    return {
        "protocolVersion": "2024-11-05",
        "capabilities": {"tools": {"listChanged": False}},
        "serverInfo": {"name": "lazaxa-mcp-server", "version": "1.0.0"},
    }


@app.post("/mcp/tools/list")
async def list_tools(req: Request):
    return {"tools": list(_tools_cache)}


@app.post("/mcp/tools/call")
async def call_tool(req: Request):
    body = await req.json()
    tool_name = body.get("params", {}).get("name", "")
    arguments = body.get("params", {}).get("arguments", {})

    tool = _kaelo_registry._tools.get(tool_name)
    if tool is None:
        return JSONResponse(
            status_code=400, content={"error": f"未知工具: {tool_name}"}
        )

    logger.info(f"调用工具: {tool_name}")
    try:
        result = tool.fn(**arguments)
        text = (
            result.brief if hasattr(result, "brief") and result.brief else str(result)
        )
        is_error = hasattr(result, "ok") and not result.ok
        return {
            "content": [{"type": "text", "text": text}],
            "isError": bool(is_error),
        }
    except Exception as e:
        logger.error(f"工具 {tool_name} 执行异常: {e}")
        return {
            "content": [{"type": "text", "text": f"工具执行异常: {e}"}],
            "isError": True,
        }


@app.get("/health")
async def health():
    return {"status": "ok", "tools_count": len(_tools_cache)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Lazaxa MCP Server")
    parser.add_argument("--http", action="store_true", help="HTTP模式（默认）")
    parser.add_argument("--port", type=int, default=8765, help="HTTP端口")
    args = parser.parse_args()

    logger.info(f"Lazaxa MCP Server 启动（HTTP 模式，端口 {args.port}）")
    uvicorn.run(app, host="0.0.0.0", port=args.port)
